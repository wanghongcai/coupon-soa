//package com.lenovo.m2.couponV2.dao;
//
//import org.apache.commons.logging.Log;
//import org.apache.commons.logging.LogFactory;
//import org.junit.runner.RunWith;
//import org.springframework.test.context.ContextConfiguration;
//import org.springframework.test.context.junit4.AbstractJUnit4SpringContextTests;
//import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
//
///**
// * 功能描述：测试基类
// * Created by qingyunzhang on 2015/7/3.
// */
//
//@ContextConfiguration(locations = {
//        "classpath:applicationContext-dao.xml"
//})
//@RunWith(SpringJUnit4ClassRunner.class)
//public class GeneralSpringTest extends AbstractJUnit4SpringContextTests {
//    protected Log log = LogFactory.getLog(this.getClass());
//}
