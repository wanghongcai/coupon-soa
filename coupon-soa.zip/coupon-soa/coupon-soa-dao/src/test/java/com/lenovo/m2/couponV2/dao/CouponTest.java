//package com.lenovo.m2.couponV2.dao;
//
//import com.lenovo.m2.couponcode.dao.mybatis.mapper.CouponMapper;
//import com.lenovo.m2.couponcode.dao.mybatis.model.Coupon;
//import org.junit.Test;
//import org.springframework.beans.factory.annotation.Autowired;
//
///**
// * 功能描述：优惠券DAO测试类
// * Created by qingyunzhang on 2015/7/3.
// */
//public class CouponTest extends GeneralSpringTest {
//
//    @Autowired
//    private CouponMapper couponMapper;
//
//    @Test
//    public void getCouponTest() {
//        Coupon couponcode = couponMapper.selectByPrimaryKey(1L);
//        System.out.println(couponcode + " ================="+couponcode.getScope());
//    }
//
//}
