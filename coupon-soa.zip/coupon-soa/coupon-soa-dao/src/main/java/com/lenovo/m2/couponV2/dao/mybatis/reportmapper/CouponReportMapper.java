package com.lenovo.m2.couponV2.dao.mybatis.reportmapper;

import java.util.List;
import java.util.Map;

import com.lenovo.m2.arch.framework.domain.PageModel;
import com.lenovo.m2.arch.framework.domain.PageQuery;
import com.lenovo.m2.couponV2.dao.mybatis.model.CouponReport;
import com.lenovo.m2.couponV2.dao.mybatis.model.Coupons;
import com.lenovo.m2.couponV2.dao.mybatis.model.Membercouponrels;
import org.apache.ibatis.annotations.Param;

/**
 * Created by fenglg1 on 2017/1/9.
 */
public interface CouponReportMapper {

    /**
     * 分页查询，根据条件查询优惠券的领取及使用数据
     * @param pageQuery
     * @param map
     * @return
     */
    PageModel<CouponReport> getMemberCouponByCondition(PageQuery pageQuery, Map map);

    /**
     * 根据优惠券ID查询已使用优惠券及对应的订单号
     * @param pageQuery
     * @param map
     * @return
     */
    PageModel<CouponReport> exportMemberCouponByCouponID(PageQuery pageQuery, Map map);
    PageModel<CouponReport> exportMemberCouponOrderIdByMemberCoupon(PageQuery pageQuery,@Param("list") List<Membercouponrels> list);
    
    /**
     * 
    * @Title: countCouponByCondition
    * @Description: 统计数量 （大量数据时，分页导出）
    * @param map
    * @return    设定文件
    * @throws
     */
    Integer countCouponByCondition(Map<String,Object> map);
    /**
     * 
    * @Title: getCouponListPageByCondition
    * @Description: 分页获取优惠码信息
    * @param map
    * @return    设定文件
    * @throws
     */
    List<Coupons> getCouponListPageByCondition(Map<String,Object> map);
}
