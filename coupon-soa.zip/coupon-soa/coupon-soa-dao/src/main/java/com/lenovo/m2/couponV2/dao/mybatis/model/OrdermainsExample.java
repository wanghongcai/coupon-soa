package com.lenovo.m2.couponV2.dao.mybatis.model;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class OrdermainsExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public OrdermainsExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andIdIsNull() {
            addCriterion("ID is null");
            return (Criteria) this;
        }

        public Criteria andIdIsNotNull() {
            addCriterion("ID is not null");
            return (Criteria) this;
        }

        public Criteria andIdEqualTo(String value) {
            addCriterion("ID =", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotEqualTo(String value) {
            addCriterion("ID <>", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThan(String value) {
            addCriterion("ID >", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThanOrEqualTo(String value) {
            addCriterion("ID >=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThan(String value) {
            addCriterion("ID <", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThanOrEqualTo(String value) {
            addCriterion("ID <=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLike(String value) {
            addCriterion("ID like", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotLike(String value) {
            addCriterion("ID not like", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdIn(List<String> values) {
            addCriterion("ID in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotIn(List<String> values) {
            addCriterion("ID not in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdBetween(String value1, String value2) {
            addCriterion("ID between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotBetween(String value1, String value2) {
            addCriterion("ID not between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andSourceIsNull() {
            addCriterion("Source is null");
            return (Criteria) this;
        }

        public Criteria andSourceIsNotNull() {
            addCriterion("Source is not null");
            return (Criteria) this;
        }

        public Criteria andSourceEqualTo(Integer value) {
            addCriterion("Source =", value, "source");
            return (Criteria) this;
        }

        public Criteria andSourceNotEqualTo(Integer value) {
            addCriterion("Source <>", value, "source");
            return (Criteria) this;
        }

        public Criteria andSourceGreaterThan(Integer value) {
            addCriterion("Source >", value, "source");
            return (Criteria) this;
        }

        public Criteria andSourceGreaterThanOrEqualTo(Integer value) {
            addCriterion("Source >=", value, "source");
            return (Criteria) this;
        }

        public Criteria andSourceLessThan(Integer value) {
            addCriterion("Source <", value, "source");
            return (Criteria) this;
        }

        public Criteria andSourceLessThanOrEqualTo(Integer value) {
            addCriterion("Source <=", value, "source");
            return (Criteria) this;
        }

        public Criteria andSourceIn(List<Integer> values) {
            addCriterion("Source in", values, "source");
            return (Criteria) this;
        }

        public Criteria andSourceNotIn(List<Integer> values) {
            addCriterion("Source not in", values, "source");
            return (Criteria) this;
        }

        public Criteria andSourceBetween(Integer value1, Integer value2) {
            addCriterion("Source between", value1, value2, "source");
            return (Criteria) this;
        }

        public Criteria andSourceNotBetween(Integer value1, Integer value2) {
            addCriterion("Source not between", value1, value2, "source");
            return (Criteria) this;
        }

        public Criteria andPayordernoIsNull() {
            addCriterion("PayOrderNo is null");
            return (Criteria) this;
        }

        public Criteria andPayordernoIsNotNull() {
            addCriterion("PayOrderNo is not null");
            return (Criteria) this;
        }

        public Criteria andPayordernoEqualTo(String value) {
            addCriterion("PayOrderNo =", value, "payorderno");
            return (Criteria) this;
        }

        public Criteria andPayordernoNotEqualTo(String value) {
            addCriterion("PayOrderNo <>", value, "payorderno");
            return (Criteria) this;
        }

        public Criteria andPayordernoGreaterThan(String value) {
            addCriterion("PayOrderNo >", value, "payorderno");
            return (Criteria) this;
        }

        public Criteria andPayordernoGreaterThanOrEqualTo(String value) {
            addCriterion("PayOrderNo >=", value, "payorderno");
            return (Criteria) this;
        }

        public Criteria andPayordernoLessThan(String value) {
            addCriterion("PayOrderNo <", value, "payorderno");
            return (Criteria) this;
        }

        public Criteria andPayordernoLessThanOrEqualTo(String value) {
            addCriterion("PayOrderNo <=", value, "payorderno");
            return (Criteria) this;
        }

        public Criteria andPayordernoLike(String value) {
            addCriterion("PayOrderNo like", value, "payorderno");
            return (Criteria) this;
        }

        public Criteria andPayordernoNotLike(String value) {
            addCriterion("PayOrderNo not like", value, "payorderno");
            return (Criteria) this;
        }

        public Criteria andPayordernoIn(List<String> values) {
            addCriterion("PayOrderNo in", values, "payorderno");
            return (Criteria) this;
        }

        public Criteria andPayordernoNotIn(List<String> values) {
            addCriterion("PayOrderNo not in", values, "payorderno");
            return (Criteria) this;
        }

        public Criteria andPayordernoBetween(String value1, String value2) {
            addCriterion("PayOrderNo between", value1, value2, "payorderno");
            return (Criteria) this;
        }

        public Criteria andPayordernoNotBetween(String value1, String value2) {
            addCriterion("PayOrderNo not between", value1, value2, "payorderno");
            return (Criteria) this;
        }

        public Criteria andOrdermaincodeIsNull() {
            addCriterion("OrderMainCode is null");
            return (Criteria) this;
        }

        public Criteria andOrdermaincodeIsNotNull() {
            addCriterion("OrderMainCode is not null");
            return (Criteria) this;
        }

        public Criteria andOrdermaincodeEqualTo(String value) {
            addCriterion("OrderMainCode =", value, "ordermaincode");
            return (Criteria) this;
        }

        public Criteria andOrdermaincodeNotEqualTo(String value) {
            addCriterion("OrderMainCode <>", value, "ordermaincode");
            return (Criteria) this;
        }

        public Criteria andOrdermaincodeGreaterThan(String value) {
            addCriterion("OrderMainCode >", value, "ordermaincode");
            return (Criteria) this;
        }

        public Criteria andOrdermaincodeGreaterThanOrEqualTo(String value) {
            addCriterion("OrderMainCode >=", value, "ordermaincode");
            return (Criteria) this;
        }

        public Criteria andOrdermaincodeLessThan(String value) {
            addCriterion("OrderMainCode <", value, "ordermaincode");
            return (Criteria) this;
        }

        public Criteria andOrdermaincodeLessThanOrEqualTo(String value) {
            addCriterion("OrderMainCode <=", value, "ordermaincode");
            return (Criteria) this;
        }

        public Criteria andOrdermaincodeLike(String value) {
            addCriterion("OrderMainCode like", value, "ordermaincode");
            return (Criteria) this;
        }

        public Criteria andOrdermaincodeNotLike(String value) {
            addCriterion("OrderMainCode not like", value, "ordermaincode");
            return (Criteria) this;
        }

        public Criteria andOrdermaincodeIn(List<String> values) {
            addCriterion("OrderMainCode in", values, "ordermaincode");
            return (Criteria) this;
        }

        public Criteria andOrdermaincodeNotIn(List<String> values) {
            addCriterion("OrderMainCode not in", values, "ordermaincode");
            return (Criteria) this;
        }

        public Criteria andOrdermaincodeBetween(String value1, String value2) {
            addCriterion("OrderMainCode between", value1, value2, "ordermaincode");
            return (Criteria) this;
        }

        public Criteria andOrdermaincodeNotBetween(String value1, String value2) {
            addCriterion("OrderMainCode not between", value1, value2, "ordermaincode");
            return (Criteria) this;
        }

        public Criteria andOrdercodeIsNull() {
            addCriterion("OrderCode is null");
            return (Criteria) this;
        }

        public Criteria andOrdercodeIsNotNull() {
            addCriterion("OrderCode is not null");
            return (Criteria) this;
        }

        public Criteria andOrdercodeEqualTo(String value) {
            addCriterion("OrderCode =", value, "ordercode");
            return (Criteria) this;
        }

        public Criteria andOrdercodeNotEqualTo(String value) {
            addCriterion("OrderCode <>", value, "ordercode");
            return (Criteria) this;
        }

        public Criteria andOrdercodeGreaterThan(String value) {
            addCriterion("OrderCode >", value, "ordercode");
            return (Criteria) this;
        }

        public Criteria andOrdercodeGreaterThanOrEqualTo(String value) {
            addCriterion("OrderCode >=", value, "ordercode");
            return (Criteria) this;
        }

        public Criteria andOrdercodeLessThan(String value) {
            addCriterion("OrderCode <", value, "ordercode");
            return (Criteria) this;
        }

        public Criteria andOrdercodeLessThanOrEqualTo(String value) {
            addCriterion("OrderCode <=", value, "ordercode");
            return (Criteria) this;
        }

        public Criteria andOrdercodeLike(String value) {
            addCriterion("OrderCode like", value, "ordercode");
            return (Criteria) this;
        }

        public Criteria andOrdercodeNotLike(String value) {
            addCriterion("OrderCode not like", value, "ordercode");
            return (Criteria) this;
        }

        public Criteria andOrdercodeIn(List<String> values) {
            addCriterion("OrderCode in", values, "ordercode");
            return (Criteria) this;
        }

        public Criteria andOrdercodeNotIn(List<String> values) {
            addCriterion("OrderCode not in", values, "ordercode");
            return (Criteria) this;
        }

        public Criteria andOrdercodeBetween(String value1, String value2) {
            addCriterion("OrderCode between", value1, value2, "ordercode");
            return (Criteria) this;
        }

        public Criteria andOrdercodeNotBetween(String value1, String value2) {
            addCriterion("OrderCode not between", value1, value2, "ordercode");
            return (Criteria) this;
        }

        public Criteria andVkorgIsNull() {
            addCriterion("Vkorg is null");
            return (Criteria) this;
        }

        public Criteria andVkorgIsNotNull() {
            addCriterion("Vkorg is not null");
            return (Criteria) this;
        }

        public Criteria andVkorgEqualTo(String value) {
            addCriterion("Vkorg =", value, "vkorg");
            return (Criteria) this;
        }

        public Criteria andVkorgNotEqualTo(String value) {
            addCriterion("Vkorg <>", value, "vkorg");
            return (Criteria) this;
        }

        public Criteria andVkorgGreaterThan(String value) {
            addCriterion("Vkorg >", value, "vkorg");
            return (Criteria) this;
        }

        public Criteria andVkorgGreaterThanOrEqualTo(String value) {
            addCriterion("Vkorg >=", value, "vkorg");
            return (Criteria) this;
        }

        public Criteria andVkorgLessThan(String value) {
            addCriterion("Vkorg <", value, "vkorg");
            return (Criteria) this;
        }

        public Criteria andVkorgLessThanOrEqualTo(String value) {
            addCriterion("Vkorg <=", value, "vkorg");
            return (Criteria) this;
        }

        public Criteria andVkorgLike(String value) {
            addCriterion("Vkorg like", value, "vkorg");
            return (Criteria) this;
        }

        public Criteria andVkorgNotLike(String value) {
            addCriterion("Vkorg not like", value, "vkorg");
            return (Criteria) this;
        }

        public Criteria andVkorgIn(List<String> values) {
            addCriterion("Vkorg in", values, "vkorg");
            return (Criteria) this;
        }

        public Criteria andVkorgNotIn(List<String> values) {
            addCriterion("Vkorg not in", values, "vkorg");
            return (Criteria) this;
        }

        public Criteria andVkorgBetween(String value1, String value2) {
            addCriterion("Vkorg between", value1, value2, "vkorg");
            return (Criteria) this;
        }

        public Criteria andVkorgNotBetween(String value1, String value2) {
            addCriterion("Vkorg not between", value1, value2, "vkorg");
            return (Criteria) this;
        }

        public Criteria andSaleschannelIsNull() {
            addCriterion("SalesChannel is null");
            return (Criteria) this;
        }

        public Criteria andSaleschannelIsNotNull() {
            addCriterion("SalesChannel is not null");
            return (Criteria) this;
        }

        public Criteria andSaleschannelEqualTo(String value) {
            addCriterion("SalesChannel =", value, "saleschannel");
            return (Criteria) this;
        }

        public Criteria andSaleschannelNotEqualTo(String value) {
            addCriterion("SalesChannel <>", value, "saleschannel");
            return (Criteria) this;
        }

        public Criteria andSaleschannelGreaterThan(String value) {
            addCriterion("SalesChannel >", value, "saleschannel");
            return (Criteria) this;
        }

        public Criteria andSaleschannelGreaterThanOrEqualTo(String value) {
            addCriterion("SalesChannel >=", value, "saleschannel");
            return (Criteria) this;
        }

        public Criteria andSaleschannelLessThan(String value) {
            addCriterion("SalesChannel <", value, "saleschannel");
            return (Criteria) this;
        }

        public Criteria andSaleschannelLessThanOrEqualTo(String value) {
            addCriterion("SalesChannel <=", value, "saleschannel");
            return (Criteria) this;
        }

        public Criteria andSaleschannelLike(String value) {
            addCriterion("SalesChannel like", value, "saleschannel");
            return (Criteria) this;
        }

        public Criteria andSaleschannelNotLike(String value) {
            addCriterion("SalesChannel not like", value, "saleschannel");
            return (Criteria) this;
        }

        public Criteria andSaleschannelIn(List<String> values) {
            addCriterion("SalesChannel in", values, "saleschannel");
            return (Criteria) this;
        }

        public Criteria andSaleschannelNotIn(List<String> values) {
            addCriterion("SalesChannel not in", values, "saleschannel");
            return (Criteria) this;
        }

        public Criteria andSaleschannelBetween(String value1, String value2) {
            addCriterion("SalesChannel between", value1, value2, "saleschannel");
            return (Criteria) this;
        }

        public Criteria andSaleschannelNotBetween(String value1, String value2) {
            addCriterion("SalesChannel not between", value1, value2, "saleschannel");
            return (Criteria) this;
        }

        public Criteria andMemberidIsNull() {
            addCriterion("MemberID is null");
            return (Criteria) this;
        }

        public Criteria andMemberidIsNotNull() {
            addCriterion("MemberID is not null");
            return (Criteria) this;
        }

        public Criteria andMemberidEqualTo(String value) {
            addCriterion("MemberID =", value, "memberid");
            return (Criteria) this;
        }

        public Criteria andMemberidNotEqualTo(String value) {
            addCriterion("MemberID <>", value, "memberid");
            return (Criteria) this;
        }

        public Criteria andMemberidGreaterThan(String value) {
            addCriterion("MemberID >", value, "memberid");
            return (Criteria) this;
        }

        public Criteria andMemberidGreaterThanOrEqualTo(String value) {
            addCriterion("MemberID >=", value, "memberid");
            return (Criteria) this;
        }

        public Criteria andMemberidLessThan(String value) {
            addCriterion("MemberID <", value, "memberid");
            return (Criteria) this;
        }

        public Criteria andMemberidLessThanOrEqualTo(String value) {
            addCriterion("MemberID <=", value, "memberid");
            return (Criteria) this;
        }

        public Criteria andMemberidLike(String value) {
            addCriterion("MemberID like", value, "memberid");
            return (Criteria) this;
        }

        public Criteria andMemberidNotLike(String value) {
            addCriterion("MemberID not like", value, "memberid");
            return (Criteria) this;
        }

        public Criteria andMemberidIn(List<String> values) {
            addCriterion("MemberID in", values, "memberid");
            return (Criteria) this;
        }

        public Criteria andMemberidNotIn(List<String> values) {
            addCriterion("MemberID not in", values, "memberid");
            return (Criteria) this;
        }

        public Criteria andMemberidBetween(String value1, String value2) {
            addCriterion("MemberID between", value1, value2, "memberid");
            return (Criteria) this;
        }

        public Criteria andMemberidNotBetween(String value1, String value2) {
            addCriterion("MemberID not between", value1, value2, "memberid");
            return (Criteria) this;
        }

        public Criteria andMembercodeIsNull() {
            addCriterion("MemberCode is null");
            return (Criteria) this;
        }

        public Criteria andMembercodeIsNotNull() {
            addCriterion("MemberCode is not null");
            return (Criteria) this;
        }

        public Criteria andMembercodeEqualTo(String value) {
            addCriterion("MemberCode =", value, "membercode");
            return (Criteria) this;
        }

        public Criteria andMembercodeNotEqualTo(String value) {
            addCriterion("MemberCode <>", value, "membercode");
            return (Criteria) this;
        }

        public Criteria andMembercodeGreaterThan(String value) {
            addCriterion("MemberCode >", value, "membercode");
            return (Criteria) this;
        }

        public Criteria andMembercodeGreaterThanOrEqualTo(String value) {
            addCriterion("MemberCode >=", value, "membercode");
            return (Criteria) this;
        }

        public Criteria andMembercodeLessThan(String value) {
            addCriterion("MemberCode <", value, "membercode");
            return (Criteria) this;
        }

        public Criteria andMembercodeLessThanOrEqualTo(String value) {
            addCriterion("MemberCode <=", value, "membercode");
            return (Criteria) this;
        }

        public Criteria andMembercodeLike(String value) {
            addCriterion("MemberCode like", value, "membercode");
            return (Criteria) this;
        }

        public Criteria andMembercodeNotLike(String value) {
            addCriterion("MemberCode not like", value, "membercode");
            return (Criteria) this;
        }

        public Criteria andMembercodeIn(List<String> values) {
            addCriterion("MemberCode in", values, "membercode");
            return (Criteria) this;
        }

        public Criteria andMembercodeNotIn(List<String> values) {
            addCriterion("MemberCode not in", values, "membercode");
            return (Criteria) this;
        }

        public Criteria andMembercodeBetween(String value1, String value2) {
            addCriterion("MemberCode between", value1, value2, "membercode");
            return (Criteria) this;
        }

        public Criteria andMembercodeNotBetween(String value1, String value2) {
            addCriterion("MemberCode not between", value1, value2, "membercode");
            return (Criteria) this;
        }

        public Criteria andC1lenovoidIsNull() {
            addCriterion("C1LenovoID is null");
            return (Criteria) this;
        }

        public Criteria andC1lenovoidIsNotNull() {
            addCriterion("C1LenovoID is not null");
            return (Criteria) this;
        }

        public Criteria andC1lenovoidEqualTo(String value) {
            addCriterion("C1LenovoID =", value, "c1lenovoid");
            return (Criteria) this;
        }

        public Criteria andC1lenovoidNotEqualTo(String value) {
            addCriterion("C1LenovoID <>", value, "c1lenovoid");
            return (Criteria) this;
        }

        public Criteria andC1lenovoidGreaterThan(String value) {
            addCriterion("C1LenovoID >", value, "c1lenovoid");
            return (Criteria) this;
        }

        public Criteria andC1lenovoidGreaterThanOrEqualTo(String value) {
            addCriterion("C1LenovoID >=", value, "c1lenovoid");
            return (Criteria) this;
        }

        public Criteria andC1lenovoidLessThan(String value) {
            addCriterion("C1LenovoID <", value, "c1lenovoid");
            return (Criteria) this;
        }

        public Criteria andC1lenovoidLessThanOrEqualTo(String value) {
            addCriterion("C1LenovoID <=", value, "c1lenovoid");
            return (Criteria) this;
        }

        public Criteria andC1lenovoidLike(String value) {
            addCriterion("C1LenovoID like", value, "c1lenovoid");
            return (Criteria) this;
        }

        public Criteria andC1lenovoidNotLike(String value) {
            addCriterion("C1LenovoID not like", value, "c1lenovoid");
            return (Criteria) this;
        }

        public Criteria andC1lenovoidIn(List<String> values) {
            addCriterion("C1LenovoID in", values, "c1lenovoid");
            return (Criteria) this;
        }

        public Criteria andC1lenovoidNotIn(List<String> values) {
            addCriterion("C1LenovoID not in", values, "c1lenovoid");
            return (Criteria) this;
        }

        public Criteria andC1lenovoidBetween(String value1, String value2) {
            addCriterion("C1LenovoID between", value1, value2, "c1lenovoid");
            return (Criteria) this;
        }

        public Criteria andC1lenovoidNotBetween(String value1, String value2) {
            addCriterion("C1LenovoID not between", value1, value2, "c1lenovoid");
            return (Criteria) this;
        }

        public Criteria andTypeidIsNull() {
            addCriterion("TypeID is null");
            return (Criteria) this;
        }

        public Criteria andTypeidIsNotNull() {
            addCriterion("TypeID is not null");
            return (Criteria) this;
        }

        public Criteria andTypeidEqualTo(String value) {
            addCriterion("TypeID =", value, "typeid");
            return (Criteria) this;
        }

        public Criteria andTypeidNotEqualTo(String value) {
            addCriterion("TypeID <>", value, "typeid");
            return (Criteria) this;
        }

        public Criteria andTypeidGreaterThan(String value) {
            addCriterion("TypeID >", value, "typeid");
            return (Criteria) this;
        }

        public Criteria andTypeidGreaterThanOrEqualTo(String value) {
            addCriterion("TypeID >=", value, "typeid");
            return (Criteria) this;
        }

        public Criteria andTypeidLessThan(String value) {
            addCriterion("TypeID <", value, "typeid");
            return (Criteria) this;
        }

        public Criteria andTypeidLessThanOrEqualTo(String value) {
            addCriterion("TypeID <=", value, "typeid");
            return (Criteria) this;
        }

        public Criteria andTypeidLike(String value) {
            addCriterion("TypeID like", value, "typeid");
            return (Criteria) this;
        }

        public Criteria andTypeidNotLike(String value) {
            addCriterion("TypeID not like", value, "typeid");
            return (Criteria) this;
        }

        public Criteria andTypeidIn(List<String> values) {
            addCriterion("TypeID in", values, "typeid");
            return (Criteria) this;
        }

        public Criteria andTypeidNotIn(List<String> values) {
            addCriterion("TypeID not in", values, "typeid");
            return (Criteria) this;
        }

        public Criteria andTypeidBetween(String value1, String value2) {
            addCriterion("TypeID between", value1, value2, "typeid");
            return (Criteria) this;
        }

        public Criteria andTypeidNotBetween(String value1, String value2) {
            addCriterion("TypeID not between", value1, value2, "typeid");
            return (Criteria) this;
        }

        public Criteria andOrderaddtypeIsNull() {
            addCriterion("OrderAddType is null");
            return (Criteria) this;
        }

        public Criteria andOrderaddtypeIsNotNull() {
            addCriterion("OrderAddType is not null");
            return (Criteria) this;
        }

        public Criteria andOrderaddtypeEqualTo(Integer value) {
            addCriterion("OrderAddType =", value, "orderaddtype");
            return (Criteria) this;
        }

        public Criteria andOrderaddtypeNotEqualTo(Integer value) {
            addCriterion("OrderAddType <>", value, "orderaddtype");
            return (Criteria) this;
        }

        public Criteria andOrderaddtypeGreaterThan(Integer value) {
            addCriterion("OrderAddType >", value, "orderaddtype");
            return (Criteria) this;
        }

        public Criteria andOrderaddtypeGreaterThanOrEqualTo(Integer value) {
            addCriterion("OrderAddType >=", value, "orderaddtype");
            return (Criteria) this;
        }

        public Criteria andOrderaddtypeLessThan(Integer value) {
            addCriterion("OrderAddType <", value, "orderaddtype");
            return (Criteria) this;
        }

        public Criteria andOrderaddtypeLessThanOrEqualTo(Integer value) {
            addCriterion("OrderAddType <=", value, "orderaddtype");
            return (Criteria) this;
        }

        public Criteria andOrderaddtypeIn(List<Integer> values) {
            addCriterion("OrderAddType in", values, "orderaddtype");
            return (Criteria) this;
        }

        public Criteria andOrderaddtypeNotIn(List<Integer> values) {
            addCriterion("OrderAddType not in", values, "orderaddtype");
            return (Criteria) this;
        }

        public Criteria andOrderaddtypeBetween(Integer value1, Integer value2) {
            addCriterion("OrderAddType between", value1, value2, "orderaddtype");
            return (Criteria) this;
        }

        public Criteria andOrderaddtypeNotBetween(Integer value1, Integer value2) {
            addCriterion("OrderAddType not between", value1, value2, "orderaddtype");
            return (Criteria) this;
        }

        public Criteria andSalesordertypeIsNull() {
            addCriterion("SalesOrderType is null");
            return (Criteria) this;
        }

        public Criteria andSalesordertypeIsNotNull() {
            addCriterion("SalesOrderType is not null");
            return (Criteria) this;
        }

        public Criteria andSalesordertypeEqualTo(Integer value) {
            addCriterion("SalesOrderType =", value, "salesordertype");
            return (Criteria) this;
        }

        public Criteria andSalesordertypeNotEqualTo(Integer value) {
            addCriterion("SalesOrderType <>", value, "salesordertype");
            return (Criteria) this;
        }

        public Criteria andSalesordertypeGreaterThan(Integer value) {
            addCriterion("SalesOrderType >", value, "salesordertype");
            return (Criteria) this;
        }

        public Criteria andSalesordertypeGreaterThanOrEqualTo(Integer value) {
            addCriterion("SalesOrderType >=", value, "salesordertype");
            return (Criteria) this;
        }

        public Criteria andSalesordertypeLessThan(Integer value) {
            addCriterion("SalesOrderType <", value, "salesordertype");
            return (Criteria) this;
        }

        public Criteria andSalesordertypeLessThanOrEqualTo(Integer value) {
            addCriterion("SalesOrderType <=", value, "salesordertype");
            return (Criteria) this;
        }

        public Criteria andSalesordertypeIn(List<Integer> values) {
            addCriterion("SalesOrderType in", values, "salesordertype");
            return (Criteria) this;
        }

        public Criteria andSalesordertypeNotIn(List<Integer> values) {
            addCriterion("SalesOrderType not in", values, "salesordertype");
            return (Criteria) this;
        }

        public Criteria andSalesordertypeBetween(Integer value1, Integer value2) {
            addCriterion("SalesOrderType between", value1, value2, "salesordertype");
            return (Criteria) this;
        }

        public Criteria andSalesordertypeNotBetween(Integer value1, Integer value2) {
            addCriterion("SalesOrderType not between", value1, value2, "salesordertype");
            return (Criteria) this;
        }

        public Criteria andCostitemIsNull() {
            addCriterion("CostItem is null");
            return (Criteria) this;
        }

        public Criteria andCostitemIsNotNull() {
            addCriterion("CostItem is not null");
            return (Criteria) this;
        }

        public Criteria andCostitemEqualTo(BigDecimal value) {
            addCriterion("CostItem =", value, "costitem");
            return (Criteria) this;
        }

        public Criteria andCostitemNotEqualTo(BigDecimal value) {
            addCriterion("CostItem <>", value, "costitem");
            return (Criteria) this;
        }

        public Criteria andCostitemGreaterThan(BigDecimal value) {
            addCriterion("CostItem >", value, "costitem");
            return (Criteria) this;
        }

        public Criteria andCostitemGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("CostItem >=", value, "costitem");
            return (Criteria) this;
        }

        public Criteria andCostitemLessThan(BigDecimal value) {
            addCriterion("CostItem <", value, "costitem");
            return (Criteria) this;
        }

        public Criteria andCostitemLessThanOrEqualTo(BigDecimal value) {
            addCriterion("CostItem <=", value, "costitem");
            return (Criteria) this;
        }

        public Criteria andCostitemIn(List<BigDecimal> values) {
            addCriterion("CostItem in", values, "costitem");
            return (Criteria) this;
        }

        public Criteria andCostitemNotIn(List<BigDecimal> values) {
            addCriterion("CostItem not in", values, "costitem");
            return (Criteria) this;
        }

        public Criteria andCostitemBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("CostItem between", value1, value2, "costitem");
            return (Criteria) this;
        }

        public Criteria andCostitemNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("CostItem not between", value1, value2, "costitem");
            return (Criteria) this;
        }

        public Criteria andAmountmoneyIsNull() {
            addCriterion("AmountMoney is null");
            return (Criteria) this;
        }

        public Criteria andAmountmoneyIsNotNull() {
            addCriterion("AmountMoney is not null");
            return (Criteria) this;
        }

        public Criteria andAmountmoneyEqualTo(BigDecimal value) {
            addCriterion("AmountMoney =", value, "amountmoney");
            return (Criteria) this;
        }

        public Criteria andAmountmoneyNotEqualTo(BigDecimal value) {
            addCriterion("AmountMoney <>", value, "amountmoney");
            return (Criteria) this;
        }

        public Criteria andAmountmoneyGreaterThan(BigDecimal value) {
            addCriterion("AmountMoney >", value, "amountmoney");
            return (Criteria) this;
        }

        public Criteria andAmountmoneyGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("AmountMoney >=", value, "amountmoney");
            return (Criteria) this;
        }

        public Criteria andAmountmoneyLessThan(BigDecimal value) {
            addCriterion("AmountMoney <", value, "amountmoney");
            return (Criteria) this;
        }

        public Criteria andAmountmoneyLessThanOrEqualTo(BigDecimal value) {
            addCriterion("AmountMoney <=", value, "amountmoney");
            return (Criteria) this;
        }

        public Criteria andAmountmoneyIn(List<BigDecimal> values) {
            addCriterion("AmountMoney in", values, "amountmoney");
            return (Criteria) this;
        }

        public Criteria andAmountmoneyNotIn(List<BigDecimal> values) {
            addCriterion("AmountMoney not in", values, "amountmoney");
            return (Criteria) this;
        }

        public Criteria andAmountmoneyBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("AmountMoney between", value1, value2, "amountmoney");
            return (Criteria) this;
        }

        public Criteria andAmountmoneyNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("AmountMoney not between", value1, value2, "amountmoney");
            return (Criteria) this;
        }

        public Criteria andGiveawaycostIsNull() {
            addCriterion("GiveawayCost is null");
            return (Criteria) this;
        }

        public Criteria andGiveawaycostIsNotNull() {
            addCriterion("GiveawayCost is not null");
            return (Criteria) this;
        }

        public Criteria andGiveawaycostEqualTo(BigDecimal value) {
            addCriterion("GiveawayCost =", value, "giveawaycost");
            return (Criteria) this;
        }

        public Criteria andGiveawaycostNotEqualTo(BigDecimal value) {
            addCriterion("GiveawayCost <>", value, "giveawaycost");
            return (Criteria) this;
        }

        public Criteria andGiveawaycostGreaterThan(BigDecimal value) {
            addCriterion("GiveawayCost >", value, "giveawaycost");
            return (Criteria) this;
        }

        public Criteria andGiveawaycostGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("GiveawayCost >=", value, "giveawaycost");
            return (Criteria) this;
        }

        public Criteria andGiveawaycostLessThan(BigDecimal value) {
            addCriterion("GiveawayCost <", value, "giveawaycost");
            return (Criteria) this;
        }

        public Criteria andGiveawaycostLessThanOrEqualTo(BigDecimal value) {
            addCriterion("GiveawayCost <=", value, "giveawaycost");
            return (Criteria) this;
        }

        public Criteria andGiveawaycostIn(List<BigDecimal> values) {
            addCriterion("GiveawayCost in", values, "giveawaycost");
            return (Criteria) this;
        }

        public Criteria andGiveawaycostNotIn(List<BigDecimal> values) {
            addCriterion("GiveawayCost not in", values, "giveawaycost");
            return (Criteria) this;
        }

        public Criteria andGiveawaycostBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("GiveawayCost between", value1, value2, "giveawaycost");
            return (Criteria) this;
        }

        public Criteria andGiveawaycostNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("GiveawayCost not between", value1, value2, "giveawaycost");
            return (Criteria) this;
        }

        public Criteria andGiveawaytotalIsNull() {
            addCriterion("GiveawayTotal is null");
            return (Criteria) this;
        }

        public Criteria andGiveawaytotalIsNotNull() {
            addCriterion("GiveawayTotal is not null");
            return (Criteria) this;
        }

        public Criteria andGiveawaytotalEqualTo(BigDecimal value) {
            addCriterion("GiveawayTotal =", value, "giveawaytotal");
            return (Criteria) this;
        }

        public Criteria andGiveawaytotalNotEqualTo(BigDecimal value) {
            addCriterion("GiveawayTotal <>", value, "giveawaytotal");
            return (Criteria) this;
        }

        public Criteria andGiveawaytotalGreaterThan(BigDecimal value) {
            addCriterion("GiveawayTotal >", value, "giveawaytotal");
            return (Criteria) this;
        }

        public Criteria andGiveawaytotalGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("GiveawayTotal >=", value, "giveawaytotal");
            return (Criteria) this;
        }

        public Criteria andGiveawaytotalLessThan(BigDecimal value) {
            addCriterion("GiveawayTotal <", value, "giveawaytotal");
            return (Criteria) this;
        }

        public Criteria andGiveawaytotalLessThanOrEqualTo(BigDecimal value) {
            addCriterion("GiveawayTotal <=", value, "giveawaytotal");
            return (Criteria) this;
        }

        public Criteria andGiveawaytotalIn(List<BigDecimal> values) {
            addCriterion("GiveawayTotal in", values, "giveawaytotal");
            return (Criteria) this;
        }

        public Criteria andGiveawaytotalNotIn(List<BigDecimal> values) {
            addCriterion("GiveawayTotal not in", values, "giveawaytotal");
            return (Criteria) this;
        }

        public Criteria andGiveawaytotalBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("GiveawayTotal between", value1, value2, "giveawaytotal");
            return (Criteria) this;
        }

        public Criteria andGiveawaytotalNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("GiveawayTotal not between", value1, value2, "giveawaytotal");
            return (Criteria) this;
        }

        public Criteria andVouchertotalamountIsNull() {
            addCriterion("VoucherTotalAmount is null");
            return (Criteria) this;
        }

        public Criteria andVouchertotalamountIsNotNull() {
            addCriterion("VoucherTotalAmount is not null");
            return (Criteria) this;
        }

        public Criteria andVouchertotalamountEqualTo(BigDecimal value) {
            addCriterion("VoucherTotalAmount =", value, "vouchertotalamount");
            return (Criteria) this;
        }

        public Criteria andVouchertotalamountNotEqualTo(BigDecimal value) {
            addCriterion("VoucherTotalAmount <>", value, "vouchertotalamount");
            return (Criteria) this;
        }

        public Criteria andVouchertotalamountGreaterThan(BigDecimal value) {
            addCriterion("VoucherTotalAmount >", value, "vouchertotalamount");
            return (Criteria) this;
        }

        public Criteria andVouchertotalamountGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("VoucherTotalAmount >=", value, "vouchertotalamount");
            return (Criteria) this;
        }

        public Criteria andVouchertotalamountLessThan(BigDecimal value) {
            addCriterion("VoucherTotalAmount <", value, "vouchertotalamount");
            return (Criteria) this;
        }

        public Criteria andVouchertotalamountLessThanOrEqualTo(BigDecimal value) {
            addCriterion("VoucherTotalAmount <=", value, "vouchertotalamount");
            return (Criteria) this;
        }

        public Criteria andVouchertotalamountIn(List<BigDecimal> values) {
            addCriterion("VoucherTotalAmount in", values, "vouchertotalamount");
            return (Criteria) this;
        }

        public Criteria andVouchertotalamountNotIn(List<BigDecimal> values) {
            addCriterion("VoucherTotalAmount not in", values, "vouchertotalamount");
            return (Criteria) this;
        }

        public Criteria andVouchertotalamountBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("VoucherTotalAmount between", value1, value2, "vouchertotalamount");
            return (Criteria) this;
        }

        public Criteria andVouchertotalamountNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("VoucherTotalAmount not between", value1, value2, "vouchertotalamount");
            return (Criteria) this;
        }

        public Criteria andGiftcardtotalamountIsNull() {
            addCriterion("GiftCardTotalAmount is null");
            return (Criteria) this;
        }

        public Criteria andGiftcardtotalamountIsNotNull() {
            addCriterion("GiftCardTotalAmount is not null");
            return (Criteria) this;
        }

        public Criteria andGiftcardtotalamountEqualTo(BigDecimal value) {
            addCriterion("GiftCardTotalAmount =", value, "giftcardtotalamount");
            return (Criteria) this;
        }

        public Criteria andGiftcardtotalamountNotEqualTo(BigDecimal value) {
            addCriterion("GiftCardTotalAmount <>", value, "giftcardtotalamount");
            return (Criteria) this;
        }

        public Criteria andGiftcardtotalamountGreaterThan(BigDecimal value) {
            addCriterion("GiftCardTotalAmount >", value, "giftcardtotalamount");
            return (Criteria) this;
        }

        public Criteria andGiftcardtotalamountGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("GiftCardTotalAmount >=", value, "giftcardtotalamount");
            return (Criteria) this;
        }

        public Criteria andGiftcardtotalamountLessThan(BigDecimal value) {
            addCriterion("GiftCardTotalAmount <", value, "giftcardtotalamount");
            return (Criteria) this;
        }

        public Criteria andGiftcardtotalamountLessThanOrEqualTo(BigDecimal value) {
            addCriterion("GiftCardTotalAmount <=", value, "giftcardtotalamount");
            return (Criteria) this;
        }

        public Criteria andGiftcardtotalamountIn(List<BigDecimal> values) {
            addCriterion("GiftCardTotalAmount in", values, "giftcardtotalamount");
            return (Criteria) this;
        }

        public Criteria andGiftcardtotalamountNotIn(List<BigDecimal> values) {
            addCriterion("GiftCardTotalAmount not in", values, "giftcardtotalamount");
            return (Criteria) this;
        }

        public Criteria andGiftcardtotalamountBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("GiftCardTotalAmount between", value1, value2, "giftcardtotalamount");
            return (Criteria) this;
        }

        public Criteria andGiftcardtotalamountNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("GiftCardTotalAmount not between", value1, value2, "giftcardtotalamount");
            return (Criteria) this;
        }

        public Criteria andCredittotalIsNull() {
            addCriterion("CreditTotal is null");
            return (Criteria) this;
        }

        public Criteria andCredittotalIsNotNull() {
            addCriterion("CreditTotal is not null");
            return (Criteria) this;
        }

        public Criteria andCredittotalEqualTo(Integer value) {
            addCriterion("CreditTotal =", value, "credittotal");
            return (Criteria) this;
        }

        public Criteria andCredittotalNotEqualTo(Integer value) {
            addCriterion("CreditTotal <>", value, "credittotal");
            return (Criteria) this;
        }

        public Criteria andCredittotalGreaterThan(Integer value) {
            addCriterion("CreditTotal >", value, "credittotal");
            return (Criteria) this;
        }

        public Criteria andCredittotalGreaterThanOrEqualTo(Integer value) {
            addCriterion("CreditTotal >=", value, "credittotal");
            return (Criteria) this;
        }

        public Criteria andCredittotalLessThan(Integer value) {
            addCriterion("CreditTotal <", value, "credittotal");
            return (Criteria) this;
        }

        public Criteria andCredittotalLessThanOrEqualTo(Integer value) {
            addCriterion("CreditTotal <=", value, "credittotal");
            return (Criteria) this;
        }

        public Criteria andCredittotalIn(List<Integer> values) {
            addCriterion("CreditTotal in", values, "credittotal");
            return (Criteria) this;
        }

        public Criteria andCredittotalNotIn(List<Integer> values) {
            addCriterion("CreditTotal not in", values, "credittotal");
            return (Criteria) this;
        }

        public Criteria andCredittotalBetween(Integer value1, Integer value2) {
            addCriterion("CreditTotal between", value1, value2, "credittotal");
            return (Criteria) this;
        }

        public Criteria andCredittotalNotBetween(Integer value1, Integer value2) {
            addCriterion("CreditTotal not between", value1, value2, "credittotal");
            return (Criteria) this;
        }

        public Criteria andPaystatusIsNull() {
            addCriterion("PayStatus is null");
            return (Criteria) this;
        }

        public Criteria andPaystatusIsNotNull() {
            addCriterion("PayStatus is not null");
            return (Criteria) this;
        }

        public Criteria andPaystatusEqualTo(Integer value) {
            addCriterion("PayStatus =", value, "paystatus");
            return (Criteria) this;
        }

        public Criteria andPaystatusNotEqualTo(Integer value) {
            addCriterion("PayStatus <>", value, "paystatus");
            return (Criteria) this;
        }

        public Criteria andPaystatusGreaterThan(Integer value) {
            addCriterion("PayStatus >", value, "paystatus");
            return (Criteria) this;
        }

        public Criteria andPaystatusGreaterThanOrEqualTo(Integer value) {
            addCriterion("PayStatus >=", value, "paystatus");
            return (Criteria) this;
        }

        public Criteria andPaystatusLessThan(Integer value) {
            addCriterion("PayStatus <", value, "paystatus");
            return (Criteria) this;
        }

        public Criteria andPaystatusLessThanOrEqualTo(Integer value) {
            addCriterion("PayStatus <=", value, "paystatus");
            return (Criteria) this;
        }

        public Criteria andPaystatusIn(List<Integer> values) {
            addCriterion("PayStatus in", values, "paystatus");
            return (Criteria) this;
        }

        public Criteria andPaystatusNotIn(List<Integer> values) {
            addCriterion("PayStatus not in", values, "paystatus");
            return (Criteria) this;
        }

        public Criteria andPaystatusBetween(Integer value1, Integer value2) {
            addCriterion("PayStatus between", value1, value2, "paystatus");
            return (Criteria) this;
        }

        public Criteria andPaystatusNotBetween(Integer value1, Integer value2) {
            addCriterion("PayStatus not between", value1, value2, "paystatus");
            return (Criteria) this;
        }

        public Criteria andPaydatetimeIsNull() {
            addCriterion("PayDatetime is null");
            return (Criteria) this;
        }

        public Criteria andPaydatetimeIsNotNull() {
            addCriterion("PayDatetime is not null");
            return (Criteria) this;
        }

        public Criteria andPaydatetimeEqualTo(Date value) {
            addCriterion("PayDatetime =", value, "paydatetime");
            return (Criteria) this;
        }

        public Criteria andPaydatetimeNotEqualTo(Date value) {
            addCriterion("PayDatetime <>", value, "paydatetime");
            return (Criteria) this;
        }

        public Criteria andPaydatetimeGreaterThan(Date value) {
            addCriterion("PayDatetime >", value, "paydatetime");
            return (Criteria) this;
        }

        public Criteria andPaydatetimeGreaterThanOrEqualTo(Date value) {
            addCriterion("PayDatetime >=", value, "paydatetime");
            return (Criteria) this;
        }

        public Criteria andPaydatetimeLessThan(Date value) {
            addCriterion("PayDatetime <", value, "paydatetime");
            return (Criteria) this;
        }

        public Criteria andPaydatetimeLessThanOrEqualTo(Date value) {
            addCriterion("PayDatetime <=", value, "paydatetime");
            return (Criteria) this;
        }

        public Criteria andPaydatetimeIn(List<Date> values) {
            addCriterion("PayDatetime in", values, "paydatetime");
            return (Criteria) this;
        }

        public Criteria andPaydatetimeNotIn(List<Date> values) {
            addCriterion("PayDatetime not in", values, "paydatetime");
            return (Criteria) this;
        }

        public Criteria andPaydatetimeBetween(Date value1, Date value2) {
            addCriterion("PayDatetime between", value1, value2, "paydatetime");
            return (Criteria) this;
        }

        public Criteria andPaydatetimeNotBetween(Date value1, Date value2) {
            addCriterion("PayDatetime not between", value1, value2, "paydatetime");
            return (Criteria) this;
        }

        public Criteria andExpectdateIsNull() {
            addCriterion("ExpectDate is null");
            return (Criteria) this;
        }

        public Criteria andExpectdateIsNotNull() {
            addCriterion("ExpectDate is not null");
            return (Criteria) this;
        }

        public Criteria andExpectdateEqualTo(Date value) {
            addCriterion("ExpectDate =", value, "expectdate");
            return (Criteria) this;
        }

        public Criteria andExpectdateNotEqualTo(Date value) {
            addCriterion("ExpectDate <>", value, "expectdate");
            return (Criteria) this;
        }

        public Criteria andExpectdateGreaterThan(Date value) {
            addCriterion("ExpectDate >", value, "expectdate");
            return (Criteria) this;
        }

        public Criteria andExpectdateGreaterThanOrEqualTo(Date value) {
            addCriterion("ExpectDate >=", value, "expectdate");
            return (Criteria) this;
        }

        public Criteria andExpectdateLessThan(Date value) {
            addCriterion("ExpectDate <", value, "expectdate");
            return (Criteria) this;
        }

        public Criteria andExpectdateLessThanOrEqualTo(Date value) {
            addCriterion("ExpectDate <=", value, "expectdate");
            return (Criteria) this;
        }

        public Criteria andExpectdateIn(List<Date> values) {
            addCriterion("ExpectDate in", values, "expectdate");
            return (Criteria) this;
        }

        public Criteria andExpectdateNotIn(List<Date> values) {
            addCriterion("ExpectDate not in", values, "expectdate");
            return (Criteria) this;
        }

        public Criteria andExpectdateBetween(Date value1, Date value2) {
            addCriterion("ExpectDate between", value1, value2, "expectdate");
            return (Criteria) this;
        }

        public Criteria andExpectdateNotBetween(Date value1, Date value2) {
            addCriterion("ExpectDate not between", value1, value2, "expectdate");
            return (Criteria) this;
        }

        public Criteria andAugruIsNull() {
            addCriterion("Augru is null");
            return (Criteria) this;
        }

        public Criteria andAugruIsNotNull() {
            addCriterion("Augru is not null");
            return (Criteria) this;
        }

        public Criteria andAugruEqualTo(String value) {
            addCriterion("Augru =", value, "augru");
            return (Criteria) this;
        }

        public Criteria andAugruNotEqualTo(String value) {
            addCriterion("Augru <>", value, "augru");
            return (Criteria) this;
        }

        public Criteria andAugruGreaterThan(String value) {
            addCriterion("Augru >", value, "augru");
            return (Criteria) this;
        }

        public Criteria andAugruGreaterThanOrEqualTo(String value) {
            addCriterion("Augru >=", value, "augru");
            return (Criteria) this;
        }

        public Criteria andAugruLessThan(String value) {
            addCriterion("Augru <", value, "augru");
            return (Criteria) this;
        }

        public Criteria andAugruLessThanOrEqualTo(String value) {
            addCriterion("Augru <=", value, "augru");
            return (Criteria) this;
        }

        public Criteria andAugruLike(String value) {
            addCriterion("Augru like", value, "augru");
            return (Criteria) this;
        }

        public Criteria andAugruNotLike(String value) {
            addCriterion("Augru not like", value, "augru");
            return (Criteria) this;
        }

        public Criteria andAugruIn(List<String> values) {
            addCriterion("Augru in", values, "augru");
            return (Criteria) this;
        }

        public Criteria andAugruNotIn(List<String> values) {
            addCriterion("Augru not in", values, "augru");
            return (Criteria) this;
        }

        public Criteria andAugruBetween(String value1, String value2) {
            addCriterion("Augru between", value1, value2, "augru");
            return (Criteria) this;
        }

        public Criteria andAugruNotBetween(String value1, String value2) {
            addCriterion("Augru not between", value1, value2, "augru");
            return (Criteria) this;
        }

        public Criteria andPaymentdayIsNull() {
            addCriterion("PaymentDay is null");
            return (Criteria) this;
        }

        public Criteria andPaymentdayIsNotNull() {
            addCriterion("PaymentDay is not null");
            return (Criteria) this;
        }

        public Criteria andPaymentdayEqualTo(String value) {
            addCriterion("PaymentDay =", value, "paymentday");
            return (Criteria) this;
        }

        public Criteria andPaymentdayNotEqualTo(String value) {
            addCriterion("PaymentDay <>", value, "paymentday");
            return (Criteria) this;
        }

        public Criteria andPaymentdayGreaterThan(String value) {
            addCriterion("PaymentDay >", value, "paymentday");
            return (Criteria) this;
        }

        public Criteria andPaymentdayGreaterThanOrEqualTo(String value) {
            addCriterion("PaymentDay >=", value, "paymentday");
            return (Criteria) this;
        }

        public Criteria andPaymentdayLessThan(String value) {
            addCriterion("PaymentDay <", value, "paymentday");
            return (Criteria) this;
        }

        public Criteria andPaymentdayLessThanOrEqualTo(String value) {
            addCriterion("PaymentDay <=", value, "paymentday");
            return (Criteria) this;
        }

        public Criteria andPaymentdayLike(String value) {
            addCriterion("PaymentDay like", value, "paymentday");
            return (Criteria) this;
        }

        public Criteria andPaymentdayNotLike(String value) {
            addCriterion("PaymentDay not like", value, "paymentday");
            return (Criteria) this;
        }

        public Criteria andPaymentdayIn(List<String> values) {
            addCriterion("PaymentDay in", values, "paymentday");
            return (Criteria) this;
        }

        public Criteria andPaymentdayNotIn(List<String> values) {
            addCriterion("PaymentDay not in", values, "paymentday");
            return (Criteria) this;
        }

        public Criteria andPaymentdayBetween(String value1, String value2) {
            addCriterion("PaymentDay between", value1, value2, "paymentday");
            return (Criteria) this;
        }

        public Criteria andPaymentdayNotBetween(String value1, String value2) {
            addCriterion("PaymentDay not between", value1, value2, "paymentday");
            return (Criteria) this;
        }

        public Criteria andBiztypeIsNull() {
            addCriterion("BizType is null");
            return (Criteria) this;
        }

        public Criteria andBiztypeIsNotNull() {
            addCriterion("BizType is not null");
            return (Criteria) this;
        }

        public Criteria andBiztypeEqualTo(String value) {
            addCriterion("BizType =", value, "biztype");
            return (Criteria) this;
        }

        public Criteria andBiztypeNotEqualTo(String value) {
            addCriterion("BizType <>", value, "biztype");
            return (Criteria) this;
        }

        public Criteria andBiztypeGreaterThan(String value) {
            addCriterion("BizType >", value, "biztype");
            return (Criteria) this;
        }

        public Criteria andBiztypeGreaterThanOrEqualTo(String value) {
            addCriterion("BizType >=", value, "biztype");
            return (Criteria) this;
        }

        public Criteria andBiztypeLessThan(String value) {
            addCriterion("BizType <", value, "biztype");
            return (Criteria) this;
        }

        public Criteria andBiztypeLessThanOrEqualTo(String value) {
            addCriterion("BizType <=", value, "biztype");
            return (Criteria) this;
        }

        public Criteria andBiztypeLike(String value) {
            addCriterion("BizType like", value, "biztype");
            return (Criteria) this;
        }

        public Criteria andBiztypeNotLike(String value) {
            addCriterion("BizType not like", value, "biztype");
            return (Criteria) this;
        }

        public Criteria andBiztypeIn(List<String> values) {
            addCriterion("BizType in", values, "biztype");
            return (Criteria) this;
        }

        public Criteria andBiztypeNotIn(List<String> values) {
            addCriterion("BizType not in", values, "biztype");
            return (Criteria) this;
        }

        public Criteria andBiztypeBetween(String value1, String value2) {
            addCriterion("BizType between", value1, value2, "biztype");
            return (Criteria) this;
        }

        public Criteria andBiztypeNotBetween(String value1, String value2) {
            addCriterion("BizType not between", value1, value2, "biztype");
            return (Criteria) this;
        }

        public Criteria andIsdeliveryIsNull() {
            addCriterion("IsDelivery is null");
            return (Criteria) this;
        }

        public Criteria andIsdeliveryIsNotNull() {
            addCriterion("IsDelivery is not null");
            return (Criteria) this;
        }

        public Criteria andIsdeliveryEqualTo(Boolean value) {
            addCriterion("IsDelivery =", value, "isdelivery");
            return (Criteria) this;
        }

        public Criteria andIsdeliveryNotEqualTo(Boolean value) {
            addCriterion("IsDelivery <>", value, "isdelivery");
            return (Criteria) this;
        }

        public Criteria andIsdeliveryGreaterThan(Boolean value) {
            addCriterion("IsDelivery >", value, "isdelivery");
            return (Criteria) this;
        }

        public Criteria andIsdeliveryGreaterThanOrEqualTo(Boolean value) {
            addCriterion("IsDelivery >=", value, "isdelivery");
            return (Criteria) this;
        }

        public Criteria andIsdeliveryLessThan(Boolean value) {
            addCriterion("IsDelivery <", value, "isdelivery");
            return (Criteria) this;
        }

        public Criteria andIsdeliveryLessThanOrEqualTo(Boolean value) {
            addCriterion("IsDelivery <=", value, "isdelivery");
            return (Criteria) this;
        }

        public Criteria andIsdeliveryIn(List<Boolean> values) {
            addCriterion("IsDelivery in", values, "isdelivery");
            return (Criteria) this;
        }

        public Criteria andIsdeliveryNotIn(List<Boolean> values) {
            addCriterion("IsDelivery not in", values, "isdelivery");
            return (Criteria) this;
        }

        public Criteria andIsdeliveryBetween(Boolean value1, Boolean value2) {
            addCriterion("IsDelivery between", value1, value2, "isdelivery");
            return (Criteria) this;
        }

        public Criteria andIsdeliveryNotBetween(Boolean value1, Boolean value2) {
            addCriterion("IsDelivery not between", value1, value2, "isdelivery");
            return (Criteria) this;
        }

        public Criteria andIstaxIsNull() {
            addCriterion("IsTax is null");
            return (Criteria) this;
        }

        public Criteria andIstaxIsNotNull() {
            addCriterion("IsTax is not null");
            return (Criteria) this;
        }

        public Criteria andIstaxEqualTo(Boolean value) {
            addCriterion("IsTax =", value, "istax");
            return (Criteria) this;
        }

        public Criteria andIstaxNotEqualTo(Boolean value) {
            addCriterion("IsTax <>", value, "istax");
            return (Criteria) this;
        }

        public Criteria andIstaxGreaterThan(Boolean value) {
            addCriterion("IsTax >", value, "istax");
            return (Criteria) this;
        }

        public Criteria andIstaxGreaterThanOrEqualTo(Boolean value) {
            addCriterion("IsTax >=", value, "istax");
            return (Criteria) this;
        }

        public Criteria andIstaxLessThan(Boolean value) {
            addCriterion("IsTax <", value, "istax");
            return (Criteria) this;
        }

        public Criteria andIstaxLessThanOrEqualTo(Boolean value) {
            addCriterion("IsTax <=", value, "istax");
            return (Criteria) this;
        }

        public Criteria andIstaxIn(List<Boolean> values) {
            addCriterion("IsTax in", values, "istax");
            return (Criteria) this;
        }

        public Criteria andIstaxNotIn(List<Boolean> values) {
            addCriterion("IsTax not in", values, "istax");
            return (Criteria) this;
        }

        public Criteria andIstaxBetween(Boolean value1, Boolean value2) {
            addCriterion("IsTax between", value1, value2, "istax");
            return (Criteria) this;
        }

        public Criteria andIstaxNotBetween(Boolean value1, Boolean value2) {
            addCriterion("IsTax not between", value1, value2, "istax");
            return (Criteria) this;
        }

        public Criteria andTaxcontentIsNull() {
            addCriterion("TaxContent is null");
            return (Criteria) this;
        }

        public Criteria andTaxcontentIsNotNull() {
            addCriterion("TaxContent is not null");
            return (Criteria) this;
        }

        public Criteria andTaxcontentEqualTo(String value) {
            addCriterion("TaxContent =", value, "taxcontent");
            return (Criteria) this;
        }

        public Criteria andTaxcontentNotEqualTo(String value) {
            addCriterion("TaxContent <>", value, "taxcontent");
            return (Criteria) this;
        }

        public Criteria andTaxcontentGreaterThan(String value) {
            addCriterion("TaxContent >", value, "taxcontent");
            return (Criteria) this;
        }

        public Criteria andTaxcontentGreaterThanOrEqualTo(String value) {
            addCriterion("TaxContent >=", value, "taxcontent");
            return (Criteria) this;
        }

        public Criteria andTaxcontentLessThan(String value) {
            addCriterion("TaxContent <", value, "taxcontent");
            return (Criteria) this;
        }

        public Criteria andTaxcontentLessThanOrEqualTo(String value) {
            addCriterion("TaxContent <=", value, "taxcontent");
            return (Criteria) this;
        }

        public Criteria andTaxcontentLike(String value) {
            addCriterion("TaxContent like", value, "taxcontent");
            return (Criteria) this;
        }

        public Criteria andTaxcontentNotLike(String value) {
            addCriterion("TaxContent not like", value, "taxcontent");
            return (Criteria) this;
        }

        public Criteria andTaxcontentIn(List<String> values) {
            addCriterion("TaxContent in", values, "taxcontent");
            return (Criteria) this;
        }

        public Criteria andTaxcontentNotIn(List<String> values) {
            addCriterion("TaxContent not in", values, "taxcontent");
            return (Criteria) this;
        }

        public Criteria andTaxcontentBetween(String value1, String value2) {
            addCriterion("TaxContent between", value1, value2, "taxcontent");
            return (Criteria) this;
        }

        public Criteria andTaxcontentNotBetween(String value1, String value2) {
            addCriterion("TaxContent not between", value1, value2, "taxcontent");
            return (Criteria) this;
        }

        public Criteria andTaxcompanyIsNull() {
            addCriterion("TaxCompany is null");
            return (Criteria) this;
        }

        public Criteria andTaxcompanyIsNotNull() {
            addCriterion("TaxCompany is not null");
            return (Criteria) this;
        }

        public Criteria andTaxcompanyEqualTo(String value) {
            addCriterion("TaxCompany =", value, "taxcompany");
            return (Criteria) this;
        }

        public Criteria andTaxcompanyNotEqualTo(String value) {
            addCriterion("TaxCompany <>", value, "taxcompany");
            return (Criteria) this;
        }

        public Criteria andTaxcompanyGreaterThan(String value) {
            addCriterion("TaxCompany >", value, "taxcompany");
            return (Criteria) this;
        }

        public Criteria andTaxcompanyGreaterThanOrEqualTo(String value) {
            addCriterion("TaxCompany >=", value, "taxcompany");
            return (Criteria) this;
        }

        public Criteria andTaxcompanyLessThan(String value) {
            addCriterion("TaxCompany <", value, "taxcompany");
            return (Criteria) this;
        }

        public Criteria andTaxcompanyLessThanOrEqualTo(String value) {
            addCriterion("TaxCompany <=", value, "taxcompany");
            return (Criteria) this;
        }

        public Criteria andTaxcompanyLike(String value) {
            addCriterion("TaxCompany like", value, "taxcompany");
            return (Criteria) this;
        }

        public Criteria andTaxcompanyNotLike(String value) {
            addCriterion("TaxCompany not like", value, "taxcompany");
            return (Criteria) this;
        }

        public Criteria andTaxcompanyIn(List<String> values) {
            addCriterion("TaxCompany in", values, "taxcompany");
            return (Criteria) this;
        }

        public Criteria andTaxcompanyNotIn(List<String> values) {
            addCriterion("TaxCompany not in", values, "taxcompany");
            return (Criteria) this;
        }

        public Criteria andTaxcompanyBetween(String value1, String value2) {
            addCriterion("TaxCompany between", value1, value2, "taxcompany");
            return (Criteria) this;
        }

        public Criteria andTaxcompanyNotBetween(String value1, String value2) {
            addCriterion("TaxCompany not between", value1, value2, "taxcompany");
            return (Criteria) this;
        }

        public Criteria andShipstatusIsNull() {
            addCriterion("ShipStatus is null");
            return (Criteria) this;
        }

        public Criteria andShipstatusIsNotNull() {
            addCriterion("ShipStatus is not null");
            return (Criteria) this;
        }

        public Criteria andShipstatusEqualTo(Integer value) {
            addCriterion("ShipStatus =", value, "shipstatus");
            return (Criteria) this;
        }

        public Criteria andShipstatusNotEqualTo(Integer value) {
            addCriterion("ShipStatus <>", value, "shipstatus");
            return (Criteria) this;
        }

        public Criteria andShipstatusGreaterThan(Integer value) {
            addCriterion("ShipStatus >", value, "shipstatus");
            return (Criteria) this;
        }

        public Criteria andShipstatusGreaterThanOrEqualTo(Integer value) {
            addCriterion("ShipStatus >=", value, "shipstatus");
            return (Criteria) this;
        }

        public Criteria andShipstatusLessThan(Integer value) {
            addCriterion("ShipStatus <", value, "shipstatus");
            return (Criteria) this;
        }

        public Criteria andShipstatusLessThanOrEqualTo(Integer value) {
            addCriterion("ShipStatus <=", value, "shipstatus");
            return (Criteria) this;
        }

        public Criteria andShipstatusIn(List<Integer> values) {
            addCriterion("ShipStatus in", values, "shipstatus");
            return (Criteria) this;
        }

        public Criteria andShipstatusNotIn(List<Integer> values) {
            addCriterion("ShipStatus not in", values, "shipstatus");
            return (Criteria) this;
        }

        public Criteria andShipstatusBetween(Integer value1, Integer value2) {
            addCriterion("ShipStatus between", value1, value2, "shipstatus");
            return (Criteria) this;
        }

        public Criteria andShipstatusNotBetween(Integer value1, Integer value2) {
            addCriterion("ShipStatus not between", value1, value2, "shipstatus");
            return (Criteria) this;
        }

        public Criteria andStatusIsNull() {
            addCriterion("status is null");
            return (Criteria) this;
        }

        public Criteria andStatusIsNotNull() {
            addCriterion("status is not null");
            return (Criteria) this;
        }

        public Criteria andStatusEqualTo(Integer value) {
            addCriterion("status =", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusNotEqualTo(Integer value) {
            addCriterion("status <>", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusGreaterThan(Integer value) {
            addCriterion("status >", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusGreaterThanOrEqualTo(Integer value) {
            addCriterion("status >=", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusLessThan(Integer value) {
            addCriterion("status <", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusLessThanOrEqualTo(Integer value) {
            addCriterion("status <=", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusIn(List<Integer> values) {
            addCriterion("status in", values, "status");
            return (Criteria) this;
        }

        public Criteria andStatusNotIn(List<Integer> values) {
            addCriterion("status not in", values, "status");
            return (Criteria) this;
        }

        public Criteria andStatusBetween(Integer value1, Integer value2) {
            addCriterion("status between", value1, value2, "status");
            return (Criteria) this;
        }

        public Criteria andStatusNotBetween(Integer value1, Integer value2) {
            addCriterion("status not between", value1, value2, "status");
            return (Criteria) this;
        }

        public Criteria andIsreturnIsNull() {
            addCriterion("Isreturn is null");
            return (Criteria) this;
        }

        public Criteria andIsreturnIsNotNull() {
            addCriterion("Isreturn is not null");
            return (Criteria) this;
        }

        public Criteria andIsreturnEqualTo(Integer value) {
            addCriterion("Isreturn =", value, "isreturn");
            return (Criteria) this;
        }

        public Criteria andIsreturnNotEqualTo(Integer value) {
            addCriterion("Isreturn <>", value, "isreturn");
            return (Criteria) this;
        }

        public Criteria andIsreturnGreaterThan(Integer value) {
            addCriterion("Isreturn >", value, "isreturn");
            return (Criteria) this;
        }

        public Criteria andIsreturnGreaterThanOrEqualTo(Integer value) {
            addCriterion("Isreturn >=", value, "isreturn");
            return (Criteria) this;
        }

        public Criteria andIsreturnLessThan(Integer value) {
            addCriterion("Isreturn <", value, "isreturn");
            return (Criteria) this;
        }

        public Criteria andIsreturnLessThanOrEqualTo(Integer value) {
            addCriterion("Isreturn <=", value, "isreturn");
            return (Criteria) this;
        }

        public Criteria andIsreturnIn(List<Integer> values) {
            addCriterion("Isreturn in", values, "isreturn");
            return (Criteria) this;
        }

        public Criteria andIsreturnNotIn(List<Integer> values) {
            addCriterion("Isreturn not in", values, "isreturn");
            return (Criteria) this;
        }

        public Criteria andIsreturnBetween(Integer value1, Integer value2) {
            addCriterion("Isreturn between", value1, value2, "isreturn");
            return (Criteria) this;
        }

        public Criteria andIsreturnNotBetween(Integer value1, Integer value2) {
            addCriterion("Isreturn not between", value1, value2, "isreturn");
            return (Criteria) this;
        }

        public Criteria andMarktextIsNull() {
            addCriterion("MarkText is null");
            return (Criteria) this;
        }

        public Criteria andMarktextIsNotNull() {
            addCriterion("MarkText is not null");
            return (Criteria) this;
        }

        public Criteria andMarktextEqualTo(String value) {
            addCriterion("MarkText =", value, "marktext");
            return (Criteria) this;
        }

        public Criteria andMarktextNotEqualTo(String value) {
            addCriterion("MarkText <>", value, "marktext");
            return (Criteria) this;
        }

        public Criteria andMarktextGreaterThan(String value) {
            addCriterion("MarkText >", value, "marktext");
            return (Criteria) this;
        }

        public Criteria andMarktextGreaterThanOrEqualTo(String value) {
            addCriterion("MarkText >=", value, "marktext");
            return (Criteria) this;
        }

        public Criteria andMarktextLessThan(String value) {
            addCriterion("MarkText <", value, "marktext");
            return (Criteria) this;
        }

        public Criteria andMarktextLessThanOrEqualTo(String value) {
            addCriterion("MarkText <=", value, "marktext");
            return (Criteria) this;
        }

        public Criteria andMarktextLike(String value) {
            addCriterion("MarkText like", value, "marktext");
            return (Criteria) this;
        }

        public Criteria andMarktextNotLike(String value) {
            addCriterion("MarkText not like", value, "marktext");
            return (Criteria) this;
        }

        public Criteria andMarktextIn(List<String> values) {
            addCriterion("MarkText in", values, "marktext");
            return (Criteria) this;
        }

        public Criteria andMarktextNotIn(List<String> values) {
            addCriterion("MarkText not in", values, "marktext");
            return (Criteria) this;
        }

        public Criteria andMarktextBetween(String value1, String value2) {
            addCriterion("MarkText between", value1, value2, "marktext");
            return (Criteria) this;
        }

        public Criteria andMarktextNotBetween(String value1, String value2) {
            addCriterion("MarkText not between", value1, value2, "marktext");
            return (Criteria) this;
        }

        public Criteria andMemberdescIsNull() {
            addCriterion("MemberDesc is null");
            return (Criteria) this;
        }

        public Criteria andMemberdescIsNotNull() {
            addCriterion("MemberDesc is not null");
            return (Criteria) this;
        }

        public Criteria andMemberdescEqualTo(String value) {
            addCriterion("MemberDesc =", value, "memberdesc");
            return (Criteria) this;
        }

        public Criteria andMemberdescNotEqualTo(String value) {
            addCriterion("MemberDesc <>", value, "memberdesc");
            return (Criteria) this;
        }

        public Criteria andMemberdescGreaterThan(String value) {
            addCriterion("MemberDesc >", value, "memberdesc");
            return (Criteria) this;
        }

        public Criteria andMemberdescGreaterThanOrEqualTo(String value) {
            addCriterion("MemberDesc >=", value, "memberdesc");
            return (Criteria) this;
        }

        public Criteria andMemberdescLessThan(String value) {
            addCriterion("MemberDesc <", value, "memberdesc");
            return (Criteria) this;
        }

        public Criteria andMemberdescLessThanOrEqualTo(String value) {
            addCriterion("MemberDesc <=", value, "memberdesc");
            return (Criteria) this;
        }

        public Criteria andMemberdescLike(String value) {
            addCriterion("MemberDesc like", value, "memberdesc");
            return (Criteria) this;
        }

        public Criteria andMemberdescNotLike(String value) {
            addCriterion("MemberDesc not like", value, "memberdesc");
            return (Criteria) this;
        }

        public Criteria andMemberdescIn(List<String> values) {
            addCriterion("MemberDesc in", values, "memberdesc");
            return (Criteria) this;
        }

        public Criteria andMemberdescNotIn(List<String> values) {
            addCriterion("MemberDesc not in", values, "memberdesc");
            return (Criteria) this;
        }

        public Criteria andMemberdescBetween(String value1, String value2) {
            addCriterion("MemberDesc between", value1, value2, "memberdesc");
            return (Criteria) this;
        }

        public Criteria andMemberdescNotBetween(String value1, String value2) {
            addCriterion("MemberDesc not between", value1, value2, "memberdesc");
            return (Criteria) this;
        }

        public Criteria andAddonstrIsNull() {
            addCriterion("Addonstr is null");
            return (Criteria) this;
        }

        public Criteria andAddonstrIsNotNull() {
            addCriterion("Addonstr is not null");
            return (Criteria) this;
        }

        public Criteria andAddonstrEqualTo(String value) {
            addCriterion("Addonstr =", value, "addonstr");
            return (Criteria) this;
        }

        public Criteria andAddonstrNotEqualTo(String value) {
            addCriterion("Addonstr <>", value, "addonstr");
            return (Criteria) this;
        }

        public Criteria andAddonstrGreaterThan(String value) {
            addCriterion("Addonstr >", value, "addonstr");
            return (Criteria) this;
        }

        public Criteria andAddonstrGreaterThanOrEqualTo(String value) {
            addCriterion("Addonstr >=", value, "addonstr");
            return (Criteria) this;
        }

        public Criteria andAddonstrLessThan(String value) {
            addCriterion("Addonstr <", value, "addonstr");
            return (Criteria) this;
        }

        public Criteria andAddonstrLessThanOrEqualTo(String value) {
            addCriterion("Addonstr <=", value, "addonstr");
            return (Criteria) this;
        }

        public Criteria andAddonstrLike(String value) {
            addCriterion("Addonstr like", value, "addonstr");
            return (Criteria) this;
        }

        public Criteria andAddonstrNotLike(String value) {
            addCriterion("Addonstr not like", value, "addonstr");
            return (Criteria) this;
        }

        public Criteria andAddonstrIn(List<String> values) {
            addCriterion("Addonstr in", values, "addonstr");
            return (Criteria) this;
        }

        public Criteria andAddonstrNotIn(List<String> values) {
            addCriterion("Addonstr not in", values, "addonstr");
            return (Criteria) this;
        }

        public Criteria andAddonstrBetween(String value1, String value2) {
            addCriterion("Addonstr between", value1, value2, "addonstr");
            return (Criteria) this;
        }

        public Criteria andAddonstrNotBetween(String value1, String value2) {
            addCriterion("Addonstr not between", value1, value2, "addonstr");
            return (Criteria) this;
        }

        public Criteria andOrderreferIsNull() {
            addCriterion("OrderRefer is null");
            return (Criteria) this;
        }

        public Criteria andOrderreferIsNotNull() {
            addCriterion("OrderRefer is not null");
            return (Criteria) this;
        }

        public Criteria andOrderreferEqualTo(String value) {
            addCriterion("OrderRefer =", value, "orderrefer");
            return (Criteria) this;
        }

        public Criteria andOrderreferNotEqualTo(String value) {
            addCriterion("OrderRefer <>", value, "orderrefer");
            return (Criteria) this;
        }

        public Criteria andOrderreferGreaterThan(String value) {
            addCriterion("OrderRefer >", value, "orderrefer");
            return (Criteria) this;
        }

        public Criteria andOrderreferGreaterThanOrEqualTo(String value) {
            addCriterion("OrderRefer >=", value, "orderrefer");
            return (Criteria) this;
        }

        public Criteria andOrderreferLessThan(String value) {
            addCriterion("OrderRefer <", value, "orderrefer");
            return (Criteria) this;
        }

        public Criteria andOrderreferLessThanOrEqualTo(String value) {
            addCriterion("OrderRefer <=", value, "orderrefer");
            return (Criteria) this;
        }

        public Criteria andOrderreferLike(String value) {
            addCriterion("OrderRefer like", value, "orderrefer");
            return (Criteria) this;
        }

        public Criteria andOrderreferNotLike(String value) {
            addCriterion("OrderRefer not like", value, "orderrefer");
            return (Criteria) this;
        }

        public Criteria andOrderreferIn(List<String> values) {
            addCriterion("OrderRefer in", values, "orderrefer");
            return (Criteria) this;
        }

        public Criteria andOrderreferNotIn(List<String> values) {
            addCriterion("OrderRefer not in", values, "orderrefer");
            return (Criteria) this;
        }

        public Criteria andOrderreferBetween(String value1, String value2) {
            addCriterion("OrderRefer between", value1, value2, "orderrefer");
            return (Criteria) this;
        }

        public Criteria andOrderreferNotBetween(String value1, String value2) {
            addCriterion("OrderRefer not between", value1, value2, "orderrefer");
            return (Criteria) this;
        }

        public Criteria andReturngoodsremarkIsNull() {
            addCriterion("ReturnGoodsRemark is null");
            return (Criteria) this;
        }

        public Criteria andReturngoodsremarkIsNotNull() {
            addCriterion("ReturnGoodsRemark is not null");
            return (Criteria) this;
        }

        public Criteria andReturngoodsremarkEqualTo(String value) {
            addCriterion("ReturnGoodsRemark =", value, "returngoodsremark");
            return (Criteria) this;
        }

        public Criteria andReturngoodsremarkNotEqualTo(String value) {
            addCriterion("ReturnGoodsRemark <>", value, "returngoodsremark");
            return (Criteria) this;
        }

        public Criteria andReturngoodsremarkGreaterThan(String value) {
            addCriterion("ReturnGoodsRemark >", value, "returngoodsremark");
            return (Criteria) this;
        }

        public Criteria andReturngoodsremarkGreaterThanOrEqualTo(String value) {
            addCriterion("ReturnGoodsRemark >=", value, "returngoodsremark");
            return (Criteria) this;
        }

        public Criteria andReturngoodsremarkLessThan(String value) {
            addCriterion("ReturnGoodsRemark <", value, "returngoodsremark");
            return (Criteria) this;
        }

        public Criteria andReturngoodsremarkLessThanOrEqualTo(String value) {
            addCriterion("ReturnGoodsRemark <=", value, "returngoodsremark");
            return (Criteria) this;
        }

        public Criteria andReturngoodsremarkLike(String value) {
            addCriterion("ReturnGoodsRemark like", value, "returngoodsremark");
            return (Criteria) this;
        }

        public Criteria andReturngoodsremarkNotLike(String value) {
            addCriterion("ReturnGoodsRemark not like", value, "returngoodsremark");
            return (Criteria) this;
        }

        public Criteria andReturngoodsremarkIn(List<String> values) {
            addCriterion("ReturnGoodsRemark in", values, "returngoodsremark");
            return (Criteria) this;
        }

        public Criteria andReturngoodsremarkNotIn(List<String> values) {
            addCriterion("ReturnGoodsRemark not in", values, "returngoodsremark");
            return (Criteria) this;
        }

        public Criteria andReturngoodsremarkBetween(String value1, String value2) {
            addCriterion("ReturnGoodsRemark between", value1, value2, "returngoodsremark");
            return (Criteria) this;
        }

        public Criteria andReturngoodsremarkNotBetween(String value1, String value2) {
            addCriterion("ReturnGoodsRemark not between", value1, value2, "returngoodsremark");
            return (Criteria) this;
        }

        public Criteria andFatypeIsNull() {
            addCriterion("FAtype is null");
            return (Criteria) this;
        }

        public Criteria andFatypeIsNotNull() {
            addCriterion("FAtype is not null");
            return (Criteria) this;
        }

        public Criteria andFatypeEqualTo(Integer value) {
            addCriterion("FAtype =", value, "fatype");
            return (Criteria) this;
        }

        public Criteria andFatypeNotEqualTo(Integer value) {
            addCriterion("FAtype <>", value, "fatype");
            return (Criteria) this;
        }

        public Criteria andFatypeGreaterThan(Integer value) {
            addCriterion("FAtype >", value, "fatype");
            return (Criteria) this;
        }

        public Criteria andFatypeGreaterThanOrEqualTo(Integer value) {
            addCriterion("FAtype >=", value, "fatype");
            return (Criteria) this;
        }

        public Criteria andFatypeLessThan(Integer value) {
            addCriterion("FAtype <", value, "fatype");
            return (Criteria) this;
        }

        public Criteria andFatypeLessThanOrEqualTo(Integer value) {
            addCriterion("FAtype <=", value, "fatype");
            return (Criteria) this;
        }

        public Criteria andFatypeIn(List<Integer> values) {
            addCriterion("FAtype in", values, "fatype");
            return (Criteria) this;
        }

        public Criteria andFatypeNotIn(List<Integer> values) {
            addCriterion("FAtype not in", values, "fatype");
            return (Criteria) this;
        }

        public Criteria andFatypeBetween(Integer value1, Integer value2) {
            addCriterion("FAtype between", value1, value2, "fatype");
            return (Criteria) this;
        }

        public Criteria andFatypeNotBetween(Integer value1, Integer value2) {
            addCriterion("FAtype not between", value1, value2, "fatype");
            return (Criteria) this;
        }

        public Criteria andFaidIsNull() {
            addCriterion("FAID is null");
            return (Criteria) this;
        }

        public Criteria andFaidIsNotNull() {
            addCriterion("FAID is not null");
            return (Criteria) this;
        }

        public Criteria andFaidEqualTo(String value) {
            addCriterion("FAID =", value, "faid");
            return (Criteria) this;
        }

        public Criteria andFaidNotEqualTo(String value) {
            addCriterion("FAID <>", value, "faid");
            return (Criteria) this;
        }

        public Criteria andFaidGreaterThan(String value) {
            addCriterion("FAID >", value, "faid");
            return (Criteria) this;
        }

        public Criteria andFaidGreaterThanOrEqualTo(String value) {
            addCriterion("FAID >=", value, "faid");
            return (Criteria) this;
        }

        public Criteria andFaidLessThan(String value) {
            addCriterion("FAID <", value, "faid");
            return (Criteria) this;
        }

        public Criteria andFaidLessThanOrEqualTo(String value) {
            addCriterion("FAID <=", value, "faid");
            return (Criteria) this;
        }

        public Criteria andFaidLike(String value) {
            addCriterion("FAID like", value, "faid");
            return (Criteria) this;
        }

        public Criteria andFaidNotLike(String value) {
            addCriterion("FAID not like", value, "faid");
            return (Criteria) this;
        }

        public Criteria andFaidIn(List<String> values) {
            addCriterion("FAID in", values, "faid");
            return (Criteria) this;
        }

        public Criteria andFaidNotIn(List<String> values) {
            addCriterion("FAID not in", values, "faid");
            return (Criteria) this;
        }

        public Criteria andFaidBetween(String value1, String value2) {
            addCriterion("FAID between", value1, value2, "faid");
            return (Criteria) this;
        }

        public Criteria andFaidNotBetween(String value1, String value2) {
            addCriterion("FAID not between", value1, value2, "faid");
            return (Criteria) this;
        }

        public Criteria andFanameIsNull() {
            addCriterion("FAName is null");
            return (Criteria) this;
        }

        public Criteria andFanameIsNotNull() {
            addCriterion("FAName is not null");
            return (Criteria) this;
        }

        public Criteria andFanameEqualTo(String value) {
            addCriterion("FAName =", value, "faname");
            return (Criteria) this;
        }

        public Criteria andFanameNotEqualTo(String value) {
            addCriterion("FAName <>", value, "faname");
            return (Criteria) this;
        }

        public Criteria andFanameGreaterThan(String value) {
            addCriterion("FAName >", value, "faname");
            return (Criteria) this;
        }

        public Criteria andFanameGreaterThanOrEqualTo(String value) {
            addCriterion("FAName >=", value, "faname");
            return (Criteria) this;
        }

        public Criteria andFanameLessThan(String value) {
            addCriterion("FAName <", value, "faname");
            return (Criteria) this;
        }

        public Criteria andFanameLessThanOrEqualTo(String value) {
            addCriterion("FAName <=", value, "faname");
            return (Criteria) this;
        }

        public Criteria andFanameLike(String value) {
            addCriterion("FAName like", value, "faname");
            return (Criteria) this;
        }

        public Criteria andFanameNotLike(String value) {
            addCriterion("FAName not like", value, "faname");
            return (Criteria) this;
        }

        public Criteria andFanameIn(List<String> values) {
            addCriterion("FAName in", values, "faname");
            return (Criteria) this;
        }

        public Criteria andFanameNotIn(List<String> values) {
            addCriterion("FAName not in", values, "faname");
            return (Criteria) this;
        }

        public Criteria andFanameBetween(String value1, String value2) {
            addCriterion("FAName between", value1, value2, "faname");
            return (Criteria) this;
        }

        public Criteria andFanameNotBetween(String value1, String value2) {
            addCriterion("FAName not between", value1, value2, "faname");
            return (Criteria) this;
        }

        public Criteria andIsqualifiedIsNull() {
            addCriterion("IsQualified is null");
            return (Criteria) this;
        }

        public Criteria andIsqualifiedIsNotNull() {
            addCriterion("IsQualified is not null");
            return (Criteria) this;
        }

        public Criteria andIsqualifiedEqualTo(Boolean value) {
            addCriterion("IsQualified =", value, "isqualified");
            return (Criteria) this;
        }

        public Criteria andIsqualifiedNotEqualTo(Boolean value) {
            addCriterion("IsQualified <>", value, "isqualified");
            return (Criteria) this;
        }

        public Criteria andIsqualifiedGreaterThan(Boolean value) {
            addCriterion("IsQualified >", value, "isqualified");
            return (Criteria) this;
        }

        public Criteria andIsqualifiedGreaterThanOrEqualTo(Boolean value) {
            addCriterion("IsQualified >=", value, "isqualified");
            return (Criteria) this;
        }

        public Criteria andIsqualifiedLessThan(Boolean value) {
            addCriterion("IsQualified <", value, "isqualified");
            return (Criteria) this;
        }

        public Criteria andIsqualifiedLessThanOrEqualTo(Boolean value) {
            addCriterion("IsQualified <=", value, "isqualified");
            return (Criteria) this;
        }

        public Criteria andIsqualifiedIn(List<Boolean> values) {
            addCriterion("IsQualified in", values, "isqualified");
            return (Criteria) this;
        }

        public Criteria andIsqualifiedNotIn(List<Boolean> values) {
            addCriterion("IsQualified not in", values, "isqualified");
            return (Criteria) this;
        }

        public Criteria andIsqualifiedBetween(Boolean value1, Boolean value2) {
            addCriterion("IsQualified between", value1, value2, "isqualified");
            return (Criteria) this;
        }

        public Criteria andIsqualifiedNotBetween(Boolean value1, Boolean value2) {
            addCriterion("IsQualified not between", value1, value2, "isqualified");
            return (Criteria) this;
        }

        public Criteria andIsabnormalIsNull() {
            addCriterion("isAbnormal is null");
            return (Criteria) this;
        }

        public Criteria andIsabnormalIsNotNull() {
            addCriterion("isAbnormal is not null");
            return (Criteria) this;
        }

        public Criteria andIsabnormalEqualTo(String value) {
            addCriterion("isAbnormal =", value, "isabnormal");
            return (Criteria) this;
        }

        public Criteria andIsabnormalNotEqualTo(String value) {
            addCriterion("isAbnormal <>", value, "isabnormal");
            return (Criteria) this;
        }

        public Criteria andIsabnormalGreaterThan(String value) {
            addCriterion("isAbnormal >", value, "isabnormal");
            return (Criteria) this;
        }

        public Criteria andIsabnormalGreaterThanOrEqualTo(String value) {
            addCriterion("isAbnormal >=", value, "isabnormal");
            return (Criteria) this;
        }

        public Criteria andIsabnormalLessThan(String value) {
            addCriterion("isAbnormal <", value, "isabnormal");
            return (Criteria) this;
        }

        public Criteria andIsabnormalLessThanOrEqualTo(String value) {
            addCriterion("isAbnormal <=", value, "isabnormal");
            return (Criteria) this;
        }

        public Criteria andIsabnormalLike(String value) {
            addCriterion("isAbnormal like", value, "isabnormal");
            return (Criteria) this;
        }

        public Criteria andIsabnormalNotLike(String value) {
            addCriterion("isAbnormal not like", value, "isabnormal");
            return (Criteria) this;
        }

        public Criteria andIsabnormalIn(List<String> values) {
            addCriterion("isAbnormal in", values, "isabnormal");
            return (Criteria) this;
        }

        public Criteria andIsabnormalNotIn(List<String> values) {
            addCriterion("isAbnormal not in", values, "isabnormal");
            return (Criteria) this;
        }

        public Criteria andIsabnormalBetween(String value1, String value2) {
            addCriterion("isAbnormal between", value1, value2, "isabnormal");
            return (Criteria) this;
        }

        public Criteria andIsabnormalNotBetween(String value1, String value2) {
            addCriterion("isAbnormal not between", value1, value2, "isabnormal");
            return (Criteria) this;
        }

        public Criteria andHascommentIsNull() {
            addCriterion("hasComment is null");
            return (Criteria) this;
        }

        public Criteria andHascommentIsNotNull() {
            addCriterion("hasComment is not null");
            return (Criteria) this;
        }

        public Criteria andHascommentEqualTo(String value) {
            addCriterion("hasComment =", value, "hascomment");
            return (Criteria) this;
        }

        public Criteria andHascommentNotEqualTo(String value) {
            addCriterion("hasComment <>", value, "hascomment");
            return (Criteria) this;
        }

        public Criteria andHascommentGreaterThan(String value) {
            addCriterion("hasComment >", value, "hascomment");
            return (Criteria) this;
        }

        public Criteria andHascommentGreaterThanOrEqualTo(String value) {
            addCriterion("hasComment >=", value, "hascomment");
            return (Criteria) this;
        }

        public Criteria andHascommentLessThan(String value) {
            addCriterion("hasComment <", value, "hascomment");
            return (Criteria) this;
        }

        public Criteria andHascommentLessThanOrEqualTo(String value) {
            addCriterion("hasComment <=", value, "hascomment");
            return (Criteria) this;
        }

        public Criteria andHascommentLike(String value) {
            addCriterion("hasComment like", value, "hascomment");
            return (Criteria) this;
        }

        public Criteria andHascommentNotLike(String value) {
            addCriterion("hasComment not like", value, "hascomment");
            return (Criteria) this;
        }

        public Criteria andHascommentIn(List<String> values) {
            addCriterion("hasComment in", values, "hascomment");
            return (Criteria) this;
        }

        public Criteria andHascommentNotIn(List<String> values) {
            addCriterion("hasComment not in", values, "hascomment");
            return (Criteria) this;
        }

        public Criteria andHascommentBetween(String value1, String value2) {
            addCriterion("hasComment between", value1, value2, "hascomment");
            return (Criteria) this;
        }

        public Criteria andHascommentNotBetween(String value1, String value2) {
            addCriterion("hasComment not between", value1, value2, "hascomment");
            return (Criteria) this;
        }

        public Criteria andCreatetimeIsNull() {
            addCriterion("CreateTime is null");
            return (Criteria) this;
        }

        public Criteria andCreatetimeIsNotNull() {
            addCriterion("CreateTime is not null");
            return (Criteria) this;
        }

        public Criteria andCreatetimeEqualTo(Date value) {
            addCriterion("CreateTime =", value, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeNotEqualTo(Date value) {
            addCriterion("CreateTime <>", value, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeGreaterThan(Date value) {
            addCriterion("CreateTime >", value, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeGreaterThanOrEqualTo(Date value) {
            addCriterion("CreateTime >=", value, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeLessThan(Date value) {
            addCriterion("CreateTime <", value, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeLessThanOrEqualTo(Date value) {
            addCriterion("CreateTime <=", value, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeIn(List<Date> values) {
            addCriterion("CreateTime in", values, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeNotIn(List<Date> values) {
            addCriterion("CreateTime not in", values, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeBetween(Date value1, Date value2) {
            addCriterion("CreateTime between", value1, value2, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeNotBetween(Date value1, Date value2) {
            addCriterion("CreateTime not between", value1, value2, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatebyIsNull() {
            addCriterion("CreateBy is null");
            return (Criteria) this;
        }

        public Criteria andCreatebyIsNotNull() {
            addCriterion("CreateBy is not null");
            return (Criteria) this;
        }

        public Criteria andCreatebyEqualTo(String value) {
            addCriterion("CreateBy =", value, "createby");
            return (Criteria) this;
        }

        public Criteria andCreatebyNotEqualTo(String value) {
            addCriterion("CreateBy <>", value, "createby");
            return (Criteria) this;
        }

        public Criteria andCreatebyGreaterThan(String value) {
            addCriterion("CreateBy >", value, "createby");
            return (Criteria) this;
        }

        public Criteria andCreatebyGreaterThanOrEqualTo(String value) {
            addCriterion("CreateBy >=", value, "createby");
            return (Criteria) this;
        }

        public Criteria andCreatebyLessThan(String value) {
            addCriterion("CreateBy <", value, "createby");
            return (Criteria) this;
        }

        public Criteria andCreatebyLessThanOrEqualTo(String value) {
            addCriterion("CreateBy <=", value, "createby");
            return (Criteria) this;
        }

        public Criteria andCreatebyLike(String value) {
            addCriterion("CreateBy like", value, "createby");
            return (Criteria) this;
        }

        public Criteria andCreatebyNotLike(String value) {
            addCriterion("CreateBy not like", value, "createby");
            return (Criteria) this;
        }

        public Criteria andCreatebyIn(List<String> values) {
            addCriterion("CreateBy in", values, "createby");
            return (Criteria) this;
        }

        public Criteria andCreatebyNotIn(List<String> values) {
            addCriterion("CreateBy not in", values, "createby");
            return (Criteria) this;
        }

        public Criteria andCreatebyBetween(String value1, String value2) {
            addCriterion("CreateBy between", value1, value2, "createby");
            return (Criteria) this;
        }

        public Criteria andCreatebyNotBetween(String value1, String value2) {
            addCriterion("CreateBy not between", value1, value2, "createby");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeIsNull() {
            addCriterion("UpdateTime is null");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeIsNotNull() {
            addCriterion("UpdateTime is not null");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeEqualTo(Date value) {
            addCriterion("UpdateTime =", value, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeNotEqualTo(Date value) {
            addCriterion("UpdateTime <>", value, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeGreaterThan(Date value) {
            addCriterion("UpdateTime >", value, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeGreaterThanOrEqualTo(Date value) {
            addCriterion("UpdateTime >=", value, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeLessThan(Date value) {
            addCriterion("UpdateTime <", value, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeLessThanOrEqualTo(Date value) {
            addCriterion("UpdateTime <=", value, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeIn(List<Date> values) {
            addCriterion("UpdateTime in", values, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeNotIn(List<Date> values) {
            addCriterion("UpdateTime not in", values, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeBetween(Date value1, Date value2) {
            addCriterion("UpdateTime between", value1, value2, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeNotBetween(Date value1, Date value2) {
            addCriterion("UpdateTime not between", value1, value2, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatebyIsNull() {
            addCriterion("UpdateBy is null");
            return (Criteria) this;
        }

        public Criteria andUpdatebyIsNotNull() {
            addCriterion("UpdateBy is not null");
            return (Criteria) this;
        }

        public Criteria andUpdatebyEqualTo(String value) {
            addCriterion("UpdateBy =", value, "updateby");
            return (Criteria) this;
        }

        public Criteria andUpdatebyNotEqualTo(String value) {
            addCriterion("UpdateBy <>", value, "updateby");
            return (Criteria) this;
        }

        public Criteria andUpdatebyGreaterThan(String value) {
            addCriterion("UpdateBy >", value, "updateby");
            return (Criteria) this;
        }

        public Criteria andUpdatebyGreaterThanOrEqualTo(String value) {
            addCriterion("UpdateBy >=", value, "updateby");
            return (Criteria) this;
        }

        public Criteria andUpdatebyLessThan(String value) {
            addCriterion("UpdateBy <", value, "updateby");
            return (Criteria) this;
        }

        public Criteria andUpdatebyLessThanOrEqualTo(String value) {
            addCriterion("UpdateBy <=", value, "updateby");
            return (Criteria) this;
        }

        public Criteria andUpdatebyLike(String value) {
            addCriterion("UpdateBy like", value, "updateby");
            return (Criteria) this;
        }

        public Criteria andUpdatebyNotLike(String value) {
            addCriterion("UpdateBy not like", value, "updateby");
            return (Criteria) this;
        }

        public Criteria andUpdatebyIn(List<String> values) {
            addCriterion("UpdateBy in", values, "updateby");
            return (Criteria) this;
        }

        public Criteria andUpdatebyNotIn(List<String> values) {
            addCriterion("UpdateBy not in", values, "updateby");
            return (Criteria) this;
        }

        public Criteria andUpdatebyBetween(String value1, String value2) {
            addCriterion("UpdateBy between", value1, value2, "updateby");
            return (Criteria) this;
        }

        public Criteria andUpdatebyNotBetween(String value1, String value2) {
            addCriterion("UpdateBy not between", value1, value2, "updateby");
            return (Criteria) this;
        }

        public Criteria andUsedledounumIsNull() {
            addCriterion("UsedLeDouNum is null");
            return (Criteria) this;
        }

        public Criteria andUsedledounumIsNotNull() {
            addCriterion("UsedLeDouNum is not null");
            return (Criteria) this;
        }

        public Criteria andUsedledounumEqualTo(Integer value) {
            addCriterion("UsedLeDouNum =", value, "usedledounum");
            return (Criteria) this;
        }

        public Criteria andUsedledounumNotEqualTo(Integer value) {
            addCriterion("UsedLeDouNum <>", value, "usedledounum");
            return (Criteria) this;
        }

        public Criteria andUsedledounumGreaterThan(Integer value) {
            addCriterion("UsedLeDouNum >", value, "usedledounum");
            return (Criteria) this;
        }

        public Criteria andUsedledounumGreaterThanOrEqualTo(Integer value) {
            addCriterion("UsedLeDouNum >=", value, "usedledounum");
            return (Criteria) this;
        }

        public Criteria andUsedledounumLessThan(Integer value) {
            addCriterion("UsedLeDouNum <", value, "usedledounum");
            return (Criteria) this;
        }

        public Criteria andUsedledounumLessThanOrEqualTo(Integer value) {
            addCriterion("UsedLeDouNum <=", value, "usedledounum");
            return (Criteria) this;
        }

        public Criteria andUsedledounumIn(List<Integer> values) {
            addCriterion("UsedLeDouNum in", values, "usedledounum");
            return (Criteria) this;
        }

        public Criteria andUsedledounumNotIn(List<Integer> values) {
            addCriterion("UsedLeDouNum not in", values, "usedledounum");
            return (Criteria) this;
        }

        public Criteria andUsedledounumBetween(Integer value1, Integer value2) {
            addCriterion("UsedLeDouNum between", value1, value2, "usedledounum");
            return (Criteria) this;
        }

        public Criteria andUsedledounumNotBetween(Integer value1, Integer value2) {
            addCriterion("UsedLeDouNum not between", value1, value2, "usedledounum");
            return (Criteria) this;
        }

        public Criteria andRewardledounumIsNull() {
            addCriterion("RewardLeDouNum is null");
            return (Criteria) this;
        }

        public Criteria andRewardledounumIsNotNull() {
            addCriterion("RewardLeDouNum is not null");
            return (Criteria) this;
        }

        public Criteria andRewardledounumEqualTo(Integer value) {
            addCriterion("RewardLeDouNum =", value, "rewardledounum");
            return (Criteria) this;
        }

        public Criteria andRewardledounumNotEqualTo(Integer value) {
            addCriterion("RewardLeDouNum <>", value, "rewardledounum");
            return (Criteria) this;
        }

        public Criteria andRewardledounumGreaterThan(Integer value) {
            addCriterion("RewardLeDouNum >", value, "rewardledounum");
            return (Criteria) this;
        }

        public Criteria andRewardledounumGreaterThanOrEqualTo(Integer value) {
            addCriterion("RewardLeDouNum >=", value, "rewardledounum");
            return (Criteria) this;
        }

        public Criteria andRewardledounumLessThan(Integer value) {
            addCriterion("RewardLeDouNum <", value, "rewardledounum");
            return (Criteria) this;
        }

        public Criteria andRewardledounumLessThanOrEqualTo(Integer value) {
            addCriterion("RewardLeDouNum <=", value, "rewardledounum");
            return (Criteria) this;
        }

        public Criteria andRewardledounumIn(List<Integer> values) {
            addCriterion("RewardLeDouNum in", values, "rewardledounum");
            return (Criteria) this;
        }

        public Criteria andRewardledounumNotIn(List<Integer> values) {
            addCriterion("RewardLeDouNum not in", values, "rewardledounum");
            return (Criteria) this;
        }

        public Criteria andRewardledounumBetween(Integer value1, Integer value2) {
            addCriterion("RewardLeDouNum between", value1, value2, "rewardledounum");
            return (Criteria) this;
        }

        public Criteria andRewardledounumNotBetween(Integer value1, Integer value2) {
            addCriterion("RewardLeDouNum not between", value1, value2, "rewardledounum");
            return (Criteria) this;
        }

        public Criteria andMerchantidIsNull() {
            addCriterion("MerchantId is null");
            return (Criteria) this;
        }

        public Criteria andMerchantidIsNotNull() {
            addCriterion("MerchantId is not null");
            return (Criteria) this;
        }

        public Criteria andMerchantidEqualTo(Integer value) {
            addCriterion("MerchantId =", value, "merchantid");
            return (Criteria) this;
        }

        public Criteria andMerchantidNotEqualTo(Integer value) {
            addCriterion("MerchantId <>", value, "merchantid");
            return (Criteria) this;
        }

        public Criteria andMerchantidGreaterThan(Integer value) {
            addCriterion("MerchantId >", value, "merchantid");
            return (Criteria) this;
        }

        public Criteria andMerchantidGreaterThanOrEqualTo(Integer value) {
            addCriterion("MerchantId >=", value, "merchantid");
            return (Criteria) this;
        }

        public Criteria andMerchantidLessThan(Integer value) {
            addCriterion("MerchantId <", value, "merchantid");
            return (Criteria) this;
        }

        public Criteria andMerchantidLessThanOrEqualTo(Integer value) {
            addCriterion("MerchantId <=", value, "merchantid");
            return (Criteria) this;
        }

        public Criteria andMerchantidIn(List<Integer> values) {
            addCriterion("MerchantId in", values, "merchantid");
            return (Criteria) this;
        }

        public Criteria andMerchantidNotIn(List<Integer> values) {
            addCriterion("MerchantId not in", values, "merchantid");
            return (Criteria) this;
        }

        public Criteria andMerchantidBetween(Integer value1, Integer value2) {
            addCriterion("MerchantId between", value1, value2, "merchantid");
            return (Criteria) this;
        }

        public Criteria andMerchantidNotBetween(Integer value1, Integer value2) {
            addCriterion("MerchantId not between", value1, value2, "merchantid");
            return (Criteria) this;
        }

        public Criteria andEnterpriseIsNull() {
            addCriterion("Enterprise is null");
            return (Criteria) this;
        }

        public Criteria andEnterpriseIsNotNull() {
            addCriterion("Enterprise is not null");
            return (Criteria) this;
        }

        public Criteria andEnterpriseEqualTo(String value) {
            addCriterion("Enterprise =", value, "enterprise");
            return (Criteria) this;
        }

        public Criteria andEnterpriseNotEqualTo(String value) {
            addCriterion("Enterprise <>", value, "enterprise");
            return (Criteria) this;
        }

        public Criteria andEnterpriseGreaterThan(String value) {
            addCriterion("Enterprise >", value, "enterprise");
            return (Criteria) this;
        }

        public Criteria andEnterpriseGreaterThanOrEqualTo(String value) {
            addCriterion("Enterprise >=", value, "enterprise");
            return (Criteria) this;
        }

        public Criteria andEnterpriseLessThan(String value) {
            addCriterion("Enterprise <", value, "enterprise");
            return (Criteria) this;
        }

        public Criteria andEnterpriseLessThanOrEqualTo(String value) {
            addCriterion("Enterprise <=", value, "enterprise");
            return (Criteria) this;
        }

        public Criteria andEnterpriseLike(String value) {
            addCriterion("Enterprise like", value, "enterprise");
            return (Criteria) this;
        }

        public Criteria andEnterpriseNotLike(String value) {
            addCriterion("Enterprise not like", value, "enterprise");
            return (Criteria) this;
        }

        public Criteria andEnterpriseIn(List<String> values) {
            addCriterion("Enterprise in", values, "enterprise");
            return (Criteria) this;
        }

        public Criteria andEnterpriseNotIn(List<String> values) {
            addCriterion("Enterprise not in", values, "enterprise");
            return (Criteria) this;
        }

        public Criteria andEnterpriseBetween(String value1, String value2) {
            addCriterion("Enterprise between", value1, value2, "enterprise");
            return (Criteria) this;
        }

        public Criteria andEnterpriseNotBetween(String value1, String value2) {
            addCriterion("Enterprise not between", value1, value2, "enterprise");
            return (Criteria) this;
        }

        public Criteria andEnrolledgroupIsNull() {
            addCriterion("EnrolledGroup is null");
            return (Criteria) this;
        }

        public Criteria andEnrolledgroupIsNotNull() {
            addCriterion("EnrolledGroup is not null");
            return (Criteria) this;
        }

        public Criteria andEnrolledgroupEqualTo(String value) {
            addCriterion("EnrolledGroup =", value, "enrolledgroup");
            return (Criteria) this;
        }

        public Criteria andEnrolledgroupNotEqualTo(String value) {
            addCriterion("EnrolledGroup <>", value, "enrolledgroup");
            return (Criteria) this;
        }

        public Criteria andEnrolledgroupGreaterThan(String value) {
            addCriterion("EnrolledGroup >", value, "enrolledgroup");
            return (Criteria) this;
        }

        public Criteria andEnrolledgroupGreaterThanOrEqualTo(String value) {
            addCriterion("EnrolledGroup >=", value, "enrolledgroup");
            return (Criteria) this;
        }

        public Criteria andEnrolledgroupLessThan(String value) {
            addCriterion("EnrolledGroup <", value, "enrolledgroup");
            return (Criteria) this;
        }

        public Criteria andEnrolledgroupLessThanOrEqualTo(String value) {
            addCriterion("EnrolledGroup <=", value, "enrolledgroup");
            return (Criteria) this;
        }

        public Criteria andEnrolledgroupLike(String value) {
            addCriterion("EnrolledGroup like", value, "enrolledgroup");
            return (Criteria) this;
        }

        public Criteria andEnrolledgroupNotLike(String value) {
            addCriterion("EnrolledGroup not like", value, "enrolledgroup");
            return (Criteria) this;
        }

        public Criteria andEnrolledgroupIn(List<String> values) {
            addCriterion("EnrolledGroup in", values, "enrolledgroup");
            return (Criteria) this;
        }

        public Criteria andEnrolledgroupNotIn(List<String> values) {
            addCriterion("EnrolledGroup not in", values, "enrolledgroup");
            return (Criteria) this;
        }

        public Criteria andEnrolledgroupBetween(String value1, String value2) {
            addCriterion("EnrolledGroup between", value1, value2, "enrolledgroup");
            return (Criteria) this;
        }

        public Criteria andEnrolledgroupNotBetween(String value1, String value2) {
            addCriterion("EnrolledGroup not between", value1, value2, "enrolledgroup");
            return (Criteria) this;
        }

        public Criteria andContractnoIsNull() {
            addCriterion("ContractNo is null");
            return (Criteria) this;
        }

        public Criteria andContractnoIsNotNull() {
            addCriterion("ContractNo is not null");
            return (Criteria) this;
        }

        public Criteria andContractnoEqualTo(String value) {
            addCriterion("ContractNo =", value, "contractno");
            return (Criteria) this;
        }

        public Criteria andContractnoNotEqualTo(String value) {
            addCriterion("ContractNo <>", value, "contractno");
            return (Criteria) this;
        }

        public Criteria andContractnoGreaterThan(String value) {
            addCriterion("ContractNo >", value, "contractno");
            return (Criteria) this;
        }

        public Criteria andContractnoGreaterThanOrEqualTo(String value) {
            addCriterion("ContractNo >=", value, "contractno");
            return (Criteria) this;
        }

        public Criteria andContractnoLessThan(String value) {
            addCriterion("ContractNo <", value, "contractno");
            return (Criteria) this;
        }

        public Criteria andContractnoLessThanOrEqualTo(String value) {
            addCriterion("ContractNo <=", value, "contractno");
            return (Criteria) this;
        }

        public Criteria andContractnoLike(String value) {
            addCriterion("ContractNo like", value, "contractno");
            return (Criteria) this;
        }

        public Criteria andContractnoNotLike(String value) {
            addCriterion("ContractNo not like", value, "contractno");
            return (Criteria) this;
        }

        public Criteria andContractnoIn(List<String> values) {
            addCriterion("ContractNo in", values, "contractno");
            return (Criteria) this;
        }

        public Criteria andContractnoNotIn(List<String> values) {
            addCriterion("ContractNo not in", values, "contractno");
            return (Criteria) this;
        }

        public Criteria andContractnoBetween(String value1, String value2) {
            addCriterion("ContractNo between", value1, value2, "contractno");
            return (Criteria) this;
        }

        public Criteria andContractnoNotBetween(String value1, String value2) {
            addCriterion("ContractNo not between", value1, value2, "contractno");
            return (Criteria) this;
        }

        public Criteria andInnerbuymoneyIsNull() {
            addCriterion("InnerBuyMoney is null");
            return (Criteria) this;
        }

        public Criteria andInnerbuymoneyIsNotNull() {
            addCriterion("InnerBuyMoney is not null");
            return (Criteria) this;
        }

        public Criteria andInnerbuymoneyEqualTo(BigDecimal value) {
            addCriterion("InnerBuyMoney =", value, "innerbuymoney");
            return (Criteria) this;
        }

        public Criteria andInnerbuymoneyNotEqualTo(BigDecimal value) {
            addCriterion("InnerBuyMoney <>", value, "innerbuymoney");
            return (Criteria) this;
        }

        public Criteria andInnerbuymoneyGreaterThan(BigDecimal value) {
            addCriterion("InnerBuyMoney >", value, "innerbuymoney");
            return (Criteria) this;
        }

        public Criteria andInnerbuymoneyGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("InnerBuyMoney >=", value, "innerbuymoney");
            return (Criteria) this;
        }

        public Criteria andInnerbuymoneyLessThan(BigDecimal value) {
            addCriterion("InnerBuyMoney <", value, "innerbuymoney");
            return (Criteria) this;
        }

        public Criteria andInnerbuymoneyLessThanOrEqualTo(BigDecimal value) {
            addCriterion("InnerBuyMoney <=", value, "innerbuymoney");
            return (Criteria) this;
        }

        public Criteria andInnerbuymoneyIn(List<BigDecimal> values) {
            addCriterion("InnerBuyMoney in", values, "innerbuymoney");
            return (Criteria) this;
        }

        public Criteria andInnerbuymoneyNotIn(List<BigDecimal> values) {
            addCriterion("InnerBuyMoney not in", values, "innerbuymoney");
            return (Criteria) this;
        }

        public Criteria andInnerbuymoneyBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("InnerBuyMoney between", value1, value2, "innerbuymoney");
            return (Criteria) this;
        }

        public Criteria andInnerbuymoneyNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("InnerBuyMoney not between", value1, value2, "innerbuymoney");
            return (Criteria) this;
        }

        public Criteria andCommissionIsNull() {
            addCriterion("Commission is null");
            return (Criteria) this;
        }

        public Criteria andCommissionIsNotNull() {
            addCriterion("Commission is not null");
            return (Criteria) this;
        }

        public Criteria andCommissionEqualTo(BigDecimal value) {
            addCriterion("Commission =", value, "commission");
            return (Criteria) this;
        }

        public Criteria andCommissionNotEqualTo(BigDecimal value) {
            addCriterion("Commission <>", value, "commission");
            return (Criteria) this;
        }

        public Criteria andCommissionGreaterThan(BigDecimal value) {
            addCriterion("Commission >", value, "commission");
            return (Criteria) this;
        }

        public Criteria andCommissionGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("Commission >=", value, "commission");
            return (Criteria) this;
        }

        public Criteria andCommissionLessThan(BigDecimal value) {
            addCriterion("Commission <", value, "commission");
            return (Criteria) this;
        }

        public Criteria andCommissionLessThanOrEqualTo(BigDecimal value) {
            addCriterion("Commission <=", value, "commission");
            return (Criteria) this;
        }

        public Criteria andCommissionIn(List<BigDecimal> values) {
            addCriterion("Commission in", values, "commission");
            return (Criteria) this;
        }

        public Criteria andCommissionNotIn(List<BigDecimal> values) {
            addCriterion("Commission not in", values, "commission");
            return (Criteria) this;
        }

        public Criteria andCommissionBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("Commission between", value1, value2, "commission");
            return (Criteria) this;
        }

        public Criteria andCommissionNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("Commission not between", value1, value2, "commission");
            return (Criteria) this;
        }

        public Criteria andEnterprisecodeIsNull() {
            addCriterion("EnterpriseCode is null");
            return (Criteria) this;
        }

        public Criteria andEnterprisecodeIsNotNull() {
            addCriterion("EnterpriseCode is not null");
            return (Criteria) this;
        }

        public Criteria andEnterprisecodeEqualTo(String value) {
            addCriterion("EnterpriseCode =", value, "enterprisecode");
            return (Criteria) this;
        }

        public Criteria andEnterprisecodeNotEqualTo(String value) {
            addCriterion("EnterpriseCode <>", value, "enterprisecode");
            return (Criteria) this;
        }

        public Criteria andEnterprisecodeGreaterThan(String value) {
            addCriterion("EnterpriseCode >", value, "enterprisecode");
            return (Criteria) this;
        }

        public Criteria andEnterprisecodeGreaterThanOrEqualTo(String value) {
            addCriterion("EnterpriseCode >=", value, "enterprisecode");
            return (Criteria) this;
        }

        public Criteria andEnterprisecodeLessThan(String value) {
            addCriterion("EnterpriseCode <", value, "enterprisecode");
            return (Criteria) this;
        }

        public Criteria andEnterprisecodeLessThanOrEqualTo(String value) {
            addCriterion("EnterpriseCode <=", value, "enterprisecode");
            return (Criteria) this;
        }

        public Criteria andEnterprisecodeLike(String value) {
            addCriterion("EnterpriseCode like", value, "enterprisecode");
            return (Criteria) this;
        }

        public Criteria andEnterprisecodeNotLike(String value) {
            addCriterion("EnterpriseCode not like", value, "enterprisecode");
            return (Criteria) this;
        }

        public Criteria andEnterprisecodeIn(List<String> values) {
            addCriterion("EnterpriseCode in", values, "enterprisecode");
            return (Criteria) this;
        }

        public Criteria andEnterprisecodeNotIn(List<String> values) {
            addCriterion("EnterpriseCode not in", values, "enterprisecode");
            return (Criteria) this;
        }

        public Criteria andEnterprisecodeBetween(String value1, String value2) {
            addCriterion("EnterpriseCode between", value1, value2, "enterprisecode");
            return (Criteria) this;
        }

        public Criteria andEnterprisecodeNotBetween(String value1, String value2) {
            addCriterion("EnterpriseCode not between", value1, value2, "enterprisecode");
            return (Criteria) this;
        }

        public Criteria andRaiseidIsNull() {
            addCriterion("RaiseId is null");
            return (Criteria) this;
        }

        public Criteria andRaiseidIsNotNull() {
            addCriterion("RaiseId is not null");
            return (Criteria) this;
        }

        public Criteria andRaiseidEqualTo(String value) {
            addCriterion("RaiseId =", value, "raiseid");
            return (Criteria) this;
        }

        public Criteria andRaiseidNotEqualTo(String value) {
            addCriterion("RaiseId <>", value, "raiseid");
            return (Criteria) this;
        }

        public Criteria andRaiseidGreaterThan(String value) {
            addCriterion("RaiseId >", value, "raiseid");
            return (Criteria) this;
        }

        public Criteria andRaiseidGreaterThanOrEqualTo(String value) {
            addCriterion("RaiseId >=", value, "raiseid");
            return (Criteria) this;
        }

        public Criteria andRaiseidLessThan(String value) {
            addCriterion("RaiseId <", value, "raiseid");
            return (Criteria) this;
        }

        public Criteria andRaiseidLessThanOrEqualTo(String value) {
            addCriterion("RaiseId <=", value, "raiseid");
            return (Criteria) this;
        }

        public Criteria andRaiseidLike(String value) {
            addCriterion("RaiseId like", value, "raiseid");
            return (Criteria) this;
        }

        public Criteria andRaiseidNotLike(String value) {
            addCriterion("RaiseId not like", value, "raiseid");
            return (Criteria) this;
        }

        public Criteria andRaiseidIn(List<String> values) {
            addCriterion("RaiseId in", values, "raiseid");
            return (Criteria) this;
        }

        public Criteria andRaiseidNotIn(List<String> values) {
            addCriterion("RaiseId not in", values, "raiseid");
            return (Criteria) this;
        }

        public Criteria andRaiseidBetween(String value1, String value2) {
            addCriterion("RaiseId between", value1, value2, "raiseid");
            return (Criteria) this;
        }

        public Criteria andRaiseidNotBetween(String value1, String value2) {
            addCriterion("RaiseId not between", value1, value2, "raiseid");
            return (Criteria) this;
        }

        public Criteria andRaisemodeidIsNull() {
            addCriterion("RaiseModeId is null");
            return (Criteria) this;
        }

        public Criteria andRaisemodeidIsNotNull() {
            addCriterion("RaiseModeId is not null");
            return (Criteria) this;
        }

        public Criteria andRaisemodeidEqualTo(String value) {
            addCriterion("RaiseModeId =", value, "raisemodeid");
            return (Criteria) this;
        }

        public Criteria andRaisemodeidNotEqualTo(String value) {
            addCriterion("RaiseModeId <>", value, "raisemodeid");
            return (Criteria) this;
        }

        public Criteria andRaisemodeidGreaterThan(String value) {
            addCriterion("RaiseModeId >", value, "raisemodeid");
            return (Criteria) this;
        }

        public Criteria andRaisemodeidGreaterThanOrEqualTo(String value) {
            addCriterion("RaiseModeId >=", value, "raisemodeid");
            return (Criteria) this;
        }

        public Criteria andRaisemodeidLessThan(String value) {
            addCriterion("RaiseModeId <", value, "raisemodeid");
            return (Criteria) this;
        }

        public Criteria andRaisemodeidLessThanOrEqualTo(String value) {
            addCriterion("RaiseModeId <=", value, "raisemodeid");
            return (Criteria) this;
        }

        public Criteria andRaisemodeidLike(String value) {
            addCriterion("RaiseModeId like", value, "raisemodeid");
            return (Criteria) this;
        }

        public Criteria andRaisemodeidNotLike(String value) {
            addCriterion("RaiseModeId not like", value, "raisemodeid");
            return (Criteria) this;
        }

        public Criteria andRaisemodeidIn(List<String> values) {
            addCriterion("RaiseModeId in", values, "raisemodeid");
            return (Criteria) this;
        }

        public Criteria andRaisemodeidNotIn(List<String> values) {
            addCriterion("RaiseModeId not in", values, "raisemodeid");
            return (Criteria) this;
        }

        public Criteria andRaisemodeidBetween(String value1, String value2) {
            addCriterion("RaiseModeId between", value1, value2, "raisemodeid");
            return (Criteria) this;
        }

        public Criteria andRaisemodeidNotBetween(String value1, String value2) {
            addCriterion("RaiseModeId not between", value1, value2, "raisemodeid");
            return (Criteria) this;
        }

        public Criteria andLenovoidIsNull() {
            addCriterion("LenovoID is null");
            return (Criteria) this;
        }

        public Criteria andLenovoidIsNotNull() {
            addCriterion("LenovoID is not null");
            return (Criteria) this;
        }

        public Criteria andLenovoidEqualTo(String value) {
            addCriterion("LenovoID =", value, "lenovoid");
            return (Criteria) this;
        }

        public Criteria andLenovoidNotEqualTo(String value) {
            addCriterion("LenovoID <>", value, "lenovoid");
            return (Criteria) this;
        }

        public Criteria andLenovoidGreaterThan(String value) {
            addCriterion("LenovoID >", value, "lenovoid");
            return (Criteria) this;
        }

        public Criteria andLenovoidGreaterThanOrEqualTo(String value) {
            addCriterion("LenovoID >=", value, "lenovoid");
            return (Criteria) this;
        }

        public Criteria andLenovoidLessThan(String value) {
            addCriterion("LenovoID <", value, "lenovoid");
            return (Criteria) this;
        }

        public Criteria andLenovoidLessThanOrEqualTo(String value) {
            addCriterion("LenovoID <=", value, "lenovoid");
            return (Criteria) this;
        }

        public Criteria andLenovoidLike(String value) {
            addCriterion("LenovoID like", value, "lenovoid");
            return (Criteria) this;
        }

        public Criteria andLenovoidNotLike(String value) {
            addCriterion("LenovoID not like", value, "lenovoid");
            return (Criteria) this;
        }

        public Criteria andLenovoidIn(List<String> values) {
            addCriterion("LenovoID in", values, "lenovoid");
            return (Criteria) this;
        }

        public Criteria andLenovoidNotIn(List<String> values) {
            addCriterion("LenovoID not in", values, "lenovoid");
            return (Criteria) this;
        }

        public Criteria andLenovoidBetween(String value1, String value2) {
            addCriterion("LenovoID between", value1, value2, "lenovoid");
            return (Criteria) this;
        }

        public Criteria andLenovoidNotBetween(String value1, String value2) {
            addCriterion("LenovoID not between", value1, value2, "lenovoid");
            return (Criteria) this;
        }

        public Criteria andFullreduceIsNull() {
            addCriterion("FullReduce is null");
            return (Criteria) this;
        }

        public Criteria andFullreduceIsNotNull() {
            addCriterion("FullReduce is not null");
            return (Criteria) this;
        }

        public Criteria andFullreduceEqualTo(Long value) {
            addCriterion("FullReduce =", value, "fullreduce");
            return (Criteria) this;
        }

        public Criteria andFullreduceNotEqualTo(Long value) {
            addCriterion("FullReduce <>", value, "fullreduce");
            return (Criteria) this;
        }

        public Criteria andFullreduceGreaterThan(Long value) {
            addCriterion("FullReduce >", value, "fullreduce");
            return (Criteria) this;
        }

        public Criteria andFullreduceGreaterThanOrEqualTo(Long value) {
            addCriterion("FullReduce >=", value, "fullreduce");
            return (Criteria) this;
        }

        public Criteria andFullreduceLessThan(Long value) {
            addCriterion("FullReduce <", value, "fullreduce");
            return (Criteria) this;
        }

        public Criteria andFullreduceLessThanOrEqualTo(Long value) {
            addCriterion("FullReduce <=", value, "fullreduce");
            return (Criteria) this;
        }

        public Criteria andFullreduceIn(List<Long> values) {
            addCriterion("FullReduce in", values, "fullreduce");
            return (Criteria) this;
        }

        public Criteria andFullreduceNotIn(List<Long> values) {
            addCriterion("FullReduce not in", values, "fullreduce");
            return (Criteria) this;
        }

        public Criteria andFullreduceBetween(Long value1, Long value2) {
            addCriterion("FullReduce between", value1, value2, "fullreduce");
            return (Criteria) this;
        }

        public Criteria andFullreduceNotBetween(Long value1, Long value2) {
            addCriterion("FullReduce not between", value1, value2, "fullreduce");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}