package com.lenovo.m2.couponV2.dao.mybatis.model;

import com.lenovo.m2.couponV2.common.BaseObject;

import java.util.Date;

/**
 * Created by zhanghb2 on 2016/6/16.
 */
public class KcodeResultInfo extends BaseObject {
    private String kcode;//K码
    private String productCode;//商品code
    private Integer invalid;
    private Integer status;
    private Date fromtime;
    private Date totime;
    private Integer isUsed;

    public String getKcode() {
        return kcode;
    }

    public void setKcode(String kcode) {
        this.kcode = kcode;
    }

    public String getProductCode() {
        return productCode;
    }

    public void setProductCode(String productCode) {
        this.productCode = productCode;
    }

    public Integer getInvalid() {
        return invalid;
    }

    public void setInvalid(Integer invalid) {
        this.invalid = invalid;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Date getFromtime() {
        return fromtime;
    }

    public void setFromtime(Date fromtime) {
        this.fromtime = fromtime;
    }

    public Date getTotime() {
        return totime;
    }

    public void setTotime(Date totime) {
        this.totime = totime;
    }

    public Integer getIsUsed() {
        return isUsed;
    }

    public void setIsUsed(Integer isUsed) {
        this.isUsed = isUsed;
    }

    @Override
    public String toString() {
        return "";
    }

    @Override
    public boolean equals(Object paramObject) {
        return false;
    }

    @Override
    public int hashCode() {
        return 0;
    }
}
