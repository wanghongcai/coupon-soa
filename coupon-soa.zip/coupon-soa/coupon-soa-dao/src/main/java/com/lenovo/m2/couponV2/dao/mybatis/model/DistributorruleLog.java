package com.lenovo.m2.couponV2.dao.mybatis.model;

/**
 * Created by fenglg1 on 2016/11/28.
 */
public class DistributorruleLog extends Distributorrule {

    /**
     * 主键（自增）
     */
    private Long logId;
    /**
     * 记录日志的批次号
     */
    private Long logBatch;

    public Long getLogId() {
        return logId;
    }

    public void setLogId(Long logId) {
        this.logId = logId;
    }

    public Long getLogBatch() {
        return logBatch;
    }

    public void setLogBatch(Long logBatch) {
        this.logBatch = logBatch;
    }
}
