package com.lenovo.m2.couponV2.dao.mybatis.model;

import com.lenovo.m2.arch.framework.domain.Money;
import com.lenovo.m2.couponV2.common.BaseObject;
import org.codehaus.jackson.map.deser.ValueInstantiators;

import java.util.Date;

/**
 * Created by fenglg1 on 2017/1/9.
 */
public class CouponReport extends BaseObject {
    /**
     * 优惠券主键
     */
    private Long id;
    /**
     * LenovoID
     */
    private String lenovoid;
    /**
     * 会员帐号
     */
    private String membercode;
    /**
     * 优惠券ID
     */
    private Long salescouponid;
    /**
     * 优惠券名称
     */
    private String name;
    /**
     * 优惠券面值
     */
    private Money amount;
    /**
     * 币种
     */
    private String currencyCode;
    /**
     * 优惠券使用状态  0：未使用  1：已使用
     */
    private Integer status;
    /**
     * 优惠券使用时间
     */
    private Date usetime;
    /**
     * 订单号（主单号）
     */
    private String orderId;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getLenovoid() {
        return lenovoid;
    }

    public void setLenovoid(String lenovoid) {
        this.lenovoid = lenovoid;
    }

    public String getMembercode() {
        return membercode;
    }

    public void setMembercode(String membercode) {
        this.membercode = membercode;
    }

    public Long getSalescouponid() {
        return salescouponid;
    }

    public void setSalescouponid(Long salescouponid) {
        this.salescouponid = salescouponid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Money getAmount() {
        return amount;
    }

    public void setAmount(Money amount) {
        this.amount = amount;
    }

    public String getCurrencyCode() {
        return currencyCode;
    }

    public void setCurrencyCode(String currencyCode) {
        this.currencyCode = currencyCode;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Date getUsetime() {
        return usetime;
    }

    public void setUsetime(Date usetime) {
        this.usetime = usetime;
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        CouponReport that = (CouponReport) o;

        if (amount != null ? !amount.equals(that.amount) : that.amount != null) return false;
        if (currencyCode != null ? !currencyCode.equals(that.currencyCode) : that.currencyCode != null) return false;
        if (id != null ? !id.equals(that.id) : that.id != null) return false;
        if (lenovoid != null ? !lenovoid.equals(that.lenovoid) : that.lenovoid != null) return false;
        if (membercode != null ? !membercode.equals(that.membercode) : that.membercode != null) return false;
        if (name != null ? !name.equals(that.name) : that.name != null) return false;
        if (orderId != null ? !orderId.equals(that.orderId) : that.orderId != null) return false;
        if (salescouponid != null ? !salescouponid.equals(that.salescouponid) : that.salescouponid != null)
            return false;
        if (status != null ? !status.equals(that.status) : that.status != null) return false;
        if (usetime != null ? !usetime.equals(that.usetime) : that.usetime != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = id != null ? id.hashCode() : 0;
        result = 31 * result + (lenovoid != null ? lenovoid.hashCode() : 0);
        result = 31 * result + (membercode != null ? membercode.hashCode() : 0);
        result = 31 * result + (salescouponid != null ? salescouponid.hashCode() : 0);
        result = 31 * result + (name != null ? name.hashCode() : 0);
        result = 31 * result + (amount != null ? amount.hashCode() : 0);
        result = 31 * result + (currencyCode != null ? currencyCode.hashCode() : 0);
        result = 31 * result + (status != null ? status.hashCode() : 0);
        result = 31 * result + (usetime != null ? usetime.hashCode() : 0);
        result = 31 * result + (orderId != null ? orderId.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "CouponReport{" +
                "id=" + id +
                ", lenovoid='" + lenovoid + '\'' +
                ", membercode='" + membercode + '\'' +
                ", salescouponid=" + salescouponid +
                ", name='" + name + '\'' +
                ", amount=" + amount +
                ", currencyCode='" + currencyCode + '\'' +
                ", status=" + status +
                ", usetime=" + usetime +
                ", orderId='" + orderId + '\'' +
                '}';
    }
}
