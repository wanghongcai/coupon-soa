package com.lenovo.m2.couponV2.dao.mybatis.mapper;

import com.lenovo.m2.couponV2.dao.mybatis.model.DetailsruleLog;
import com.lenovo.m2.couponV2.dao.mybatis.model.DistributorruleLog;

import java.util.List;

/**
 * Created by fenglg1 on 2016/11/30.
 */
public interface DistributorruleLogMapper {

    /**
     * 保存绑定产品组规则日志
     * @param distributorruleLogList
     * @return
     */
    int insertDistributorruleLog(List<DistributorruleLog> distributorruleLogList);
}
