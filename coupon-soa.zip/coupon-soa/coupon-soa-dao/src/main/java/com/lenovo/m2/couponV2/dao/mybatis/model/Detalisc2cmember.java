package com.lenovo.m2.couponV2.dao.mybatis.model;

import java.util.Date;

public class Detalisc2cmember implements java.io.Serializable {
    private Long id;

    private String lenovoid;

    private String membercode;

    private String orderid;

    private Date paytime;

    private String status;

    private Integer xpintegral;

    private Date createtime;

    private Date updatetime;

    private String createby;

    private String updateby;

    private Integer sumintegral;
    public Integer getSumintegral() {
        return sumintegral;
    }

    public void setSumintegral(Integer sumintegral) {
        this.sumintegral = sumintegral;
    }
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getLenovoid() {
        return lenovoid;
    }

    public void setLenovoid(String lenovoid) {
        this.lenovoid = lenovoid;
    }

    public String getMembercode() {
        return membercode;
    }

    public void setMembercode(String membercode) {
        this.membercode = membercode;
    }

    public String getOrderid() {
        return orderid;
    }

    public void setOrderid(String orderid) {
        this.orderid = orderid;
    }

    public Date getPaytime() {
        return paytime;
    }

    public void setPaytime(Date paytime) {
        this.paytime = paytime;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Integer getXpintegral() {
        return xpintegral;
    }

    public void setXpintegral(Integer xpintegral) {
        this.xpintegral = xpintegral;
    }

    public Date getCreatetime() {
        return createtime;
    }

    public void setCreatetime(Date createtime) {
        this.createtime = createtime;
    }

    public Date getUpdatetime() {
        return updatetime;
    }

    public void setUpdatetime(Date updatetime) {
        this.updatetime = updatetime;
    }

    public String getCreateby() {
        return createby;
    }

    public void setCreateby(String createby) {
        this.createby = createby;
    }

    public String getUpdateby() {
        return updateby;
    }

    public void setUpdateby(String updateby) {
        this.updateby = updateby;
    }
}