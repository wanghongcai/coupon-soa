package com.lenovo.m2.couponV2.dao.mybatis.mapper;

import com.lenovo.m2.arch.framework.domain.PageModel2;
import com.lenovo.m2.arch.framework.domain.PageQuery;
import com.lenovo.m2.couponV2.dao.mybatis.model.OneKeyToReceive;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

/**
 * Created by pxg01 on 2017/7/4.
 */
public interface OneKeyToReceiveMapper {

    OneKeyToReceive getActivityName(String activityName);
    int addReceiveActivity(OneKeyToReceive list);
    int editReceiveActivity(OneKeyToReceive list);
    int deleteReceiveActivity(Map map);
    /*查看活动信息*/
    List<OneKeyToReceive> getReceiveActivityByCondityon(PageQuery pageQuery, Map map);
    List<OneKeyToReceive> getReceiveActivity(PageQuery pageQuery, Map map);
    List<OneKeyToReceive> getReceiveActivityForBinds(Map map);

    String confirmUserIfJoinTheAcitity(@Param("lenovoId") String lenovoId, @Param("activityType")Integer activityType,@Param("activityName")String activityName);
    int saveOnekeygetinfo(Map map);
    OneKeyToReceive getActivityInfoById(@Param("id")Long id);
    int  setOnekeyUseable(@Param("id") Long id, @Param("useable") Integer useable,@Param("itcode") String itcode);
    Integer selectAnyActivityIsHolding();
}
