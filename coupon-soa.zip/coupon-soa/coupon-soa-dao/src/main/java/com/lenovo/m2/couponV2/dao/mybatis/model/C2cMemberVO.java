package com.lenovo.m2.couponV2.dao.mybatis.model;

import java.util.Date;

/**
 * Created by zhanglijun on 2016/1/7.
 */
public class C2cMemberVO extends C2cMember {

    private String orderid;
    private Date   paytime;
    private String status;
    private Integer xpintegral;

    public String getOrderid() {
        return orderid;
    }

    public void setOrderid(String orderid) {
        this.orderid = orderid;
    }

    public Date getPaytime() {
        return paytime;
    }

    public void setPaytime(Date paytime) {
        this.paytime = paytime;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Integer getXpintegral() {
        return xpintegral;
    }

    public void setXpintegral(Integer xpintegral) {
        this.xpintegral = xpintegral;
    }

    @Override
    public String toString() {
        return "C2cMemberVO{" +
                "orderid='" + orderid + '\'' +
                ", paytime=" + paytime +
                ", status='" + status + '\'' +
                ", xpintegral=" + xpintegral +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;

        C2cMemberVO that = (C2cMemberVO) o;

        if (orderid != null ? !orderid.equals(that.orderid) : that.orderid != null) return false;
        if (paytime != null ? !paytime.equals(that.paytime) : that.paytime != null) return false;
        if (status != null ? !status.equals(that.status) : that.status != null) return false;
        return !(xpintegral != null ? !xpintegral.equals(that.xpintegral) : that.xpintegral != null);

    }

    @Override
    public int hashCode() {
        int result = super.hashCode();
        result = 31 * result + (orderid != null ? orderid.hashCode() : 0);
        result = 31 * result + (paytime != null ? paytime.hashCode() : 0);
        result = 31 * result + (status != null ? status.hashCode() : 0);
        result = 31 * result + (xpintegral != null ? xpintegral.hashCode() : 0);
        return result;
    }
}
