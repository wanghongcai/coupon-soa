package com.lenovo.m2.couponV2.dao.mybatis.model;

import com.lenovo.m2.couponV2.common.BaseObject;

import java.util.Date;

/**
 * Created by fenglg1 on 2016/12/14.
 */
public class AvailableSalescoupons extends BaseObject {

    /**
     * 主键
     */
    private Long id;

    /**
     * 优惠券ID
     */
    private Long salesCouponsID;

    /**
     * 创建时间（前台可领取时间）
     */
    private Date createTime;

    /**
     * 操作人
     */
    private String createBy;
    //显示位置 0，个人中心，1，小新
    private String displayPosition;


    public String getDisplayPosition() {
        return displayPosition;
    }

    public void setDisplayPosition(String displayPosition) {
        this.displayPosition = displayPosition;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getSalesCouponsID() {
        return salesCouponsID;
    }

    public void setSalesCouponsID(Long salesCouponsID) {
        this.salesCouponsID = salesCouponsID;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getCreateBy() {
        return createBy;
    }

    public void setCreateBy(String createBy) {
        this.createBy = createBy;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        AvailableSalescoupons that = (AvailableSalescoupons) o;

        if (createBy != null ? !createBy.equals(that.createBy) : that.createBy != null) return false;
        if (createTime != null ? !createTime.equals(that.createTime) : that.createTime != null) return false;
        if (id != null ? !id.equals(that.id) : that.id != null) return false;
        if (salesCouponsID != null ? !salesCouponsID.equals(that.salesCouponsID) : that.salesCouponsID != null)
            return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = id != null ? id.hashCode() : 0;
        result = 31 * result + (salesCouponsID != null ? salesCouponsID.hashCode() : 0);
        result = 31 * result + (createTime != null ? createTime.hashCode() : 0);
        result = 31 * result + (createBy != null ? createBy.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "AvailableSalescoupons{" +
                "id=" + id +
                ", salesCouponsID=" + salesCouponsID +
                ", createTime=" + createTime +
                ", createBy='" + createBy + '\'' +
                '}';
    }
}
