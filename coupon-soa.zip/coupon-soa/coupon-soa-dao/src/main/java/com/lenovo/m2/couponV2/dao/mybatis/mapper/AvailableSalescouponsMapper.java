package com.lenovo.m2.couponV2.dao.mybatis.mapper;

import com.lenovo.m2.arch.framework.domain.PageModel;
import com.lenovo.m2.arch.framework.domain.PageQuery;
import com.lenovo.m2.couponV2.dao.mybatis.model.AvailableSalescoupons;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

/**
 * Created by fenglg1 on 2016/12/14.
 */
public interface AvailableSalescouponsMapper {

    /**
     * 查询所有可领取的优惠券列表
     * @return
     */
    List<AvailableSalescoupons> getAllAvailableSalescoupons();

    /**
     * 根据优惠券ID查询可领取的优惠券
     * @param salesCouponsId
     * @return
     */
    List<AvailableSalescoupons> getAvailableSalescouponsByCouponId(Long salesCouponsId);

    /**
     * 保存选中的可领取的优惠券
     * @param availableSalescouponsList
     * @return
     */
    int saveAvailableSalescoupons(List<AvailableSalescoupons> availableSalescouponsList);

    /**
     * 根据主键 和 优惠券ID 删除可领取的优惠券
     * @param salesCouponsId
     * @return
     */
    int deleteAvailableSalescoupons(@Param(value = "salesCouponsID") Long salesCouponsId,@Param(value = "displayPosition") String displayPosition);

    /**
     * 删除所有可领取的优惠券
     * @return
     */
    int deleteAllAvailableSalescoupons();
}
