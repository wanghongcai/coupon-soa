package com.lenovo.m2.couponV2.dao.mybatis.model;

import java.math.BigDecimal;
import java.util.Date;

public class Ordermains {
    private String id;

    private Integer source;

    private String payorderno;

    private String ordermaincode;

    private String ordercode;

    private String vkorg;

    private String saleschannel;

    private String memberid;

    private String membercode;

    private String c1lenovoid;

    private String typeid;

    private Integer orderaddtype;

    private Integer salesordertype;

    private BigDecimal costitem;

    private BigDecimal amountmoney;

    private BigDecimal giveawaycost;

    private BigDecimal giveawaytotal;

    private BigDecimal vouchertotalamount;

    private BigDecimal giftcardtotalamount;

    private Integer credittotal;

    private Integer paystatus;

    private Date paydatetime;

    private Date expectdate;

    private String augru;

    private String paymentday;

    private String biztype;

    private Boolean isdelivery;

    private Boolean istax;

    private String taxcontent;

    private String taxcompany;

    private Integer shipstatus;

    private Integer status;

    private Integer isreturn;

    private String marktext;

    private String memberdesc;

    private String addonstr;

    private String orderrefer;

    private String returngoodsremark;

    private Integer fatype;

    private String faid;

    private String faname;

    private Boolean isqualified;

    private String isabnormal;

    private String hascomment;

    private Date createtime;

    private String createby;

    private Date updatetime;

    private String updateby;

    private Integer usedledounum;

    private Integer rewardledounum;

    private Integer merchantid;

    private String enterprise;

    private String enrolledgroup;

    private String contractno;

    private BigDecimal innerbuymoney;

    private BigDecimal commission;

    private String enterprisecode;

    private String raiseid;

    private String raisemodeid;

    private String lenovoid;

    private Long fullreduce;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Integer getSource() {
        return source;
    }

    public void setSource(Integer source) {
        this.source = source;
    }

    public String getPayorderno() {
        return payorderno;
    }

    public void setPayorderno(String payorderno) {
        this.payorderno = payorderno;
    }

    public String getOrdermaincode() {
        return ordermaincode;
    }

    public void setOrdermaincode(String ordermaincode) {
        this.ordermaincode = ordermaincode;
    }

    public String getOrdercode() {
        return ordercode;
    }

    public void setOrdercode(String ordercode) {
        this.ordercode = ordercode;
    }

    public String getVkorg() {
        return vkorg;
    }

    public void setVkorg(String vkorg) {
        this.vkorg = vkorg;
    }

    public String getSaleschannel() {
        return saleschannel;
    }

    public void setSaleschannel(String saleschannel) {
        this.saleschannel = saleschannel;
    }

    public String getMemberid() {
        return memberid;
    }

    public void setMemberid(String memberid) {
        this.memberid = memberid;
    }

    public String getMembercode() {
        return membercode;
    }

    public void setMembercode(String membercode) {
        this.membercode = membercode;
    }

    public String getC1lenovoid() {
        return c1lenovoid;
    }

    public void setC1lenovoid(String c1lenovoid) {
        this.c1lenovoid = c1lenovoid;
    }

    public String getTypeid() {
        return typeid;
    }

    public void setTypeid(String typeid) {
        this.typeid = typeid;
    }

    public Integer getOrderaddtype() {
        return orderaddtype;
    }

    public void setOrderaddtype(Integer orderaddtype) {
        this.orderaddtype = orderaddtype;
    }

    public Integer getSalesordertype() {
        return salesordertype;
    }

    public void setSalesordertype(Integer salesordertype) {
        this.salesordertype = salesordertype;
    }

    public BigDecimal getCostitem() {
        return costitem;
    }

    public void setCostitem(BigDecimal costitem) {
        this.costitem = costitem;
    }

    public BigDecimal getAmountmoney() {
        return amountmoney;
    }

    public void setAmountmoney(BigDecimal amountmoney) {
        this.amountmoney = amountmoney;
    }

    public BigDecimal getGiveawaycost() {
        return giveawaycost;
    }

    public void setGiveawaycost(BigDecimal giveawaycost) {
        this.giveawaycost = giveawaycost;
    }

    public BigDecimal getGiveawaytotal() {
        return giveawaytotal;
    }

    public void setGiveawaytotal(BigDecimal giveawaytotal) {
        this.giveawaytotal = giveawaytotal;
    }

    public BigDecimal getVouchertotalamount() {
        return vouchertotalamount;
    }

    public void setVouchertotalamount(BigDecimal vouchertotalamount) {
        this.vouchertotalamount = vouchertotalamount;
    }

    public BigDecimal getGiftcardtotalamount() {
        return giftcardtotalamount;
    }

    public void setGiftcardtotalamount(BigDecimal giftcardtotalamount) {
        this.giftcardtotalamount = giftcardtotalamount;
    }

    public Integer getCredittotal() {
        return credittotal;
    }

    public void setCredittotal(Integer credittotal) {
        this.credittotal = credittotal;
    }

    public Integer getPaystatus() {
        return paystatus;
    }

    public void setPaystatus(Integer paystatus) {
        this.paystatus = paystatus;
    }

    public Date getPaydatetime() {
        return paydatetime;
    }

    public void setPaydatetime(Date paydatetime) {
        this.paydatetime = paydatetime;
    }

    public Date getExpectdate() {
        return expectdate;
    }

    public void setExpectdate(Date expectdate) {
        this.expectdate = expectdate;
    }

    public String getAugru() {
        return augru;
    }

    public void setAugru(String augru) {
        this.augru = augru;
    }

    public String getPaymentday() {
        return paymentday;
    }

    public void setPaymentday(String paymentday) {
        this.paymentday = paymentday;
    }

    public String getBiztype() {
        return biztype;
    }

    public void setBiztype(String biztype) {
        this.biztype = biztype;
    }

    public Boolean getIsdelivery() {
        return isdelivery;
    }

    public void setIsdelivery(Boolean isdelivery) {
        this.isdelivery = isdelivery;
    }

    public Boolean getIstax() {
        return istax;
    }

    public void setIstax(Boolean istax) {
        this.istax = istax;
    }

    public String getTaxcontent() {
        return taxcontent;
    }

    public void setTaxcontent(String taxcontent) {
        this.taxcontent = taxcontent;
    }

    public String getTaxcompany() {
        return taxcompany;
    }

    public void setTaxcompany(String taxcompany) {
        this.taxcompany = taxcompany;
    }

    public Integer getShipstatus() {
        return shipstatus;
    }

    public void setShipstatus(Integer shipstatus) {
        this.shipstatus = shipstatus;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Integer getIsreturn() {
        return isreturn;
    }

    public void setIsreturn(Integer isreturn) {
        this.isreturn = isreturn;
    }

    public String getMarktext() {
        return marktext;
    }

    public void setMarktext(String marktext) {
        this.marktext = marktext;
    }

    public String getMemberdesc() {
        return memberdesc;
    }

    public void setMemberdesc(String memberdesc) {
        this.memberdesc = memberdesc;
    }

    public String getAddonstr() {
        return addonstr;
    }

    public void setAddonstr(String addonstr) {
        this.addonstr = addonstr;
    }

    public String getOrderrefer() {
        return orderrefer;
    }

    public void setOrderrefer(String orderrefer) {
        this.orderrefer = orderrefer;
    }

    public String getReturngoodsremark() {
        return returngoodsremark;
    }

    public void setReturngoodsremark(String returngoodsremark) {
        this.returngoodsremark = returngoodsremark;
    }

    public Integer getFatype() {
        return fatype;
    }

    public void setFatype(Integer fatype) {
        this.fatype = fatype;
    }

    public String getFaid() {
        return faid;
    }

    public void setFaid(String faid) {
        this.faid = faid;
    }

    public String getFaname() {
        return faname;
    }

    public void setFaname(String faname) {
        this.faname = faname;
    }

    public Boolean getIsqualified() {
        return isqualified;
    }

    public void setIsqualified(Boolean isqualified) {
        this.isqualified = isqualified;
    }

    public String getIsabnormal() {
        return isabnormal;
    }

    public void setIsabnormal(String isabnormal) {
        this.isabnormal = isabnormal;
    }

    public String getHascomment() {
        return hascomment;
    }

    public void setHascomment(String hascomment) {
        this.hascomment = hascomment;
    }

    public Date getCreatetime() {
        return createtime;
    }

    public void setCreatetime(Date createtime) {
        this.createtime = createtime;
    }

    public String getCreateby() {
        return createby;
    }

    public void setCreateby(String createby) {
        this.createby = createby;
    }

    public Date getUpdatetime() {
        return updatetime;
    }

    public void setUpdatetime(Date updatetime) {
        this.updatetime = updatetime;
    }

    public String getUpdateby() {
        return updateby;
    }

    public void setUpdateby(String updateby) {
        this.updateby = updateby;
    }

    public Integer getUsedledounum() {
        return usedledounum;
    }

    public void setUsedledounum(Integer usedledounum) {
        this.usedledounum = usedledounum;
    }

    public Integer getRewardledounum() {
        return rewardledounum;
    }

    public void setRewardledounum(Integer rewardledounum) {
        this.rewardledounum = rewardledounum;
    }

    public Integer getMerchantid() {
        return merchantid;
    }

    public void setMerchantid(Integer merchantid) {
        this.merchantid = merchantid;
    }

    public String getEnterprise() {
        return enterprise;
    }

    public void setEnterprise(String enterprise) {
        this.enterprise = enterprise;
    }

    public String getEnrolledgroup() {
        return enrolledgroup;
    }

    public void setEnrolledgroup(String enrolledgroup) {
        this.enrolledgroup = enrolledgroup;
    }

    public String getContractno() {
        return contractno;
    }

    public void setContractno(String contractno) {
        this.contractno = contractno;
    }

    public BigDecimal getInnerbuymoney() {
        return innerbuymoney;
    }

    public void setInnerbuymoney(BigDecimal innerbuymoney) {
        this.innerbuymoney = innerbuymoney;
    }

    public BigDecimal getCommission() {
        return commission;
    }

    public void setCommission(BigDecimal commission) {
        this.commission = commission;
    }

    public String getEnterprisecode() {
        return enterprisecode;
    }

    public void setEnterprisecode(String enterprisecode) {
        this.enterprisecode = enterprisecode;
    }

    public String getRaiseid() {
        return raiseid;
    }

    public void setRaiseid(String raiseid) {
        this.raiseid = raiseid;
    }

    public String getRaisemodeid() {
        return raisemodeid;
    }

    public void setRaisemodeid(String raisemodeid) {
        this.raisemodeid = raisemodeid;
    }

    public String getLenovoid() {
        return lenovoid;
    }

    public void setLenovoid(String lenovoid) {
        this.lenovoid = lenovoid;
    }

    public Long getFullreduce() {
        return fullreduce;
    }

    public void setFullreduce(Long fullreduce) {
        this.fullreduce = fullreduce;
    }
}