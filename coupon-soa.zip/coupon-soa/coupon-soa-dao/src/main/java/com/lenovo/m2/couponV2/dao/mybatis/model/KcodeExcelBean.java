package com.lenovo.m2.couponV2.dao.mybatis.model;

import com.lenovo.m2.couponV2.common.BaseObject;

import java.util.Date;

/**
 * Created by yezhenyue on 2016/6/21.
 */
public class KcodeExcelBean extends BaseObject{
    private Long id;//L码表主键ID
    private Long kcodeInfoId;//L码基本信息主键ID
    private String batchno;//批次号
    private String kName;//L码名称
    private String kcode;//L码
    private Date fromtime;//有效开始时间
    private Date totime;//有效结束时间
    private Integer isused;//是否使用
    private String createby;//创建人
    private Date createTime;//创建时间

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getKcodeInfoId() {
        return kcodeInfoId;
    }

    public void setKcodeInfoId(Long kcodeInfoId) {
        this.kcodeInfoId = kcodeInfoId;
    }

    public String getBatchno() {
        return batchno;
    }

    public void setBatchno(String batchno) {
        this.batchno = batchno;
    }

    public String getKName() {
        return kName;
    }

    public void setKName(String kName) {
        this.kName = kName;
    }

    public String getKcode() {
        return kcode;
    }

    public void setKcode(String kcode) {
        this.kcode = kcode;
    }

    public Date getFromtime() {
        return fromtime;
    }

    public void setFromtime(Date fromtime) {
        this.fromtime = fromtime;
    }

    public Date getTotime() {
        return totime;
    }

    public void setTotime(Date totime) {
        this.totime = totime;
    }

    public Integer getIsused() {
        return isused;
    }

    public void setIsused(Integer isused) {
        this.isused = isused;
    }

    public String getCreateby() {
        return createby;
    }

    public void setCreateby(String createby) {
        this.createby = createby;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        KcodeExcelBean that = (KcodeExcelBean) o;

        if (getId() != null ? !getId().equals(that.getId()) : that.getId() != null) return false;
        if (getKcodeInfoId() != null ? !getKcodeInfoId().equals(that.getKcodeInfoId()) : that.getKcodeInfoId() != null)
            return false;
        if (getBatchno() != null ? !getBatchno().equals(that.getBatchno()) : that.getBatchno() != null) return false;
        if (getKName() != null ? !getKName().equals(that.getKName()) : that.getKName() != null) return false;
        if (getKcode() != null ? !getKcode().equals(that.getKcode()) : that.getKcode() != null) return false;
        if (getFromtime() != null ? !getFromtime().equals(that.getFromtime()) : that.getFromtime() != null)
            return false;
        if (getTotime() != null ? !getTotime().equals(that.getTotime()) : that.getTotime() != null) return false;
        if (getIsused() != null ? !getIsused().equals(that.getIsused()) : that.getIsused() != null) return false;
        if (getCreateby() != null ? !getCreateby().equals(that.getCreateby()) : that.getCreateby() != null)
            return false;
        return !(getCreateTime() != null ? !getCreateTime().equals(that.getCreateTime()) : that.getCreateTime() != null);

    }

    @Override
    public int hashCode() {
        int result = getId() != null ? getId().hashCode() : 0;
        result = 31 * result + (getKcodeInfoId() != null ? getKcodeInfoId().hashCode() : 0);
        result = 31 * result + (getBatchno() != null ? getBatchno().hashCode() : 0);
        result = 31 * result + (getKName() != null ? getKName().hashCode() : 0);
        result = 31 * result + (getKcode() != null ? getKcode().hashCode() : 0);
        result = 31 * result + (getFromtime() != null ? getFromtime().hashCode() : 0);
        result = 31 * result + (getTotime() != null ? getTotime().hashCode() : 0);
        result = 31 * result + (getIsused() != null ? getIsused().hashCode() : 0);
        result = 31 * result + (getCreateby() != null ? getCreateby().hashCode() : 0);
        result = 31 * result + (getCreateTime() != null ? getCreateTime().hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "KcodeExcelBean{" +
                "id=" + id +
                ", kcodeInfoId=" + kcodeInfoId +
                ", batchno='" + batchno + '\'' +
                ", kName='" + kName + '\'' +
                ", kcode='" + kcode + '\'' +
                ", fromtime=" + fromtime +
                ", totime=" + totime +
                ", isused=" + isused +
                ", createby='" + createby + '\'' +
                ", createTime=" + createTime +
                '}';
    }
}
