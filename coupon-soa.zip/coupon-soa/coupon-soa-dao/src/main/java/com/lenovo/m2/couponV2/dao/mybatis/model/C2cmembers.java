package com.lenovo.m2.couponV2.dao.mybatis.model;

import java.util.Date;

public class C2cmembers {
    private String ID;

    private String memberID;

    private String c2CMemberTypeID;

    private Integer memberLevel;

    private Integer integral;

    private Date createTime;

    private String createBy;

    private Date updateTime;

    private String updateBy;

    private Integer totalIntegral;

    private Integer freezeIntegral;

    private Integer status;




    private String lenovoID;

    private String name;

    private String brief;

    private String telPhone;

    private String email;




    public String getLenovoID() {
        return lenovoID;
    }

    public String getBrief() {
        return brief;
    }

    public String getTelPhone() {
        return telPhone;
    }

    public void setTelPhone(String telPhone) {
        this.telPhone = telPhone;
    }

    public String getEmail() {
        return email;

    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setBrief(String brief) {
        this.brief = brief;
    }

    public String getName() {

        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setLenovoID(String lenovoID) {
        this.lenovoID = lenovoID;
    }

    public String getID() {
        return ID;
    }

    public void setID(String ID) {
        this.ID = ID == null ? null : ID.trim();
    }

    public String getMemberID() {
        return memberID;
    }

    public void setMemberID(String memberID) {
        this.memberID = memberID == null ? null : memberID.trim();
    }

    public String getC2CMemberTypeID() {
        return c2CMemberTypeID;
    }

    public void setC2CMemberTypeID(String c2CMemberTypeID) {
        this.c2CMemberTypeID = c2CMemberTypeID == null ? null : c2CMemberTypeID.trim();
    }

    public Integer getMemberLevel() {
        return memberLevel;
    }

    public void setMemberLevel(Integer memberLevel) {
        this.memberLevel = memberLevel;
    }

    public Integer getIntegral() {
        return integral;
    }

    public void setIntegral(Integer integral) {
        this.integral = integral;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getCreateBy() {
        return createBy;
    }

    public void setCreateBy(String createBy) {
        this.createBy = createBy == null ? null : createBy.trim();
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public String getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(String updateBy) {
        this.updateBy = updateBy == null ? null : updateBy.trim();
    }

    public Integer getTotalIntegral() {
        return totalIntegral;
    }

    public void setTotalIntegral(Integer totalIntegral) {
        this.totalIntegral = totalIntegral;
    }

    public Integer getFreezeIntegral() {
        return freezeIntegral;
    }

    public void setFreezeIntegral(Integer freezeIntegral) {
        this.freezeIntegral = freezeIntegral;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }
}