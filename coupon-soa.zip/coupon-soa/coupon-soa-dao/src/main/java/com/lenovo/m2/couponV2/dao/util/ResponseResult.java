package com.lenovo.m2.couponV2.dao.util;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

public class ResponseResult<T> implements Serializable{

    private String msg;
    private String code;
    private T data;
    private boolean success;
    private Map<String,Object> responseResult = new HashMap<String,Object>();
    private String modelKey = "value";

    public ResponseResult(boolean success){
        this.success = success;
    }

    public Object addDefaultModel(Object obj){
        return this.responseResult.put("value",obj);
    }

    public Object addDefaultModel(String key,Object obj){
        this.modelKey = key;
        return this.responseResult.put(key,obj);
    }

    public Object get(){
        return this.responseResult.get(this.modelKey);
    }

    public Object get(String key){
        return this.responseResult.get(key);
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public T getData() {
        return data;
    }

    public void setData(T data) {
        this.data = data;
    }

    public boolean isSuccess() {
        return success;
    }

    public void setSuccess(boolean success) {
        this.success = success;
    }

    @Override
    public String toString() {
        return "Result{" +
                "msg='" + msg + '\'' +
                ", code='" + code + '\'' +
                ", data=" + data +
                ", success=" + success +
                '}';
    }
}
