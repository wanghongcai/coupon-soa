package com.lenovo.m2.couponV2.dao.mybatis.mapper1;


import com.lenovo.m2.couponV2.dao.mybatis.model.Ordermains;
import com.lenovo.m2.couponV2.dao.mybatis.model.OrdermainsExample;
import com.lenovo.m2.couponV2.dao.mybatis.model.OrdermainsWithBLOBs;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface OrdermainsMapper {
    int countByExample(OrdermainsExample example);

    int deleteByExample(OrdermainsExample example);

    int deleteByPrimaryKey(String id);

    int insert(OrdermainsWithBLOBs record);

    int insertSelective(OrdermainsWithBLOBs record);

    List<OrdermainsWithBLOBs> selectByExampleWithBLOBs(OrdermainsExample example);

    List<Ordermains> selectByExample(OrdermainsExample example);

    OrdermainsWithBLOBs selectByPrimaryKey(String id);

     List<Ordermains>  selectOrderByLenovoId(String lenovoId);
    Ordermains  selectOrderByLenovoIdC1(String lenovoId);


    List<Ordermains>  selectc2cScanLogByOrderCode();
    List<Ordermains>  selectJydaScanLogByOrderCode();

    int updateByExampleSelective(@Param("record") OrdermainsWithBLOBs record, @Param("example") OrdermainsExample example);

    int updateByExampleWithBLOBs(@Param("record") OrdermainsWithBLOBs record, @Param("example") OrdermainsExample example);

    int updateByExample(@Param("record") Ordermains record, @Param("example") OrdermainsExample example);

    int updateByPrimaryKeySelective(OrdermainsWithBLOBs record);

    int updateByPrimaryKeyWithBLOBs(OrdermainsWithBLOBs record);

    int updateByPrimaryKey(Ordermains record);
}