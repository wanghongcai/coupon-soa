package com.lenovo.m2.couponV2.dao.mybatis.model;

public class OrdermainsWithBLOBs extends Ordermains {
    private String note;

    private String paymenttype;

    private String taxtype;

    private String returngoodsreason;

    private String customermanagercode;

    private String orderextend;

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    public String getPaymenttype() {
        return paymenttype;
    }

    public void setPaymenttype(String paymenttype) {
        this.paymenttype = paymenttype;
    }

    public String getTaxtype() {
        return taxtype;
    }

    public void setTaxtype(String taxtype) {
        this.taxtype = taxtype;
    }

    public String getReturngoodsreason() {
        return returngoodsreason;
    }

    public void setReturngoodsreason(String returngoodsreason) {
        this.returngoodsreason = returngoodsreason;
    }

    public String getCustomermanagercode() {
        return customermanagercode;
    }

    public void setCustomermanagercode(String customermanagercode) {
        this.customermanagercode = customermanagercode;
    }

    public String getOrderextend() {
        return orderextend;
    }

    public void setOrderextend(String orderextend) {
        this.orderextend = orderextend;
    }
}