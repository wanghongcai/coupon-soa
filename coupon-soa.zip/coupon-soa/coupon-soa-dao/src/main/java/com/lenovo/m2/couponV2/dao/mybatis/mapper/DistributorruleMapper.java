package com.lenovo.m2.couponV2.dao.mybatis.mapper;

import com.lenovo.m2.couponV2.dao.mybatis.model.Detailsrule;
import com.lenovo.m2.couponV2.dao.mybatis.model.DetailsruleExample;
import com.lenovo.m2.couponV2.dao.mybatis.model.Distributorrule;
import com.lenovo.m2.couponV2.dao.mybatis.model.DistributorruleExample;

import java.util.List;
import java.util.Map;

/**
 * Created by pxg01 on 2017/4/20.
 */
public interface DistributorruleMapper {
    //插入优惠券
    int insertBatchDistributorrule(List<Distributorrule> distributorruleList);
    //更新优惠券
    int deleteByExample(DistributorruleExample example);
    /**
     * 通过优惠券主键id批量获取数据
     * @param map
     * @return
     */
    List<Distributorrule> getBatchBySalescouponids(Map map);
    List<Distributorrule> selectByExampleWithBLOBs(DistributorruleExample example);
    List<Distributorrule> selectByExampleWithBLOBsGroupBy(DistributorruleExample example);
}
