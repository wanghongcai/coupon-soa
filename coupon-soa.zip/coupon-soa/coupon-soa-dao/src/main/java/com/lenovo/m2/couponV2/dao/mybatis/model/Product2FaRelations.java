package com.lenovo.m2.couponV2.dao.mybatis.model;

import com.lenovo.m2.couponV2.api.model.Product2FaRelationsApi;
import com.lenovo.m2.couponV2.common.BaseObject;

import java.util.List;

/**
 * Created by pxg01 on 2017/5/19.
 */
public class Product2FaRelations extends BaseObject{

    //产品组编号
    private  String productgroupno;
    //产in组id
    private  String productgroupid;
    //分销商编码
    private List<String> facodes;

    public String getProductgroupno() {
        return productgroupno;
    }

    public void setProductgroupno(String productgroupno) {
        this.productgroupno = productgroupno;
    }


    public String getProductgroupid() {
        return productgroupid;
    }

    public void setProductgroupid(String productgroupid) {
        this.productgroupid = productgroupid;
    }

    public List<String> getFacodes() {
        return facodes;
    }

    public void setFacodes(List<String> facodes) {
        this.facodes = facodes;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Product2FaRelations that = (Product2FaRelations) o;

        if (!productgroupno.equals(that.productgroupno)) return false;
        if (!productgroupid.equals(that.productgroupid)) return false;
        return facodes.equals(that.facodes);

    }

    @Override
    public int hashCode() {
        int result = productgroupno.hashCode();
        result = 31 * result + productgroupid.hashCode();
        result = 31 * result + facodes.hashCode();
        return result;
    }

    @Override
    public String toString() {
        return "Product2FaRelations{" +
                "productgroupno='" + productgroupno + '\'' +
                ", productgroupid='" + productgroupid + '\'' +
                ", facodes=" + facodes +
                '}';
    }
}
