package com.lenovo.m2.couponV2.remote;

/**
 * Created by Administrator on 2017/9/13.
 */
public interface IDSequenceService {
    public String genId();
}
