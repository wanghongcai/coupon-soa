package com.lenovo.m2.couponV2.remote.impl;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.tool.util.KeyGenerator;
import com.lenovo.m2.couponV2.common.JacksonMapper;
import com.lenovo.m2.couponV2.remote.IDSequenceService;
import com.lenovo.m2.sequence.api.GenerateSequenceApiService;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * Created by Administrator on 2017/9/13.
 */
@Service
public class IDSequenceServiceImpl implements IDSequenceService {
    private static Logger logger = Logger.getLogger(IDSequenceServiceImpl.class);
//    @Autowired
//    private GenerateSequenceApiService generateSequenceApiService;

    @Override
    public String genId() {
        try {

            Long result = KeyGenerator.generateKey();
            logger.info("KeyGenerator.generateKey return = "+ result);
            if(result!=null && result!=0){
                return String.valueOf(result);
            }
        } catch (Exception e) {
            logger.error("occor error",e);
        }
        return null;
    }




}
