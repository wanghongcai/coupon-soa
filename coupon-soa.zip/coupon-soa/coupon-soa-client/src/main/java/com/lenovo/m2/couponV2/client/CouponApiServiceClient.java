package com.lenovo.m2.couponV2.client;

import com.lenovo.m2.couponV2.api.dubboService.RpcMemberCounponrelsService;
import com.lenovo.m2.couponV2.api.dubboService.RpcSalescouponsService;
import com.lenovo.m2.couponV2.api.service.SalescouponsService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.support.PropertiesLoaderUtils;

import java.util.Properties;

/**
 * Created by zhaocl1 on 2016/3/10.
 */
public class CouponApiServiceClient {
    private static final Logger LOGGER = LoggerFactory.getLogger(CouponApiServiceClient.class);
    private static final CouponApiServiceClient INSTANCE = new CouponApiServiceClient();
    private final ClassPathXmlApplicationContext ctx;
    private CouponApiServiceClient(){
        String filename ="coupon-soa-consumer-test.xml";
        try {
            Properties props = PropertiesLoaderUtils.loadAllProperties("env.properties");
            String env = props.getProperty("couponenv");
            System.out.println("=====load env coupon====="+env);
            if(env != null && env.length() > 0){
                if("pro".equals(env) || "product".equals(env) || "domain".equals(env) ||"docker-product".equals(env)){
                    filename = "coupon-soa-consumer-domain.xml";
                }else if("docker-preprod".equals(env)){
                    filename = "coupon-soa-consumer-docker-preprod.xml";
                }
                else if("uat".equals(env)){
                    filename = "coupon-soa-consumer-uat.xml";
                }else if("docker-uat-new".equals(env)){
                    filename = "coupon-soa-consumer-test.xml";
                }else{
                    filename = "coupon-soa-consumer-test.xml";
                }
            }else{
                filename = "coupon-soa-consumer-test.xml";
            }
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
        }
        System.out.println("=====load couponfileName ====="+filename);
        this.ctx = new ClassPathXmlApplicationContext(filename);
    }
    public static CouponApiServiceClient getINSTANCE(){
        return INSTANCE;
    }

    public RpcMemberCounponrelsService getRpcMemberCounponrelsService(){
        return (RpcMemberCounponrelsService)this.ctx.getBean("rpcMemberCounponrelsService");
    }

    public RpcSalescouponsService getRpcSalescouponsService(){
        return (RpcSalescouponsService)this.ctx.getBean("rpcSalescouponsService");
    }

    public SalescouponsService getSalescouponsService(){
        return (SalescouponsService)this.ctx.getBean("salescouponService");
    }


//    public  static  void  main(String args[]){
//        List<Long> list = new ArrayList<Long>();
//        list.add(107456L);
//        list.add(107457L);
//        list.add(107458L);
//        List<MemberVo> memberVos = new ArrayList<MemberVo>();
//        MemberVo memberVo = new MemberVo();
//        memberVo.setLenovoId("10084518350");
//        memberVo.setLoginname("luyi10@lenovo.com");
//        MemberVo memberVo1 = new MemberVo();
//        memberVo1.setLenovoId("10084518350");
//        memberVo1.setLoginname("luyi10@lenovo.com");
//        memberVos.add(memberVo);
//        memberVos.add(memberVo1);
//        for(int i=0;i<2;i++){
//            RemoteResult<Boolean> result = CouponApiServiceClient.getINSTANCE().getSalescouponsService().sendCouponsesToMember(list, memberVos, "luyi10@lenovo.com");
//            System.out.println(result);
//        }
//
//    }
}
