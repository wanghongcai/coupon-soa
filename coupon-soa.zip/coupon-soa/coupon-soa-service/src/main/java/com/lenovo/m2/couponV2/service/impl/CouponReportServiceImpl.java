package com.lenovo.m2.couponV2.service.impl;

import com.lenovo.m2.arch.framework.domain.PageModel2;
import com.lenovo.m2.arch.framework.domain.PageQuery;
import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.couponV2.api.model.CouponReportApi;
import com.lenovo.m2.couponV2.api.service.CouponReportService;
import com.lenovo.m2.couponV2.common.CouponConstant;
import com.lenovo.m2.couponV2.common.DomainUtil;
import com.lenovo.m2.couponV2.common.enums.ErrorMessageEnum;
import com.lenovo.m2.couponV2.common.exception.ExceptionUtil;
import com.lenovo.m2.couponV2.dao.mybatis.model.CouponReport;
import com.lenovo.m2.couponV2.manager.CouponReportManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Created by fenglg1 on 2017/1/9.
 */
@Service("couponReportService")
public class CouponReportServiceImpl implements CouponReportService {

    private static final Logger log = LoggerFactory.getLogger(CouponReportServiceImpl.class);

    @Autowired
    private CouponReportManager couponReportManager;
    @Override
    public RemoteResult<PageModel2<CouponReportApi>> getCouponReportInfoPage(PageQuery pageQuery, Map map) {
        RemoteResult<PageModel2<CouponReportApi>> remoteResult = new RemoteResult<PageModel2<CouponReportApi>>(false);
        try {
            PageModel2<CouponReport> couponInfo = couponReportManager.getCouponReportInfoPage(pageQuery, map);
            List<CouponReport> couponReportList = couponInfo.getDatas();
            if(couponInfo != null && couponReportList != null && couponReportList.size() > 0){
                List<CouponReportApi> couponReportApiList = new ArrayList<CouponReportApi>(couponReportList.size());
                DomainUtil domainUtil = new DomainUtil();
                for(CouponReport couponReport : couponReportList){
                    CouponReportApi couponReportApi = new CouponReportApi();
                    domainUtil.copy(couponReport, couponReportApi);
                    couponReportApiList.add(couponReportApi);
                }
                remoteResult.setSuccess(true);
                remoteResult.setResultCode(CouponConstant.RESULT_CODE_SUC);
                remoteResult.setResultMsg(CouponConstant.RESULT_MSG_SUC);
                remoteResult.setT(new PageModel2<CouponReportApi>(pageQuery, couponReportApiList));
            }else{
                remoteResult.setResultCode(ErrorMessageEnum.ERROR_NOT_VALIDE_COUPON.getCode());
                remoteResult.setResultMsg(ErrorMessageEnum.ERROR_NOT_VALIDE_COUPON.getCommon());
            }
        } catch (Exception e) {
            log.error("CouponReportServiceImpl: " + ExceptionUtil.getStackTrace(e));
            remoteResult.setResultCode(CouponConstant.RESULT_CODE_FAIL);
            remoteResult.setResultMsg(CouponConstant.RESULT_MSG_FAIL);
        }
        return remoteResult;
    }

    @Override
    public RemoteResult<PageModel2<CouponReportApi>> getCouponAndOrderIdInfoPage(PageQuery pageQuery, Map map) {
        RemoteResult<PageModel2<CouponReportApi>> remoteResult = new RemoteResult<PageModel2<CouponReportApi>>(false);
        try {
            PageModel2<CouponReport> couponInfo = couponReportManager.getCouponAndOrderInfoPage(pageQuery, map);
            List<CouponReport> couponReportList = couponInfo.getDatas();
            if(couponInfo != null && couponReportList != null && couponReportList.size() > 0){
                List<CouponReportApi> couponReportApiList = new ArrayList<CouponReportApi>(couponReportList.size());
                DomainUtil domainUtil = new DomainUtil();
                for(CouponReport couponReport : couponReportList){
                    CouponReportApi couponReportApi = new CouponReportApi();
                    domainUtil.copy(couponReport, couponReportApi);
                    couponReportApiList.add(couponReportApi);
                }
                remoteResult.setSuccess(true);
                remoteResult.setResultCode(CouponConstant.RESULT_CODE_SUC);
                remoteResult.setResultMsg(CouponConstant.RESULT_MSG_SUC);
                remoteResult.setT(new PageModel2<CouponReportApi>(pageQuery, couponReportApiList));
            }else{
                remoteResult.setResultCode(CouponConstant.RESULT_CODE_FAIL);
                remoteResult.setResultMsg(CouponConstant.RESULT_MSG_FAIL);
            }
        } catch (Exception e) {
            log.error("CouponReportServiceImpl: " + ExceptionUtil.getStackTrace(e));
            remoteResult.setResultCode(CouponConstant.RESULT_CODE_FAIL);
            remoteResult.setResultMsg(CouponConstant.RESULT_MSG_FAIL);
        }
        return remoteResult;
    }
}
