package com.lenovo.m2.couponV2.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import com.lenovo.m2.couponV2.manager.redisObject.RedisObjectManager;
import org.apache.commons.lang.RandomStringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alibaba.dubbo.common.utils.StringUtils;
import com.lenovo.m2.arch.framework.domain.PageModel2;
import com.lenovo.m2.arch.framework.domain.PageQuery;
import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.couponV2.api.model.CouponsApi;
import com.lenovo.m2.couponV2.api.service.CouponsService;
import com.lenovo.m2.couponV2.common.CouponConstant;
import com.lenovo.m2.couponV2.common.DomainUtil;
import com.lenovo.m2.couponV2.common.JacksonMapper;
import com.lenovo.m2.couponV2.common.TripleDESUtil;
import com.lenovo.m2.couponV2.common.exception.ExceptionUtil;
import com.lenovo.m2.couponV2.dao.mybatis.model.Coupons;
import com.lenovo.m2.couponV2.dao.mybatis.model.Salescoupons;
import com.lenovo.m2.couponV2.dao.util.ResponseResult;
import com.lenovo.m2.couponV2.manager.CouponsManager;
import com.lenovo.m2.couponV2.manager.SalescouponsManager;

/**
 * Created by zhaocl1 on 2016/3/11.
 */
@Service("couponsService")
public class CouponsServiceImpl implements CouponsService {
    private static final Logger log = LoggerFactory.getLogger(CouponsServiceImpl.class);
    @Autowired
    private CouponsManager couponsManager;
    @Autowired
    private SalescouponsManager salescouponsManager;
    @Autowired
    private RedisObjectManager redisObjectManager;

    private static final int NUM = 1000;
    private static final ExecutorService executorService = Executors.newCachedThreadPool();
    private static final String batchNO_key = "batch";
    @Override
    public RemoteResult<PageModel2<CouponsApi>> getCouponsInfoPage(PageQuery pageQuery, Map map) {
        RemoteResult result = new RemoteResult(false);
        //库里优惠码有加密和未加密的  sql 兼容
        String maCode = (String) map.get("macode");
        if(StringUtils.isNotEmpty(maCode)){
            String enmaCode = TripleDESUtil.encryptMode(maCode);
            map.put("enmacode",enmaCode);
        }

        try{
            PageModel2<Coupons> rs = couponsManager.getCouponsInfoPage(pageQuery, map);
            List<CouponsApi> couponsApiList = new ArrayList<CouponsApi>();
            if(null != rs && null !=rs.getDatas() && rs.getDatas().size() > 0 ){
                for (Coupons coupon : rs.getDatas()) {
                    CouponsApi couponsApi = new CouponsApi();
                    new DomainUtil().copy(coupon, couponsApi);
                    if (couponsApi.getMacode().length()>10){
                        couponsApi.setMacode(TripleDESUtil.hiddenCharacter(TripleDESUtil.decryptMode(couponsApi.getMacode()), 4, "*"));
                    }else {
                        couponsApi.setMacode(TripleDESUtil.hiddenCharacter(couponsApi.getMacode(), 4, "*"));
                    }
                    couponsApiList.add(couponsApi);
                }
            }
            PageModel2<CouponsApi> pageModel=new PageModel2<CouponsApi>(pageQuery,couponsApiList);
            result.setResultMsg(CouponConstant.RESULT_MSG_SUC);
            result.setResultCode(CouponConstant.RESULT_CODE_SUC);
            result.setT(pageModel);
            result.setSuccess(true);
        }catch (Exception e){
            log.error(ExceptionUtil.getStackTrace(e));
        }
        return result;
    }

    @Override
    public RemoteResult<PageModel2<CouponsApi>> getExportCouponsInfoPage(PageQuery pageQuery, Map map) {
        log.info("getExportCouponsInfoPage param={},map={}", JacksonMapper.obj2json(pageQuery),JacksonMapper.obj2json(map));
        RemoteResult result = new RemoteResult(false);
        //库里优惠码有加密和未加密的  sql 兼容
        String maCode = (String) map.get("macode");
        if(StringUtils.isNotEmpty(maCode)){
            String enmaCode = TripleDESUtil.encryptMode(maCode);
            map.put("enmacode",enmaCode);
        }
        try{
            PageModel2<Coupons> rs = couponsManager.getCouponsInfoPage(pageQuery, map);
            List<CouponsApi> couponsApiList = new ArrayList<CouponsApi>();
            if(null != rs && null !=rs.getDatas() && rs.getDatas().size() > 0 ){
                for (Coupons coupon : rs.getDatas()) {
                    CouponsApi couponsApi = new CouponsApi();
                    new DomainUtil().copy(coupon, couponsApi);
                    if (couponsApi.getMacode().length()>10){
                        couponsApi.setMacode(TripleDESUtil.decryptMode(couponsApi.getMacode()));
                    }else {
                        couponsApi.setMacode(couponsApi.getMacode());
                    }
                    couponsApiList.add(couponsApi);
                }
            }
            PageModel2<CouponsApi> pageModel=new PageModel2<CouponsApi>(pageQuery,couponsApiList);
            result.setResultMsg(CouponConstant.RESULT_MSG_SUC);
            result.setResultCode(CouponConstant.RESULT_CODE_SUC);
            result.setT(pageModel);
            result.setSuccess(true);
        }catch (Exception e){
            log.error(ExceptionUtil.getStackTrace(e));
        }
        return result;
    }



    @Override
    public RemoteResult getCouponsBySalescouponsId(long salescouponid) {
        log.info("getCouponsBySalescouponsId 导出优惠码时,优惠码批次的主键为[" + salescouponid + "]");
        RemoteResult result = new RemoteResult(false);
        try {
            if (salescouponid <= 0) {
                result.setResultMsg(CouponConstant.RESULT_MSG_ERROR_PARAM);
                result.setResultCode(CouponConstant.RESULT_CODE_ERROR_PARAM);
                return result;
            }
            ResponseResult res = couponsManager.getCouponsBySalescouponsId(salescouponid);
            if (res.isSuccess()) {
                List<Coupons> list = (List<Coupons>) res.getData();
                List<CouponsApi> listapi = new ArrayList<CouponsApi>();
                CouponsApi couponsApi = null;
                for (Coupons c : list) {
                    couponsApi = new CouponsApi();
                    new DomainUtil().copy(c, couponsApi);
                    listapi.add(couponsApi);
                }
                result.setSuccess(true);
                result.setT(listapi);
                result.setResultCode(CouponConstant.RESULT_CODE_SUC);
                result.setResultMsg(CouponConstant.RESULT_MSG_SUC);
                return result;
            }
        } catch (Exception e) {
            log.error(ExceptionUtil.getStackTrace(e));
        }
        return result;
    }

    @Override
    public RemoteResult getCouponsBySalescouponsIdAndBatchNO(long salescouponid) {
        log.info("getCouponsBySalescouponsId 导出优惠码时,优惠码批次的主键为[" + salescouponid + "]");
        RemoteResult result = new RemoteResult(false);
        try {
            if (salescouponid <= 0) {
                result.setResultMsg(CouponConstant.RESULT_MSG_ERROR_PARAM);
                result.setResultCode(CouponConstant.RESULT_CODE_ERROR_PARAM);
                return result;
            }
            String batchNo = redisObjectManager.getString(batchNO_key + "_" + salescouponid);
            if(batchNo == null){
                log.info("batchNo is null!");
                result.setResultMsg(CouponConstant.RESULT_MSG_ERROR_PARAM);
                result.setResultCode(CouponConstant.RESULT_CODE_ERROR_PARAM);
                return result;
            }
            log.info("redis.getString batchNo :",batchNo);
            ResponseResult res = couponsManager.getCouponsBySalescouponsIdAndBatchNO(salescouponid,batchNo);
            if (res.isSuccess()) {
                List<Coupons> list = (List<Coupons>) res.getData();
                List<CouponsApi> listapi = new ArrayList<CouponsApi>();
                CouponsApi couponsApi = null;
                for (Coupons c : list) {
                    couponsApi = new CouponsApi();
                    new DomainUtil().copy(c, couponsApi);
                    listapi.add(couponsApi);
                }
                result.setSuccess(true);
                result.setT(listapi);
                result.setResultCode(CouponConstant.RESULT_CODE_SUC);
                result.setResultMsg(CouponConstant.RESULT_MSG_SUC);
                return result;
            }
        } catch (Exception e) {
            log.error(ExceptionUtil.getStackTrace(e));
        }
        return result;
    }

    public RemoteResult<Boolean> toIncreaseCodes(final long couponId, final int count, final String operator) {
        RemoteResult<Boolean> remoteResult = new RemoteResult<Boolean>(false);
        try {
            ResponseResult<Salescoupons> responseResult = salescouponsManager.getSalescoupons(couponId);
            if (responseResult != null && responseResult.isSuccess()) {
                final Salescoupons salescoupons = responseResult.getData();
                if(salescoupons.getStatus() != CouponConstant.COUPON_STATUS_PASTAUDIT_2){
                    remoteResult.setResultCode(CouponConstant.RESULT_CODE_FAIL);
                    remoteResult.setResultMsg(CouponConstant.RESULT_MSG_FAIL);
                    return remoteResult;
                }
                salescoupons.setMaxnumber(salescoupons.getMaxnumber() + count);
                salescoupons.setUpdateby(operator);
                salescoupons.setUpdatetime(new Date());
                ResponseResult response = salescouponsManager.editSalescoupons(salescoupons);
                if (!response.isSuccess()){
                    remoteResult.setResultCode(CouponConstant.RESULT_CODE_FAIL);
                    remoteResult.setResultMsg(CouponConstant.RESULT_MSG_FAIL);
                    return remoteResult;
                }

                String batchNo = String.valueOf(new Date().getTime());
                salescoupons.setBatchno(batchNo);
                String redis_key = batchNO_key+"_"+couponId;
                log.info("redis_key:",redis_key);
                redisObjectManager.setString(redis_key,batchNo);

                executorService.execute(new Runnable() {
                    int rows;

                    @Override
                    public void run() {
                        if (count <= NUM) {
                            rows += produceCouponCodes(salescoupons, count, operator);
                        } else {
                            int n = count / NUM;
                            int m = count % NUM;
                            for (int i = 0; i < n; i++) {
                                rows += produceCouponCodes(salescoupons, NUM, operator);
                            }
                            if (m > 0) {
                                rows += produceCouponCodes(salescoupons, m, operator);
                            }
                        }
                        log.info("成功追加的优惠码数量：" + rows + " couponId: " + couponId);
                    }
                });
                remoteResult.setResultMsg(CouponConstant.RESULT_MSG_SUC);
                remoteResult.setResultCode(CouponConstant.RESULT_CODE_SUC);
                remoteResult.setSuccess(true);
                return remoteResult;
            }
        }catch (Exception e){
            log.error(ExceptionUtil.getStackTrace(e));
        }
        return remoteResult;
    }

    @Override
    public RemoteResult<CouponsApi> getTrueMacode(Long id,String itCode) {
        log.info(itCode+"获取"+id+"的真实优惠码");
        RemoteResult result = new RemoteResult(false);
        try {
            ResponseResult<List<Coupons>> responseResult = couponsManager.getTrueMacode(id,itCode);
            if (responseResult.isSuccess()){
                List<Coupons> list = responseResult.getData();
                List<CouponsApi> clist = new ArrayList<CouponsApi>();
                CouponsApi capi = null;
                for (Coupons c : list){
                    capi = new CouponsApi();
                    new DomainUtil().copy(c, capi);
                    String TrueMacode = list.get(0).getMacode();
                    capi.setMacode(TrueMacode);

                    clist.add(capi);
                }
                result.setResultMsg(CouponConstant.RESULT_MSG_SUC);
                result.setResultCode(CouponConstant.RESULT_CODE_SUC);
                result.setT(clist);
                result.setSuccess(true);
            }
        }catch (Exception e){
            log.error(ExceptionUtil.getStackTrace(e));
        }
        return result;
    }

    /**
     * 批量生成优惠码
     * @param main 优惠码主属性对象
     * @param count 要生成的数量
     * @param operator 操作人
     * @return 返回成功的数量
     */
    private int produceCouponCodes(Salescoupons main,int count,String operator){
        if (count<=0){
            log.info("优惠码的批次创建数量为0");
            return 0;
        }
        List<Coupons> list = new ArrayList<Coupons>();
        Date currentTime = new Date();
        for (int i = 0; i < count; i++) {
            Coupons couponCode = new Coupons();
            couponCode.setBatchno(main.getBatchno());
            couponCode.setAmount(main.getAmount());
            couponCode.setName(main.getName());
            couponCode.setMacode(TripleDESUtil.encryptMode(RandomStringUtils.randomAlphanumeric(10)));
            couponCode.setStatus(CouponConstant.COUPON_COUPONS_STATUS_NORMAL); //0正常，1禁用
            couponCode.setSalescouponid(main.getId());
            couponCode.setShopid(main.getShopid());
            couponCode.setTerminal(main.getTerminal());
            couponCode.setType(main.getType());
            couponCode.setStarttime(main.getFromtime());
            couponCode.setEndtime(main.getTotime());
            couponCode.setTotalnumber(main.getTotalnumber());
            couponCode.setSurplusnumber(main.getTotalnumber());
            couponCode.setGroupcode(main.getEppgroup());
            couponCode.setOccupynumber(0);
            couponCode.setCreatetime(currentTime);
            couponCode.setCreateby(operator);
            couponCode.setUpdatetime(currentTime);
            couponCode.setCurrencyCode(main.getCurrencyCode());
            list.add(couponCode);
        }
        ResponseResult<Integer> result= couponsManager.insertBatch(list);
        if (result!=null&&result.isSuccess()){
            return result.getData();
        }
        return 0;
    }
}
