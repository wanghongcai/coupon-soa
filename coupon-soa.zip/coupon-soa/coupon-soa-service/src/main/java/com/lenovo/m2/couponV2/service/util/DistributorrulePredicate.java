package com.lenovo.m2.couponV2.service.util;

import com.google.common.base.Predicate;
import com.lenovo.m2.couponV2.dao.mybatis.model.Detailsrule;
import com.lenovo.m2.couponV2.dao.mybatis.model.Distributorrule;

/**
 * Created by zhaocl1 on 2016/4/20.
 */
public class DistributorrulePredicate implements Predicate<Distributorrule>{

    private Long salescouponid;

    public DistributorrulePredicate(Long salescouponid) {
        this.salescouponid = salescouponid;
    }

    @Override
    public boolean apply(Distributorrule distributorrule) {
        if(distributorrule.getSalescouponid().equals(salescouponid)){
            return true;
        }
        return false;
    }
}
