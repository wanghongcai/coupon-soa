package com.lenovo.m2.couponV2.service.impl;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.couponV2.api.model.ProductruleApi;
import com.lenovo.m2.couponV2.api.service.ProductruleService;
import com.lenovo.m2.couponV2.manager.ProductruleManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Created by zhaocl1 on 2016/2/15.
 */
@Service("productruleService")
public class ProductruleServiceImpl implements ProductruleService {

    @Autowired
    private ProductruleManager productruleManager;

    @Override
    public RemoteResult insertProductrule(ProductruleApi productruleApi) {
        return null;
    }

    @Override
    public RemoteResult delProductrule(ProductruleApi productruleApi) {
        return null;
    }

    @Override
    public RemoteResult<List<ProductruleApi>> getProductruleList(ProductruleApi productruleApi) {
        return null;
    }
}
