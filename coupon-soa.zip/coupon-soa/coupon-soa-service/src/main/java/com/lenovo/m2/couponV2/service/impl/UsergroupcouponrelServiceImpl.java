package com.lenovo.m2.couponV2.service.impl;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.couponV2.api.model.UsergroupcouponrelApi;
import com.lenovo.m2.couponV2.api.service.UsergroupcouponrelService;
import com.lenovo.m2.couponV2.common.CouponConstant;
import com.lenovo.m2.couponV2.common.DomainUtil;
import com.lenovo.m2.couponV2.common.exception.ExceptionUtil;
import com.lenovo.m2.couponV2.dao.mybatis.model.Usergroupcouponrel;
import com.lenovo.m2.couponV2.dao.util.ResponseResult;
import com.lenovo.m2.couponV2.manager.UsergroupcouponrelManager;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by zhaocl1 on 2015/9/15.
 */
@Service("usergroupcouponrelService")
public class UsergroupcouponrelServiceImpl implements UsergroupcouponrelService {
    private static final Logger log = LoggerFactory.getLogger(UsergroupcouponrelServiceImpl.class);

    @Autowired
    private UsergroupcouponrelManager usergroupcouponrelManager;

    @Override
    public RemoteResult insertBatch(List<UsergroupcouponrelApi> list) {
        log.info("insertBatch "+list);
        RemoteResult result = new RemoteResult(false);
        try {
            if(list != null && list.size() > 0){
                List<Usergroupcouponrel> usergroupcouponrelList = new ArrayList<Usergroupcouponrel>();
                Usergroupcouponrel usergroupcouponrel =null;
                for(UsergroupcouponrelApi api : list){
                    usergroupcouponrel = new Usergroupcouponrel();
                    new DomainUtil().copy(api, usergroupcouponrel);
                    usergroupcouponrelList.add(usergroupcouponrel);
                }
                ResponseResult res = usergroupcouponrelManager.insertBatch(usergroupcouponrelList);
                if(res.isSuccess()){
                    result.setResultMsg(CouponConstant.RESULT_MSG_SUC);
                    result.setResultCode(CouponConstant.RESULT_CODE_SUC);
                    result.setSuccess(true);
                }
            }else {
                result.setResultMsg(CouponConstant.RESULT_MSG_ERROR_PARAM);
                result.setResultCode(CouponConstant.RESULT_CODE_ERROR_PARAM);
            }
        } catch (Exception e) {
            log.error("insertBatch保存券失败" + ExceptionUtil.getStackTrace(e));
        }
        return result;
    }
}
