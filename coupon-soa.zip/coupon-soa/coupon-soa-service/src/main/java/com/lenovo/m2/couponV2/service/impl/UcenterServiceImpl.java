package com.lenovo.m2.couponV2.service.impl;


import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.lenovo.m2.couponV2.api.service.UcenterService;
import com.lenovo.m2.couponV2.common.CustomizedPropertyConfigurer;
import com.lenovo.m2.couponV2.common.HttpConnectionUtil;
import com.lenovo.m2.couponV2.common.exception.ExceptionUtil;
import com.lenovo.m2.couponV2.common.util.JsonUtil;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by yezhenyue on 2016/3/4.
 */
@Service("ucenterService")
public class UcenterServiceImpl implements UcenterService {
    private static final Logger LOGGER = LoggerFactory.getLogger(UcenterServiceImpl.class);
    @Override
    public Date getMemberRegisterTime(String lenovoId,String shopid) {
        try {
        	Map<String,String> map = new HashMap<String, String>();
        	map.put("lenovoId", lenovoId);
        	map.put("shopId", shopid);
        	LOGGER.info("获取用户注册时间，请求参数:{}",JsonUtil.toJson(map));
        	String url = CustomizedPropertyConfigurer.getContextProperty("user.createtime.url")+"";
        	if(StringUtils.isEmpty(url)){
                LOGGER.info("读取用户注册接口失败！ url:{}",url);
                return null;
            }
        	String json = HttpConnectionUtil.sendPostByHttpClient(url, map);
            LOGGER.info("请求用户注册时间接口url="+url);
            LOGGER.info("responseBody="+json);
            if(json != null && json.startsWith("{")){
                JSONObject jsonObject = JSONObject.parseObject(json);
                LOGGER.info("jsonObject=" + jsonObject);
                String ret =jsonObject.getString("ret");
                LOGGER.info("ret="+ret);
                if(ret.equals("0")){
                	JSONArray data = jsonObject.getJSONArray("data");
                	if(null == data || data.size() ==0){
                		return null;
                	}
                	JSONObject o = (JSONObject) data.get(0);
                	if(null == o){
                		return null;
                	}
                    String time = o.getString("createTime");
                    if(!StringUtils.isEmpty(time)){
                        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
                        Date regiterTime = formatter.parse(time);
                        return regiterTime;
                    }else {
                        LOGGER.info("请求用户注册时间为空");
                    }
                }else {
                    LOGGER.info("请求用户注册时间接口出现错误");
                }
            }else {
                LOGGER.info("请求用户注册时间接口出现错误");
                return null;
            }
        } catch (Exception e) {
            LOGGER.error(ExceptionUtil.getStackTrace(e));
            return null;
        }
        return null;
    }
}
