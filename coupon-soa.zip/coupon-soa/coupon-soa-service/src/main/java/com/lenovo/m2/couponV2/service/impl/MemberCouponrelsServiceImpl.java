package com.lenovo.m2.couponV2.service.impl;

import com.alibaba.dubbo.common.utils.StringUtils;
import com.lenovo.m2.arch.framework.domain.PageModel2;
import com.lenovo.m2.arch.framework.domain.PageQuery;
import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.framework.domain.Tenant;
import com.lenovo.m2.arch.tool.util.CollectionUtils;
import com.lenovo.m2.couponV2.api.model.MembercouponrelsApi;
import com.lenovo.m2.couponV2.api.service.MemberCounponrelsService;
import com.lenovo.m2.couponV2.api.service.UcenterService;
import com.lenovo.m2.couponV2.common.*;
import com.lenovo.m2.couponV2.common.enums.ErrorMessageEnum;
import com.lenovo.m2.couponV2.common.exception.ExceptionUtil;
import com.lenovo.m2.couponV2.common.usercenter.RemoteLenovo;
import com.lenovo.m2.couponV2.common.util.JsonUtil;
import com.lenovo.m2.couponV2.dao.mybatis.model.*;
import com.lenovo.m2.couponV2.dao.util.ResponseResult;
import com.lenovo.m2.couponV2.manager.*;
import com.lenovo.m2.couponV2.manager.redisObject.RedisObjectManager;
import com.lenovo.m2.couponV2.remote.IDSequenceService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Created by yezhenyue on 2016/1/19.
 */
@Service("memberCounponrelsService")
public class MemberCouponrelsServiceImpl implements MemberCounponrelsService {
    private static final Logger log = LoggerFactory.getLogger(MemberCouponrelsServiceImpl.class);
    @Autowired
    private MemberCouponrelsManager memberCouponrelsManager;
    @Autowired
    private SalescouponsManager salescouponsManager;
    @Autowired
    private UsergroupcouponrelManager usergroupcouponrelManager;
    @Autowired
    private UsercouponrelManager usercouponrelManager;
    @Autowired
    private CouponsCategoryManager couponsCategoryManager;
    @Autowired
    private RedisObjectManager redisObjectManager;
    @Autowired
    private IDSequenceService idSequenceService;
    @Autowired
    private UcenterService ucenterService;

    @Override
    public RemoteResult<PageModel2<MembercouponrelsApi>> getMemberCouponrelsPage(PageQuery pageQuery, Map map) {
        log.info("getMemberCouponrelsPage pageQuery={}" + pageQuery + "map = {}" + map);
        RemoteResult result = new RemoteResult(false);
        try {
            PageModel2<Membercouponrels> rs = memberCouponrelsManager.getMemberCouponrelsPage(pageQuery, map);
            log.info("getMemberCouponrelsPage return={}" + JsonUtil.toJson(rs));
            List<MembercouponrelsApi> membercouponrelsApiList = new ArrayList<MembercouponrelsApi>();
            if (null != rs && null != rs.getDatas() && rs.getDatas().size() > 0) {
                for (Membercouponrels memberCoupon : rs.getDatas()) {
                    MembercouponrelsApi membercouponrelsApi = new MembercouponrelsApi();
                    new DomainUtil().copy(memberCoupon, membercouponrelsApi);
                    membercouponrelsApiList.add(membercouponrelsApi);
                }
            }
            PageModel2<MembercouponrelsApi> pageModel = new PageModel2<MembercouponrelsApi>(pageQuery, membercouponrelsApiList);
            result.setResultMsg(CouponConstant.RESULT_MSG_SUC);
            result.setResultCode(CouponConstant.RESULT_CODE_SUC);
            result.setT(pageModel);
            result.setSuccess(true);
        } catch (Exception e) {
            log.error("occour error", e);
        }
        return result;
    }

    @Override
    public RemoteResult<Boolean> disableMemberCouponById(long id) {
        return disableMemberCouponByIdandLenovoId(id, "");
    }

    @Override
    public RemoteResult<Boolean> disableMemberCouponByIdandLenovoId(long id, String lenovoId) {
        return memberCouponrelsManager.disableMemberCouponById(id, lenovoId);
    }

    @Override
    public RemoteResult<MembercouponrelsApi> queryMemberCouponById(long id) {
        RemoteResult<MembercouponrelsApi> result = new RemoteResult<MembercouponrelsApi>(false);
        try {
            RemoteResult<Membercouponrels> remoteResult = memberCouponrelsManager.queryMemberCouponById(id);
            if (remoteResult != null && remoteResult.isSuccess() && remoteResult.getT() != null) {
                Membercouponrels membercouponrels = remoteResult.getT();
                CouponsCategory couponsCategory = new CouponsCategory();
                if (membercouponrels.getClassification() != null && membercouponrels.getClassification() > 0) {
                    couponsCategory = couponsCategoryManager.selectByPrimaryKey(membercouponrels.getClassification());
                }
                MembercouponrelsApi membercouponrelsApi = new MembercouponrelsApi();
                new DomainUtil().copy(remoteResult.getT(), membercouponrelsApi);
                membercouponrelsApi.setClassificationname(couponsCategory.getClassificationname());
                result.setT(membercouponrelsApi);
                result.setSuccess(true);
            }
        } catch (Exception e) {
            log.error(ExceptionUtil.getStackTrace(e));
        }
        return result;
    }

    @Transactional(rollbackFor = Exception.class)
    public int bindAllMemberSalesCoupons(Tenant tenant, String lenovoid, String memberCode, String groupcode) {
        MethodResult<Integer, Void, Void> me = this.bindAllMemberSalesCouponsN(lenovoid, memberCode, groupcode, String.valueOf(tenant.getShopId()));
        if (null == me) {
            return 0;
        }
        if (!me.isSuccess()) {
            return 0;
        }
        return me.getT1();
    }

    /**
     * 绑定全员券返回绑定成功的数量
     *
     * @param lenovoid
     * @param memberCode
     * @param groupcode
     * @param shopid
     * @return
     */
    @Transactional(rollbackFor = Exception.class)
    public MethodResult<Integer, Void, Void> bindAllMemberSalesCouponsN(String lenovoid, String memberCode, String groupcode, String shopid) {
        if (StringUtils.isEmpty(lenovoid) || StringUtils.isEmpty(groupcode) || StringUtils.isEmpty(shopid)) {
            return new MethodResult<Integer, Void, Void>(ErrorMessageEnum.ERROR_PARA);
        }
        /**
         * 获取用户注册时间
         */
        Date date = null;
        try {
            date = new SimpleDateFormat("yyyy-mm-dd HH:mm:ss").parse("2000-01-01 12:12:12");
        } catch (ParseException e) {
            log.error("data error:{}",e);
        }
        if (date != null) {
            //根据用户组编号、平台、注册时间查询满足领取条件的全员券
            long time_getListByCondition_start = new Date().getTime();
            ResponseResult<List<Usergroupcouponrel>> responseResult = usergroupcouponrelManager.getListByCondition(groupcode, shopid, date);
            long time_getListByCondition_end = new Date().getTime();
            log.info("bindAllMemberSalesCoupons 获取全员券耗时：" + (time_getListByCondition_end - time_getListByCondition_start) + "毫秒");

            if (responseResult != null && responseResult.isSuccess()) {
                List<Usergroupcouponrel> list = responseResult.getData();
                if (list == null || list.size() == 0) {
                    log.info("没有满足条件的全员券groupcode：" + groupcode + ", shopid:" + shopid + ",用户注册时间：" + date);
                    return new MethodResult<Integer, Void, Void>(ErrorMessageEnum.ERROR_CANT_FIND_CONDITION_COUPON.getCode(), ArrayUtil.toArrayString(new String[]{groupcode, shopid, date + ""}));
                }
                Map<String, Object> salesCouponMap = new HashMap<String, Object>();
                List<Usergroupcouponrel> usefullist = new ArrayList<Usergroupcouponrel>();
                //校验优惠券的有效性，排除掉过期的优惠券，有效的券放入map
                long time_validateSalesCoupon_start = new Date().getTime();
                boolean flag = validateSalesCouponV2(list, usefullist, salesCouponMap);

                long time_validateSalesCoupon_end = new Date().getTime();
                log.info("bindAllMemberSalesCoupons 验证券的有效性耗时：" + (time_validateSalesCoupon_end - time_validateSalesCoupon_start) + "毫秒");

                if (CollectionUtils.isEmpty(usefullist) || salesCouponMap.isEmpty()) {
                    log.info("没有有效的优惠券groupcode：" + groupcode + ", shopid:" + shopid + ",用户注册时间：" + date);
                    return new MethodResult<Integer, Void, Void>(ErrorMessageEnum.ERROR_CANT_FIND_CONDITION_COUPON.getCode(), ArrayUtil.toArrayString(new String[]{groupcode, shopid, date + ""}));
                }
                if (!flag) {
                    return new MethodResult<Integer, Void, Void>(ErrorMessageEnum.ERROR_NOT_VALIDE_COUPON);

                }
                List<Membercouponrels> membercouponrelsList = new ArrayList<Membercouponrels>();
                List<Usercouponrel> usercouponrelList = new ArrayList<Usercouponrel>();
                for (Usergroupcouponrel u : usefullist) {
                    //检查用户领取记录，防止重复领取
                    long time_isBindedUserCoupon_start = new Date().getTime();
                    boolean tag = this.isBindedUserCoupon(u.getId(), lenovoid);
                    long time_isBindedUserCoupon_end = new Date().getTime();
                    log.info("bindAllMemberSalesCoupons 判断是否领取过耗时：" + (time_isBindedUserCoupon_end - time_isBindedUserCoupon_start) + "毫秒");

                    if (tag) {
                        Membercouponrels membercouponrels = new Membercouponrels();
                        Usercouponrel usercouponrel = new Usercouponrel();
                        usercouponrel.setUsergroupcouponrelid(u.getId());
                        usercouponrel.setLenovoid(lenovoid);
                        usercouponrel.setCreatetime(new Date());
                        Salescoupons salescoupons = (Salescoupons) salesCouponMap.get(u.getSalescouponid());
                        String batchNo = new Date().getTime() + "";//发放批次号
                        //拼装用户优惠券对象
                        this.initMembercouponrels(lenovoid, memberCode, batchNo, salescoupons, membercouponrels);
                        membercouponrelsList.add(membercouponrels);
                        usercouponrelList.add(usercouponrel);
                    }
                }
                if (membercouponrelsList.size() > 0) {
                    //批量插入用户优惠券表
                    RemoteResult<Boolean> remoteResult = memberCouponrelsManager.insertBatch(membercouponrelsList);
                    //批量插入用户全员券领取记录表
                    ResponseResult result = usercouponrelManager.insertBatch(usercouponrelList);

                    if (remoteResult != null && remoteResult.isSuccess()) {
                        return new MethodResult<Integer, Void, Void>(ErrorMessageEnum.SUCCESS, membercouponrelsList.size(), null, null);
                    }
                }
            } else {
                log.info("获取满足条件的全员券时出错");
                return new MethodResult<Integer, Void, Void>(ErrorMessageEnum.ERROR_CANT_FIND_CONDITION_ALL_COUPON);
            }
        } else {
            log.info("获取用户注册时间出错");
            return new MethodResult<Integer, Void, Void>(ErrorMessageEnum.ERROR_USER_REGIST_TIME);
        }
        return new MethodResult<Integer, Void, Void>(ErrorMessageEnum.ERROR_USER_REGIST_TIME);
    }

    /**
     * 获取用户注册时间
     * 用户注册时间放入缓存，先从缓存取，取不到,调用户接口
     */
   /* private Date getRegisterDate(String lenovoid, String shopid) {
        long time_getMemberRegisterTime_start = System.currentTimeMillis();
        Date date = null;
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String datestr = redisObjectManager.getString(lenovoid);
        if (StringUtils.isEmpty(datestr)) {
            date = ucenterService.getMemberRegisterTime(lenovoid, shopid);
            if (date != null) {
                String time = sdf.format(date);
                redisObjectManager.setString(lenovoid, time);
            }
        } else {
            try {
                date = sdf.parse(datestr);
            } catch (ParseException e) {
                log.error("getRegisterDate 从缓存中取用户注册时间转换为date类型时，出现异常" + ExceptionUtil.getStackTrace(e));
            }
        }
        long time_getMemberRegisterTime_end = System.currentTimeMillis();
        log.info("getRegisterDate 获取用户注册时间耗时：" + (time_getMemberRegisterTime_end - time_getMemberRegisterTime_start) + "毫秒");
        return date;
    }*/

    /**
     * 校验优惠券有效性，将有效的券放入map
     *
     * @param list
     * @param userGroupMap   保存Usergroupcouponrel对象 key是优惠券ID
     * @param salesCouponMap 保存Salescoupons对象  key是优惠券ID
     */
    public boolean validateSalesCoupon(List<Usergroupcouponrel> list, Map<String, Object> userGroupMap, Map<String, Object> salesCouponMap) {
        String[] ids_array = new String[list.size()];
        for (int i = 0; i < list.size(); i++) {
            ids_array[i] = list.get(i).getSalescouponid();
            userGroupMap.put(list.get(i).getSalescouponid(), list.get(i));
        }
        Map paramMap = new HashMap();
        paramMap.put("ids", ids_array);
        ResponseResult<List<Salescoupons>> result = salescouponsManager.getSalescouponsList(paramMap);
        if (result != null && result.isSuccess()) {
            List<Salescoupons> salescouponsList = result.getData();
            if (salescouponsList == null || salescouponsList.size() == 0) {
                log.info("检验券有效性时未找到相应的优惠券");
                return false;
            }
            for (Salescoupons salescoupons : salescouponsList) {
                if (salescoupons.getTotime().getTime() <= new Date().getTime()) {
                    //去掉过期的优惠券
                    userGroupMap.remove(salescoupons.getId().toString());
                    continue;
                }
                salesCouponMap.put(salescoupons.getId().toString(), salescoupons);
            }
            return true;
        }
        log.info("获取优惠券列表时出错");
        return false;
    }


    /**
     * 校验优惠券有效性，将有效的券放入map
     *
     * @param list
     * @param usefullist     过滤掉过期的券
     * @param salesCouponMap 保存Salescoupons对象  key是优惠券ID
     */
    public boolean validateSalesCouponV2(List<Usergroupcouponrel> list, List<Usergroupcouponrel> usefullist, Map<String, Object> salesCouponMap) {
        String[] ids_array = new String[list.size()];
        for (int i = 0; i < list.size(); i++) {
            ids_array[i] = list.get(i).getSalescouponid();
        }

        usefullist.addAll(list);

        Map paramMap = new HashMap();
        paramMap.put("ids", ids_array);
        ResponseResult<List<Salescoupons>> result = salescouponsManager.getSalescouponsList(paramMap);
        if (result != null && result.isSuccess()) {
            List<Salescoupons> salescouponsList = result.getData();
            if (salescouponsList == null || salescouponsList.size() == 0) {
                log.info("检验券有效性时未找到相应的优惠券");
                return false;
            }
            for (Salescoupons salescoupons : salescouponsList) {
                if (salescoupons.getTotime().getTime() <= new Date().getTime()) {
                    //去掉过期的优惠券
                    Iterator<Usergroupcouponrel> iter = usefullist.iterator();
                    while (iter.hasNext()) {
                        String salescouponid = iter.next().getSalescouponid();
                        if (salescoupons.getId().toString().equals(salescouponid)) {
                            iter.remove();
                        }
                    }
                    continue;
                }
                salesCouponMap.put(salescoupons.getId().toString(), salescoupons);
            }
            return true;
        }
        log.info("获取优惠券列表时出错");
        return false;
    }

    public boolean isBindedUserCoupon(Long userGroupId, String lenovoid) {
        Usercouponrel usercouponrel = new Usercouponrel();
        usercouponrel.setLenovoid(lenovoid);
        usercouponrel.setUsergroupcouponrelid(userGroupId);
        ResponseResult<List<Usercouponrel>> listResponseResult = usercouponrelManager.getUsercouponrelByCondition(usercouponrel);
        if (listResponseResult != null && listResponseResult.isSuccess() && listResponseResult.getData() != null) {
            List<Usercouponrel> usercouponrels = listResponseResult.getData();
            if (usercouponrels.size() == 0) {//没有领取记录，说明可以领取
                log.info("用户" + lenovoid + "未领过，可以领取!");
                return true;
            }
        }
        return false;
    }

    public void initMembercouponrels(String lenovoid, String memberCode, String batchNo, Salescoupons salescoupons, Membercouponrels membercouponrels) {
        membercouponrels.setId(Long.parseLong(idSequenceService.genId()));
        membercouponrels.setMembercode(memberCode);
        membercouponrels.setLenovoid(lenovoid);
        membercouponrels.setSalescouponid(salescoupons.getId());
        membercouponrels.setUsescope(salescoupons.getUsescope());
        membercouponrels.setCouponcode(salescoupons.getCouponcode());
        membercouponrels.setShopid(salescoupons.getShopid());
        membercouponrels.setTerminal(salescoupons.getTerminal());
        membercouponrels.setName(salescoupons.getName());
        membercouponrels.setAmount(salescoupons.getAmount());
        membercouponrels.setConditions(salescoupons.getConditions());
        membercouponrels.setType(salescoupons.getType());
        membercouponrels.setDescription(salescoupons.getDescription());
        membercouponrels.setFromtime(salescoupons.getFromtime());
        membercouponrels.setTotime(salescoupons.getTotime());
        membercouponrels.setTotalnumber(salescoupons.getTotalnumber());
        membercouponrels.setSurplusnumber(salescoupons.getTotalnumber());
        membercouponrels.setClassification(salescoupons.getClassification());
        membercouponrels.setSuperposition(salescoupons.getSuperposition());
        membercouponrels.setCouponsource(CouponConstant.COUPON_SOURCE_ALL_USER);
        membercouponrels.setEppgroup(salescoupons.getEppgroup());
        membercouponrels.setBatchno(batchNo);
        membercouponrels.setStatus(0);//0未使用 1已使用
        membercouponrels.setDisabled(0);//0未禁用 1已禁用
        membercouponrels.setCreatetime(new Date());
        membercouponrels.setUpdatetime(new Date());
        membercouponrels.setCreateby("ALL_USER");
        membercouponrels.setCurrencyCode(salescoupons.getCurrencyCode());
    }

    @Override
    public RemoteResult<PageModel2<MembercouponrelsApi>> getAppSaleCoupons(Tenant tenant, String lenovoId, String terminal, String status, PageQuery pageQuery) {
        return this.getAppSaleCoupons(lenovoId, String.valueOf(tenant.getShopId()), terminal, status, pageQuery);
    }

    @Override
    public RemoteResult<PageModel2<MembercouponrelsApi>> getAppSaleCoupons(String lenovoId, String shopid, String terminal, String status, PageQuery pageQuery) {
        RemoteResult<PageModel2<MembercouponrelsApi>> result = new RemoteResult<PageModel2<MembercouponrelsApi>>(false);
        try {
            Map<String, Object> map = new HashMap<String, Object>();
            map.put("lenovoid", lenovoId);
            map.put("shopid", shopid);
//            map.put("terminal",terminal);
            map.put("disabled", "0");
            if (status != null) {
                map.put("status", status);
            }
            PageModel2<Membercouponrels> res = memberCouponrelsManager.getMemberCouponrelsPage(pageQuery, map);
            if (res != null && res.getDatas() != null) {
                List<Membercouponrels> list = res.getDatas();
                List<MembercouponrelsApi> listapi = new ArrayList<MembercouponrelsApi>();
                MembercouponrelsApi api = null;
                for (Membercouponrels s : list) {
                    api = new MembercouponrelsApi();
                    new DomainUtil().copy(s, api);
                    listapi.add(api);
                }
                if (listapi.size() == 0) {
                    result.setT(new PageModel2<MembercouponrelsApi>());
                } else {
                    result.setT(new PageModel2<MembercouponrelsApi>(pageQuery, listapi));
                }
                result.setResultMsg(CouponConstant.RESULT_MSG_SUC);
                result.setResultCode(CouponConstant.RESULT_CODE_SUC);
                result.setSuccess(true);
            }
        } catch (Exception e) {
            log.error(ExceptionUtil.getStackTrace(e));
        }
        return result;
    }

    @Override
    public RemoteLenovo<PageModel2<MembercouponrelsApi>> getMemberCouponrelsPage4UserCenter(Tenant tenant, String lenovoId, String terminal, String status, String time, PageQuery pageQuery) {

        return this.getMemberCouponrelsPage4UserCenter(lenovoId, String.valueOf(tenant.getShopId()), terminal, status, time, pageQuery);
    }

    /**
     * 个人中心用户可以查看该商城的所有优惠券
     *
     * @param lenovoId
     * @param shopid    字符串 Lenovo，Think，EPP
     * @param terminal  1pc 2wap 3app 4微信
     * @param status    0未使用  1已使用
     * @param time
     * @param pageQuery
     * @return
     */
    @Override
    public RemoteLenovo<PageModel2<MembercouponrelsApi>> getMemberCouponrelsPage4UserCenter(String lenovoId, String shopid, String terminal, String status, String time, PageQuery pageQuery) {
       /* if(updateConfig.getShardingFlag()){
            return  newMemberCouponsApi.getMemberCouponrelsPage4UserCenter(lenovoId,shopid,terminal,status,time,pageQuery);
        }*/
        RemoteLenovo<PageModel2<MembercouponrelsApi>> result = new RemoteLenovo<PageModel2<MembercouponrelsApi>>();
        try {
            Map<String, Object> map = new HashMap<String, Object>();
            map.put("lenovoid", lenovoId);
            map.put("shopid", shopid);
//            map.put("terminal",terminal);
            map.put("createtime_start", dealTime(time));
            map.put("disabled", "0");//未禁用的disabled
            if (status != null) {
                map.put("status", status);
            }
            PageModel2<Membercouponrels> res = memberCouponrelsManager.getMemberCouponrelsInfoPage(pageQuery, map);
            System.out.println("res=" + JacksonMapper.obj2json(res));
            if (res != null && res.getDatas() != null) {
                List<Membercouponrels> list = res.getDatas();
                List<MembercouponrelsApi> listapi = new ArrayList<MembercouponrelsApi>();
                int allCount;//全部
                int canbeUser;//未使用且未过期数量
                int InvalueableCount;//已使用数量
                int expirecount;//已过期且未使用数量
                Map<String, Object> parmmap = new HashMap<String, Object>();
                parmmap.put("lenovoid", lenovoId);
                parmmap.put("shopid", shopid);
                allCount = memberCouponrelsManager.getMembercouponrelsCount(parmmap); //总数
                parmmap.put("status", 0);//未使用
                canbeUser = memberCouponrelsManager.getMembercouponrelsCount(parmmap);
                parmmap.put("status", 1);//已使用
                InvalueableCount = memberCouponrelsManager.getMembercouponrelsCount(parmmap);
                parmmap.put("status", 2);//已经过期的
                expirecount = memberCouponrelsManager.getMembercouponrelsCount(parmmap);

                MembercouponrelsApi api = null;
                for (Membercouponrels s : list) {
                    api = new MembercouponrelsApi();
                    new DomainUtil().copy(s, api);
                    if (s.getStatus() == 0 && s.getTotime().getTime() > new Date().getTime()) {
                        api.setStatus(0);
                    } else if (s.getStatus() == 1) {
                        api.setStatus(1);
                    } else {
                        api.setStatus(2);
                    }
                    listapi.add(api);
                }
                if (listapi.size() == 0) {
                    result.setT(new PageModel2<MembercouponrelsApi>());
                } else {
                    result.setT(new PageModel2<MembercouponrelsApi>(pageQuery, listapi));
                }
                result.setAllCount(allCount);//总数
                result.setCanUserCount(canbeUser);//未使用的且未过期的
                result.setInvalueableCount(InvalueableCount);//已使用的
                result.setExpireCount(expirecount);//已经过期的且未使用的
                result.setResultMsg(CouponConstant.RESULT_MSG_SUC);
                result.setResultCode(CouponConstant.RESULT_CODE_SUC);
                result.setSuccess(true);
            }
        } catch (Exception e) {
            result.setSuccess(false);
            result.setResultMsg(ErrorMessageEnum.ERROR_SERVICE.getCommon());
            result.setResultCode(ErrorMessageEnum.ERROR_SERVICE.getCode());
            log.error(ExceptionUtil.getStackTrace(e));
        }
        return result;
    }

    public RemoteLenovo<PageModel2<MembercouponrelsApi>> getMemberCouponrelsPage4WapUserCenter(Tenant tenant, String lenovoId, String terminal, String status, PageQuery pageQuery) {

        return this.getMemberCouponrelsPage4WapUserCenter(lenovoId, String.valueOf(tenant.getShopId()), terminal, status, pageQuery);
    }

    /**
     * 个人中心用户可以查看该商城的所有优惠券
     *
     * @param lenovoId
     * @param shopid    字符串 Lenovo，Think，EPP
     * @param terminal  1pc 2wap 3app 4微信
     * @param status    0未使用  1已使用 2过期的
     * @param pageQuery
     * @return
     */
    @Override
    public RemoteLenovo<PageModel2<MembercouponrelsApi>> getMemberCouponrelsPage4WapUserCenter(String lenovoId, String shopid, String terminal, String status, PageQuery pageQuery) {
       /* if(updateConfig.getShardingFlag()){
            return  newMemberCouponsApi.getMemberCouponrelsPage4WapUserCenter(lenovoId,shopid,terminal,status,pageQuery);
        }*/
        RemoteLenovo<PageModel2<MembercouponrelsApi>> result = new RemoteLenovo<PageModel2<MembercouponrelsApi>>();
        try {
            Map<String, Object> map = new HashMap<String, Object>();
            map.put("lenovoid", lenovoId);
            map.put("shopid", shopid);
//            map.put("terminal",terminal);
            map.put("disabled", "0");//未禁用的
            if (status != null) {
                map.put("status", status);
            }
            PageModel2<Membercouponrels> res = memberCouponrelsManager.getMemberCouponrelsInfoPage(pageQuery, map);
            log.info("res=", JacksonMapper.obj2json(res));
            if (res != null && res.getDatas() != null) {
                List<Membercouponrels> list = res.getDatas();
                List<MembercouponrelsApi> listapi = new ArrayList<MembercouponrelsApi>();
                MembercouponrelsApi api = null;
                for (Membercouponrels s : list) {
                    api = new MembercouponrelsApi();
                    new DomainUtil().copy(s, api);
                    listapi.add(api);
                }
                if (listapi.size() == 0) {
                    result.setT(new PageModel2<MembercouponrelsApi>());
                } else {
                    result.setT(new PageModel2<MembercouponrelsApi>(pageQuery, listapi));
                }
                result.setResultMsg(CouponConstant.RESULT_MSG_SUC);
                result.setResultCode(CouponConstant.RESULT_CODE_SUC);
                result.setSuccess(true);
            }
        } catch (Exception e) {
            result.setSuccess(false);
            result.setResultMsg(ErrorMessageEnum.ERROR_SERVICE.getCommon());
            result.setResultCode(ErrorMessageEnum.ERROR_SERVICE.getCode());
            log.error(ExceptionUtil.getStackTrace(e));
        }
        return result;
    }

    @Override
    public RemoteResult insertBatchMembercouponrels(List<MembercouponrelsApi> list) {
        log.info("insertBatchMembercouponrels " + list);
        RemoteResult result = new RemoteResult(false);

        try {
            if (list != null && list.size() > 0) {
                List<Membercouponrels> membercouponrelsList = new ArrayList<Membercouponrels>();
                Membercouponrels membercouponrels = null;
                for (MembercouponrelsApi api : list) {
                    membercouponrels = new Membercouponrels();
                    new DomainUtil().copy(api, membercouponrels);
                    membercouponrels.setId(Long.parseLong(idSequenceService.genId()));
                    membercouponrelsList.add(membercouponrels);
                }
                ResponseResult remoteResult = memberCouponrelsManager.insertBatchMembercouponrels(membercouponrelsList);
                if (remoteResult.isSuccess()) {
                    result.setResultMsg(CouponConstant.RESULT_MSG_SUC);
                    result.setResultCode(CouponConstant.RESULT_CODE_SUC);
                    log.info("批量插入excel用户优惠券成功");
                    result.setSuccess(true);
                }
            } else {
                result.setResultMsg(CouponConstant.RESULT_MSG_ERROR_PARAM);
                result.setResultCode(CouponConstant.RESULT_CODE_ERROR_PARAM);
                log.info("批量插入excel用户优惠券失败");
                result.setSuccess(false);
            }
        } catch (Exception e) {
            log.error("insertBatchMembercouponrels保存券失败: " + ExceptionUtil.getStackTrace(e));
        }
        return result;
    }

    @Override
    public RemoteResult getMemberCouponsStatus(Map map) {
        log.info("getMemberCouponsStatus 参数：shopId=" + map.get("shopId") + ",lenovoId=" + map.get("lenovoId") + ",salesCouponId=" + map.get("salesCouponId"));
        RemoteResult result = new RemoteResult(false);
        try {
            ResponseResult<List<Membercouponrels>> res = memberCouponrelsManager.getMemberCouponsStatus(map);
            if (res.isSuccess() && res.getData() != null) {
                List<Membercouponrels> list = res.getData();
                List<Membercouponrels> listApi = new ArrayList<Membercouponrels>();
                Membercouponrels memApi = null;
                for (Membercouponrels mem : list) {
                    memApi = new Membercouponrels();
                    new DomainUtil().copy(mem, memApi);
                    listApi.add(memApi);
                }
                if (listApi.size() == 0) {
                    log.error("未找到用户" + map.get("lenovoId") + "下拥有" + map.get("salesCouponId") + "该优惠券");
                    result.setResultMsg(ErrorMessageEnum.ERROR_CANT_FIND_COUPON_INOF.getCommon());
                    result.setResultCode(ErrorMessageEnum.ERROR_CANT_FIND_COUPON_INOF.getCode());
                    result.setT(listApi);
                    result.setSuccess(true);
                    log.info("getMemberCouponsStatus获取成功");
                } else {
                    result.setResultMsg(CouponConstant.RESULT_MSG_SUC);
                    result.setResultCode(CouponConstant.RESULT_CODE_SUC);
                    result.setT(listApi);
                    result.setSuccess(true);
                    log.info("getMemberCouponsStatus获取成功");
                }
            } else {
                result.setResultMsg(CouponConstant.RESULT_MSG_FAIL);
                result.setResultCode(CouponConstant.RESULT_CODE_FAIL);
                result.setSuccess(false);
                log.info("getMemberCouponsStatus获取失败");
            }
        } catch (Exception e) {
            result.setResultMsg(CouponConstant.RESULT_MSG_FAIL);
            result.setResultCode(CouponConstant.RESULT_CODE_FAIL);
            result.setSuccess(false);
            log.error("getMemberCouponsStatus获取失败: " + ExceptionUtil.getStackTrace(e));
        }
        return result;
    }

    @Override
    public RemoteResult<List<MembercouponrelsApi>> getMemberCouponRelBySalesCouponId(Long salesCouponId) {
        log.info("getMemberCouponRelBySalesCouponId, salesCouponId=" + salesCouponId);
        RemoteResult remoteResult = new RemoteResult(false);
        try {
            ResponseResult<List<Membercouponrels>> result = memberCouponrelsManager.getMemberCouponRelBySalesCouponId(salesCouponId);
            if (result != null && result.isSuccess()) {
                List<Membercouponrels> membercouponrelsList = result.getData();
                DomainUtil domainUtil = new DomainUtil();
                List<MembercouponrelsApi> membercouponrelsApiList = new ArrayList<MembercouponrelsApi>(membercouponrelsList.size());
                for (Membercouponrels membercouponrels : membercouponrelsList) {
                    MembercouponrelsApi membercouponrelsApi = new MembercouponrelsApi();
                    domainUtil.copy(membercouponrels, membercouponrelsApi);
                    membercouponrelsApiList.add(membercouponrelsApi);
                }
                remoteResult.setSuccess(true);
                remoteResult.setResultCode(CouponConstant.RESULT_CODE_SUC);
                remoteResult.setResultMsg(CouponConstant.RESULT_MSG_SUC);
                remoteResult.setT(membercouponrelsApiList);
                return remoteResult;
            }
        } catch (Exception e) {
            log.error("getMemberCouponRelBySalesCouponId 异常：" + ExceptionUtil.getStackTrace(e));
        }
        return null;
    }

    @Override
    public RemoteResult updateBatchMembercouponrels(List<MembercouponrelsApi> list) {
        RemoteResult result = new RemoteResult(false);
        try {
            if (list != null && list.size() > 0) {
                List<Membercouponrels> membercouponrelsList = new ArrayList<Membercouponrels>();
                Membercouponrels membercouponrels = null;
                for (MembercouponrelsApi api : list) {
                    membercouponrels = new Membercouponrels();
                    new DomainUtil().copy(api, membercouponrels);
                    membercouponrelsList.add(membercouponrels);
                }

                ResponseResult remoteResult = memberCouponrelsManager.updateBatchMembercouponrels(membercouponrelsList);
                if (remoteResult.isSuccess()) {
                    result.setResultMsg(CouponConstant.RESULT_MSG_SUC);
                    result.setResultCode(CouponConstant.RESULT_CODE_SUC);
                    log.info("批量更新用户优惠券成功");
                    result.setSuccess(true);
                }
            } else {
                result.setResultMsg(CouponConstant.RESULT_MSG_ERROR_PARAM);
                result.setResultCode(CouponConstant.RESULT_CODE_ERROR_PARAM);
                log.info("批量更新用户优惠券失败");
                result.setSuccess(false);
            }
        } catch (Exception e) {
            log.error("updateBatchMembercouponrels保存券失败: " + ExceptionUtil.getStackTrace(e));
        }
        return result;
    }
    @Override
    public RemoteResult<Integer> getMembercouponrelsByUser(Tenant tenant, String lenovoid, String terminal) {
        RemoteResult<Integer> result = new RemoteResult<Integer>();
        try {
            if(tenant != null && StringUtils.isNotEmpty(lenovoid)&&StringUtils.isNotEmpty(terminal)){
                log.info("getMembercouponrelsByUser param: Tenant:{},lenovoid:{},terminal:{}",tenant,lenovoid,terminal);
                Map<String,Object> parmmap = new HashMap<String,Object>();
                parmmap.put("lenovoid",lenovoid);
                parmmap.put("shopid",tenant.getShopId());
                parmmap.put("terminal",terminal);
                parmmap.put("status",0);//未使用的
                log.info("getMembercouponrelsCount map:{}",JacksonMapper.obj2json(parmmap));
                Integer totalNum = memberCouponrelsManager.getMembercouponrelsCount(parmmap); //有效数
                result.setT(totalNum);
                result.setSuccess(true);
                result.setResultMsg(CouponConstant.RESULT_MSG_SUC);
                result.setResultCode(CouponConstant.RESULT_CODE_SUC);
                return result;
            }else{
                result.setSuccess(false);
                result.setResultMsg(CouponConstant.RESULT_MSG_ERROR_PARAM);
                result.setResultCode(CouponConstant.RESULT_CODE_ERROR_PARAM);
                return result;
            }
        } catch (Exception e) {
            log.error("getMembercouponrelsByUser error:{}",e);
            result.setSuccess(false);
            result.setResultMsg(CouponConstant.RESULT_MSG_ERROR);
            result.setResultCode(CouponConstant.RESULT_CODE_ERROR);
            return result;
        }
    }
    @Override
    public RemoteResult insertBatchMembercouponrelsSharding(List<MembercouponrelsApi> list) {
        log.info("insertBatchMembercouponrelsSharding " + list);
        RemoteResult result = new RemoteResult(false);
        try {
            if (list != null && list.size() > 0) {
                List<Membercouponrels> membercouponrelsList = new ArrayList<Membercouponrels>();
                Membercouponrels membercouponrels = null;
                for (MembercouponrelsApi api : list) {
                    membercouponrels = new Membercouponrels();
                    new DomainUtil().copy(api, membercouponrels);
                    membercouponrelsList.add(membercouponrels);
                }
                ResponseResult remoteResult = memberCouponrelsManager.insertBatchMembercouponrelsSharding(membercouponrelsList);
                if (remoteResult.isSuccess()) {
                    result.setResultMsg(CouponConstant.RESULT_MSG_SUC);
                    result.setResultCode(CouponConstant.RESULT_CODE_SUC);
                    log.info("批量插入用户优惠券成功");
                    result.setSuccess(true);
                }
            } else {
                result.setResultMsg(CouponConstant.RESULT_MSG_ERROR_PARAM);
                result.setResultCode(CouponConstant.RESULT_CODE_ERROR_PARAM);
                log.info("批量插入用户优惠券失败");
                result.setSuccess(false);
            }
        } catch (Exception e) {
            log.error("insertBatchMembercouponrelsSharding保存券失败: " + ExceptionUtil.getStackTrace(e));
        }
        return result;
    }


    private String dealTime(String time) {
        String date = null;
        if (com.lenovo.m2.arch.tool.util.StringUtils.isBlank(time) || time.equals("0")) {
            return date;
        }
        if (time.equals("1"))//一周
            date = getCurrentTimeaddDay(-7);
        if (time.equals("2"))//一月
            date = getCurrentTimeaddMonth(-1);
        if (time.equals("3"))//三月
            date = getCurrentTimeaddMonth(-3);
        if (time.equals("4"))//六月
            date = getCurrentTimeaddMonth(-6);
        if (time.equals("5"))//一年
            date = getCurrentTimeaddMonth(-12);
        return date;
    }

    private String getCurrentTimeaddDay(int days) {
        Date date = new Date();//取时间
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.add(calendar.DATE, days);
        date = calendar.getTime();
        return formatDateTime(date, "yyyy-MM-dd");
    }

    private String getCurrentTimeaddMonth(int months) {
        Date date = new Date();//取时间
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.add(calendar.MONTH, months);
        date = calendar.getTime();
        return formatDateTime(date, "yyyy-MM-dd");
    }

    private String formatDateTime(java.util.Date date, String format) {
        SimpleDateFormat simpledateformat = new SimpleDateFormat(
                format);
        return simpledateformat.format(date);
    }

    @Override
    public RemoteResult<Integer> bindAllMemberSalesCouponsN(Tenant tenant, String lenovoid, String memberCode, String groupcode) {
        MethodResult<Integer, Void, Void> me = this.bindAllMemberSalesCouponsN(lenovoid, memberCode, groupcode, String.valueOf(tenant.getShopId()));
        RemoteResult<Integer> re = new RemoteResult<Integer>();
        if (null == me) {
            re.setSuccess(false);
            re.setResultCode(ErrorMessageEnum.ERROR_SERVICE.getCode());
            re.setResultMsg(ErrorMessageEnum.ERROR_SERVICE.getCommon());
            return re;
        }
        if (!me.isSuccess()) {
            re.setSuccess(false);
            re.setResultCode(me.getCode());
            re.setResultMsg(me.getMsg());
            return re;
        }
        re.setSuccess(true);
        re.setResultCode(me.getCode());
        re.setT(me.getT1());
        return re;
    }

    @Override
    public int bindAllMemberSalesCoupons(String lenovoid, String memberCode, String groupcode, String shopid) {
        MethodResult<Integer, Void, Void> me = this.bindAllMemberSalesCouponsN(lenovoid, memberCode, groupcode, shopid);
        if (null == me) {
            return 0;
        }
        if (!me.isSuccess()) {
            return 0;
        }
        return me.getT1();
    }
}
