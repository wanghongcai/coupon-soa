package com.lenovo.m2.couponV2.service.impl;

import com.alibaba.fastjson.JSONObject;
import com.jayway.jsonpath.JsonPath;
import com.lenovo.m2.arch.framework.domain.PageModel2;
import com.lenovo.m2.arch.framework.domain.PageQuery;
import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.framework.domain.Tenant;
import com.lenovo.m2.arch.tool.util.StringUtils;
import com.lenovo.m2.couponV2.api.dubboModel.DisplayPositionEnum;
import com.lenovo.m2.couponV2.api.dubboModel.MemberExcelTempApi;
import com.lenovo.m2.couponV2.api.model.*;
import com.lenovo.m2.couponV2.api.service.SalescouponsService;
import com.lenovo.m2.couponV2.common.*;
import com.lenovo.m2.couponV2.common.enums.ErrorMessageEnum;
import com.lenovo.m2.couponV2.common.enums.ModulNameEnum;
import com.lenovo.m2.couponV2.common.exception.ExceptionUtil;
import com.lenovo.m2.couponV2.common.util.JsonUtil;
import com.lenovo.m2.couponV2.common.vo.LogVo;
import com.lenovo.m2.couponV2.dao.mybatis.model.*;
import com.lenovo.m2.couponV2.dao.util.ResponseResult;
import com.lenovo.m2.couponV2.manager.*;
import com.lenovo.m2.couponV2.manager.conf.UpdateConfig;
import com.lenovo.m2.couponV2.manager.redisObject.RedisObjectManager;
import com.lenovo.m2.couponV2.manager.redisObject.lock.RedisLock;
import com.lenovo.m2.couponV2.remote.IDSequenceService;
import com.lenovo.open.gateway.java.sdk.JavaSDKClient;
import com.lenovo.open.gateway.java.sdk.util.Response;
import com.lenovo.price.model.NotifyType;
import com.lenovo.price.model.massage.CouponChangeMessage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Created by zhaocl1 on 2015/8/26.
 */
@Service("salescouponsService")
public class SalescouponsServiceImpl implements SalescouponsService {
    private static final Logger log = LoggerFactory.getLogger(SalescouponsServiceImpl.class);

    @Autowired
    private SalescouponsManager salescouponsManager;
    @Autowired
    private DetailsruleManager detailsruleManager;
    @Autowired
    private ProductruleManager productruleManager;
    @Autowired
    MemberCouponrelsManager memberCouponrelsManager;
    @Autowired
    private RedisObjectManager redisObjectManager;
    @Autowired
    private DistributorruleManager distributorruleManager;
    @Autowired
    private LogService logService;
    @Autowired
    private IDSequenceService idSequenceService;
    @Autowired
    private CouponchecksManager couponchecksManager;
    ExecutorService service = Executors.newFixedThreadPool(10);

    @Value("${openapiUrl}")
    private String openapiUrl;
    @Value("${openapiAppKey}")
    private String openapiAppKey;
    @Value("${openapiScrebt}")
    private String openapiScrebt;

    private String invokeOpenPlateMethed = "lenovo.fxs.getProductForSearch.com_hs";
    //es开关

    private static ArrayList<String> list = new ArrayList<String>();
    static {
        list.add("goodscategoryids");
        list.add("goodcodes");
        list.add("detailsruleApiList");
        list.add("productruleApi");
        list.add("pageSize");
        list.add("nojoingoodcodes");
        list.add("createTime");
        list.add("lastModifyTime");
        list.add("version");
        list.add("facodes");
        list.add("distributorruleApiList");
        list.add("productgroupid");
        list.add("productgroupno");
        list.add("group2facodes");
    }

    @Override
    public RemoteResult<PageModel2<SalescouponsApi>> getSalescouponsInfoPage(PageQuery pageQuery, Map map) {
        RemoteResult result = new RemoteResult(false);
        try{
            PageModel2<Salescoupons> rs = salescouponsManager.getSalescouponsInfoPage(pageQuery, map);
            List<SalescouponsApi> salescouponsApiList = new ArrayList<SalescouponsApi>();
            if(null != rs && null !=rs.getDatas() && rs.getDatas().size() > 0 ){
                for (Salescoupons coupon : rs.getDatas()) {
                    SalescouponsApi salescouponsApi = new SalescouponsApi();
                    new DomainUtil().copy(coupon, salescouponsApi);
                    salescouponsApiList.add(salescouponsApi);
                }
            }
            PageModel2<SalescouponsApi> pageModel=new PageModel2<SalescouponsApi>(pageQuery,salescouponsApiList);
            result.setResultMsg(CouponConstant.RESULT_MSG_SUC);
            result.setResultCode(CouponConstant.RESULT_CODE_SUC);
            result.setT(pageModel);
            result.setSuccess(true);
        }catch (Exception e){
            log.error(ExceptionUtil.getStackTrace(e));
        }
        return result;
    }

    @Override
    public RemoteResult insertSalescoupons(SalescouponsApi salescouponsApi) {
        log.info(" insertSalescoupons "+salescouponsApi);
        RemoteResult result = new RemoteResult(false);
        try{
            if(salescouponsApi!=null){
                //如果是慧商按产品组新建优惠券 验证优惠券和分销商的签约关系

               /* List<String> unconfirmed = confirmProductGroupIdAndFaCodesRelation(salescouponsApi);
                if(!CollectionUtils.isEmpty(unconfirmed)){
                    result.setResultCode(CouponConstant.RESULT_CODE_FAIL);
                    result.setResultMsg(CouponConstant.RESULT_MSG_FAIL+"未查询到分销商"+unconfirmed+"与产品组"+salescouponsApi.getProductgroupno()+"的签约关系");
                    return result;
                }*/
            	BaseInfo baseinfo = confirmProductGroupIdAndFaCodesRelation(salescouponsApi);
            	if(0!= baseinfo.getRc()){
            		 result.setResultCode(CouponConstant.RESULT_CODE_FAIL);
            		  result.setResultMsg(baseinfo.getMsg());
                      return result;
            	}
                Salescoupons salesCoupons = new Salescoupons();
                new DomainUtil().copy2(salescouponsApi,salesCoupons,list);
                ResponseResult<Salescoupons> responseResult = salescouponsManager.insertSalescoupons(salesCoupons);
                if(responseResult.isSuccess()){
                    //依旧换新券不绑定商品和分类
                    if(salescouponsApi.getUsescope() == CouponConstant.COUPON_USESCOPE_YIJIUHUANXIN){
                        result.setResultMsg(CouponConstant.RESULT_MSG_SUC);
                        result.setResultCode(CouponConstant.RESULT_CODE_SUC);
                        result.setSuccess(true);
                    }

                    if(salescouponsApi.getType() == CouponConstant.COUPON_TYPE_DETAIL_1 && salescouponsApi.getDetailsruleApiList() != null && salescouponsApi.getDetailsruleApiList().size() >0){  //分类券
                        List<DetailsruleApi> listapi = salescouponsApi.getDetailsruleApiList();
                        List<Detailsrule> list = new ArrayList<Detailsrule>();
                        Detailsrule detailsrule = null;
                        for(DetailsruleApi detail : listapi){
                            detailsrule = new Detailsrule();
                            new DomainUtil().copy(detail, detailsrule);
                            detailsrule.setSalescouponid(responseResult.getData().getId());
                            list.add(detailsrule);
                        }
                        ResponseResult resdetail = detailsruleManager.insertBatchDetailsrule(list);
                        if(resdetail.isSuccess()){
                            result.setResultMsg(CouponConstant.RESULT_MSG_SUC);
                            result.setResultCode(CouponConstant.RESULT_CODE_SUC);
                            result.setSuccess(true);
                        }
                    }else if(salescouponsApi.getType() == CouponConstant.COUPON_TYPE_PRODUCT_2 && salescouponsApi.getProductruleApi() != null){//单品券
                        Productrule productrule = new Productrule();
                        new DomainUtil().copy(salescouponsApi.getProductruleApi(), productrule);
                        productrule.setSalescouponid(responseResult.getData().getId());
                        ResponseResult respro = productruleManager.insertProductrule(productrule);
                        if(respro.isSuccess()){
                            result.setResultMsg(CouponConstant.RESULT_MSG_SUC);
                            result.setResultCode(CouponConstant.RESULT_CODE_SUC);
                            result.setSuccess(true);
                        }
                    }else if(salescouponsApi.getType() == CouponConstant.COUPON_TYPE_PRODUCTGROUP_3 && salescouponsApi.getDistributorruleApiList() != null && salescouponsApi.getDistributorruleApiList().size() >0){  //慧商按产品组
                        List<DistributorruleApi> listapi = salescouponsApi.getDistributorruleApiList();
                        List<Distributorrule> list = new ArrayList<Distributorrule>();
                        Distributorrule distributorrule = null;
                        for(DistributorruleApi detail : listapi){
                            distributorrule = new Distributorrule();
                            new DomainUtil().copy(detail, distributorrule);
                            distributorrule.setSalescouponid(responseResult.getData().getId());
                            list.add(distributorrule);
                        }
                        ResponseResult resdetail = distributorruleManager.insertBatchDistributorrule(list);
                        if(resdetail.isSuccess()){
                            result.setResultMsg(CouponConstant.RESULT_MSG_SUC);
                            result.setResultCode(CouponConstant.RESULT_CODE_SUC);
                            result.setSuccess(true);
                        }
                    }
                }
            }else {
                result.setResultMsg(CouponConstant.RESULT_MSG_ERROR_PARAM);
                result.setResultCode(CouponConstant.RESULT_CODE_ERROR_PARAM);
            }
        }catch (Exception e){
            log.error(ExceptionUtil.getStackTrace(e));
        }
        return result;
    }

    @Override
    public RemoteResult<SalescouponsApi> getSalescoupons(SalescouponsApi salescouponsApi) {
        RemoteResult result = new RemoteResult(false);
        try{
            if(salescouponsApi != null && salescouponsApi.getId()>0){
                ResponseResult<Salescoupons> responseResult = salescouponsManager.getSalescoupons(salescouponsApi.getId());
                if(responseResult.isSuccess() && responseResult.getData() != null){
                    //依旧换新券不绑定商品和分类
                    if(salescouponsApi.getUsescope() == CouponConstant.COUPON_USESCOPE_YIJIUHUANXIN){
                        result.setResultMsg(CouponConstant.RESULT_MSG_SUC);
                        result.setResultCode(CouponConstant.RESULT_CODE_SUC);
                        result.setSuccess(true);
                    }

                    Salescoupons salescoupons = responseResult.getData();
                    SalescouponsApi salescouponsApi1 = new SalescouponsApi();
                    if(salescoupons.getType() == CouponConstant.COUPON_TYPE_DETAIL_1){ //分类
                        Detailsrule detailsrule = new Detailsrule();
                        detailsrule.setSalescouponid(salescouponsApi.getId());
                        ResponseResult<List<Detailsrule>> resdetail = detailsruleManager.getDetailsruleList(detailsrule);
                        if(resdetail.isSuccess() && resdetail.getData() != null && resdetail.getData().size() > 0){
                            List<Detailsrule> list = resdetail.getData();
                            List<DetailsruleApi> listapi = new ArrayList<DetailsruleApi>();
                            DetailsruleApi detailsruleApi = null;
                            for(Detailsrule detail : list){
                                detailsruleApi = new DetailsruleApi();
                                new DomainUtil().copy(detail, detailsruleApi);
                                listapi.add(detailsruleApi);
                            }
                            salescouponsApi1.setDetailsruleApiList(listapi);
                        }
                    }else if(salescoupons.getType() == CouponConstant.COUPON_TYPE_PRODUCT_2){ //商品
                        Productrule productrule = new Productrule();
                        productrule.setSalescouponid(salescouponsApi.getId());
                        ResponseResult<List<Productrule>> respro = productruleManager.getProductruleList(productrule);
                        if(respro.isSuccess() && respro.getData() != null && respro.getData().size() == 1){
                            Productrule productrule1  = respro.getData().get(0);
                            ProductruleApi productruleApi = new ProductruleApi();
                            new DomainUtil().copy(productrule1, productruleApi);
                            salescouponsApi1.setProductruleApi(productruleApi);
                        }
                    }else if(salescoupons.getType() == CouponConstant.COUPON_TYPE_PRODUCTGROUP_3){ //产品组
                        Distributorrule distributorrule = new Distributorrule();
                        distributorrule.setSalescouponid(salescouponsApi.getId());
                        ResponseResult<List<Distributorrule>> resdetail = distributorruleManager.getDistributorruleListGroupBy(distributorrule);
                        if(resdetail.isSuccess() && resdetail.getData() != null && resdetail.getData().size() > 0){
                            List<Distributorrule> list = resdetail.getData();
                            List<DistributorruleApi> listapi = new ArrayList<DistributorruleApi>();
                            DistributorruleApi distributorruleApi = null;
                            Set<String> set = new HashSet<String>();
                            for(Distributorrule detail : list){
                            	String temp = detail.getProductgroupid()+"_"+detail.getProductgroupno();
                            	if(set.contains(temp)){
                            		continue;
                            	}
                            	set.add(temp);
                                distributorruleApi = new DistributorruleApi();
                                new DomainUtil().copy(detail, distributorruleApi);
                                listapi.add(distributorruleApi);
                            }
                            salescouponsApi1.setDistributorruleApiList(listapi);
                        }
                    }

                    new DomainUtil().copy(responseResult.getData(),salescouponsApi1);
                    log.info("编辑优惠券记录日志 参数salescouponsApi={}",JsonUtil.toJson(salescouponsApi1));
                    result.setResultMsg(CouponConstant.RESULT_MSG_SUC);
                    result.setResultCode(CouponConstant.RESULT_CODE_SUC);
                    result.setT(salescouponsApi1);
                    result.setSuccess(true);
                }
            }else {
                result.setResultMsg(CouponConstant.RESULT_MSG_ERROR_PARAM);
                result.setResultCode(CouponConstant.RESULT_CODE_ERROR_PARAM);
            }
        }catch (Exception e){
            log.error(ExceptionUtil.getStackTrace(e));
        }
        return result;
    }

    @Override
    public RemoteResult<Boolean> delSalescoupons(SalescouponsApi salescouponsApi) {
        // todo
        return null;
    }

    /**
     *
     * @param salescouponsApi
     * @return
     */
    @Override
    @Transactional(rollbackFor=Exception.class)
    public RemoteResult editSalescoupons(SalescouponsApi salescouponsApi) throws Exception {
        log.info("editSalescoupons "+salescouponsApi);
        RemoteResult result = new RemoteResult(false);
        if( salescouponsApi != null && salescouponsApi.getId() > 0 && salescouponsApi.getType() != null ){
           /* List<String> unconfirmed = confirmProductGroupIdAndFaCodesRelation(salescouponsApi);
            if(!CollectionUtils.isEmpty(unconfirmed)){
                result.setResultCode(CouponConstant.RESULT_CODE_FAIL);
                result.setResultMsg(CouponConstant.RESULT_MSG_FAIL+"未查询到分销商"+unconfirmed+"与产品组"+salescouponsApi.getProductgroupno()+"的签约关系");
                return result;
            }*/
        	BaseInfo baseinfo = confirmProductGroupIdAndFaCodesRelation(salescouponsApi);
        	if(0!= baseinfo.getRc()){
        		 result.setResultCode(CouponConstant.RESULT_CODE_FAIL);
        		  result.setResultMsg(baseinfo.getMsg());
                  return result;
        	}
            RemoteResult<SalescouponsApi> responseResult1 = this.getSalescoupons(salescouponsApi);
            if(responseResult1.isSuccess()){
                SalescouponsApi salescoupons_get = responseResult1.getT();
                log.info("editSalescoupons 老数据 "+salescoupons_get);
                //记录更新日志
                saveSalesCouponEditLog(salescoupons_get, salescouponsApi.getUpdateby());
                Salescoupons salescoupons = new Salescoupons();
                //更新主表
                new DomainUtil().copy2(salescouponsApi, salescoupons, list);
                salescoupons.setStatus(0);//编辑后优惠券/码的状态变为新建状态，需重新提交审核
                ResponseResult responseResult = salescouponsManager.editSalescoupons(salescoupons);
                if(responseResult.isSuccess()){
                    //依旧换新券不绑定商品和分类
                    if(salescouponsApi.getUsescope() == CouponConstant.COUPON_USESCOPE_YIJIUHUANXIN){
                        /**在
                         * 以旧换新时删除分类和商品表，以防止由其他类型的券保存后编辑时出现脏数据
                         */
                        Detailsrule dr = new Detailsrule();
                        dr.setSalescouponid(salescouponsApi.getId());
                        ResponseResult resdetail = detailsruleManager.delDetailsrule(dr);

                        Productrule pro = new Productrule();
                        pro.setSalescouponid(salescouponsApi.getId());
                        ResponseResult respro = productruleManager.delProductrule(pro);

                        result.setResultMsg(CouponConstant.RESULT_MSG_SUC);
                        result.setResultCode(CouponConstant.RESULT_CODE_SUC);
                        result.setSuccess(true);
                    }

                    if(salescoupons_get.getType() == salescouponsApi.getType()){
                        if(salescouponsApi.getType() == CouponConstant.COUPON_TYPE_DETAIL_1){ //分类
                            Detailsrule dr = new Detailsrule();
                            dr.setSalescouponid(salescouponsApi.getId());
                            ResponseResult resdetail = detailsruleManager.delDetailsrule(dr);
                            if(resdetail.isSuccess()){
                                List<DetailsruleApi> listapi = salescouponsApi.getDetailsruleApiList();
                                List<Detailsrule> list = new ArrayList<Detailsrule>();
                                Detailsrule detailsrule = null;
                                for(DetailsruleApi detail : listapi){
                                    detailsrule = new Detailsrule();
                                    new DomainUtil().copy(detail, detailsrule);
                                    list.add(detailsrule);
                                }
                                ResponseResult res = detailsruleManager.insertBatchDetailsrule(list);
                                if(res.isSuccess()){
                                    result.setResultMsg(CouponConstant.RESULT_MSG_SUC);
                                    result.setResultCode(CouponConstant.RESULT_CODE_SUC);
                                    result.setSuccess(true);
                                }
                            }
                        }else if(salescouponsApi.getType() == CouponConstant.COUPON_TYPE_PRODUCT_2){ //商品
                            Productrule pro = new Productrule();
                            pro.setSalescouponid(salescouponsApi.getId());
                            ResponseResult respro = productruleManager.delProductrule(pro);
                            if(respro.isSuccess()){
                                Productrule productrule = new Productrule();
                                new DomainUtil().copy(salescouponsApi.getProductruleApi(), productrule);
                                ResponseResult res = productruleManager.insertProductrule(productrule);
                                if(res.isSuccess()){
                                    result.setResultMsg(CouponConstant.RESULT_MSG_SUC);
                                    result.setResultCode(CouponConstant.RESULT_CODE_SUC);
                                    result.setSuccess(true);
                                }
                            }

                        }else if(salescouponsApi.getType() == CouponConstant.COUPON_TYPE_PRODUCTGROUP_3){  //慧商按产品组
                            Distributorrule dr = new Distributorrule();
                            dr.setSalescouponid(salescouponsApi.getId());
                            ResponseResult resdetail = distributorruleManager.delDistributorrule(dr);
                            log.info("editSalescoupons delDistributorrule return:"+JacksonMapper.obj2json(resdetail));

                            if(resdetail.isSuccess()){
                                List<DistributorruleApi> listapi = salescouponsApi.getDistributorruleApiList();
                                List<Distributorrule> list = new ArrayList<Distributorrule>();
                                Distributorrule distributorrule = null;
                                for(DistributorruleApi detail : listapi){
                                    distributorrule = new Distributorrule();
                                    new DomainUtil().copy(detail, distributorrule);
                                    list.add(distributorrule);
                                }
                                ResponseResult res = distributorruleManager.insertBatchDistributorrule(list);
                                log.info("editSalescoupons insertdata return:"+JacksonMapper.obj2json(res));
                                if(res.isSuccess()){
                                    result.setResultMsg(CouponConstant.RESULT_MSG_SUC);
                                    result.setResultCode(CouponConstant.RESULT_CODE_SUC);
                                    result.setSuccess(true);
                                    return result;
                                }
                            }
                        }
                    }else {
                        if(salescouponsApi.getType() == CouponConstant.COUPON_TYPE_DETAIL_1){
                            //原来保存的商品，现在要修改成分类
                            Productrule pro = new Productrule();
                            pro.setSalescouponid(salescouponsApi.getId());
                            ResponseResult respro = productruleManager.delProductrule(pro);
                            if(respro.isSuccess()){
                                List<DetailsruleApi> listapi = salescouponsApi.getDetailsruleApiList();
                                List<Detailsrule> list = new ArrayList<Detailsrule>();
                                Detailsrule detailsrule = null;
                                for(DetailsruleApi detail : listapi){
                                    detailsrule = new Detailsrule();
                                    new DomainUtil().copy(detail, detailsrule);
                                    list.add(detailsrule);
                                }
                                ResponseResult res = detailsruleManager.insertBatchDetailsrule(list);
                                if(res.isSuccess()){
                                    result.setResultMsg(CouponConstant.RESULT_MSG_SUC);
                                    result.setResultCode(CouponConstant.RESULT_CODE_SUC);
                                    result.setSuccess(true);
                                }
                            }
                        }else if(salescouponsApi.getType() == CouponConstant.COUPON_TYPE_PRODUCT_2){
                            //原来保存的产品组或分类，现在要修改成商品
                            ResponseResult resdetail = null;
                            if(salescoupons_get.getType() == CouponConstant.COUPON_TYPE_DETAIL_1){
                               //原来绑定分类
                                Detailsrule dr = new Detailsrule();
                                dr.setSalescouponid(salescouponsApi.getId());
                                 resdetail = detailsruleManager.delDetailsrule(dr);
                            }else{
                                //原来绑定产品组
                                Distributorrule dr = new Distributorrule();
                                dr.setSalescouponid(salescouponsApi.getId());
                                 resdetail = distributorruleManager.delDistributorrule(dr);
                            }

                            if(resdetail != null && resdetail.isSuccess()){
                                Productrule productrule = new Productrule();
                                new DomainUtil().copy(salescouponsApi.getProductruleApi(), productrule);
                                ResponseResult res = productruleManager.insertProductrule(productrule);
                                if(res.isSuccess()){
                                    result.setResultMsg(CouponConstant.RESULT_MSG_SUC);
                                    result.setResultCode(CouponConstant.RESULT_CODE_SUC);
                                    result.setSuccess(true);
                                }
                            }
                        }else if(salescouponsApi.getType() == CouponConstant.COUPON_TYPE_PRODUCTGROUP_3){
                            //原来保存的商品，现在要修改成产品组
                            Productrule pro = new Productrule();
                            pro.setSalescouponid(salescouponsApi.getId());
                            ResponseResult resdetail = productruleManager.delProductrule(pro);
                            log.info("editSalescoupons delDistributorrule return:"+JacksonMapper.obj2json(resdetail));

                            if(resdetail.isSuccess()){
                                List<DistributorruleApi> listapi = salescouponsApi.getDistributorruleApiList();
                                List<Distributorrule> list = new ArrayList<Distributorrule>();
                                Distributorrule distributorrule = null;
                                for(DistributorruleApi detail : listapi){
                                    distributorrule = new Distributorrule();
                                    new DomainUtil().copy(detail, distributorrule);
                                    list.add(distributorrule);
                                }
                                ResponseResult res = distributorruleManager.insertBatchDistributorrule(list);
                                log.info("editSalescoupons insertdata return:"+JacksonMapper.obj2json(res));
                                if(res.isSuccess()){
                                    result.setResultMsg(CouponConstant.RESULT_MSG_SUC);
                                    result.setResultCode(CouponConstant.RESULT_CODE_SUC);
                                    result.setSuccess(true);
                                    return result;
                                }
                            }
                        }
                    }
                }

                /**
                 * 更新缓存中数据 并且通知商品和搜索
                 * 已经审核过的优惠券在编辑时，进行缓存操作
                 */
                updateRedisAndNotice(salescoupons_get,result,salescoupons,salescouponsApi);
            }else {
                result.setResultMsg(CouponConstant.CAN_NOT_GET_CONPON_EFFIEC_MSG);
                result.setResultCode(CouponConstant.CAN_NOT_GET_CONPON_EFFIEC_NO);
            }
        }else {
            result.setResultMsg(CouponConstant.RESULT_MSG_ERROR_PARAM);
            result.setResultCode(CouponConstant.RESULT_CODE_ERROR_PARAM);
        }
        return result;
    }

    private  void updateRedisAndNotice(final SalescouponsApi salescoupons_get,final RemoteResult result,final Salescoupons salescoupons,final SalescouponsApi salescouponsApi){
        service.execute(new Runnable() {
            @Override
            public void run() {
                if(salescoupons_get.getStyle().equals(CouponConstant.COUPON_style_coupon_1)  && salescoupons_get.getHaspassed().equals(1) && salescoupons_get.getUsescope().equals( CouponConstant.COUPON_USESCOPE_ZHEKOU)  && salescoupons_get.getFromtime().getTime() < new Date().getTime()){
                    if(result.isSuccess()){
                        //缓存清理
                        try {
                            deleteSalescoupons4redis(salescoupons_get);
                        } catch (Exception e) {
                            log.error("deleteSalescoupons4redis"+e);

                        }
                        //更新通知无效次数
                        if(salescoupons_get.getNoticeValidCount() > salescoupons_get.getNoticeInvalidCount()){
                            RemoteResult remoteResult_invalid = updateNoticeInvalidCount(salescoupons_get.getId());
                            if(remoteResult_invalid.isSuccess()){
                                log.info("通知优惠券无效时更新缓存成功，参数id=["+salescoupons.getId()+"]");
                            }else {
                                log.info("通知优惠券无效时更新缓存出现错误，参数id=[" + salescoupons.getId() + "] " + remoteResult_invalid);
                            }
                        }

                        log.info("通知优惠券无效参数topic={},id={}",salescoupons_get.getId());
                        CouponChangeMessage message = new CouponChangeMessage();
                        message.setCouponId(salescoupons_get.getId());
                        message.setNotifyType(NotifyType.coupon_invalid);
                        log.info("通知优惠券无效结束id={}",salescoupons_get.getId());

                    }
                }
            }
        });
    }
    @Override
    public RemoteResult editSalescouponsOnly(SalescouponsApi salescouponsApi) {
        RemoteResult result = new RemoteResult(false);
        try {
            if( salescouponsApi != null && salescouponsApi.getId() > 0  ){
                //更新主表
                Salescoupons salescoupons = new Salescoupons();
                new DomainUtil().copy2(salescouponsApi, salescoupons, list);
//                salescoupons.setStatus(0);//编辑后优惠券/码的状态变为新建状态，需重新提交审核
                ResponseResult responseResult = salescouponsManager.editSalescoupons(salescoupons);
                if(responseResult.isSuccess()){
                    result.setResultMsg(CouponConstant.RESULT_MSG_SUC);
                    result.setResultCode(CouponConstant.RESULT_CODE_SUC);
                    result.setSuccess(true);
                }
            }else {
                result.setResultMsg(CouponConstant.RESULT_MSG_ERROR_PARAM);
                result.setResultCode(CouponConstant.RESULT_CODE_ERROR_PARAM);
            }
        } catch (Exception e) {
            log.error(ExceptionUtil.getStackTrace(e));
        }
        return result;
    }

    @Override
    public RemoteResult<List<SalescouponsApi>> getSalescouponsList(Map map) {
        RemoteResult result = new RemoteResult(false);
        try {
            ResponseResult<List<Salescoupons>> res = salescouponsManager.getSalescouponsList(map);
            if(res.isSuccess() && res.getData() != null && res.getData().size() > 0){
                List<Salescoupons> list =  res.getData();
                List<SalescouponsApi> listapi = new ArrayList<SalescouponsApi>();
                SalescouponsApi api = null;
                for(Salescoupons s : list){
                    api = new SalescouponsApi();
                    new DomainUtil().copy(s,api);
                    listapi.add(api);
                }
                result.setResultMsg(CouponConstant.RESULT_MSG_SUC);
                result.setResultCode(CouponConstant.RESULT_CODE_SUC);
                result.setT(listapi);
                result.setSuccess(true);
            }
        } catch (Exception e) {
            log.error(ExceptionUtil.getStackTrace(e));
        }
        return result;
    }

    @Override
    public RemoteResult<Boolean> submitToCheckBatch(List<SalescouponsApi> list) {
        RemoteResult<Boolean> remoteResult = new RemoteResult<Boolean>(false);
        try {
            List<Salescoupons> salescouponsList = new ArrayList<Salescoupons>();
            List<Couponchecks> couponchecksList = new ArrayList<Couponchecks>();
            for (SalescouponsApi salescouponsApi : list) {
                Salescoupons salescoupons = new Salescoupons();
                Couponchecks couponchecks = new Couponchecks();

                salescoupons.setId(salescouponsApi.getId());
                salescoupons.setStatus(salescouponsApi.getStatus());//0新建 1审核未通过 2审核通过 3未审核
                salescoupons.setUpdateby(salescouponsApi.getUpdateby());

                couponchecks.setSalescouponid(salescouponsApi.getId());
                couponchecks.setStyle(salescouponsApi.getStyle());
                couponchecks.setCheckstatus(salescouponsApi.getStatus());//0新建 1审核未通过 2审核通过 3未审核
                couponchecks.setName(salescouponsApi.getName());
                couponchecks.setCreateby(salescouponsApi.getUpdateby());
                couponchecks.setShopid(salescouponsApi.getShopid());

                salescouponsList.add(salescoupons);
                couponchecksList.add(couponchecks);
            }
            int i = salescouponsManager.updateSalesCouponStatusBatch(salescouponsList);
            int k = couponchecksManager.insertCouponchecksBatch(couponchecksList);
            if (i>0 && k>0){
                remoteResult.setResultMsg(CouponConstant.RESULT_MSG_SUC);
                remoteResult.setResultCode(CouponConstant.RESULT_CODE_SUC);
                remoteResult.setSuccess(true);
                return remoteResult;
            }else {
                remoteResult.setResultMsg(CouponConstant.RESULT_MSG_ERROR_PARAM);
                remoteResult.setResultCode(CouponConstant.RESULT_CODE_ERROR_PARAM);
            }
        }catch (Exception e){
            log.error(ExceptionUtil.getStackTrace(e));
        }
        return remoteResult;
    }

    @Override
    public RemoteResult<Boolean> sendCouponsToMember(Long couponid, List<MemberVo> list,String itCode) {
        RemoteResult<Boolean> remoteResult = new RemoteResult<Boolean>(false);
        try{
            ResponseResult<Salescoupons>  result = salescouponsManager.getSalescoupons(couponid);
            if (result!=null && result.isSuccess()){
                Salescoupons salescoupons = result.getData();
                Date currentDate =  new Date();
                //检查券有效性
                if(salescoupons.getStatus() != 2){
                    log.info("优惠券未审核通过couponid：" + couponid);
                    remoteResult.setResultCode(CouponConstant.RESULT_CODE_FAIL);
                    remoteResult.setResultMsg("优惠券<" + salescoupons.getName() + ">未审核，请先审核！");
                    return remoteResult;
                }
                if (currentDate.after(salescoupons.getTotime())){
                    log.info("优惠券已过期toTime：" + salescoupons.getTotime());
                    remoteResult.setResultCode(CouponConstant.RESULT_CODE_FAIL);
                    remoteResult.setResultMsg("优惠券<" + salescoupons.getName() + ">已过期！");
                    return remoteResult;
                }
                List<Membercouponrels> membercouponrelsList = new ArrayList<Membercouponrels>();
                String batchNo = String.valueOf(currentDate.getTime());//发放批次号
                for (MemberVo memberVo : list){
                    Membercouponrels membercouponrels = new Membercouponrels();
                    membercouponrels.setId(Long.parseLong(idSequenceService.genId()));
                    membercouponrels.setMembercode(memberVo.getLoginname());
                    membercouponrels.setLenovoid(memberVo.getLenovoId());
                    membercouponrels.setSalescouponid(salescoupons.getId());
                    membercouponrels.setUsescope(salescoupons.getUsescope());
                    membercouponrels.setCouponcode(salescoupons.getCouponcode());
                    membercouponrels.setShopid(salescoupons.getShopid());
                    membercouponrels.setTerminal(salescoupons.getTerminal());
                    membercouponrels.setName(salescoupons.getName());
                    membercouponrels.setAmount(salescoupons.getAmount());
                    membercouponrels.setCurrencyCode(salescoupons.getCurrencyCode());
                    membercouponrels.setConditions(salescoupons.getConditions());
                    membercouponrels.setType(salescoupons.getType());
                    membercouponrels.setDescription(salescoupons.getDescription());
                    membercouponrels.setFromtime(salescoupons.getFromtime());
                    membercouponrels.setTotime(salescoupons.getTotime());
                    membercouponrels.setTotalnumber(salescoupons.getTotalnumber());
                    membercouponrels.setSurplusnumber(salescoupons.getTotalnumber());
                    membercouponrels.setClassification(salescoupons.getClassification());
                    membercouponrels.setSuperposition(salescoupons.getSuperposition());
                    membercouponrels.setCouponsource(CouponConstant.COUPON_SOURCE_ADMIN);
                    membercouponrels.setBatchno(batchNo);
                    membercouponrels.setEppgroup(salescoupons.getEppgroup());
                    membercouponrels.setStatus(0);//0未使用 1已使用
                    membercouponrels.setDisabled(0);//0 未禁用 1已禁用
                    membercouponrels.setCreatetime(currentDate);
                    membercouponrels.setUpdatetime(currentDate);
                    membercouponrels.setCreateby(itCode);
                    membercouponrels.setCurrencyCode(salescoupons.getCurrencyCode());
                    membercouponrelsList.add(membercouponrels);
                }
                log.info("insertBatch data:{}", JsonUtil.toJson(membercouponrelsList));
                RemoteResult<Boolean> insertResult = memberCouponrelsManager.insertBatchByOneMember(membercouponrelsList);
                if (insertResult!=null&&insertResult.isSuccess()){
                    if (salescoupons.getBacksend()==1){
                        remoteResult.setResultMsg(CouponConstant.RESULT_MSG_SUC);
                        remoteResult.setResultCode(CouponConstant.RESULT_CODE_SUC);
                        remoteResult.setSuccess(true);
                        return remoteResult;
                    }
                    SalescouponsApi salescouponsApi = new SalescouponsApi();
                    salescouponsApi.setId(salescoupons.getId());
//                    salescouponsApi.setWholenumber(salescoupons.getWholenumber()+1);//发全员券次数
                    salescouponsApi.setBacksend(CouponConstant.COUPON_Backsend_1);// 1 已经发过券，0 未发过券
                    salescouponsApi.setUpdatetime(new Date());
                    salescouponsApi.setUpdateby(itCode);

                    // -todo
//                    if (rs!=null&&rs.isSuccess()) {
                    remoteResult.setResultMsg(CouponConstant.RESULT_MSG_SUC);
                    remoteResult.setResultCode(CouponConstant.RESULT_CODE_SUC);
                    remoteResult.setSuccess(true);

                    RemoteResult<Boolean> rs = this.editSalescouponsOnly(salescouponsApi);
                    if(!rs.isSuccess()){
                        log.info("sendCouponsToMember 发完券成功之后，更新券是否发过券Backsend时，出现错误！");
                    }
                    return remoteResult;
                }
            }else {
                log.info("未找到优惠券couponid：" + couponid);
            }
        }catch (Exception e){
            log.error(ExceptionUtil.getStackTrace(e));
        }
        return remoteResult;
    }

    @Override
        public RemoteResult<Boolean> bindCoupons(Long couponId, String lenovoId, String memberCode) {
        log.info("bindCoupons:couponId="+couponId+",lenovoId="+",memberCode="+memberCode);
        RemoteResult<Boolean> remoteResult = new RemoteResult<Boolean>(false);
        try{
           ResponseResult<Salescoupons> responseResult = salescouponsManager.getSalescoupons(couponId);
            if (responseResult!=null&&responseResult.isSuccess()) {
                Date currentDate = new Date();
                Salescoupons salescoupons = responseResult.getData();
                //检查券有效性
                RemoteResult checkResult = checkCouponAvailable("bindCoupons", salescoupons);
                if(!checkResult.isSuccess()){
                    return checkResult;
                }
                if(salescoupons.getLimitSymbol() == 1){
                    Long salesCouponsId = salescoupons.getId();
                    String shopId = salescoupons.getShopid();
                    Map<String,Object> conditionMap = new HashMap<String, Object>();
                    conditionMap.put("shopId",shopId);
                    conditionMap.put("id",salesCouponsId);
                    int sendNum = memberCouponrelsManager.getIsHaveSalesCouponsNum(conditionMap);
                    if (sendNum >= salescoupons.getMaxnumber()){
                        log.info(String.format("bindCoupons SalesCouponID[%d]: 该优惠券已达到最大领取张数，不可继续领取.", salescoupons.getId()));
                        remoteResult.setResultCode(CouponConstant.RESULT_CODE_FAIL);
                        remoteResult.setResultMsg("bindCoupons:优惠券<" + salescoupons.getName() + ">已达到领取上限！");
                        return remoteResult;
                    }
                }
                List<Membercouponrels> membercouponrelsList = new ArrayList<Membercouponrels>();
                String batchNo = String.valueOf(currentDate.getTime());//发放批次号
                Membercouponrels membercouponrels = new Membercouponrels();
                membercouponrels.setId(Long.parseLong(idSequenceService.genId()));
                membercouponrels.setMembercode(memberCode);
                membercouponrels.setLenovoid(lenovoId);
                membercouponrels.setSalescouponid(salescoupons.getId());
                membercouponrels.setUsescope(salescoupons.getUsescope());
                membercouponrels.setCouponcode(salescoupons.getCouponcode());
                membercouponrels.setShopid(salescoupons.getShopid());
                membercouponrels.setTerminal(salescoupons.getTerminal());
                membercouponrels.setName(salescoupons.getName());
                membercouponrels.setAmount(salescoupons.getAmount());
                membercouponrels.setConditions(salescoupons.getConditions());
                membercouponrels.setType(salescoupons.getType());
                membercouponrels.setDescription(salescoupons.getDescription());
                membercouponrels.setFromtime(salescoupons.getFromtime());
                membercouponrels.setTotime(salescoupons.getTotime());
                membercouponrels.setTotalnumber(salescoupons.getTotalnumber());
                membercouponrels.setSurplusnumber(salescoupons.getTotalnumber());
                membercouponrels.setClassification(salescoupons.getClassification());
                membercouponrels.setSuperposition(salescoupons.getSuperposition());
                membercouponrels.setCouponsource(CouponConstant.COUPON_SOURCE_API);
                membercouponrels.setBatchno(batchNo);
                membercouponrels.setStatus(0);//0已使用 1未使用
                membercouponrels.setDisabled(0);//0未禁用 1已禁用
                membercouponrels.setCreatetime(currentDate);
                membercouponrels.setUpdatetime(currentDate);
                membercouponrels.setCreateby(lenovoId);
                membercouponrels.setCurrencyCode(salescoupons.getCurrencyCode());
                membercouponrelsList.add(membercouponrels);
                RemoteResult<Boolean> insertResult = memberCouponrelsManager.insertBatch(membercouponrelsList);
                if (insertResult != null && insertResult.isSuccess()) {
                    SalescouponsApi salescouponsApi = new SalescouponsApi();
                    Integer maxNumber = salescoupons.getMaxnumber()==null ? 0:salescoupons.getMaxnumber();//最大发放数量
                    Integer backsend = salescoupons.getBacksend();// 1 已经发过券，0 未发过券
                    salescouponsApi.setId(salescoupons.getId());
                    if(backsend.equals(0)){
                        salescouponsApi.setBacksend(1);
                    }
                    if(maxNumber>0){
                        salescouponsApi.setSendnumber(salescoupons.getSendnumber() == null ? (0 + 1) : (salescoupons.getSendnumber() + 1));//优惠券已领取全张数
                    }
                    if(backsend.equals(0) || maxNumber>0){
                        salescouponsApi.setUpdatetime(new Date());
                        salescouponsApi.setUpdateby(lenovoId);
                        RemoteResult<Boolean> rs = this.editSalescouponsOnly(salescouponsApi);
                        if(rs == null || !rs.isSuccess()){
                            log.info("bindCoupons:发券完成后更新salescoupon表时出错");
                        }
                    }

                    remoteResult.setResultMsg(CouponConstant.RESULT_MSG_SUC);
                    remoteResult.setResultCode(CouponConstant.RESULT_CODE_SUC);
                    remoteResult.setSuccess(true);
                    return remoteResult;
                }
            }else{
                log.info("bindCoupons:未找到优惠券couponid：" + couponId);
            }
        }catch (Exception e){
            log.error(ExceptionUtil.getStackTrace(e));
        }
        return remoteResult;
    }

    @Override
    public RemoteResult<Boolean> bindCoupons(Tenant tenant, Long couponId, String lenovoId, String memberCode) {

        return this.bindCoupons(String.valueOf(tenant.getShopId()), couponId, lenovoId, memberCode);
    }

    @Override
    public RemoteResult<Boolean> bindCoupons(String shopId, Long couponId, String lenovoId, String memberCode) {
        log.info("bindCoupons:shopId="+shopId+" couponId="+couponId+",lenovoId="+",memberCode="+memberCode);
        RemoteResult<Boolean> remoteResult = new RemoteResult<Boolean>(false);
        String key = shopId+","+couponId+","+lenovoId+","+memberCode;
        RedisLock redisLock = new RedisLock(key, redisObjectManager);
        boolean flag = redisLock.lock(5);
        if(!flag){
            return RemoteResultUtil.convert(ErrorMessageEnum.ERROR_APP_ERROR_BUSY);
        }
        try{

            ResponseResult<Salescoupons> responseResult = salescouponsManager.getSalescoupons(couponId);
            if (responseResult != null && responseResult.isSuccess()) {
                Salescoupons salescoupons = responseResult.getData();
                Date currentTime = new Date();
                //检查券有效性
                if (salescoupons.getStatus() != 2) {
                    log.info("bindCoupons:优惠券未审核通过couponid：" + couponId);
                    /*remoteResult.setResultCode(CouponConstant.RESULT_CODE_FAIL);
                    remoteResult.setResultMsg("bindCoupons:优惠券<" + salescoupons.getName() + ">未审核，请先审核！");
                    return remoteResult;*/
                    return RemoteResultUtil.convert(ErrorMessageEnum.ERROR_COUPON_NOTSHENHE.getCode(),ArrayUtil.toArrayString(new String[]{ salescoupons.getName()}));
                }
                if (salescoupons.getTotime().before(currentTime)) {
                    log.info("bindCoupons:优惠券已过期toTime：" + salescoupons.getTotime());
                   /* remoteResult.setResultCode(CouponConstant.RESULT_CODE_FAIL);
                    remoteResult.setResultMsg("bindCoupons:优惠券<" + salescoupons.getName() + ">已过期！");*/
                    return RemoteResultUtil.convert(ErrorMessageEnum.ERROR_COUPON_EXPIRE.getCode(),ArrayUtil.toArrayString(new String[]{ salescoupons.getName()}));
                    //return remoteResult;
                }
                if (salescoupons.getIscanget() == 0){//0不可领取 1可领取
                    log.info("bindCoupons:优惠券不可领取isCanget等于0");
                   /* remoteResult.setResultCode(CouponConstant.RESULT_CODE_FAIL);
                    remoteResult.setResultMsg("bindCoupons:优惠券<" + salescoupons.getName() + ">不可领取！");
                    return remoteResult;*/
                    return RemoteResultUtil.convert(ErrorMessageEnum.ERROR_COUPON_CANT_GET.getCode(),ArrayUtil.toArrayString(new String[]{ salescoupons.getName()}));
                }
                if (salescoupons.getIscanget() == 1){
                    if (salescoupons.getGetendtime().before(currentTime) ||  salescoupons.getGetstarttime().after(currentTime)){
                        log.info("bindCoupons:优惠券领取时间错误：" + salescoupons.getGetstarttime() + "至" + salescoupons.getGetendtime() + "可领取");
                       /* remoteResult.setResultCode(CouponConstant.RESULT_CODE_FAIL);
                        remoteResult.setResultMsg("bindCoupons:优惠券<" + salescoupons.getName() + ">领取时间错误！");
                        return remoteResult;*/
                        return RemoteResultUtil.convert(ErrorMessageEnum.ERROR_COUPON_GETTIME.getCode(),ArrayUtil.toArrayString(new String[]{ salescoupons.getName()}));
                    }
                }
                if(salescoupons.getMaxnumber()!=0){
                    Long salesCouponsId = salescoupons.getId();
                    String shopIds = salescoupons.getShopid();
                    Map<String,Object> conditionMap = new HashMap<String, Object>();
                    conditionMap.put("shopId",shopIds);
                    conditionMap.put("id",salesCouponsId);
                    int isHaveNum = memberCouponrelsManager.getIsHaveSalesCouponsNum(conditionMap);
                    if (isHaveNum>=salescoupons.getMaxnumber()){
                        log.info("bindCoupons:该优惠券已达到最大领取张数，不可继续领取");
                       /* remoteResult.setResultCode(CouponConstant.RESULT_CODE_FAIL);
                        remoteResult.setResultMsg("bindCoupons:优惠券<" + salescoupons.getName() + ">已达到领取上限！");
                        return remoteResult;*/
                        return RemoteResultUtil.convert(ErrorMessageEnum.ERROR_COUPON_GETLIMIT.getCode(),ArrayUtil.toArrayString(new String[]{ salescoupons.getName()}));
                    }
                }
//                //Maxnumber优惠券可发放的最大张数 -1代表无限制，Sendnumber已发放张数
//                if (salescoupons.getMaxnumber()!=-1 && salescoupons.getSendnumber() == salescoupons.getMaxnumber()){
//                    log.info("bindCoupons:该优惠券已达到最大领取张数，不可继续领取");
//                    remoteResult.setResultCode(CouponConstant.RESULT_CODE_FAIL);
//                    remoteResult.setResultMsg("bindCoupons:优惠券<" + salescoupons.getName() + ">已达到领取上限！");
//                    return remoteResult;
//                }
                List<Membercouponrels> membercouponrelsList = new ArrayList<Membercouponrels>();
                String batchNo = String.valueOf(new Date().getTime());//发放批次号
                Membercouponrels membercouponrels = new Membercouponrels();
                membercouponrels.setId(Long.parseLong(idSequenceService.genId()));
                membercouponrels.setMembercode(memberCode);
                membercouponrels.setLenovoid(lenovoId);
                membercouponrels.setSalescouponid(salescoupons.getId());
                membercouponrels.setUsescope(salescoupons.getUsescope());
                membercouponrels.setCouponcode(salescoupons.getCouponcode());
                membercouponrels.setShopid(salescoupons.getShopid());
                membercouponrels.setTerminal(salescoupons.getTerminal());
                membercouponrels.setName(salescoupons.getName());
                membercouponrels.setAmount(salescoupons.getAmount());
                membercouponrels.setConditions(salescoupons.getConditions());
                membercouponrels.setType(salescoupons.getType());
                membercouponrels.setDescription(salescoupons.getDescription());
                membercouponrels.setFromtime(salescoupons.getFromtime());
                membercouponrels.setTotime(salescoupons.getTotime());
                membercouponrels.setTotalnumber(salescoupons.getTotalnumber());
                membercouponrels.setSurplusnumber(salescoupons.getTotalnumber());
                membercouponrels.setClassification(salescoupons.getClassification());
                membercouponrels.setSuperposition(salescoupons.getSuperposition());
                membercouponrels.setCouponsource(CouponConstant.COUPON_SOURCE_API);
                membercouponrels.setBatchno(batchNo);
                membercouponrels.setStatus(0);//0已使用 1未使用
                membercouponrels.setDisabled(0);//0未禁用 1已禁用
                membercouponrels.setCreatetime(new Date());
                membercouponrels.setUpdatetime(new Date());
                membercouponrels.setCreateby(lenovoId);
                membercouponrels.setCurrencyCode(salescoupons.getCurrencyCode());
                membercouponrelsList.add(membercouponrels);
                log.info("insertBatch param={}",JacksonMapper.obj2json(membercouponrelsList));
                RemoteResult<Boolean> insertResult = memberCouponrelsManager.insertBatch(membercouponrelsList);
                if (insertResult != null && insertResult.isSuccess()) {

                    SalescouponsApi salescouponsApi = new SalescouponsApi();
                    Integer maxNumber = salescoupons.getMaxnumber()==null ? 0:salescoupons.getMaxnumber();//最大发放数量
                    Integer backsend = salescoupons.getBacksend();// 1 已经发过券，0 未发过券
                    salescouponsApi.setId(salescoupons.getId());
                    if(backsend.equals(0)){
                        salescouponsApi.setBacksend(1);
                    }
                    if(maxNumber>0){
                        salescouponsApi.setSendnumber(salescoupons.getSendnumber() == null ? (0 + 1) : (salescoupons.getSendnumber() + 1));//优惠券已领取全张数
                    }
                    if(backsend.equals(0) || maxNumber>0){
                        salescouponsApi.setUpdatetime(new Date());
                        salescouponsApi.setUpdateby(lenovoId);
                        RemoteResult<Boolean> rs = this.editSalescouponsOnly(salescouponsApi);
                        if(rs == null || !rs.isSuccess()){
                            log.info("bindCoupons:发券完成后更新salescoupon表时出错");
                        }
                    }

                    remoteResult.setResultMsg(CouponConstant.RESULT_MSG_SUC);
                    remoteResult.setResultCode(CouponConstant.RESULT_CODE_SUC);
                    remoteResult.setSuccess(true);
                    return remoteResult;
                }
            }else{
                log.info("bindCoupons:未找到优惠券couponid："+couponId);
            }
        }catch (Exception e){
            log.error(ExceptionUtil.getStackTrace(e));
        }finally {
            redisLock.unlock();
        }
        return remoteResult;
    }

    @Override
    public RemoteResult<Boolean> bindCouponsForOnce(Tenant tenant, Long couponId, String lenovoId, String memberCode) {

        return this.bindCouponsForOnce(String.valueOf(tenant.getShopId()), couponId, lenovoId, memberCode);
    }

    /**
     * 单个绑券，优惠券只能领取一次
     * @param shopId
     * @param couponId
     * @param lenovoId
     * @param memberCode
     * @return
     */
    @Override
    public RemoteResult<Boolean> bindCouponsForOnce(String shopId, Long couponId, String lenovoId, String memberCode) {
        log.info("bindCouponsForOnce:shopId="+shopId+" couponId="+couponId+",lenovoId="+lenovoId+",memberCode="+memberCode);
        RemoteResult<Boolean> remoteResult = new RemoteResult<Boolean>(false);
        String key = shopId+","+couponId+","+lenovoId+","+memberCode;
        RedisLock redisLock = new RedisLock(key, redisObjectManager);
        try{
            boolean flag = redisLock.lock(5000);
            if(!flag){
                return RemoteResultUtil.convert(ErrorMessageEnum.ERROR_APP_ERROR_BUSY);
            }
            ResponseResult<MemberExcelTempApi> res = memberCouponrelsManager.getMembercouponrelsByLenovoIdandSalescouponIdandshopId(shopId,lenovoId,couponId);
            if (res.isSuccess()){
                log.info("bindCouponsForOnce:" + lenovoId + "用户已拥有" + couponId + "优惠券");
               /* remoteResult.setSuccess(false);
                remoteResult.setResultCode(CouponConstant.RESULT_CODE_OWNED);
                remoteResult.setResultMsg("bindCouponsForOnce:" + lenovoId + "用户已拥有"+couponId+"优惠券");
                return remoteResult;*/
                return RemoteResultUtil.convert(ErrorMessageEnum.ERROR_COUPON_ALREDY_HAVE.getCode(),ArrayUtil.toArrayString(new String[]{lenovoId,couponId+""}));
            }

            ResponseResult<Salescoupons> responseResult = salescouponsManager.getSalescoupons(couponId);
            if (responseResult != null && responseResult.isSuccess()) {
                Salescoupons salescoupons = responseResult.getData();

                RemoteResult checkResult = checkCouponAvailable("bindCouponsForOnce", salescoupons);
                if(!checkResult.isSuccess()){
                    return checkResult;
                }
                if(!shopId.equals(salescoupons.getShopid())){
                    log.info("绑券平台{}与优惠券支持平台{}不匹配",shopId,salescoupons.getShopid());
                    return  RemoteResultUtil.convert(ErrorMessageEnum.ERROR_SHOPID_NOT_MATCH);
                }
                int sendNum = 0; //已发数量
                int maxNum = (salescoupons.getMaxnumber() == null) ? Integer.MAX_VALUE : salescoupons.getMaxnumber(); //最大可发数量
                Map<String,Object> conditionMap = new HashMap<String, Object>();
                conditionMap.put("shopId", salescoupons.getShopid());
                conditionMap.put("id", salescoupons.getId());
                sendNum = memberCouponrelsManager.getIsHaveSalesCouponsNum(conditionMap);

                if (sendNum >= maxNum) {
//                    remoteResult.setResultCode(CouponConstant.RESULT_CODE_EMPTY);
//                    remoteResult.setResultMsg(String.format("优惠券[%s]已领完", salescoupons.getName()));
//                    log.info(String.format("bindCouponsForOnce: 该优惠券已达到最大领取张数，不可继续领取, CouponId:%d",salescoupons.getId()));
//                    return remoteResult;
                	 return RemoteResultUtil.convert(ErrorMessageEnum.ERROR_COUPON_GETLIMIT.getCode(),ArrayUtil.toArrayString(new String[]{salescoupons.getName()}));
                }

                List<Membercouponrels> membercouponrelsList = new ArrayList<Membercouponrels>();
                String batchNo = String.valueOf(new Date().getTime());//发放批次号
                Membercouponrels membercouponrels = new Membercouponrels();
                membercouponrels.setId(Long.parseLong(idSequenceService.genId()));
                membercouponrels.setMembercode(memberCode);
                membercouponrels.setLenovoid(lenovoId);
                membercouponrels.setSalescouponid(salescoupons.getId());
                membercouponrels.setUsescope(salescoupons.getUsescope());
                membercouponrels.setCouponcode(salescoupons.getCouponcode());
                membercouponrels.setShopid(salescoupons.getShopid());
                membercouponrels.setTerminal(salescoupons.getTerminal());
                membercouponrels.setName(salescoupons.getName());
                membercouponrels.setAmount(salescoupons.getAmount());
                membercouponrels.setConditions(salescoupons.getConditions());
                membercouponrels.setType(salescoupons.getType());
                membercouponrels.setDescription(salescoupons.getDescription());
                membercouponrels.setFromtime(salescoupons.getFromtime());
                membercouponrels.setTotime(salescoupons.getTotime());
                membercouponrels.setTotalnumber(salescoupons.getTotalnumber());
                membercouponrels.setSurplusnumber(salescoupons.getTotalnumber());
                membercouponrels.setClassification(salescoupons.getClassification());
                membercouponrels.setSuperposition(salescoupons.getSuperposition());
                membercouponrels.setCouponsource(CouponConstant.COUPON_SOURCE_API);
                membercouponrels.setBatchno(batchNo);
                membercouponrels.setStatus(0);//0已使用 1未使用
                membercouponrels.setDisabled(0);//0未禁用 1已禁用
                membercouponrels.setCreatetime(new Date());
                membercouponrels.setUpdatetime(new Date());
                membercouponrels.setCreateby(lenovoId);
                membercouponrels.setCurrencyCode(salescoupons.getCurrencyCode());
                membercouponrelsList.add(membercouponrels);
                RemoteResult<Boolean> insertResult = memberCouponrelsManager.insertBatch(membercouponrelsList);
                if (insertResult != null && insertResult.isSuccess()) {
                    SalescouponsApi salescouponsApi = new SalescouponsApi();
                    Integer maxNumber = (salescoupons.getMaxnumber() == null) ? Integer.MAX_VALUE : salescoupons.getMaxnumber();//最大发放数量
                    Integer backsend = salescoupons.getBacksend();// 1 已经发过券，0 未发过券
                    salescouponsApi.setId(salescoupons.getId());
                    if(backsend.equals(0)){
                        salescouponsApi.setBacksend(1);
                    }
                    if(maxNumber > 0){
                        salescouponsApi.setSendnumber(salescoupons.getSendnumber() == null ? 1 : (salescoupons.getSendnumber() + 1));//优惠券已领取全张数
                    }
                    if(backsend.equals(0) || maxNumber > 0){
                        salescouponsApi.setUpdatetime(new Date());
                        salescouponsApi.setUpdateby(lenovoId);
                        RemoteResult<Boolean> rs = this.editSalescouponsOnly(salescouponsApi);
                        if(rs == null || !rs.isSuccess()){
                            log.info("bindCouponsForOnce:发券完成后更新salescoupon表时出错");
                        }
                    }
                    remoteResult.setResultMsg(CouponConstant.RESULT_MSG_SUC);
                    remoteResult.setResultCode(CouponConstant.RESULT_CODE_SUC);
                    remoteResult.setSuccess(true);
                    return remoteResult;
                }
            }else{
                log.info("bindCouponsForOnce:未找到优惠券couponid："+couponId);
            }
        }catch (Exception e){
            log.error(ExceptionUtil.getStackTrace(e));
        }finally {
            redisLock.unlock();
        }
        return remoteResult;
    }


    @Override
    public RemoteResult deleteSalescoupons4redis(SalescouponsApi salescouponsApi) throws Exception {
        log.info("deleteSalescoupons4redis "+salescouponsApi);
        RemoteResult remoteResult = new RemoteResult(false);
//        try {
            String shopId = salescouponsApi.getShopid();
            String[] terminal = salescouponsApi.getTerminal().split(",");

            if(salescouponsApi.getType() == CouponConstant.COUPON_TYPE_DETAIL_1){
                List<DetailsruleApi>  detailsruleApiList = salescouponsApi.getDetailsruleApiList();
                String nojoincodes = salescouponsApi.getNojoingoodcodes();

                for(String s : terminal){
                    for(DetailsruleApi d : detailsruleApiList ){
                        String categorycode = d.getGoodscategoryid();
                        String categorycode_Key = "coupon_"+shopId+"_"+s+"_"+categorycode;
                        log.info("deleteSalescoupons4redis categorycode_Key="+categorycode_Key);
                        String categorycode_json = redisObjectManager.getString(categorycode_Key);
                        if(StringUtils.isNotEmpty(categorycode_json)){
                            List<SalescouponsApi> list_get = JacksonMapper.json2list(categorycode_json,SalescouponsApi.class);
                            Iterator<SalescouponsApi> iter = list_get.iterator();
                            while(iter.hasNext()){
                                SalescouponsApi sapi = iter.next();
                                if(sapi.getId().equals(salescouponsApi.getId())){
                                    iter.remove();
                                }
                            }
                            String setkey_result = redisObjectManager.setString(categorycode_Key, JacksonMapper.obj2json(list_get));
                            log.info("deleteSalescoupons4redis categorycode_Key="+categorycode_Key+" setkey_result="+setkey_result);
                        }else {
                            /**
                             * 去删除缓存中的数据，结果缓存中没有查询到数据
                             */
                        }
                    }
                }
                remoteResult.setSuccess(true);
            }else if(salescouponsApi.getType() == CouponConstant.COUPON_TYPE_PRODUCT_2){
                String[] goodsCode = salescouponsApi.getProductruleApi().getGoodscodes().split(",");
                for(String s : terminal){
                    for(String code : goodsCode){
                        String goodcode_key = "coupon_"+shopId+"_"+s+"_"+code;
                        log.info("deleteSalescoupons4redis goodcode_key="+goodcode_key);
                        String json = redisObjectManager.getString(goodcode_key);
                        if(StringUtils.isNotEmpty(json)){
                            List<SalescouponsApi> list_get = JacksonMapper.json2list(json,SalescouponsApi.class);
                            Iterator<SalescouponsApi> iter = list_get.iterator();
                            while(iter.hasNext()){
                                SalescouponsApi sapi = iter.next();
                                if(sapi.getId().equals(salescouponsApi.getId())){
                                    iter.remove();
                                }
                            }
                            String setkey_result = redisObjectManager.setString(goodcode_key, JacksonMapper.obj2json(list_get));
                            log.info("deleteSalescoupons4redis goodcode_key="+goodcode_key+" setkey_result="+setkey_result);
                        }else {
                            /**
                             * 去删除缓存中的数据，结果缓存中没有查询到数据
                             */
                        }
                    }
                }
                remoteResult.setSuccess(true);
            }
//        } catch (Exception e) {
//            e.printStackTrace();
//            remoteResult.setSuccess(false);
//        }
        log.info("deleteSalescoupons4redis "+remoteResult);
        return remoteResult;
    }

    @Override
    public RemoteResult updateNoticeValidCount(Long id) {
        log.info("updateNoticeValidCount id="+id);
        RemoteResult remoteResult = new RemoteResult(false);
        if(id > 0){
            ResponseResult res = salescouponsManager.updateNoticeValidCount(id);
            if(res.isSuccess()){
                remoteResult.setResultMsg(CouponConstant.RESULT_MSG_SUC);
                remoteResult.setResultCode(CouponConstant.RESULT_CODE_SUC);
                remoteResult.setSuccess(true);
                return remoteResult;
            }else {
                remoteResult.setResultMsg(CouponConstant.RESULT_MSG_ERROR);
                remoteResult.setResultCode(CouponConstant.RESULT_CODE_ERROR);
                remoteResult.setSuccess(true);
                return remoteResult;
            }
        }else {
            remoteResult.setResultMsg(CouponConstant.RESULT_MSG_ERROR_PARAM);
            remoteResult.setResultCode(CouponConstant.RESULT_CODE_ERROR_PARAM);
            return remoteResult;
        }
    }

    @Override
    public RemoteResult updateNoticeInvalidCount(Long id) {
        log.info("updateNoticeInvalidCount id="+id);
        RemoteResult remoteResult = new RemoteResult(false);
        if(id > 0){
            ResponseResult res = salescouponsManager.updateNoticeInvalidCount(id);
            if(res.isSuccess()){
                remoteResult.setResultMsg(CouponConstant.RESULT_MSG_SUC);
                remoteResult.setResultCode(CouponConstant.RESULT_CODE_SUC);
                remoteResult.setSuccess(true);
                return remoteResult;
            }else {
                remoteResult.setResultMsg(CouponConstant.RESULT_MSG_ERROR);
                remoteResult.setResultCode(CouponConstant.RESULT_CODE_ERROR);
                remoteResult.setSuccess(true);
                return remoteResult;
            }
        }else {
            remoteResult.setResultMsg(CouponConstant.RESULT_MSG_ERROR_PARAM);
            remoteResult.setResultCode(CouponConstant.RESULT_CODE_ERROR_PARAM);
            return remoteResult;
        }
    }

    @Override
    public RemoteResult<List<SalescouponsApi>> getSalescouponsforIds(Map map){
        RemoteResult result = new RemoteResult(false);
        try{
            ResponseResult<List<Salescoupons>> res = salescouponsManager.getSalescouponsforIds(map);
            if(res.isSuccess() && res.getData() != null && res.getData().size() > 0){
                List<Salescoupons> list =  res.getData();
                List<SalescouponsApi> listapi = new ArrayList<SalescouponsApi>();
                SalescouponsApi api = null;
                for(Salescoupons s : list){
                    api = new SalescouponsApi();
                    new DomainUtil().copy(s,api);
                    listapi.add(api);
                }
                result.setResultMsg(CouponConstant.RESULT_MSG_SUC);
                result.setResultCode(CouponConstant.RESULT_CODE_SUC);
                result.setT(listapi);
                log.info("根据id查询优惠券成功");
                result.setSuccess(true);
            }
        } catch (Exception e) {
            log.error("根据id查询优惠券失败" + ExceptionUtil.getStackTrace(e));
        }
        return result;
    }

    /**
     * 根据优惠券分类ID查询优惠券
     * @param map
     * @return
     */
    @Override
    public RemoteResult<PageModel2<SalescouponsApi>> getSalescouponsByClassification(PageQuery pageQuery, Map map) {
        RemoteResult result = new RemoteResult(false);
        try{
            PageModel2<Salescoupons> rs = salescouponsManager.getSalescouponsForClassification(pageQuery, map);
            List<SalescouponsApi> salescouponsApiList = new ArrayList<SalescouponsApi>();
            if(null != rs && null !=rs.getDatas() && rs.getDatas().size() > 0 ){
                for (Salescoupons coupon : rs.getDatas()) {
                    SalescouponsApi salescouponsApi = new SalescouponsApi();
                    new DomainUtil().copy(coupon, salescouponsApi);
                    salescouponsApiList.add(salescouponsApi);
                }
            }
            PageModel2<SalescouponsApi> pageModel=new PageModel2<SalescouponsApi>(pageQuery,salescouponsApiList);
            result.setResultMsg(CouponConstant.RESULT_MSG_SUC);
            result.setResultCode(CouponConstant.RESULT_CODE_SUC);
            result.setT(pageModel);
            result.setSuccess(true);
        }catch (Exception e){
            log.error(ExceptionUtil.getStackTrace(e));
            return  RemoteResultUtil.convert(ErrorMessageEnum.ERROR_SERVICE);
        }
        return result;
    }

    @Override
    public RemoteResult<PageModel2<SalescouponsApi>> getSalescouponsBySalesCouponIds(PageQuery pageQuery, Map map) {
        RemoteResult result = new RemoteResult(false);
        try{
            PageModel2<Salescoupons> rs = salescouponsManager.getSalescouponsBySalesCouponIds(pageQuery, map);
            List<SalescouponsApi> salescouponsApiList = new ArrayList<SalescouponsApi>();
            if(null != rs && null !=rs.getDatas() && rs.getDatas().size() > 0 ){
                for (Salescoupons coupon : rs.getDatas()) {
                    SalescouponsApi salescouponsApi = new SalescouponsApi();
                    new DomainUtil().copy(coupon, salescouponsApi);
                    salescouponsApiList.add(salescouponsApi);
                }
            }
            // 对查询到的优惠券按金额大小排序
            Collections.sort(salescouponsApiList, new Comparator<SalescouponsApi>() {
                @Override
                public int compare(SalescouponsApi o1, SalescouponsApi o2) {
                    return o1.getAmount().compareTo(o2.getAmount());
                }
            });
            PageModel2<SalescouponsApi> pageModel=new PageModel2<SalescouponsApi>(pageQuery,salescouponsApiList);
            result.setResultMsg(CouponConstant.RESULT_MSG_SUC);
            result.setResultCode(CouponConstant.RESULT_CODE_SUC);
            result.setT(pageModel);
            result.setSuccess(true);
        }catch (Exception e){
            log.error(ExceptionUtil.getStackTrace(e));
            return  RemoteResultUtil.convert(ErrorMessageEnum.ERROR_SERVICE);
        }
        return result;
    }

    @Override
    public RemoteResult getSalesCouponsNumbersForId(Map map) {
        log.info("getSalesCouponsNumbersForId获取优惠券可领取数量,参数：shopId="+map.get("shopId")+",id="+map.get("id"));
        RemoteResult result = new RemoteResult(false);
        try {
            ResponseResult<Salescoupons> res = salescouponsManager.getSalesCouponsNumbersForId(map);
            if (res.isSuccess()){
                Salescoupons salescoupons = res.getData();

                RemoteResult checkResult = checkCouponAvailable("getSalesCouponsNumbersForId", salescoupons);
                if(!checkResult.isSuccess()){
                    return checkResult;
                }

                int sendNum = 0; //已发数量
                int maxNum = (salescoupons.getMaxnumber() == null) ? Integer.MAX_VALUE : salescoupons.getMaxnumber(); //最大可发数量
                sendNum = memberCouponrelsManager.getIsHaveSalesCouponsNum(map);

                if (sendNum < maxNum) {
                    result.setSuccess(true);
                    result.setResultCode(CouponConstant.RESULT_CODE_SUC);
                    result.setResultMsg(CouponConstant.RESULT_MSG_SUC);
                    result.setT(String.valueOf(maxNum - sendNum));
                } else {
                    result.setSuccess(true);
                    result.setResultCode(CouponConstant.RESULT_CODE_SUC);
                    result.setResultMsg(CouponConstant.RESULT_MSG_SUC);
                    result.setT(0);
                }

            }else {
                result.setResultMsg(CouponConstant.RESULT_MSG_FAIL);
                result.setResultCode(CouponConstant.RESULT_CODE_FAIL);
                result.setSuccess(false);
            }
        }catch (Exception e){
            log.error(ExceptionUtil.getStackTrace(e));
            return  RemoteResultUtil.convert(ErrorMessageEnum.ERROR_SERVICE);
            
        }
        return result;
    }

    @Override
    public RemoteResult getSalesNumbersManagerment(Map map) {
        log.info("getSalesNumbersManagerment获取优惠券可领取数量,参数：shopId="+map.get("shopId")+",id="+map.get("id"));
        RemoteResult result = new RemoteResult(false);
        try {
            ResponseResult<Salescoupons> res = salescouponsManager.getSalesCouponsNumbersForId(map);
            if (res.isSuccess() && res.getData()!=null){
                Salescoupons salescoupons = res.getData();

                RemoteResult checkResult = checkCouponAvailableForBackendSend("getSalesCouponsNumbersForId", salescoupons);
                if(!checkResult.isSuccess()){
                    return checkResult;
                }

                int sendNum = 0; //已发数量
                int maxNum = (salescoupons.getMaxnumber() == null) ? Integer.MAX_VALUE : salescoupons.getMaxnumber(); //最大可发数量
                sendNum = memberCouponrelsManager.getIsHaveSalesCouponsNum(map);

                if (sendNum < maxNum) {
                    result.setSuccess(true);
                    result.setResultCode(CouponConstant.RESULT_CODE_SUC);
                    result.setResultMsg(CouponConstant.RESULT_MSG_SUC);
                    result.setT(String.valueOf(maxNum - sendNum));
                } else {
                    result.setSuccess(true);
                    result.setResultCode(CouponConstant.RESULT_CODE_SUC);
                    result.setResultMsg(CouponConstant.RESULT_MSG_SUC);
                    result.setT(0);
                }

            }else {
                result.setResultMsg(CouponConstant.RESULT_MSG_FAIL);
                result.setResultCode(CouponConstant.RESULT_CODE_FAIL);
                result.setSuccess(false);
            }
        }catch (Exception e){
            log.error(ExceptionUtil.getStackTrace(e));
            return  RemoteResultUtil.convert(ErrorMessageEnum.ERROR_SERVICE);
        }
        return result;
    }

    @Override
    public RemoteResult getIsHaveSalesCouponsNum(Map map) {
        log.info("getIsHaveSalesCouponsNum参数：salesCouponId="+map.get("id")+",shopId="+map.get("shopId"));
        RemoteResult result = new RemoteResult(false);
        try {
            int countNum = memberCouponrelsManager.getIsHaveSalesCouponsNum(map);
            result.setResultMsg(CouponConstant.RESULT_MSG_SUC);
            result.setResultCode(CouponConstant.RESULT_CODE_SUC);
            result.setT(countNum);
            result.setSuccess(true);
        }catch (Exception e){
            log.error("getIsHaveSalesCouponsNum失败" + ExceptionUtil.getStackTrace(e));
            return  RemoteResultUtil.convert(ErrorMessageEnum.ERROR_SERVICE);
            
        }
        return result;
    }

    @Override
    public RemoteResult getSalesCouponsMaxNumber(Long id) {
        log.info("gerSalesCouponsMaxNumber参数：salesCouponId="+id);
        RemoteResult result = new RemoteResult(false);
        try {
            int countNum = salescouponsManager.getSalesCouponsMaxNumber(id);
            result.setResultMsg(CouponConstant.RESULT_MSG_SUC);
            result.setResultCode(CouponConstant.RESULT_CODE_SUC);
            result.setT(countNum);
            result.setSuccess(true);
        }catch (Exception e){
            log.error("getIsHaveSalesCouponsNum失败" + ExceptionUtil.getStackTrace(e));
            return  RemoteResultUtil.convert(ErrorMessageEnum.ERROR_SERVICE);
        }
        return result;
    }

    @Override
    public RemoteResult<PageModel2<SalescouponsApi>> getAvailableSalescouponsInfoPage(PageQuery pageQuery, Map map) {
        RemoteResult result = new RemoteResult(false);
        try{
            PageModel2<Salescoupons> rs = salescouponsManager.getAvailableSalescouponsInfoPage(pageQuery, map);
            List<SalescouponsApi> salescouponsApiList = new ArrayList<SalescouponsApi>();
            if(null != rs && null != rs.getDatas()){
                DomainUtil domainUtil = new DomainUtil();
                for (Salescoupons coupon : rs.getDatas()) {
                    SalescouponsApi salescouponsApi = new SalescouponsApi();
                    domainUtil.copy(coupon, salescouponsApi);
                    salescouponsApiList.add(salescouponsApi);
                }
            }
            PageModel2<SalescouponsApi> pageModel=new PageModel2<SalescouponsApi>(pageQuery,salescouponsApiList);
            result.setResultMsg(CouponConstant.RESULT_MSG_SUC);
            result.setResultCode(CouponConstant.RESULT_CODE_SUC);
            result.setT(pageModel);
            result.setSuccess(true);
        }catch (Exception e){
            log.error(ExceptionUtil.getStackTrace(e));
            return  RemoteResultUtil.convert(ErrorMessageEnum.ERROR_SERVICE);
        }
        return result;
    }

    @Override
    public RemoteResult<PageModel2<SalescouponsApi>> getAllAvailableSalescouponsInfopage(PageQuery pageQuery, Map map) {
        RemoteResult result = new RemoteResult(false);
        try{
            PageModel2<Salescoupons> rs = salescouponsManager.getAllAvailableSalescouponsInfoPage(pageQuery, map);
            List<SalescouponsApi> salescouponsApiList = new ArrayList<SalescouponsApi>();
            if(null != rs && null !=rs.getDatas() && rs.getDatas().size() > 0 ){
                DomainUtil domainUtil = new DomainUtil();
                for (Salescoupons coupon : rs.getDatas()) {
                    SalescouponsApi salescouponsApi = new SalescouponsApi();
                    domainUtil.copy(coupon, salescouponsApi);
                    salescouponsApiList.add(salescouponsApi);
                }
            }
            PageModel2<SalescouponsApi> pageModel=new PageModel2<SalescouponsApi>(pageQuery,salescouponsApiList);
            result.setResultMsg(CouponConstant.RESULT_MSG_SUC);
            result.setResultCode(CouponConstant.RESULT_CODE_SUC);
            result.setT(pageModel);
            result.setSuccess(true);
        }catch (Exception e){
            log.error(ExceptionUtil.getStackTrace(e));
            return  RemoteResultUtil.convert(ErrorMessageEnum.ERROR_SERVICE);
        }
        return result;
    }

    @Override
    public RemoteResult<PageModel2<SalescouponsApi>> getDistributeSalescoupons(PageQuery pageQuery) {
        log.info("getDistributeSalescoupons pageQuery"+JsonUtil.toJson(pageQuery));
        RemoteResult result = new RemoteResult(false);
        try{
            PageModel2<Salescoupons> rs = salescouponsManager.getDistributeSalescoupons(pageQuery);
            List<SalescouponsApi> salescouponsApiList = new ArrayList<SalescouponsApi>();
            if(null != rs && null !=rs.getDatas() && rs.getDatas().size() > 0 ){
                DomainUtil domainUtil = new DomainUtil();
                for (Salescoupons coupon : rs.getDatas()) {
                    SalescouponsApi salescouponsApi = new SalescouponsApi();
                    domainUtil.copy(coupon, salescouponsApi);
                    salescouponsApiList.add(salescouponsApi);
                }
                // 对查询到的优惠券按金额大小排序
                Collections.sort(salescouponsApiList, new Comparator<SalescouponsApi>() {
                    @Override
                    public int compare(SalescouponsApi o1, SalescouponsApi o2) {
                        return o1.getAmount().compareTo(o2.getAmount());
                    }
                });
                PageModel2<SalescouponsApi> pageModel=new PageModel2<SalescouponsApi>(pageQuery,salescouponsApiList);
                result.setResultMsg(CouponConstant.RESULT_MSG_SUC);
                result.setResultCode(CouponConstant.RESULT_CODE_SUC);
                result.setT(pageModel);
                result.setSuccess(true);
            }else {
                result.setResultMsg(CouponConstant.RESULT_MSG_FAIL);
                result.setResultCode(CouponConstant.RESULT_CODE_FAIL);
            }
        }catch (Exception e){
            log.error(ExceptionUtil.getStackTrace(e));
            return  RemoteResultUtil.convert(ErrorMessageEnum.ERROR_SERVICE);
        }
        return result;
    }


    @Override
    public RemoteResult<SalescouponsApi> getSalescouponsById(Long id) {
        log.info("getSalescouponsById 参数： " + id);
        RemoteResult remoteResult = new RemoteResult();
        try {
            if(id != null){
                ResponseResult<Salescoupons> responseResult = salescouponsManager.getSalescoupons(id);
                if (responseResult != null && responseResult.isSuccess()){
                    DomainUtil domainUtil = new DomainUtil();
                    SalescouponsApi salescouponsApi = new SalescouponsApi();
                    domainUtil.copy(responseResult.getData(), salescouponsApi);

                    if(salescouponsApi.getType() == CouponConstant.COUPON_TYPE_DETAIL_1){ //分类
                        Detailsrule detailsrule = new Detailsrule();
                        detailsrule.setSalescouponid(salescouponsApi.getId());
                        ResponseResult<List<Detailsrule>> resdetail = detailsruleManager.getDetailsruleList(detailsrule);
                        if(resdetail.isSuccess() && resdetail.getData() != null && resdetail.getData().size() > 0){
                            List<Detailsrule> list = resdetail.getData();
                            List<DetailsruleApi> listapi = new ArrayList<DetailsruleApi>();
                            DetailsruleApi detailsruleApi = null;
                            for(Detailsrule detail : list){
                                detailsruleApi = new DetailsruleApi();
                                new DomainUtil().copy(detail, detailsruleApi);
                                listapi.add(detailsruleApi);
                            }
                            salescouponsApi.setDetailsruleApiList(listapi);
                        }
                    }
                    if(salescouponsApi.getType() == CouponConstant.COUPON_TYPE_PRODUCT_2){ //商品
                        Productrule productrule = new Productrule();
                        productrule.setSalescouponid(salescouponsApi.getId());
                        ResponseResult<List<Productrule>> respro = productruleManager.getProductruleList(productrule);
                        if(respro.isSuccess() && respro.getData() != null && respro.getData().size() == 1){
                            Productrule productrule1  = respro.getData().get(0);
                            ProductruleApi productruleApi = new ProductruleApi();
                            new DomainUtil().copy(productrule1, productruleApi);
                            salescouponsApi.setProductruleApi(productruleApi);
                        }
                    }
                    if(salescouponsApi.getType() == CouponConstant.COUPON_TYPE_PRODUCTGROUP_3){ //产品组
                        Distributorrule productrule = new Distributorrule();
                        productrule.setSalescouponid(salescouponsApi.getId());
                        //facode 按产品组id合并
                        ResponseResult<List<Distributorrule>> respro = distributorruleManager.getDistributorruleList(productrule);
                        if(respro.isSuccess() && respro.getData() != null){
                            List<Distributorrule> data = respro.getData();
                            List<DistributorruleApi> apilist = new ArrayList<DistributorruleApi>();
                            for(Distributorrule rule :data){
                                DistributorruleApi api = new DistributorruleApi();
                                new DomainUtil().copy(rule,api);
                                apilist.add(api);
                            }
                            salescouponsApi.setDistributorruleApiList(apilist);
                        }
                        /*if(respro.isSuccess() && respro.getData() != null){
                            List<Distributorrule> data = respro.getData();
                            Set<Integer> allcodes = new HashSet<Integer>();
                            Set<Integer> codes = new HashSet<Integer>();
                            for (Distributorrule dis :data){
                                String   facodes = dis.getFacode();
                                String productgroupId = dis.getProductgroupid();
                                log.info("getSalescouponsById param facodes="+facodes+"productgroupId"+productgroupId);
                                codes = productService.getProductGoodesCodeByCondition(facodes, productgroupId);
                                log.info("getSalescouponsById return"+JacksonMapper.obj2json(codes));
                                allcodes.addAll(codes);
                            }
                            if(allcodes != null){
                                String noJoinCodes = data.get(0).getNojoincodes();
=======

                        /*if(respro.isSuccess() && respro.getData() != null){
                            List<Distributorrule> data = respro.getData();
                            StringBuilder facodes = new StringBuilder();
                            String productgroupId = data.get(0).getProductgroupid();

                            for (int i = 0; i<data.size();i++){
                               if(i==0){
                                   facodes.append(data.get(i).getFacode());
                               }else {
                                   facodes.append(",").append(data.get(i).getFacode());
                               }
                           }
                            log.info("getSalescouponsById param facodes="+facodes.toString()+"productgroupId"+productgroupId);
                            List<Integer> codes = productService.getProductGoodesCodeByCondition(facodes.toString(), productgroupId);
                            log.info("getSalescouponsById return"+JacksonMapper.obj2json(codes));
                            if(codes != null){
                                Distributorrule distributer  = respro.getData().get(0);
                                String noJoinCodes = distributer.getNojoincodes();
>>>>>>> refs/remotes/origin/product
                                if(noJoinCodes != null && noJoinCodes != ""){
                                    String[] split = noJoinCodes.split(",");
                                    for (String code :split){
                                        if (allcodes.contains(Integer.parseInt(code))){
                                            allcodes.remove((Object)Integer.parseInt(code));
                                        }
                                    }
                                }
                                //为salecouponsApi组装ProductruleApi
                                ProductruleApi productruleApi = new ProductruleApi();
                                productruleApi.setGoodscodes(set2String(allcodes));
                                salescouponsApi.setProductruleApi(productruleApi);
                            }
                        }*/
                    }
                    remoteResult.setSuccess(true);
                    remoteResult.setResultCode("00");
                    remoteResult.setResultMsg("操作成功");
                    remoteResult.setT(salescouponsApi);
                }else {
//                    remoteResult.setSuccess(false);
//                    remoteResult.setResultCode("01");
//                    remoteResult.setResultMsg("结果为空");
//                    remoteResult.setT(null);
                	 return  RemoteResultUtil.convert(ErrorMessageEnum.ERROR_COUPON_RESULT_NULL);
                }
            }else {
                log.info("getSalescouponsById 参数为空");
//                remoteResult.setSuccess(false);
//                remoteResult.setResultCode("02");
//                remoteResult.setResultMsg("参数错误");
                return  RemoteResultUtil.convert(ErrorMessageEnum.ERROR_PARA);
            }
            log.info("getSalescouponsById 结果：" + JSONObject.toJSONString(remoteResult));
        } catch (Exception e) {
            log.error(ExceptionUtil.getStackTrace(e));
        }
        return remoteResult;
    }

//    @Override
//    public RemoteResult<List<SalescouponsApi>> getSalescouponsByIds(List ids) {
//        log.info("getSalescouponsByIds 参数： " ,JsonUtil.toJson(ids));
//        RemoteResult remoteResult = new RemoteResult();
//        Map<String,Object> map = new HashMap();
//        map.put("ids",ids);
//        try {
//            if(ids != null){
//                //TODO
//                ResponseResult<List<Salescoupons>> responseResult = salescouponsManager.getSalescouponsList(map);
//                if (responseResult != null && responseResult.isSuccess() && responseResult.getData() !=null) {
//                    List<Salescoupons> couponsList = responseResult.getData();
//                    List<SalescouponsApi> apilist = new ArrayList<SalescouponsApi>(couponsList.size());
//                    for(Salescoupons salesCoupons :couponsList){
//                        DomainUtil domainUtil = new DomainUtil();
//                        SalescouponsApi salescouponsApi = new SalescouponsApi();
//                        domainUtil.copy(salesCoupons, salescouponsApi);
//                        apilist.add(salescouponsApi);
//                    }
//                    remoteResult.setT(apilist);
//                    remoteResult.setSuccess(true);
//                    return  remoteResult;
//                }
    @Override
    public RemoteResult<List<SalescouponsApi>> getSalescouponsByIds(List ids) {
        log.info("getSalescouponsByIds 参数： " ,JsonUtil.toJson(ids));
        RemoteResult remoteResult = new RemoteResult();
        Map<String,Object> map = new HashMap();
        map.put("ids",ids);
        try {
            if(ids != null){
                //TODO
                ResponseResult<List<Salescoupons>> responseResult = salescouponsManager.getSalescouponsList(map);
                if (responseResult != null && responseResult.isSuccess() && responseResult.getData() !=null) {
                    List<Salescoupons> couponsList = responseResult.getData();
                    List<SalescouponsApi> apilist = new ArrayList<SalescouponsApi>(couponsList.size());
                    for(Salescoupons salesCoupons :couponsList){
                        DomainUtil domainUtil = new DomainUtil();
                        SalescouponsApi salescouponsApi = new SalescouponsApi();
                        domainUtil.copy(salesCoupons, salescouponsApi);
                        apilist.add(salescouponsApi);
                    }
                    remoteResult.setT(apilist);
                    remoteResult.setSuccess(true);
                    return  remoteResult;
                }
            }else {
//                log.info("getSalescouponsById 参数为空");
//                remoteResult.setSuccess(false);
//                remoteResult.setResultCode("02");
//                remoteResult.setResultMsg("参数错误");
            	 return  RemoteResultUtil.convert(ErrorMessageEnum.ERROR_PARA);
            }
            log.info("getSalescouponsById 结果：" + JSONObject.toJSONString(remoteResult));
        } catch (Exception e) {
            log.error(ExceptionUtil.getStackTrace(e));
            return  RemoteResultUtil.convert(ErrorMessageEnum.ERROR_SERVICE);
        }
        return remoteResult;
    }
//    private String list2String(List list){
//        StringBuilder buider = new StringBuilder();
//        for(int i =0;i<list.size();i++){
//            if(i==0){
//                buider.append(list.get(i));
//            }else {
//                log.info("getSalescouponsById 参数为空");
//                remoteResult.setSuccess(false);
//                remoteResult.setResultCode("02");
//                remoteResult.setResultMsg("参数错误");
//            }
//            log.info("getSalescouponsById 结果：" + JSONObject.toJSONString(remoteResult));
//        } catch (Exception e) {
//            log.error(ExceptionUtil.getStackTrace(e));
//        }
//        return remoteResult;
//    }
    private String set2String(Set set){
        StringBuilder buider = new StringBuilder();
        Iterator iterator = set.iterator();
        while (iterator.hasNext()){
            buider.append(iterator.next()).append(",");
        }
        return buider.toString().substring(0,buider.length()-1);
    }

    /**
     * 查询指定类型下所有有效的优惠券（条件：优惠券有效，审核通过，在有效期内）
     * @param tenant
     * @param useScope 优惠券基本类型 1：普通券  4：专属券-c2c  6：专属券-以旧换新  10：惠商券
     * @return
     */
    @Override
    public RemoteResult<List<SalescouponsApi>> getSalescouponsByUseScope(Tenant tenant, int useScope, Long salescouponId, String couponName) {
        log.info(String.format("getSalescouponsByUseScope 参数：useScope=%d, salescouponId=%d, couponName=%s", useScope, salescouponId, couponName));
        RemoteResult remoteResult = new RemoteResult();
        try {
            if(tenant != null && tenant.getShopId() > 0 && useScope > 0){
                Map paramMap = new HashMap();
                paramMap.put("shopid", tenant.getShopId());
                paramMap.put("usescope", useScope);
                paramMap.put("id", salescouponId);
                paramMap.put("name", couponName);
                ResponseResult<List<Salescoupons>> responseResult = salescouponsManager.getSalescouponsByUseScope(paramMap);
                List<SalescouponsApi> salescouponsApiList = new ArrayList<SalescouponsApi>();
                if(responseResult != null && responseResult.isSuccess()){
                    remoteResult.setSuccess(true);
                    remoteResult.setResultCode(CouponConstant.RESULT_CODE_SUC);
                    remoteResult.setResultMsg(CouponConstant.RESULT_MSG_SUC);
                    DomainUtil domainUtil = new DomainUtil();
                    for (Salescoupons coupon : responseResult.getData()) {
                        SalescouponsApi salescouponsApi = new SalescouponsApi();
                        domainUtil.copy(coupon, salescouponsApi);
                        salescouponsApiList.add(salescouponsApi);
                    }
                    remoteResult.setT(salescouponsApiList);
                }else {
                    remoteResult.setSuccess(false);
                    remoteResult.setResultCode(CouponConstant.RESULT_CODE_FAIL);
                    remoteResult.setResultMsg(CouponConstant.RESULT_MSG_FAIL);
                }
            }else {
                remoteResult.setSuccess(false);
                remoteResult.setResultCode(CouponConstant.RESULT_CODE_ERROR_PARAM);
                remoteResult.setResultMsg(CouponConstant.RESULT_MSG_ERROR_PARAM);
            }
        } catch (Exception e) {
            log.error(ExceptionUtil.getStackTrace(e));
            return  RemoteResultUtil.convert(ErrorMessageEnum.ERROR_SERVICE);
        }
        return remoteResult;
    }

    @Override
    public RemoteResult<List<ShowInfo>> getShowInfoByShopId(Tenant tenent) {
        RemoteResult result = new RemoteResult();
        Integer shopId = tenent.getShopId();
        List<ShowInfo>  info = new ArrayList<ShowInfo>();
        if (shopId == ShopIdEnum.LENOVO.getType()){
            info.add(new ShowInfo(shopId,DisplayPositionEnum.USER_CENTER));
            info.add(new ShowInfo(shopId,DisplayPositionEnum.XIAO_XIN));
        }
        if (shopId == ShopIdEnum.SMB.getType()){
            info.add(new ShowInfo(shopId,DisplayPositionEnum.USER_CENTER));
        }

        result.setT(info);
        result.setSuccess(true);
        result.setResultCode(ErrorMessageEnum.SUCCESS.getCode());
        result.setResultMsg(ErrorMessageEnum.SUCCESS.getCommon());
        return result;
    }

    /**
     * Check available for specific coupon.
     * @param methodName  invoke method
     * @param salescoupons  specific coupon
     * @return
     */
    private RemoteResult checkCouponAvailable(String methodName, Salescoupons salescoupons){
        RemoteResult remoteResult = new RemoteResult();
        Date currentTime = new Date();
        if(salescoupons.getStatus() != 2){
//            remoteResult.setSuccess(false);
//            remoteResult.setResultCode(CouponConstant.RESULT_CODE_FAIL);
//            remoteResult.setResultMsg(String.format("优惠券[%d : %s]未通过审核，请先审核！", salescoupons.getId(), salescoupons.getName()));
//            log.info(String.format("%s : 优惠券未通过审核，CouponId: %d", methodName, salescoupons.getId()));
//            return remoteResult;
        	return RemoteResultUtil.convert(ErrorMessageEnum.ERROR_COUPON_NOTSHENHE.getCode(),ArrayUtil.toArrayString(new String[]{salescoupons.getName()}));
        }
        if(salescoupons.getIscanget() == 1){
            if (currentTime.before(salescoupons.getGetstarttime())) {
//                remoteResult.setSuccess(false);
//                remoteResult.setResultCode(CouponConstant.RESULT_CODE_FAIL);
//                remoteResult.setResultMsg(String.format("优惠券[%d : %s]还未到领取时间", salescoupons.getId(), salescoupons.getName()));
//                log.info(String.format("%s : 优惠券还未到领取时间，CouponId: %d", methodName, salescoupons.getId()));
//                return remoteResult;
            	return RemoteResultUtil.convert(ErrorMessageEnum.ERROR_COUPON_NOT_REACHGETTIME.getCode(),ArrayUtil.toArrayString(new String[]{salescoupons.getName()}));
            }
            if (currentTime.after(salescoupons.getGetendtime())) {
//                remoteResult.setSuccess(false);
//                remoteResult.setResultCode(CouponConstant.RESULT_CODE_FAIL);
//                remoteResult.setResultMsg(String.format("优惠券[%d : %s]领取时间已过", salescoupons.getId(), salescoupons.getName()));
//                log.info(String.format("%s : 优惠券领取时间已过，CouponId: %d", methodName, salescoupons.getId()));
//                return remoteResult;
            	return RemoteResultUtil.convert(ErrorMessageEnum.ERROR_COUPON_GETTIME_TIMEOUT.getCode(),ArrayUtil.toArrayString(new String[]{salescoupons.getName()}));
            }
        }else {
//            remoteResult.setSuccess(false);
//            remoteResult.setResultCode(CouponConstant.RESULT_CODE_FAIL);
//            remoteResult.setResultMsg(String.format("优惠券[%d : %s]不可领取", salescoupons.getId(), salescoupons.getName()));
//            log.info(String.format("%s : 优惠券不可领取，CouponId: %d", methodName, salescoupons.getId()));
//            return remoteResult;
        	return RemoteResultUtil.convert(ErrorMessageEnum.ERROR_COUPON_CANT_GET.getCode(),ArrayUtil.toArrayString(new String[]{salescoupons.getName()}));
        }
        if (currentTime.after(salescoupons.getTotime())) {
//            remoteResult.setSuccess(false);
//            remoteResult.setResultCode(CouponConstant.RESULT_CODE_FAIL);
//            remoteResult.setResultMsg(String.format("优惠券[%d : %s]已过期", salescoupons.getId(), salescoupons.getName()));
//            log.info(String.format("%s : 优惠券已过期，CouponId: %d", methodName, salescoupons.getId()));
//            return remoteResult;
        	return RemoteResultUtil.convert(ErrorMessageEnum.ERROR_COUPON_EXPIRE.getCode(),ArrayUtil.toArrayString(new String[]{salescoupons.getName()}));
        }

        remoteResult.setSuccess(true);
        return remoteResult;
    }

    /**
     * 验证优惠券有效性（只验证 1.是否审核通过  2.是否在有效期）。
     * 后台发券： 1. 不验证是否可以发  2. 不验证发放的时间
     * @param methodName
     * @param salescoupons
     * @return
     */
    private RemoteResult checkCouponAvailableForBackendSend(String methodName, Salescoupons salescoupons){
        RemoteResult remoteResult = new RemoteResult();
        Date currentTime = new Date();
        if(salescoupons.getStatus() != 2){
//            remoteResult.setSuccess(false);
//            remoteResult.setResultCode(CouponConstant.RESULT_CODE_FAIL);
//            remoteResult.setResultMsg(String.format("优惠券[%d : %s]未通过审核，请先审核！", salescoupons.getId(), salescoupons.getName()));
//            log.info(String.format("%s : 优惠券未通过审核，CouponId: %d", methodName, salescoupons.getId()));
//            return remoteResult;
        	 return  RemoteResultUtil.convert(ErrorMessageEnum.ERROR_COUPON_NOTSHENHE.getCode(),ArrayUtil.toArrayString(new String[]{salescoupons.getName()}));
        }
        if (currentTime.after(salescoupons.getTotime())) {
//            remoteResult.setSuccess(false);
//            remoteResult.setResultCode(CouponConstant.RESULT_CODE_FAIL);
//            remoteResult.setResultMsg(String.format("优惠券[%d : %s]已过期", salescoupons.getId(), salescoupons.getName()));
//            log.info(String.format("%s : 优惠券已过期，CouponId: %d", methodName, salescoupons.getId()));
//            return remoteResult;
        	 return  RemoteResultUtil.convert(ErrorMessageEnum.ERROR_COUPON_EXPIRE.getCode(),ArrayUtil.toArrayString(new String[]{salescoupons.getName()}));
        }

        remoteResult.setSuccess(true);
        return remoteResult;
    }

    /**
     * 记录优惠券/码的更新日志，将修改前的数据记录到日志表中
     * @param oldSalesCoupon
     * @param updateBy
     */
    private void saveSalesCouponEditLog(final SalescouponsApi oldSalesCoupon, final String updateBy){
        service.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    long logBatch = System.currentTimeMillis();
                    Date updateTime = new Date();
                    DomainUtil domainUtil = new DomainUtil();
                    LogVo salescouponsLog = new LogVo();
                    salescouponsLog.setContent(JsonUtil.toJson(oldSalesCoupon));
                    salescouponsLog.setOperationType("SalesCouponEdit");
                    salescouponsLog.setLenovoId(updateBy);
                    salescouponsLog.setCreateTime(updateTime.toString());
                    salescouponsLog.setModul(ModulNameEnum.SALES_COUPON_LOG.getDesc());

                    logService.save2Mongo(salescouponsLog);

                    ProductruleApi productruleApi = oldSalesCoupon.getProductruleApi();
                    if(productruleApi != null){
                        LogVo productruleLog = new LogVo();
                        productruleLog.setContent(JsonUtil.toJson(productruleApi));
                        productruleLog.setLenovoId(updateBy);
                        productruleLog.setCreateTime(updateTime.toString());
                        productruleLog.setModul(ModulNameEnum.PRODUCT_RULE_LOG.getDesc());
                        productruleLog.setOperationType("SalesCouponEdit");
                        logService.save2Mongo(productruleLog);
                    }

                    List<DetailsruleApi> detailsruleApiList = oldSalesCoupon.getDetailsruleApiList();
                    if(!CollectionUtils.isEmpty(detailsruleApiList)){
                        List<DetailsruleLog> detailsruleLogList = new ArrayList<DetailsruleLog>();
                        LogVo vo = new LogVo();
                        vo.setLenovoId(updateBy);
                        vo.setCreateTime(updateTime.toString());
                        vo.setContent(JsonUtil.toJson(detailsruleLogList));
                        vo.setModul(ModulNameEnum.DETAIL_RULE_LOG.getDesc());
                        vo.setOperationType("SalesCouponEdit");

                        logService.save2Mongo(vo);
                    }

                    List<DistributorruleApi> distributorruleApiList = oldSalesCoupon.getDistributorruleApiList();
                    log.info("saveSalesCouponEditLog distributorruleApiList:"+JacksonMapper.obj2json(distributorruleApiList));
                    if(!CollectionUtils.isEmpty(distributorruleApiList)){
                        List<DistributorruleLog> distributorruleLogList = new ArrayList<DistributorruleLog>();
                        LogVo vo = new LogVo();
                        vo.setLenovoId(updateBy);
                        vo.setCreateTime(updateTime.toString());
                        vo.setContent(JsonUtil.toJson(distributorruleLogList));
                        vo.setModul(ModulNameEnum.DISTRUBTOR_RULE_LOG.getDesc());
                        vo.setOperationType("SalesCouponEdit");

                        logService.save2Mongo(vo);
                    }
                    log.info("save salescoupon update log success.");
                } catch (Exception e) {
                    log.error("Save Salescoupon update log error.", ExceptionUtil.getStackTrace(e));
                }
            }
        });
    }


    /*
     * (非 Javadoc)
    * <p>Title: getDistributeSalescoupons</p>
    * <p>Description: </p>
    * @param pageQuery
    * @param displayPosition
    * @return
    * @see com.lenovo.m2.couponV2.api.service.SalescouponsService#getDistributeSalescoupons(com.lenovo.m2.arch.framework.domain.PageQuery, java.lang.Integer)
     */
	@Override
	public RemoteResult<PageModel2<SalescouponsApi>> getDistributeSalescoupons(Tenant tenant,PageQuery pageQuery, Integer displayPosition) {
        Integer shopId = tenant.getShopId();
	    log.info("getDistributeSalescoupons param disposition:"+displayPosition+"pageQuery"+JsonUtil.toJson(pageQuery)+"shopId:"+shopId);
	    RemoteResult result = new RemoteResult(false);
        try{
            PageModel2<Salescoupons> rs = salescouponsManager.getDistributeSalescoupons(shopId,pageQuery,displayPosition);
            log.info("getDistributeSalescoupons get rs"+JsonUtil.toJson(rs));
            List<SalescouponsApi> salescouponsApiList = new ArrayList<SalescouponsApi>();
            if(null != rs && null !=rs.getDatas() && rs.getDatas().size() > 0 ){
                DomainUtil domainUtil = new DomainUtil();
                for (Salescoupons coupon : rs.getDatas()) {
                    SalescouponsApi salescouponsApi = new SalescouponsApi();
                    domainUtil.copy(coupon, salescouponsApi);
                    salescouponsApiList.add(salescouponsApi);
                }
                // 对查询到的优惠券按金额大小排序
                Collections.sort(salescouponsApiList, new Comparator<SalescouponsApi>() {
                    @Override
                    public int compare(SalescouponsApi o1, SalescouponsApi o2) {
                        return o1.getAmount().compareTo(o2.getAmount());
                    }
                });
                PageModel2<SalescouponsApi> pageModel=new PageModel2<SalescouponsApi>(pageQuery,salescouponsApiList);
                result.setResultMsg(CouponConstant.RESULT_MSG_SUC);
                result.setResultCode(CouponConstant.RESULT_CODE_SUC);
                result.setT(pageModel);
                result.setSuccess(true);
            }else {
                PageModel2<SalescouponsApi> pageModel=new PageModel2<SalescouponsApi>(pageQuery,salescouponsApiList);
                result.setT(pageModel);
                result.setSuccess(true);
                result.setResultMsg(ErrorMessageEnum.ERROR_FIND.getCommon());
                result.setResultCode(ErrorMessageEnum.ERROR_FIND.getCode());
            }
        }catch (Exception e){
            log.error(ExceptionUtil.getStackTrace(e));
            return  RemoteResultUtil.convert(ErrorMessageEnum.ERROR_SERVICE);
        }
        return result;
	}

    @Override
    public RemoteResult<PageModel2<SalescouponsApi>> getDistributeSalescoupons(PageQuery pageQuery, Integer displayPosition) {
        Tenant tenant =new Tenant();
        tenant.setShopId(1);
        return getDistributeSalescoupons(tenant,pageQuery,displayPosition);
    }

    private String  couponOpenPlat(String productGroupId,String method){

        Map<String,Object> lenovo_param_json = new HashMap<String, Object>();
        lenovo_param_json.put("productgroupno",productGroupId);
        lenovo_param_json.put("status",1);
        log.info("invoke openplat param: {}",JsonUtil.toJson(lenovo_param_json));
        try {
            Response response = JavaSDKClient.proxy(openapiUrl, openapiAppKey, openapiScrebt, method, lenovo_param_json, null, null);
            Map temp = com.lenovo.m2.couponV2.common.util.JsonUtil.fromJson(response.getBody().toString(), Map.class);
            log.info("JavaSDKClient return temp={}",JsonUtil.toJson(temp));
            Object success = temp.get("success");
            if ("true".equals(String.valueOf(success))) {
                Map obj = (Map) temp.get("result");
                Object res = obj.get(String.format("%s_response", invokeOpenPlateMethed.replaceAll("\\.", "_")));
                log.info("unpack res={}", res);
                return JsonUtil.toJson(res);
            } else {
                log.error("couponOpenPlat not success method:{}", invokeOpenPlateMethed);
                return null;
            }

        } catch (Exception e) {
            log.error("调用开放平台失败"+e);
            return null;
        }
    }
    //返回不满足签约关系的经销商编码列表
    private BaseInfo  confirmProductGroupIdAndFaCodesRelation(SalescouponsApi salescouponsApi){
        if(salescouponsApi.getType() != CouponConstant.COUPON_TYPE_PRODUCTGROUP_3){
            return  new BaseInfo(0, "success");
        }
        //没有签约产品组的分销商列表
        List<String> uncontains = new ArrayList<String>();
        String method = "lenovo.fxs.getProductForSearch.com_hs";
        List<Product2FaRelationsApi> apiList = salescouponsApi.getGroup2facodes();
        for (Product2FaRelationsApi api:apiList){
            String s = couponOpenPlat(api.getProductgroupno(),method);
            log.info("couponOpenPlat return ={}",s);
            if(s != null){
                List<Object> read = JsonPath.read(s, "$.data");
                //sec查到的列表
                List<String> list = new ArrayList<String>();
                for(Object disInfo : read){
                    list.add((String) JsonPath.read(disInfo,"fxsno"));
                }
                //前台传的产品组
                List<String> facodes = api.getFacodes();
                for(String facode :facodes){

                    if( !list.contains(facode)){
                        uncontains.add(facode);
                    }
                }
                if (uncontains != null && uncontains.size() >0){
                    log.info("未查到产品组{}与分销商{}的签约关系",api.getProductgroupno(),JsonUtil.toJson(uncontains));
                   // return new BaseInfo(1,"未查到产品组"+api.getProductgroupno()+"与分销商"+JsonUtil.toJson(uncontains)+"的签约关系");
                    return  new BaseInfo(Integer.parseInt(ErrorMessageEnum.ERROR_FIND_GROUP_DISTRUBUTOR.getCode()),ArrayUtil.toArrayString(new String[]{api.getProductgroupno(),JsonUtil.toJson(uncontains)}));
                }
            }else{
               // return  new BaseInfo(1,"调用接口返回签约关系错误，"+api.getProductgroupno());
            	 return  new BaseInfo(Integer.parseInt(ErrorMessageEnum.ERROR_INVOIKEGROUP_DISTRUBUTOR.getCode()),ErrorMessageEnum.ERROR_INVOIKEGROUP_DISTRUBUTOR.getCommon());
            }
        }
        return new BaseInfo(0, "success");
    }
}