package com.lenovo.m2.couponV2.service.impl;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.framework.domain.Tenant;
import com.lenovo.m2.arch.tool.util.CollectionUtils;
import com.lenovo.m2.arch.tool.util.StringUtils;
import com.lenovo.m2.couponV2.api.dubboModel.ProductInfoApi;
import com.lenovo.m2.couponV2.api.dubboService.RpcSalescouponsService;
import com.lenovo.m2.couponV2.api.model.DetailsruleApi;
import com.lenovo.m2.couponV2.api.model.ProductruleApi;
import com.lenovo.m2.couponV2.api.model.SalescouponsApi;
import com.lenovo.m2.couponV2.common.CouponConstant;
import com.lenovo.m2.couponV2.common.DomainUtil;
import com.lenovo.m2.couponV2.common.JacksonMapper;
import com.lenovo.m2.couponV2.common.RemoteResultUtil;
import com.lenovo.m2.couponV2.common.enums.ErrorMessageEnum;
import com.lenovo.m2.couponV2.common.exception.ExceptionUtil;
import com.lenovo.m2.couponV2.dao.mybatis.model.Detailsrule;
import com.lenovo.m2.couponV2.dao.mybatis.model.Membercouponrels;
import com.lenovo.m2.couponV2.dao.mybatis.model.Productrule;
import com.lenovo.m2.couponV2.dao.mybatis.model.Salescoupons;
import com.lenovo.m2.couponV2.dao.util.ResponseResult;
import com.lenovo.m2.couponV2.manager.DetailsruleManager;
import com.lenovo.m2.couponV2.manager.MemberCouponrelsManager;
import com.lenovo.m2.couponV2.manager.ProductruleManager;
import com.lenovo.m2.couponV2.manager.SalescouponsManager;
import com.lenovo.m2.couponV2.manager.redisObject.RedisObjectManager;
import com.lenovo.m2.couponV2.remote.IDSequenceService;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Created by zhaocl1 on 2016/3/10.
 */
@Service("rpcSalescouponsService")
public class RpcSalescouponsServiceImpl implements RpcSalescouponsService {
    private static final Logger log = LoggerFactory.getLogger(RpcSalescouponsServiceImpl.class);
    @Autowired
    private SalescouponsManager salescouponsManager;
    @Autowired
    private DetailsruleManager detailsruleManager;
    @Autowired
    private ProductruleManager productruleManager;
    @Autowired
    private RedisObjectManager redisObjectManager;
    @Autowired
    private MemberCouponrelsManager memberCouponrelsManager;
    /**
     * 根据优惠券主键id查询优惠券，供外部调用
     * @param id
     * @return
     */
    @Override
    public RemoteResult getSalescouponsById(long id) {
        RemoteResult result = new RemoteResult(false);
        try{
            if(id>0){
                ResponseResult<Salescoupons> responseResult = salescouponsManager.getSalescoupons(id);
                if(responseResult.isSuccess() && responseResult.getData() != null){
                    Salescoupons salescoupons = responseResult.getData();
                    SalescouponsApi salescouponsApi1 = new SalescouponsApi();
                    new DomainUtil().copy(responseResult.getData(),salescouponsApi1);
                    if(salescoupons.getType() == CouponConstant.COUPON_TYPE_DETAIL_1){ //分类
                        Detailsrule detailsrule = new Detailsrule();
                        detailsrule.setSalescouponid(id);
                        ResponseResult<List<Detailsrule>> resdetail = detailsruleManager.getDetailsruleList(detailsrule);
                        if(resdetail.isSuccess() && resdetail.getData() != null && resdetail.getData().size() > 0){
                            List<Detailsrule> list = resdetail.getData();
                            List<DetailsruleApi> listapi = new ArrayList<DetailsruleApi>();
                            DetailsruleApi detailsruleApi = null;
                            for(Detailsrule detail : list){
                                detailsruleApi = new DetailsruleApi();
                                new DomainUtil().copy(detail, detailsruleApi);
                                listapi.add(detailsruleApi);
                            }
                            salescouponsApi1.setDetailsruleApiList(listapi);
                        }else {
                            log.info("getSalescouponsById 优惠券[" + id + "]是分类券[" + salescoupons.getType() + "] 但是没有查询到券的商品分类信息！");
                            result.setResultMsg("查询券["+id+"]分类时出现问题！");
                            result.setResultCode("11");
                            log.info("getSalescouponsById 结果：" + result);
                            return result;
                        }
                    }else if(salescoupons.getType() == CouponConstant.COUPON_TYPE_PRODUCT_2){ //商品
                        Productrule productrule = new Productrule();
                        productrule.setSalescouponid(id);
                        ResponseResult<List<Productrule>> respro = productruleManager.getProductruleList(productrule);
                        if(respro.isSuccess() && respro.getData() != null && respro.getData().size() == 1){
                            Productrule productrule1  = respro.getData().get(0);
                            ProductruleApi productruleApi = new ProductruleApi();
                            new DomainUtil().copy(productrule1, productruleApi);
                            salescouponsApi1.setProductruleApi(productruleApi);
                        }else {
                            log.info("getSalescouponsById 优惠券[" + id + "]是商品券[" + salescoupons.getType() + "] 但是没有查询到券的商品信息！");
                            result.setResultMsg("查询券["+id+"]商品时出现问题！");
                            result.setResultCode("12");
                            log.info("getSalescouponsById 结果：" + result);
                            return result;
                        }
                    }


                    result.setResultMsg(CouponConstant.RESULT_MSG_SUC);
                    result.setResultCode(CouponConstant.RESULT_CODE_SUC);
                    result.setT(salescouponsApi1);
                    result.setSuccess(true);
                    log.info("getSalescouponsById 结果："+result);
                    return result;
                }else {
                    log.info("getSalescouponsById 根据优惠券主键[" + id + "]没有查到优惠券！");
                    result.setResultMsg("根据优惠券主键["+id+"]没有查到优惠券！");
                    result.setResultCode("10");
                    log.info("getSalescouponsById 结果：" + result);
                    return result;
                }
            }else {
                log.info("getSalescouponsById ： 参数错误！");
                result.setResultMsg(CouponConstant.RESULT_MSG_ERROR_PARAM);
                result.setResultCode(CouponConstant.RESULT_CODE_ERROR_PARAM);
                log.info("getSalescouponsById 结果：" + result);
                return result;
            }
        }catch (Exception e){
            log.error(ExceptionUtil.getStackTrace(e));
            result.setResultCode(CouponConstant.RESULT_CODE_ERROR);
            result.setResultMsg(CouponConstant.RESULT_MSG_ERROR);
            result.setSuccess(false);
            log.error("getSalescouponsById 结果："+result);
            return result;
        }
    }

    @Override
    public RemoteResult<Boolean> addEppCoupon(int couponway, String lenovoid, String memberCode) {
        log.info("addEppCoupon 参数 couponway="+couponway+", lenovoid="+lenovoid+", memberCode="+memberCode);
        RemoteResult<Boolean> remoteResult = new RemoteResult<Boolean>(false);
        try{
            Salescoupons salescoupons = salescouponsManager.getSalescouponsByCouponWay(couponway);
            if (salescoupons==null){
                log.info("addEppCoupon 未找到相应类型的优惠券 couponway：" + couponway);
                remoteResult.setT(false);
                remoteResult.setResultMsg("未找到相应类型的优惠券");
                log.info("addEppCoupon 结果：" + remoteResult);
                return remoteResult;
            }

            List<Membercouponrels> membercouponrelsList = new ArrayList<Membercouponrels>();
            String batchNo = String.valueOf(new Date().getTime());//发放批次号
            RemoteResult<Boolean> insertResult = new RemoteResult<Boolean>(false);
            //注册送券添加去重逻辑
            if(1 == couponway){
                /**
                 * 先查询用户是否已经有了epp的注册送券
                 */
                ResponseResult responseResult = memberCouponrelsManager.getMembercouponrelsByLenovoIdandSalescouponId(lenovoid,salescoupons.getId());
                if(responseResult.isSuccess()){
                    log.info("addEppCoupon 用户" + lenovoid + "已经绑过优惠券" + salescoupons.getId());
                    remoteResult.setResultCode(CouponConstant.RESULT_CODE_SUC);
                    remoteResult.setSuccess(true);
                    remoteResult.setResultMsg("用户已经绑过注册送券");
                    log.info("addEppCoupon 结果："+remoteResult);
                    return remoteResult;
                }
                //绑券
                Membercouponrels membercouponrels = makeMembercouponrels(lenovoid, memberCode, salescoupons, batchNo);
                membercouponrelsList.add(membercouponrels);
                insertResult = memberCouponrelsManager.insertBatch(membercouponrelsList);
            }else {
                //2 代表签收送券
                Membercouponrels membercouponrels = makeMembercouponrels(lenovoid, memberCode, salescoupons, batchNo);
                membercouponrelsList.add(membercouponrels);
                insertResult = memberCouponrelsManager.insertBatch(membercouponrelsList);
            }

            if (insertResult!=null&&insertResult.isSuccess()){
                if (salescoupons.getBacksend()==1){
                    remoteResult.setResultMsg(CouponConstant.RESULT_MSG_SUC);
                    remoteResult.setResultCode(CouponConstant.RESULT_CODE_SUC);
                    remoteResult.setSuccess(true);
                    log.info("addEppCoupon 结果："+remoteResult);
                    return remoteResult;
                }
                Salescoupons s = new Salescoupons();
                s.setId(salescoupons.getId());
                s.setBacksend(CouponConstant.COUPON_Backsend_1);// 1 已经发过券，0 未发过券
                s.setUpdatetime(new Date());
                s.setUpdateby(lenovoid);
                ResponseResult rs = salescouponsManager.editSalescoupons(s) ;
                if (rs == null || !rs.isSuccess()) {
                    log.info("发券完成后更新salescoupon表时出错");
                }

                remoteResult.setResultMsg(CouponConstant.RESULT_MSG_SUC);
                remoteResult.setResultCode(CouponConstant.RESULT_CODE_SUC);
                remoteResult.setSuccess(true);
                log.info("addEppCoupon 结果："+remoteResult);
                return remoteResult;
            }
        }catch (Exception e){
            log.error("addEppCoupon 出现异常" + ExceptionUtil.getStackTrace(e));
        }
        log.info("addEppCoupon 结果：" + remoteResult);
        return remoteResult;
    }

    @Override
    public RemoteResult<Boolean> addEppCoupon(Tenant tenant, int couponway, String lenovoid, String memberCode) {
        return this.addEppCoupon(String.valueOf(tenant.getShopId()), couponway, lenovoid, memberCode);
    }

    @Override
    public RemoteResult<Boolean> addEppCoupon(String shopId, int couponway, String lenovoid, String memberCode) {
        log.info("addEppCoupon 参数 shopId="+ shopId +", couponway="+couponway+", lenovoid="+lenovoid+", memberCode="+memberCode);
        RemoteResult<Boolean> remoteResult = new RemoteResult<Boolean>(false);
        try{
            Salescoupons salescoupons = salescouponsManager.getSalescouponsByCouponWay(shopId, couponway);
            if (salescoupons == null){
                log.info("addEppCoupon 未找到相应类型的优惠券 couponway：" + couponway);
                remoteResult.setT(false);
                remoteResult.setResultMsg("未找到相应类型的优惠券");
                log.info("addEppCoupon 结果：" + remoteResult);
                return remoteResult;
            }

            List<Membercouponrels> membercouponrelsList = new ArrayList<Membercouponrels>();
            String batchNo = String.valueOf(new Date().getTime());//发放批次号
            RemoteResult<Boolean> insertResult = new RemoteResult<Boolean>(false);
            //注册送券添加去重逻辑
            if(1 == couponway){
                /**
                 * 先查询用户是否已经有了epp的注册送券
                 */
                ResponseResult responseResult = memberCouponrelsManager.getMembercouponrelsByLenovoIdandSalescouponId(lenovoid,salescoupons.getId());
                if(responseResult.isSuccess()){
                    log.info("addEppCoupon 用户" + lenovoid + "已经绑过优惠券" + salescoupons.getId());
//                    remoteResult.setResultCode(CouponConstant.RESULT_CODE_SUC);
//                    remoteResult.setSuccess(true);
//                    remoteResult.setResultMsg("用户已经绑过注册送券");
//                    log.info("addEppCoupon 结果："+remoteResult);
//                    return remoteResult;
                    return RemoteResultUtil.convert(ErrorMessageEnum.ERROR_USER_COUPON_BIND);
                }
                //绑券
                Membercouponrels membercouponrels = makeMembercouponrels(lenovoid, memberCode, salescoupons, batchNo);
                membercouponrelsList.add(membercouponrels);
                insertResult = memberCouponrelsManager.insertBatch(membercouponrelsList);
            }else {
                //2 代表签收送券
                Membercouponrels membercouponrels = makeMembercouponrels(lenovoid, memberCode, salescoupons, batchNo);
                membercouponrelsList.add(membercouponrels);
                insertResult = memberCouponrelsManager.insertBatch(membercouponrelsList);
            }

            if (insertResult!=null&&insertResult.isSuccess()){
                if (salescoupons.getBacksend()==1){
                    remoteResult.setResultMsg(CouponConstant.RESULT_MSG_SUC);
                    remoteResult.setResultCode(CouponConstant.RESULT_CODE_SUC);
                    remoteResult.setSuccess(true);
                    log.info("addEppCoupon 结果："+remoteResult);
                    return remoteResult;
                }
                Salescoupons s = new Salescoupons();
                s.setId(salescoupons.getId());
                s.setBacksend(CouponConstant.COUPON_Backsend_1);// 1 已经发过券，0 未发过券
                s.setUpdatetime(new Date());
                s.setUpdateby(lenovoid);
                ResponseResult rs = salescouponsManager.editSalescoupons(s) ;
                if (rs == null || !rs.isSuccess()) {
                    log.info("发券完成后更新salescoupon表时出错");
                }

                remoteResult.setResultMsg(CouponConstant.RESULT_MSG_SUC);
                remoteResult.setResultCode(CouponConstant.RESULT_CODE_SUC);
                remoteResult.setSuccess(true);
                log.info("addEppCoupon 结果："+remoteResult);
                return remoteResult;
            }
        }catch (Exception e){
            log.error("addEppCoupon 出现异常" + ExceptionUtil.getStackTrace(e));
            return RemoteResultUtil.convert(ErrorMessageEnum.ERROR_SERVICE);
        }
        log.info("addEppCoupon 结果：" + remoteResult);
        return remoteResult;
    }
    @Autowired
    private IDSequenceService idSequenceService;
    private Membercouponrels makeMembercouponrels(String lenovoid,String memberCode, Salescoupons salescoupons, String batchNo) {
        Membercouponrels membercouponrels = new Membercouponrels();

        membercouponrels.setId(Long.parseLong(idSequenceService.genId()));
        membercouponrels.setMembercode(memberCode);
//        membercouponrels.setMemberid(memberId);
        membercouponrels.setLenovoid(lenovoid);
        membercouponrels.setSalescouponid(salescoupons.getId());
        membercouponrels.setUsescope(salescoupons.getUsescope());
        membercouponrels.setCouponcode(salescoupons.getCouponcode());
        membercouponrels.setShopid(salescoupons.getShopid());
        membercouponrels.setTerminal(salescoupons.getTerminal());
        membercouponrels.setName(salescoupons.getName());
        membercouponrels.setAmount(salescoupons.getAmount());
        membercouponrels.setConditions(salescoupons.getConditions());
        membercouponrels.setType(salescoupons.getType());
        membercouponrels.setDescription(salescoupons.getDescription());
        membercouponrels.setFromtime(salescoupons.getFromtime());
        membercouponrels.setTotime(salescoupons.getTotime());
        membercouponrels.setTotalnumber(salescoupons.getTotalnumber());
        membercouponrels.setSurplusnumber(salescoupons.getTotalnumber());
        membercouponrels.setClassification(salescoupons.getClassification());
        membercouponrels.setSuperposition(salescoupons.getSuperposition());
        membercouponrels.setCouponsource(CouponConstant.COUPON_SOURCE_API);
        membercouponrels.setEppgroup(salescoupons.getEppgroup());
        membercouponrels.setBatchno(batchNo);
        membercouponrels.setStatus(0);//0未使用 1已使用
        membercouponrels.setDisabled(0);//0未禁用 1已禁用
        membercouponrels.setCreatetime(new Date());
        membercouponrels.setUpdatetime(new Date());
        membercouponrels.setCreateby(lenovoid);
        membercouponrels.setCurrencyCode(salescoupons.getCurrencyCode());
        return membercouponrels;
    }

    @Override
    public RemoteResult getSalescouponsValidList() {
        RemoteResult result = new RemoteResult(false);
        try {
            ResponseResult<List<Salescoupons>> responseResult = salescouponsManager.getSalescouponsValidList();
            if(responseResult.isSuccess() && responseResult.getData() != null){
                if(responseResult.getData().size() == 0){
                    log.info("getSalescouponsValidList 没有有效的优惠券！");
                    result.setResultCode("11");
                    result.setResultMsg("没有有效的优惠券！");
                    result.setSuccess(true);
                    log.info("getSalescouponsValidList 结果："+result);
                    return result;
                }

                List<Salescoupons> list_salescoupons = responseResult.getData();
                List<SalescouponsApi> list_salescouponApi = new ArrayList<SalescouponsApi>();
                SalescouponsApi salescouponsApi = null;
                for(Salescoupons salescoupons : list_salescoupons){
                    /**
                     * 只处理普通券
                     */
                    if(salescoupons.getUsescope() == CouponConstant.COUPON_USESCOPE_ZHEKOU){
                        salescouponsApi = new SalescouponsApi();
                        new DomainUtil().copy(salescoupons,salescouponsApi);
                        if(salescoupons.getType() == CouponConstant.COUPON_TYPE_DETAIL_1){ //分类
                            Detailsrule detailsrule = new Detailsrule();
                            detailsrule.setSalescouponid(salescoupons.getId());
                            ResponseResult<List<Detailsrule>> resdetail = detailsruleManager.getDetailsruleList(detailsrule);
                            if(resdetail.isSuccess() && resdetail.getData() != null && resdetail.getData().size() > 0){
                                List<Detailsrule> list = resdetail.getData();
                                List<DetailsruleApi> listapi = new ArrayList<DetailsruleApi>();
                                DetailsruleApi detailsruleApi = null;
                                for(Detailsrule detail : list){
                                    detailsruleApi = new DetailsruleApi();
                                    new DomainUtil().copy(detail, detailsruleApi);
                                    listapi.add(detailsruleApi);
                                }
                                salescouponsApi.setDetailsruleApiList(listapi);
                            }else {
                                log.info("getSalescouponsValidList 优惠券[" + salescoupons.getId() + "]是分类券[" + salescoupons.getType() + "] 但是没有查询到券的商品分类信息！");
                            }
                        }else if(salescoupons.getType() == CouponConstant.COUPON_TYPE_PRODUCT_2){ //商品
                            Productrule productrule = new Productrule();
                            productrule.setSalescouponid(salescoupons.getId());
                            ResponseResult<List<Productrule>> respro = productruleManager.getProductruleList(productrule);
                            if(respro.isSuccess() && respro.getData() != null && respro.getData().size() == 1){
                                Productrule productrule1  = respro.getData().get(0);
                                ProductruleApi productruleApi = new ProductruleApi();
                                new DomainUtil().copy(productrule1, productruleApi);
                                salescouponsApi.setProductruleApi(productruleApi);
                            }else {
                                log.info("getSalescouponsValidList 优惠券[" + salescoupons.getId() + "]是商品券[" + salescoupons.getType() + "] 但是没有查询到券的商品信息！");
                            }
                        }
                        /**
                         * 如果在批量查询优惠券信息时，如果其中一条出现问题，如没有商品信息或者没有分类信息，则这条数据不对外返回，只返回正确的数据
                         */
                        if(salescouponsApi.getDetailsruleApiList() != null || salescouponsApi.getProductruleApi() != null){
                            list_salescouponApi.add(salescouponsApi);
                        }
                    }else {
                        log.info("getSalescouponsValidList 该券类型为"+salescoupons.getUsescope());
                    }
                }
                result.setResultMsg(CouponConstant.RESULT_MSG_SUC);
                result.setResultCode(CouponConstant.RESULT_CODE_SUC);
                result.setT(list_salescouponApi);
                result.setSuccess(true);
                log.info("getSalescouponsValidList 结果："+result);
                return result;
            }else {
                log.info("getSalescouponsValidList 10 没有查到有效优惠券！");
                result.setResultMsg("没有查到有效优惠券！！");
                result.setResultCode("10");
                log.info("getSalescouponsValidList 结果：" + result);
                return result;
            }
        } catch (Exception e) {
            log.info("getSalescouponsValidList 异常：" + ExceptionUtil.getStackTrace(e));
            result.setResultCode(CouponConstant.RESULT_CODE_ERROR);
            result.setResultMsg(CouponConstant.RESULT_MSG_ERROR);
            result.setSuccess(false);
            return result;
        }
    }

    @Override
    public RemoteResult getSalescouponsByGoodsCode(Tenant tenant, ProductInfoApi productInfoApi, String terminal) {
        return this.getSalescouponsByGoodsCode(productInfoApi, String.valueOf(tenant.getShopId()), terminal);
    }

    @Override
    public RemoteResult getSalescouponsByGoodsCode(ProductInfoApi productInfoApi, String shopId, String terminal) {
        log.info("getSalescouponsByGoodsCode 参数："+productInfoApi+", shopId=["+shopId+"] terminal=["+terminal+"] ");
        RemoteResult result = new RemoteResult(false);
        try {
            if(productInfoApi == null || StringUtils.isEmpty(productInfoApi.getGoodscode()) || StringUtils.isEmpty(productInfoApi.getCategorycode()) || StringUtils.isEmpty(shopId) || StringUtils.isEmpty(terminal) ){
                log.info("getSalescouponsByGoodsCode ： 参数错误！");
                result.setResultCode(CouponConstant.RESULT_CODE_ERROR_PARAM);
                result.setResultMsg(CouponConstant.RESULT_MSG_ERROR_PARAM);
                log.info("getSalescouponsByGoodsCode 结果：" + result);
                return result;
            }
            List<Long> list =new ArrayList<Long>();
            String goodscodekey = "coupon_"+shopId+"_"+ terminal +"_"+ productInfoApi.getGoodscode();
            /**
             * 查找绑定商品的券
             */
            String goodscode_json = redisObjectManager.getString(goodscodekey);
            if(StringUtils.isNotEmpty(goodscode_json) && !goodscode_json.equals("[]")){
                List<SalescouponsApi> list_get = JacksonMapper.json2list(goodscode_json,SalescouponsApi.class);
                if(CollectionUtils.isNotEmpty(list_get)){
                    for(SalescouponsApi s : list_get){
                        list.add(s.getId());
                    }
                }else {
                    log.info("从缓存中取出数据后，转换为list时为空！即"+list_get);
                }
            }else {
                //没有对应的券
            }

            /**
             * 查找绑定分类的券
             */
            String categorycodekey = "coupon_"+shopId+"_"+ terminal +"_"+productInfoApi.getCategorycode();
            String categorycode_json = redisObjectManager.getString(categorycodekey);
            if(StringUtils.isNotEmpty(categorycode_json)  && !categorycode_json.equals("[]")){
                List<SalescouponsApi> list_get = JacksonMapper.json2list(goodscode_json,SalescouponsApi.class);
                if(CollectionUtils.isNotEmpty(list_get)){
                    for(SalescouponsApi s : list_get){
                        // 先确定商品是否是券排除的分类商品
                        if(s.getNojoingoodcodes().contains(productInfoApi.getGoodscode())){
                            continue;
                        }
                        list.add(s.getId());
                    }
                }else {
                    log.info("从缓存中取出数据后，转换为list时为空！"+list_get);
                }
            }else {
                //没有对应的券
            }

            if(CollectionUtils.isEmpty(list)){
                list = null;
            }

            result.setResultMsg(CouponConstant.RESULT_MSG_SUC);
            result.setResultCode(CouponConstant.RESULT_CODE_SUC);
            result.setT(list);
            result.setSuccess(true);
            log.info("getSalescouponsByGoodsCode 结果："+result);
            return result;

        } catch (Exception e) {
            log.error("getSalescouponsByGoodsCode 异常：" + ExceptionUtil.getStackTrace(e));
            result.setResultCode(CouponConstant.RESULT_CODE_ERROR);
            result.setResultMsg(CouponConstant.RESULT_MSG_ERROR);
            result.setSuccess(false);
            return result;
        }
    }
    
    public void test(){
    	
    }
}
