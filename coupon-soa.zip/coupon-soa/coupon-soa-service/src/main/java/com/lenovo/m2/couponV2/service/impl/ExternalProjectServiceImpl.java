package com.lenovo.m2.couponV2.service.impl;

import com.lenovo.m2.couponV2.api.service.ExternalProjectService;
import com.lenovo.m2.couponV2.common.exception.ExceptionUtil;
import com.lenovo.price.api.DataChangeService;
import com.lenovo.price.client.PriceServicesClient;
import com.lenovo.price.model.NotifyType;
import com.lenovo.search.api.PromotionRuleService;
import com.lenovo.search.client.IndexServicesClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

/**
 * Created by zhaocl1 on 2016/4/12.
 */
@Service("externalProjectService")
public class ExternalProjectServiceImpl implements ExternalProjectService{
    private static final Logger LOGGER = LoggerFactory.getLogger(ExternalProjectServiceImpl.class);
    @Override
    public void couponNotify(Long[] longPrama, NotifyType notifyType) {
        DataChangeService dataChangeService = PriceServicesClient.getInstance().getService(DataChangeService.class);
        /**
         * 通知商品无效  审核后修改
         */
        LOGGER.info("couponNotify 通知商品无效 参数："+longPrama+NotifyType.coupon_invalid);
        dataChangeService.couponNotify(longPrama, NotifyType.coupon_invalid);
    }

    @Override
    public boolean changeCoupon(long id, boolean flag) {
        boolean result = false;
        try {
            PromotionRuleService promotion = IndexServicesClient.getInstance().getPromotionRuleService();
            /**
             * 通知查询无效 审核后修改
             */
            LOGGER.info("changeCoupon 通知搜索无效 参数："+id+" ,false");
            result = promotion.changeCoupon(id,false);
            LOGGER.info("changeCoupon 通知搜索无效 结果："+flag);
        } catch (Throwable e) {
            LOGGER.error("通知搜索接口出现异常！",  e);
        }
        return result;
    }
}
