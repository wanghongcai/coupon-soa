package com.lenovo.m2.couponV2.service.impl;

import com.lenovo.m2.arch.framework.domain.PageModel2;
import com.lenovo.m2.arch.framework.domain.PageQuery;
import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.couponV2.api.model.MembercouponrelsApi;
import com.lenovo.m2.couponV2.api.service.MemberExcelTempService;
import com.lenovo.m2.couponV2.common.CouponConstant;
import com.lenovo.m2.couponV2.common.DomainUtil;
import com.lenovo.m2.couponV2.common.exception.ExceptionUtil;
import com.lenovo.m2.couponV2.dao.mybatis.model.MemberExcelTemp;
import com.lenovo.m2.couponV2.dao.util.ResponseResult;
import com.lenovo.m2.couponV2.manager.MemberExcelTempManager;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lenovo.m2.couponV2.api.dubboModel.MemberExcelTempApi;

import java.util.*;

/**
 * Created by yuzn1 on 2016/5/17.
 */


@Service("memberExcelTempService")
public class MemberExcelTempServiceImpl implements MemberExcelTempService {
    private static final Logger log = LoggerFactory.getLogger(MemberExcelTempServiceImpl.class);

    @Autowired
    private MemberExcelTempManager memberExcelTempManager;

    @Override
    public RemoteResult insertBatch(List<MemberExcelTempApi> list,String itCode) {
        log.info("导入excel用户信息去重前长度" + list);
        removeMembercouponrelsApi(list);
        log.info("导入excel用户信息去重后长度" + list);
        RemoteResult result = new RemoteResult(false);
        try {
            if(list != null && list.size() > 0){
                List<MemberExcelTemp> memberExcelTempsList = new ArrayList<MemberExcelTemp>();
                MemberExcelTemp memberExcelTemp = null;
                for(MemberExcelTempApi api : list){
                    memberExcelTemp = new MemberExcelTemp();
                    new DomainUtil().copy(api, memberExcelTemp);
                    memberExcelTempsList.add(memberExcelTemp);
                }
                //导入excel用户信息
                ResponseResult res = memberExcelTempManager.insertBatch(memberExcelTempsList);
                if(res.isSuccess()){
                    // 查出重复数据
                    List<MemberExcelTemp> memTempList = memberExcelTempManager.selectIsRepeat(itCode);
                    if(memTempList.size()==0){
                        log.info("导入excel用户信息没有重复数据");
                    }else if(memTempList.size()>0){
                        log.info("导入excel用户信息有重复数据");
                        Map<String, Object> map = new HashMap<String, Object>();
                        map.put("list",memTempList);
                        map.put("itCode",itCode);
                        //对重复数据状态赋值为1
                        int size = memberExcelTempManager.updateIsRepeatd(map);
                        if(size>0){
                            result.setResultMsg(CouponConstant.RESULT_MSG_SUC);
                            result.setResultCode(CouponConstant.RESULT_CODE_SUC);
                            log.info("导入excel用户数据更新完成");
                        }else {
                            log.info("导入excel用户数据更新失败");
                        }
                    }else{
                        log.info("导入excel用户信息时更改重复数据失败");
                    }
                    result.setResultMsg(CouponConstant.RESULT_MSG_SUC);
                    result.setResultCode(CouponConstant.RESULT_CODE_SUC);
                    log.info("导入excel用户信息保存数据成功");
                    result.setSuccess(true);
                }


            }else {
                log.info("导入excel用户信息保存数据失败");
                result.setResultMsg(CouponConstant.RESULT_MSG_ERROR_PARAM);
                result.setResultCode(CouponConstant.RESULT_CODE_ERROR_PARAM);
            }

        } catch (Exception e) {
            log.error("insertBatch保存信息失败", ExceptionUtil.getStackTrace(e));
        }

        return result;
    }

    //去除MemberExcelTempApi重复数据
    private static void  removeMembercouponrelsApi(List<MemberExcelTempApi> list)   {
        HashSet h  =   new HashSet(list);
        list.clear();
        list.addAll(h);

    }

    /**
     * 查询导入excel信息
     */
    @Override
    public RemoteResult<PageModel2<MemberExcelTempApi>> getMemberExcelTempPage(PageQuery pageQuery, Map map){
        RemoteResult result = new RemoteResult(false);
        try {

            PageModel2<MemberExcelTemp> rs = memberExcelTempManager.getMemberExcelTempPage(pageQuery, map);
            List<MemberExcelTempApi> memberExcelTempApiList = new ArrayList<MemberExcelTempApi>();
            if(null != rs && null !=rs.getDatas() && rs.getDatas().size() > 0 ){
                for (MemberExcelTemp memberExcelTemp:rs.getDatas()){
                    MemberExcelTempApi memberExcelTempApi = new MemberExcelTempApi();
                    new DomainUtil().copy(memberExcelTemp, memberExcelTempApi);
                    memberExcelTempApiList.add(memberExcelTempApi);
                }
            }

            PageModel2<MemberExcelTempApi> pageModel=new PageModel2<MemberExcelTempApi>(pageQuery,memberExcelTempApiList);
            result.setResultMsg(CouponConstant.RESULT_MSG_SUC);
            result.setResultCode(CouponConstant.RESULT_CODE_SUC);
            result.setT(pageModel);
            log.info("查询数据成功");
            result.setSuccess(true);
        } catch (Exception e) {
            log.error("查询失败", ExceptionUtil.getStackTrace(e));
        }
        return result;
    }

    @Override
    public RemoteResult<MemberExcelTempApi> getIsRepeat(String itCode){
        RemoteResult result = new RemoteResult(false);
        try {
            ResponseResult responseResult = memberExcelTempManager.getIsRepeat(itCode);
            if (responseResult.getData() !=null && responseResult.isSuccess()){
                List<MemberExcelTemp> list = (List<MemberExcelTemp>) responseResult.getData();
                List<MemberExcelTempApi> listapi = new ArrayList<MemberExcelTempApi>();
                MemberExcelTempApi memberExcelTempApi = null;
                for (MemberExcelTemp memberExcelTemp:list){
                    memberExcelTempApi = new MemberExcelTempApi();
                    new DomainUtil().copy(memberExcelTemp,memberExcelTempApi);
                    listapi.add(memberExcelTempApi);
                }
                result.setSuccess(true);
                result.setT(listapi);
                result.setResultCode(CouponConstant.RESULT_CODE_SUC);
                result.setResultMsg(CouponConstant.RESULT_MSG_SUC);
                log.info("获取重复数据成功");
                return result;
            }
        }catch (Exception e) {
            log.error("获取重复数据失败", ExceptionUtil.getStackTrace(e));
        }
        return result;

    }

    @Override
    public RemoteResult<MemberExcelTempApi> getValidList(String itCode){
        RemoteResult result = new RemoteResult(false);
        try{
            ResponseResult responseResult = memberExcelTempManager.getValidList(itCode);
            if (responseResult.getData() !=null && responseResult.isSuccess()){
                List<MemberExcelTemp> list = (List<MemberExcelTemp>) responseResult.getData();
                List<MemberExcelTempApi> listapi = new ArrayList<MemberExcelTempApi>();
                MemberExcelTempApi memberExcelTempApi = null;
                for (MemberExcelTemp memberExcelTemp:list){
                    memberExcelTempApi = new MemberExcelTempApi();
                    new DomainUtil().copy(memberExcelTemp,memberExcelTempApi);
                    listapi.add(memberExcelTempApi);
                }
                result.setSuccess(true);
                result.setT(listapi);
                result.setResultCode(CouponConstant.RESULT_CODE_SUC);
                result.setResultMsg(CouponConstant.RESULT_MSG_SUC);
                log.info("获取有效数据成功");
                return result;
            }
        }catch (Exception e) {
            log.error("获取有效数据失败", ExceptionUtil.getStackTrace(e));
        }
        return result;

    }

    @Override
    public RemoteResult toDelete_exMember(Map map){
        RemoteResult result = new RemoteResult(false);
        try {
            ResponseResult responseResult = memberExcelTempManager.toDelete_exMember(map);
            if (responseResult.isSuccess()){
                result.setSuccess(true);
                result.setResultCode(CouponConstant.RESULT_CODE_SUC);
                result.setResultMsg(CouponConstant.RESULT_MSG_SUC);
                log.info("删除导入excel用户成功");
                return result;
            }else {
                result.setSuccess(false);
                result.setResultCode(CouponConstant.RESULT_CODE_FAIL);
                result.setResultMsg(CouponConstant.RESULT_MSG_FAIL);
                log.info("删除导入excel用户失败");
                return result;
            }
        }catch (Exception e) {
            log.error("删除导入excel用户失败", ExceptionUtil.getStackTrace(e));
        }
        return result;
    }

    @Override
    public RemoteResult deleteAll(String itCode) {
        RemoteResult result = new RemoteResult(false);
        try{
            ResponseResult responseResult = memberExcelTempManager.deleteAll(itCode);
            if (responseResult.isSuccess()){
                result.setSuccess(true);
                result.setResultCode(CouponConstant.RESULT_CODE_SUC);
                result.setResultMsg(CouponConstant.RESULT_MSG_SUC);
                log.info("========"+itCode+"清除memberExcelTemp表中成功");
                return result;
            }else {
                result.setSuccess(false);
                result.setResultCode(CouponConstant.RESULT_CODE_FAIL);
                result.setResultMsg(CouponConstant.RESULT_MSG_FAIL);
                log.info("========"+itCode+"清除memberExcelTemp表失败");
                return result;
            }
        }catch (Exception e) {
            log.error("========" + itCode + "清除memberExcelTemp表异常" + ExceptionUtil.getStackTrace(e));
        }
        return result;
    }


}
