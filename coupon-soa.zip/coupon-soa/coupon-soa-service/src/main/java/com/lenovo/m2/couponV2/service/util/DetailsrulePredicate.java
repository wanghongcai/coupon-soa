package com.lenovo.m2.couponV2.service.util;

import com.google.common.base.Predicate;
import com.lenovo.m2.couponV2.dao.mybatis.model.Detailsrule;

/**
 * Created by zhaocl1 on 2016/4/20.
 */
public class DetailsrulePredicate implements Predicate<Detailsrule>{

    private Long salescouponid;

    public DetailsrulePredicate(Long salescouponid) {
        this.salescouponid = salescouponid;
    }

    @Override
    public boolean apply(Detailsrule detailsrule) {
        if(detailsrule.getSalescouponid().equals(salescouponid)){
            return true;
        }
        return false;
    }
}
