package com.lenovo.m2.couponV2.service.impl;

import com.google.common.base.Predicate;
import com.google.common.base.Predicates;
import com.google.common.collect.FluentIterable;
import com.lenovo.m2.arch.framework.domain.Money;
import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.framework.domain.Tenant;
import com.lenovo.m2.arch.tool.util.CollectionUtils;
import com.lenovo.m2.arch.tool.util.StringUtils;
import com.lenovo.m2.couponV2.api.OldforNewModel.SendCouponOldforNewOrderVo;
import com.lenovo.m2.couponV2.api.dubboModel.*;
import com.lenovo.m2.couponV2.api.dubboService.RpcMemberCounponrelsService;
import com.lenovo.m2.couponV2.api.service.MemberCounponrelsService;
import com.lenovo.m2.couponV2.common.*;
import com.lenovo.m2.couponV2.common.enums.ErrorMessageEnum;
import com.lenovo.m2.couponV2.common.enums.ModulNameEnum;
import com.lenovo.m2.couponV2.common.exception.ExceptionUtil;
import com.lenovo.m2.couponV2.common.util.JsonUtil;
import com.lenovo.m2.couponV2.common.vo.LogVo;
import com.lenovo.m2.couponV2.dao.mybatis.model.*;
import com.lenovo.m2.couponV2.dao.util.ResponseResult;
import com.lenovo.m2.couponV2.manager.*;
import com.lenovo.m2.couponV2.manager.redisObject.RedisObjectManager;
import com.lenovo.m2.couponV2.manager.redisObject.lock.RedisLock;
import com.lenovo.m2.couponV2.remote.IDSequenceService;
import com.lenovo.m2.couponV2.service.util.DetailsrulePredicate;
import com.lenovo.m2.couponV2.service.util.DistributorrulePredicate;
import com.lenovo.m2.couponV2.service.util.StringUtil;
import net.sf.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Created by zhaocl1 on 2016/3/3.
 */
@Service("rpcMemberCounponrelsService")
public class RpcMemberCounponrelsServiceImpl implements RpcMemberCounponrelsService {
    private static final Logger log = LoggerFactory.getLogger(RpcMemberCounponrelsServiceImpl.class);
    @Autowired
    private MemberCouponrelsManager memberCouponrelsManager;
    @Autowired
    private DetailsruleManager detailsruleManager;
    @Autowired
    private RedisObjectManager redisObjectManager;
    @Autowired
    private DistributorruleManager distributorruleManager;
    @Autowired
    private ProductruleManager productruleManager;
    @Autowired
    private MembercouponrelsLogManager membercouponrelsLogManager;
    @Autowired
    private CouponsManager couponsManager;
    @Autowired
    private CouponsLogManager couponsLogManager;
    @Autowired
    private SalescouponsManager salescouponsManager;
    @Autowired
    private MemberCounponrelsService memberCounponrelsService;
    @Autowired
    private SendcouponrecordManager sendcouponrecordManager;
    @Autowired
    private OldfornewcouponManager oldfornewcouponManager;
    @Autowired
    private LogService logService;
    @Autowired
    private IDSequenceService idSequenceService;
    /**
     * 获取商品对应的优惠券
     * @param userApi
     * @param list
     * @param shopId
     * @param terminal
     * @return
     */
    public RemoteResult getSalescouponsWithProduct_v1(UserApi userApi, List<ProductInfoApi> list, String shopId, String terminal) {
        log.info("getSalescouponsWithProduct 参数："+userApi+","+list+",shopId=["+shopId+"] terminal=["+terminal+"] ");
        long time1 = new Date().getTime();
        RemoteResult result = new RemoteResult(false);
        try {
            if(userApi == null || hasBlankParameter(userApi.getLenovoid(), userApi.getGroupCode(), userApi.getUsername(), shopId, terminal) || CollectionUtils.isEmpty(list)){
                log.info("getCouponsWithProduct ： 参数错误！");
                result.setResultCode(CouponConstant.RESULT_CODE_ERROR_PARAM);
                result.setResultMsg(CouponConstant.RESULT_MSG_ERROR_PARAM);
                log.info("getCouponsWithProduct 结果：" + result);
                return result;
            }

            /**
             * 查询之前先帮全员券
             */
            if(!"14".equals(shopId) && !"15".equals(shopId)) {
                long time_bindAllMember_start = new Date().getTime();
                memberCounponrelsService.bindAllMemberSalesCoupons(userApi.getLenovoid(), userApi.getUsername(), userApi.getGroupCode(), shopId);
                long time_bindAllMember_end = new Date().getTime();
                log.info("getCouponsWithProduct 绑全员券方法耗时：" + (time_bindAllMember_end - time_bindAllMember_start) + "毫秒");
            }

            long time_getMembercouponrelsList_start = new Date().getTime();
            ResponseResult<List<Membercouponrels>> res = memberCouponrelsManager.getMemberEffectiveCoupons(userApi.getLenovoid(), shopId, terminal);
            long time_getMembercouponrelsList_end = new Date().getTime();
            log.info("getCouponsWithProduct 查询用户的优惠券数据耗时："+(time_getMembercouponrelsList_end - time_getMembercouponrelsList_start)+"毫秒");
            if(res.isSuccess() && res.getData() != null ){
                List<Membercouponrels> list_mc = res.getData();
                log.info("getSalescouponsWithProduct 用户的券为"+(list_mc != null ? list_mc.size() : null));
                if(list_mc.size() == 0){
                    log.info("getSalescouponsWithProduct 用户["+userApi+"]在商城["+shopId+"] 平台["+terminal+"]上没有有效的优惠券！");
                    result.setResultCode("10");
                    result.setResultMsg("用户["+userApi.getLenovoid()+"]在商城["+shopId+"] 平台["+terminal+"]上没有有效的优惠券！");
                    result.setSuccess(true);
                    log.info("getSalescouponsWithProduct 结果："+result);
                    return result;
                }

                /**
                 * 处理用户优惠券数据
                 */


                List<SalescouponsJsonApi> salescouponJsonApiList = new ArrayList<SalescouponsJsonApi>();
                SalescouponsJsonApi salescouponJsonApi = null;
                for(ProductInfoApi p : list){
                    salescouponJsonApi = new SalescouponsJsonApi();
                    salescouponJsonApi.setCode(p.getGoodscode());
                    List<SalescouponsInfoApi> list_s_InfoApi = new ArrayList<SalescouponsInfoApi>();
                    SalescouponsInfoApi salescouponsInfoApi = null;
                    for(Membercouponrels m : list_mc){

                        if(String.valueOf(ShopIdEnum.EPP.getType()).equals(shopId) ){
                            if(StringUtils.isEmpty(m.getEppgroup())){
                                log.info("getSalescouponsWithProduct 商城["+shopId+"] 的用户组为空");
                                result.setResultCode("11");
                                result.setResultMsg("epp商城的用户组不能为空！");
                                result.setSuccess(false);
                                log.info("getSalescouponsWithProduct 结果："+result);
                                return result;
                            }
                            if(!m.getEppgroup().contains(userApi.getGroupCode())){
                                continue;
                            }
                            //-todo  epp组的包含问题
                        }
                        if(CouponConstant.COUPON_PRODUCT_TYPE_C2C == p.getType()){
                            //c2c逻辑  查询c2c + 普通券
                            if(m.getUsescope() == CouponConstant.COUPON_USESCOPE_C2C ){
                                //商品券
                                doProductrule(p, list_s_InfoApi, m);
                            }

                            if(m.getUsescope() == CouponConstant.COUPON_USESCOPE_ZHEKOU){
                                //商品券
                                doProductrule(p, list_s_InfoApi, m);

                                //分类券
                                if(CouponConstant.COUPON_TYPE_DETAIL_1 == m.getType()){
                                    Detailsrule detailsrule = new Detailsrule();
                                    detailsrule.setSalescouponid(m.getSalescouponid());
                                    ResponseResult<List<Detailsrule>> res_d = detailsruleManager.getDetailsruleList(detailsrule);
                                    if(res_d.isSuccess() && res_d.getData() != null){
                                        List<Detailsrule> list_d = res_d.getData();
                                        for(Detailsrule d : list_d){
                                            //如果该商品在分类的排除商品中，则该券不匹配该商品
                                            if(d.getNojoincodes() != null && d.getNojoincodes().contains(p.getGoodscode())){
                                                break;
                                            }
                                            //如果分类能匹配，则该券匹配该商品
                                            if(p.getCategorycode().equals(d.getGoodscategoryid())){
//                                            salescouponJsonApi.setCode(p.getGoodscode());
                                                salescouponsInfoApi = new SalescouponsInfoApi();
                                                salescouponsInfoApi.setId(m.getId());
                                                salescouponsInfoApi.setSalesCouponId(m.getSalescouponid());
                                                salescouponsInfoApi.setAmount(m.getAmount());
                                                salescouponsInfoApi.setClassification(m.getClassification());
                                                salescouponsInfoApi.setConditions(m.getConditions());
                                                salescouponsInfoApi.setFromtime(m.getFromtime());
                                                salescouponsInfoApi.setTotime(m.getTotime());
                                                salescouponsInfoApi.setShopid(m.getShopid());
                                                salescouponsInfoApi.setTerminal(m.getTerminal());
                                                salescouponsInfoApi.setSuperposition(m.getSuperposition());
                                                salescouponsInfoApi.setType(m.getType());
                                                salescouponsInfoApi.setUsescope(m.getUsescope());
                                                salescouponsInfoApi.setName(m.getName());
                                                salescouponsInfoApi.setDescription(m.getDescription());
                                                list_s_InfoApi.add(salescouponsInfoApi);
                                                break;
                                            }
                                        }
                                    }else {
                                        log.info("getSalescouponsWithProduct 优惠券["+m.getSalescouponid()+"]用户优惠券["+m.getId()+"]为分类券["+m.getType()+"] 通过["+m.getSalescouponid()+"]没有查到分类信息！"+m);
                                    }
                                }else if(CouponConstant.COUPON_TYPE_PRODUCT_2 == m.getType()){
                                    //商品券
                                    doProductrule(p, list_s_InfoApi, m);
                                }else {
                                    log.info("getSalescouponsWithProduct 优惠券不存在这个绑定规则 type="+m.getType());
                                }
                            }
                        }else if(CouponConstant.COUPON_PRODUCT_TYPE_YIJIUHUANXIN == p.getType()){
                            //依旧换新逻辑  查询依旧换新券
                            if(m.getUsescope() == CouponConstant.COUPON_USESCOPE_YIJIUHUANXIN || m.getUsescope() == CouponConstant.COUPON_USESCOPE_YIJIUHUANXINDAIJINQUAN){
                                //商品券
                                doProductruleForOldNew(p, list_s_InfoApi, m);
                            }
                        }else if(CouponConstant.COUPON_PRODUCT_TYPE_PUTONG == p.getType()){
                            //非普通券 不做匹配
                            if(m.getUsescope() != CouponConstant.COUPON_USESCOPE_ZHEKOU){
                                continue;
                            }
                            //分类券
                            if(CouponConstant.COUPON_TYPE_DETAIL_1 == m.getType()){
                                Detailsrule detailsrule = new Detailsrule();
                                detailsrule.setSalescouponid(m.getSalescouponid());
                                ResponseResult<List<Detailsrule>> res_d = detailsruleManager.getDetailsruleList(detailsrule);
                                if(res_d.isSuccess() && res_d.getData() != null){
                                    List<Detailsrule> list_d = res_d.getData();
                                    for(Detailsrule d : list_d){
                                        //如果该商品在分类的排除商品中，则该券不匹配该商品
                                        if(d.getNojoincodes() != null && d.getNojoincodes().contains(p.getGoodscode())){
                                            break;
                                        }
                                        //如果分类能匹配，则该券匹配该商品
                                        if(p.getCategorycode().equals(d.getGoodscategoryid())){
//                                            salescouponJsonApi.setCode(p.getGoodscode());
                                            salescouponsInfoApi = new SalescouponsInfoApi();
                                            salescouponsInfoApi.setId(m.getId());
                                            salescouponsInfoApi.setSalesCouponId(m.getSalescouponid());
                                            salescouponsInfoApi.setAmount(m.getAmount());
                                            salescouponsInfoApi.setClassification(m.getClassification());
                                            salescouponsInfoApi.setConditions(m.getConditions());
                                            salescouponsInfoApi.setFromtime(m.getFromtime());
                                            salescouponsInfoApi.setTotime(m.getTotime());
                                            salescouponsInfoApi.setShopid(m.getShopid());
                                            salescouponsInfoApi.setTerminal(m.getTerminal());
                                            salescouponsInfoApi.setSuperposition(m.getSuperposition());
                                            salescouponsInfoApi.setType(m.getType());
                                            salescouponsInfoApi.setUsescope(m.getUsescope());
                                            salescouponsInfoApi.setName(m.getName());
                                            salescouponsInfoApi.setDescription(m.getDescription());
                                            list_s_InfoApi.add(salescouponsInfoApi);
                                            break;
                                        }
                                    }
                                }else {
                                    log.info("getSalescouponsWithProduct 优惠券["+m.getSalescouponid()+"]用户优惠券["+m.getId()+"]为分类券["+m.getType()+"] 通过["+m.getSalescouponid()+"]没有查到分类信息！"+m);
                                }
                            }else if(CouponConstant.COUPON_TYPE_PRODUCT_2 == m.getType()){
                                //商品券
                                doProductrule(p, list_s_InfoApi, m);
                            }else {
                                log.info("getSalescouponsWithProduct 优惠券不存在这个绑定规则 type="+m.getType());
                            }
                        }else {
                            log.info("getSalescouponsWithProduct 商品类型暂时没有这个类型 type="+p.getType());
                        }


                    }
                    /**
                     * 商品如果没有适合的优惠券则不返回数据
                     */
                    if(CollectionUtils.isNotEmpty(list_s_InfoApi)){
                        salescouponJsonApi.setList(list_s_InfoApi);
                        salescouponJsonApiList.add(salescouponJsonApi);
                    }
                }
//                String json = JacksonMapper.obj2json(salescouponJsonApiList);
                result.setResultCode(CouponConstant.RESULT_CODE_SUC);
                result.setResultMsg(CouponConstant.RESULT_MSG_SUC);
                result.setT(salescouponJsonApiList);
                result.setSuccess(true);
                log.info("getSalescouponsWithProduct 结果："+result);
            }
        } catch (Exception e) {
            log.error("getSalescouponsWithProduct 异常：" + ExceptionUtil.getStackTrace(e));
            result.setResultCode(CouponConstant.RESULT_CODE_ERROR);
            result.setResultMsg(CouponConstant.RESULT_MSG_ERROR);
            result.setSuccess(false);
            return result;
        }
        long time2 = new Date().getTime();
        log.info("getSalescouponsWithProduct 方法总耗时 "+(time2 - time1)+"毫秒");
        return result;
    }

    @Override
    public RemoteResult getSalescouponsWithProduct(Tenant tenant, UserApi userApi, List<ProductInfoApi> productList, String terminal) {

        return this.getSalescouponsWithProduct(userApi, productList, String.valueOf(tenant.getShopId()), terminal);
    }

    /**
     * 购物车提交到结算页时调用
     * 根据购物车中的商品和登录人信息找到该用户下购买这些商品所有可用的优惠券
     * @param userApi
     * @param productList
     * @param shopId
     * @param terminal
     * @return
     */
    @Override
    public RemoteResult getSalescouponsWithProduct(UserApi userApi, List<ProductInfoApi> productList, String shopId, String terminal) {
        log.info("getSalescouponsWithProduct 参数："+userApi+","+productList+",shopId=["+shopId+"] terminal=["+terminal+"] ");
        long startTime = System.currentTimeMillis();
        RemoteResult result = new RemoteResult(false);
        try {
            if(userApi == null || StringUtil.isEmpty(userApi.getLenovoid()) || StringUtil.isEmpty(userApi.getGroupCode()) || StringUtil.isEmpty(userApi.getUsername()) || StringUtil.isEmpty(shopId) || StringUtil.isEmpty(terminal) || CollectionUtils.isEmpty(productList)){
                result.setResultCode(CouponConstant.RESULT_CODE_ERROR_PARAM);
                result.setResultMsg(CouponConstant.RESULT_MSG_ERROR_PARAM);
                log.info("getSalescouponsWithProduct 结果：" + result);
                return result;
            }

            // 查看有无全员券可发，如果有先将全员券发放到用户名下, 惠商不发全员券
            if(!"14".equals(shopId) && !"15".equals(shopId)) {
                long bindStartTime = System.currentTimeMillis();
                memberCounponrelsService.bindAllMemberSalesCoupons(userApi.getLenovoid(), userApi.getUsername(), userApi.getGroupCode(), shopId);
                log.info("getSalescouponsWithProduct 绑全员券耗时：========" + (System.currentTimeMillis() - bindStartTime) + "毫秒");
            }

            // 获取用户名下所有有效的优惠券
            long getUserCouponsStartTime = System.currentTimeMillis();
            ResponseResult<List<Membercouponrels>> res = memberCouponrelsManager.getMemberEffectiveCoupons(userApi.getLenovoid(), shopId, terminal);
            log.info("getSalescouponsWithProduct 查询用户优惠券耗时：========="+(System.currentTimeMillis() - getUserCouponsStartTime)+"毫秒");

            if(res.isSuccess() && res.getData() != null ){
                List<Membercouponrels> memberCouponList = res.getData();
                if(memberCouponList.size() == 0){
                    log.info("getSalescouponsWithProduct 用户["+userApi+"]在商城["+shopId+"] 平台["+terminal+"]上没有有效的优惠券！");
                    result.setResultCode("10");
                    result.setResultMsg("用户["+userApi.getLenovoid()+"]在商城["+shopId+"] 平台["+terminal+"]上没有有效的优惠券！");
                    result.setSuccess(true);
                    log.info("getSalescouponsWithProduct 结果："+result);
                    return result;
                }

                /**
                 * 获取用户所有的优惠券后，判别那些优惠可用
                 */
                Map<Object,Object> productMap = new HashMap<Object, Object>();
                Map<Object,Object> detailMap = new HashMap<Object, Object>();

                // 将用户名下有效的优惠券根据绑定规则分组，将绑分类和绑商品的分别放入detailMap和productMap
                long divideStartTime = new Date().getTime();
                getBatchData(memberCouponList, productMap, detailMap);
                log.info("getSalescouponsWithProduct 根据绑定规则将优惠券分类耗时："+(System.currentTimeMillis() - divideStartTime)+"毫秒");

                List<SalescouponsJsonApi> salescouponJsonApiList = new ArrayList<SalescouponsJsonApi>();
                SalescouponsJsonApi salescouponJsonApi = null;
                // 遍历购物车的商品，找出购买这些商品可用的优惠券
                for(ProductInfoApi p : productList){
                    salescouponJsonApi = new SalescouponsJsonApi();
                    salescouponJsonApi.setCode(p.getGoodscode());
                    List<SalescouponsInfoApi> list_s_InfoApi = new ArrayList<SalescouponsInfoApi>();
                    SalescouponsInfoApi salescouponsInfoApi = null;
                    for(Membercouponrels m : memberCouponList){
                        // 如果是Epp的订单，首先检查优惠券可用的Epp组和用户所在的组是否匹配，如果不匹配则该优惠券不可用
                        if(String.valueOf(ShopIdEnum.EPP.getType()).equals(shopId) ){
                            if(StringUtils.isEmpty(m.getEppgroup())){
                                log.info("getSalescouponsWithProduct 商城["+shopId+"] 的用户组为空");
                                result.setResultCode("11");
                                result.setResultMsg("epp商城的用户组不能为空！");
                                result.setSuccess(false);
                                log.info("getSalescouponsWithProduct 结果："+result);
                                return result;
                            }
                            if(!m.getEppgroup().contains(userApi.getGroupCode())){
                                continue;
                            }
                            //-todo  epp组的包含问题
                        }

                        if(CouponConstant.COUPON_PRODUCT_TYPE_C2C == p.getType()){
                            // 如果是C2C的商品，只判断C2C券和普通券
                            if(m.getUsescope() == CouponConstant.COUPON_USESCOPE_C2C || m.getUsescope() == CouponConstant.COUPON_USESCOPE_ZHEKOU){
                                if(CouponConstant.COUPON_TYPE_PRODUCT_2 == m.getType()){
                                    checkByProductRule(productMap, p, list_s_InfoApi, m);
                                }else if (CouponConstant.COUPON_TYPE_DETAIL_1 == m.getType()){
                                    checkByCategoryRule(detailMap, p, list_s_InfoApi, m);
                                }else {
                                    log.info(String.format("优惠券[%s]不可用", m.getSalescouponid()));
                                }
                            }
                        }else if (CouponConstant.COUPON_PRODUCT_TYPE_YIJIUHUANXIN == p.getType()){
                            //依旧换新逻辑  查询依旧换新券
                            if(m.getUsescope() == CouponConstant.COUPON_USESCOPE_YIJIUHUANXIN || m.getUsescope() == CouponConstant.COUPON_USESCOPE_YIJIUHUANXINDAIJINQUAN){
                                // 依旧换新的优惠券和依旧换新的代金券 均可用
                                doProductruleForOldNew(p, list_s_InfoApi, m);
                            }
                            if(m.getUsescope() == CouponConstant.COUPON_USESCOPE_ZHEKOU){
                                if(CouponConstant.COUPON_TYPE_PRODUCT_2 == m.getType()){
                                    checkByProductRule(productMap, p, list_s_InfoApi, m);
                                }else if (CouponConstant.COUPON_TYPE_DETAIL_1 == m.getType()){
                                    checkByCategoryRule(detailMap, p, list_s_InfoApi, m);
                                }else {
                                    log.info(String.format("优惠券[%s]不可用", m.getSalescouponid()));
                                }
                            }
                        }else if(CouponConstant.COUPON_PRODUCT_TYPE_PUTONG == p.getType()){
                            // 普通订单 只考虑普通券
                            if(m.getUsescope() != CouponConstant.COUPON_USESCOPE_ZHEKOU && m.getUsescope() != CouponConstant.COUPON_USESCOPE_ITPLACE){
                                continue;
                            }
                            if(CouponConstant.COUPON_TYPE_PRODUCT_2 == m.getType()){
                                checkByProductRule(productMap, p, list_s_InfoApi, m);
                            }else if (CouponConstant.COUPON_TYPE_DETAIL_1 == m.getType()){
                                checkByCategoryRule(detailMap, p, list_s_InfoApi, m);
                            }else if(ShopIdEnum.HS.getType()== Integer.parseInt(shopId) && CouponConstant.COUPON_TYPE_PRODUCTGROUP_3 == m.getType()){
                                checkByProductGrouprule(userApi, detailMap, p, list_s_InfoApi, m);
                            }else {
                                log.info(String.format("优惠券[%s]不可用", m.getSalescouponid()));
                            }
                        }else {
                            log.info("getSalescouponsWithProduct 商品类型暂时没有这个类型 type=" + p.getType());
                        }
                    }
                    /**
                     * 商品如果没有适合的优惠券则不返回数据
                     */
                    log.info("list_s_InfoApi"+JacksonMapper.obj2json(list_s_InfoApi));
                    if(CollectionUtils.isNotEmpty(list_s_InfoApi)){
                        salescouponJsonApi.setList(list_s_InfoApi);
                        salescouponJsonApiList.add(salescouponJsonApi);
                    }
                }
                // 只允许使用一张金额最大的C2C券，普通券没有限制
                List<SalescouponsJsonApi> finalList = new ArrayList<SalescouponsJsonApi>();
                SalescouponsInfoApi c2cSalescoupon = null;
                Map<String, String> goodsCodeMap = new HashMap<String, String>();
                if(CollectionUtils.isNotEmpty(salescouponJsonApiList)){
                    for(SalescouponsJsonApi salescouponsJsonApi : salescouponJsonApiList){
                        List<SalescouponsInfoApi> salescouponsInfoApiList = salescouponsJsonApi.getList();
                        List<SalescouponsInfoApi> adjustCouponList = new ArrayList<SalescouponsInfoApi>();
                        String goodsCode = salescouponsJsonApi.getCode();
                        for(SalescouponsInfoApi salescouponsInfoApi : salescouponsInfoApiList){
                            if(salescouponsInfoApi.getUsescope() != CouponConstant.COUPON_USESCOPE_C2C){
                                adjustCouponList.add(salescouponsInfoApi);
                                continue;
                            }
                            if(c2cSalescoupon == null){
                                c2cSalescoupon = salescouponsInfoApi;
                                goodsCodeMap.put(goodsCode, goodsCode);
                            }else {
                                Money targetAmount = c2cSalescoupon.getAmount();
                                Money currentAmount = salescouponsInfoApi.getAmount();
                                if(currentAmount.compareTo(targetAmount) == 1){
                                    c2cSalescoupon = salescouponsInfoApi;
                                    goodsCodeMap.clear();
                                    goodsCodeMap.put(goodsCode, goodsCode);
                                }else if(currentAmount.compareTo(targetAmount) == 0){
                                    if(c2cSalescoupon.getSalesCouponId() == salescouponsInfoApi.getSalesCouponId()){
                                        goodsCodeMap.put(goodsCode, goodsCode);
                                    }
                                }
                            }
                        }
                        salescouponsJsonApi.setList(adjustCouponList);
                        finalList.add(salescouponsJsonApi);
                    }
                }
                if(CollectionUtils.isNotEmpty(finalList) && c2cSalescoupon != null){
                    for(SalescouponsJsonApi salescouponsJsonApi : finalList) {
                        if(goodsCodeMap.containsKey(salescouponsJsonApi.getCode())) {
                            List<SalescouponsInfoApi> salescouponsInfoApiList = salescouponsJsonApi.getList();
                            if (CollectionUtils.isNotEmpty(salescouponsInfoApiList)) {
                                salescouponsInfoApiList.add(c2cSalescoupon);
                            } else {
                                List<SalescouponsInfoApi> couponList = new ArrayList<SalescouponsInfoApi>();
                                couponList.add(c2cSalescoupon);
                                salescouponsJsonApi.setList(couponList);
                            }
                        }
                    }
                }

//                String json = JacksonMapper.obj2json(salescouponJsonApiList);
                result.setResultCode(CouponConstant.RESULT_CODE_SUC);
                result.setResultMsg(CouponConstant.RESULT_MSG_SUC);
                result.setT(finalList);
                result.setSuccess(true);
                log.info("getSalescouponsWithProduct 结果："+result);
            }
        } catch (Exception e) {
            log.error("getSalescouponsWithProduct 异常：" + ExceptionUtil.getStackTrace(e));
            result.setResultCode(CouponConstant.RESULT_CODE_ERROR);
            result.setResultMsg(CouponConstant.RESULT_MSG_ERROR);
            result.setSuccess(false);
            log.error("getSalescouponsWithProduct 结果：" + result);
            return result;
        }
        log.info("getSalescouponsWithProduct 方法总耗时 ============ "+(System.currentTimeMillis() - startTime)+"毫秒");
        return result;
    }

    /**
     * 根据绑定分类规则校验用户名下的优惠券(m)是否可用，如果可用将该优惠券包装成需要的对象
     * 并放入可用优惠券列表中
     * @param detailMap
     * @param p
     * @param list_s_InfoApi
     * @param m
     */
    private void checkByCategoryRule(Map<Object, Object> detailMap, ProductInfoApi p, List<SalescouponsInfoApi> list_s_InfoApi, Membercouponrels m) {
        SalescouponsInfoApi salescouponsInfoApi = null;
        if(detailMap == null || detailMap.size() == 0){
            return;
        }
        Iterable<Detailsrule> detailsruleIterable = (Iterable<Detailsrule>)detailMap.get(m.getSalescouponid());
        for(Detailsrule d : detailsruleIterable){
            //如果该商品在分类的排除商品中，则该券不匹配该商品
            if(d.getNojoincodes() != null && d.getNojoincodes().contains(p.getGoodscode())){
                break;
            }
            //如果分类能匹配，则该券匹配该商品
            if(null != p.getCategorycode() && p.getCategorycode().equals(d.getGoodscategoryid())){
                salescouponsInfoApi = new SalescouponsInfoApi();
                salescouponsInfoApi.setId(m.getId());
                salescouponsInfoApi.setSalesCouponId(m.getSalescouponid());
                salescouponsInfoApi.setAmount(m.getAmount());
                salescouponsInfoApi.setClassification(m.getClassification());
                salescouponsInfoApi.setConditions(m.getConditions());
                salescouponsInfoApi.setFromtime(m.getFromtime());
                salescouponsInfoApi.setTotime(m.getTotime());
                salescouponsInfoApi.setShopid(m.getShopid());
                salescouponsInfoApi.setTerminal(m.getTerminal());
                salescouponsInfoApi.setSuperposition(m.getSuperposition());
                salescouponsInfoApi.setType(m.getType());
                salescouponsInfoApi.setUsescope(m.getUsescope());
                salescouponsInfoApi.setName(m.getName());
                salescouponsInfoApi.setDescription(m.getDescription());
                list_s_InfoApi.add(salescouponsInfoApi);
                break;
            }
        }
    }

    /**
     * 根据绑定产品组规则校验用户名下的优惠券(m)是否可用，如果可用将该优惠券包装成需要的对象
     * 并放入可用优惠券列表中
     * @param detailMap
     * @param p
     * @param list_s_InfoApi
     * @param m
     */
    private void checkByProductGrouprule(UserApi userApi,Map<Object, Object> detailMap, ProductInfoApi p, List<SalescouponsInfoApi> list_s_InfoApi, Membercouponrels m) {
        //验证经销商与商品的签约关系

       /* boolean filterProduct = ProductRedis.filterProduct(Integer.parseInt(p.getGoodscode()), userApi.getLenovoid());
        if(!filterProduct){
            log.info("checkByProductGrouprule 该用户无权限购买此商品"+userApi.getLenovoid()+p.getGoodscode());
            return;
        }*/

        SalescouponsInfoApi salescouponsInfoApi = null;
        if(detailMap == null || detailMap.size() == 0){
            return;
        }
        Iterable<Distributorrule> distributorruleIterable = (Iterable<Distributorrule>)detailMap.get(m.getSalescouponid());
        for(Distributorrule d : distributorruleIterable){
            //如果该商品在分类的排除商品中，则该券不匹配该商品
            if((d.getNojoincodes() != null && d.getNojoincodes().contains(p.getGoodscode())) || !p.getFacode().equals(d.getFacode())){
                continue;
            }
            //如果分类能匹配，则该券匹配该商品
            if(null != p.getProductgroupcode() && p.getProductgroupcode().equals(d.getProductgroupno())){
                salescouponsInfoApi = new SalescouponsInfoApi();
                salescouponsInfoApi.setId(m.getId());
                salescouponsInfoApi.setSalesCouponId(m.getSalescouponid());
                salescouponsInfoApi.setAmount(m.getAmount());
                salescouponsInfoApi.setClassification(m.getClassification());
                salescouponsInfoApi.setConditions(m.getConditions());
                salescouponsInfoApi.setFromtime(m.getFromtime());
                salescouponsInfoApi.setTotime(m.getTotime());
                salescouponsInfoApi.setShopid(m.getShopid());
                salescouponsInfoApi.setTerminal(m.getTerminal());
                salescouponsInfoApi.setSuperposition(m.getSuperposition());
                salescouponsInfoApi.setType(m.getType());
                salescouponsInfoApi.setUsescope(m.getUsescope());
                salescouponsInfoApi.setName(m.getName());
                salescouponsInfoApi.setDescription(m.getDescription());
                list_s_InfoApi.add(salescouponsInfoApi);
            }
        }
    }

    /**
     * 根据绑定商品的规则校验用户名下的优惠券(m)是否可用，如果可用将该优惠券包装成需要的对象
     * 并放入可用优惠券列表中
     * @param productMap
     * @param p
     * @param list_s_InfoApi
     * @param m
     */
    private void checkByProductRule(Map<Object, Object> productMap, ProductInfoApi p, List<SalescouponsInfoApi> list_s_InfoApi, Membercouponrels m) {
        SalescouponsInfoApi salescouponsInfoApi = null;
        if(productMap == null || productMap.size() == 0){
            return;
        }
        Productrule productrule = (Productrule)productMap.get(m.getSalescouponid());
        if(productrule != null && !StringUtil.isEmpty(productrule.getGoodscodes())){
            //券的商品集合包含该商品
            if(productrule.getGoodscodes().contains(p.getGoodscode())){
                salescouponsInfoApi = new SalescouponsInfoApi();
                salescouponsInfoApi.setId(m.getId());
                salescouponsInfoApi.setSalesCouponId(m.getSalescouponid());
                salescouponsInfoApi.setAmount(m.getAmount());
                salescouponsInfoApi.setClassification(m.getClassification());
                salescouponsInfoApi.setConditions(m.getConditions());
                salescouponsInfoApi.setFromtime(m.getFromtime());
                salescouponsInfoApi.setTotime(m.getTotime());
                salescouponsInfoApi.setShopid(m.getShopid());
                salescouponsInfoApi.setTerminal(m.getTerminal());
                salescouponsInfoApi.setSuperposition(m.getSuperposition());
                salescouponsInfoApi.setType(m.getType());
                salescouponsInfoApi.setUsescope(m.getUsescope());
                salescouponsInfoApi.setName(m.getName());
                salescouponsInfoApi.setDescription(m.getDescription());
                list_s_InfoApi.add(salescouponsInfoApi);
            }
        }
    }

    private void getBatchData(List<Membercouponrels> list_mc, Map<Object,Object> productRuleMap, Map<Object,Object> detailRuleMap){
        List<String> productList = new ArrayList<String>();
        List<String> detailList = new ArrayList<String>();
        List<String> groupList = new ArrayList<String>();

        for(Membercouponrels m : list_mc){
            if(m.getType() == CouponConstant.COUPON_TYPE_PRODUCT_2){
                productList.add(String.valueOf(m.getSalescouponid()));
            }else if(m.getType() == CouponConstant.COUPON_TYPE_DETAIL_1){
                detailList.add(String.valueOf(m.getSalescouponid()));
            }else if(m.getType() == CouponConstant.COUPON_TYPE_PRODUCTGROUP_3){
                groupList.add(String.valueOf(m.getSalescouponid()));
            }
        }

        Map parmMap = new HashMap();
        if(CollectionUtils.isNotEmpty(productList)){
            parmMap.put("ids",productList);
            ResponseResult<List<Productrule>> res_product = productruleManager.getBatchBySalescouponids(parmMap);
            if(res_product.isSuccess()){
                List<Productrule> list = res_product.getData();
                for(Productrule p : list){
                    productRuleMap.put(p.getSalescouponid(),p);
                }
            }
        }

        if(CollectionUtils.isNotEmpty(detailList)){
            parmMap.put("ids",detailList);
            ResponseResult<List<Detailsrule>> res_detail = detailsruleManager.getBatchBySalescouponids(parmMap);
            if(res_detail.isSuccess()){
                List<Detailsrule> list = res_detail.getData();
                for(String s : detailList){
                    Long id = Long.valueOf(s);
                    Predicate<Detailsrule> predicate = Predicates.alwaysTrue();
                    DetailsrulePredicate detailsrulePredicate = new DetailsrulePredicate(id);
                    predicate = Predicates.and(predicate,detailsrulePredicate);
                    Iterable<Detailsrule> detailsruleIterable = FluentIterable.from(list).filter(predicate);
                    detailRuleMap.put(id,detailsruleIterable);
                }
            }
        }

        if(CollectionUtils.isNotEmpty(groupList)){
            parmMap.put("ids",groupList);
            ResponseResult<List<Distributorrule>> res_group = distributorruleManager.getBatchBySalescouponids(parmMap);
            if(res_group.isSuccess()){
                List<Distributorrule> list = res_group.getData();
                for(String s : groupList){
                    Long id = Long.valueOf(s);
                    Predicate<Distributorrule> predicate = Predicates.alwaysTrue();
                    DistributorrulePredicate distributorrulePredicate = new DistributorrulePredicate(id);
                    predicate = Predicates.and(predicate,distributorrulePredicate);
                    Iterable<Distributorrule> distributorruleIterable = FluentIterable.from(list).filter(predicate);
                    detailRuleMap.put(id,distributorruleIterable);
                }
            }
        }
    }

    /**
     * 处理商品券
     * @param p
     * @param list_s_InfoApi
     * @param m
     */
    private void doProductruleForOldNew(ProductInfoApi p, List<SalescouponsInfoApi> list_s_InfoApi, Membercouponrels m) {
        SalescouponsInfoApi salescouponsInfoApi;
        //券的商品集合包含该商品
        salescouponsInfoApi = new SalescouponsInfoApi();
        salescouponsInfoApi.setId(m.getId());
        salescouponsInfoApi.setSalesCouponId(m.getSalescouponid());
        salescouponsInfoApi.setAmount(m.getAmount());
        salescouponsInfoApi.setClassification(m.getClassification());
        salescouponsInfoApi.setConditions(m.getConditions());
        salescouponsInfoApi.setFromtime(m.getFromtime());
        salescouponsInfoApi.setTotime(m.getTotime());
        salescouponsInfoApi.setShopid(m.getShopid());
        salescouponsInfoApi.setTerminal(m.getTerminal());
        salescouponsInfoApi.setSuperposition(m.getSuperposition());
        salescouponsInfoApi.setType(m.getType());
        salescouponsInfoApi.setUsescope(m.getUsescope());
        salescouponsInfoApi.setName(m.getName());
        salescouponsInfoApi.setDescription(m.getDescription());
        list_s_InfoApi.add(salescouponsInfoApi);
    }

    /**
     * 处理商品券
     * @param p
     * @param list_s_InfoApi
     * @param m
     */
    private void doProductrule(ProductInfoApi p, List<SalescouponsInfoApi> list_s_InfoApi, Membercouponrels m) {
        SalescouponsInfoApi salescouponsInfoApi;
        Productrule productrule = new Productrule();
        productrule.setSalescouponid(m.getSalescouponid());
        ResponseResult<List<Productrule>> res_p = productruleManager.getProductruleList(productrule);
        if(res_p.isSuccess() && res_p.getData() != null){
            Productrule pro = res_p.getData().get(0);
            //券的商品集合包含该商品
            if(pro.getGoodscodes().contains(p.getGoodscode())){
                salescouponsInfoApi = new SalescouponsInfoApi();
                salescouponsInfoApi.setId(m.getId());
                salescouponsInfoApi.setSalesCouponId(m.getSalescouponid());
                salescouponsInfoApi.setAmount(m.getAmount());
                salescouponsInfoApi.setClassification(m.getClassification());
                salescouponsInfoApi.setConditions(m.getConditions());
                salescouponsInfoApi.setFromtime(m.getFromtime());
                salescouponsInfoApi.setTotime(m.getTotime());
                salescouponsInfoApi.setShopid(m.getShopid());
                salescouponsInfoApi.setTerminal(m.getTerminal());
                salescouponsInfoApi.setSuperposition(m.getSuperposition());
                salescouponsInfoApi.setType(m.getType());
                salescouponsInfoApi.setUsescope(m.getUsescope());
                salescouponsInfoApi.setName(m.getName());
                salescouponsInfoApi.setDescription(m.getDescription());
                list_s_InfoApi.add(salescouponsInfoApi);
            }
        }else {
            log.info("getSalescouponsWithProduct 优惠券["+m.getSalescouponid()+"]用户优惠券["+m.getId()+"]为商品券["+m.getType()+"] 通过["+m.getSalescouponid()+"]没有查到关联商品信息！"+m);
        }
    }

    /**
     * 更新优惠券状态
     * @param lenovoId  操作人，即谁更改了券的状态，如果是使用券，则该操作人为用户自己；如果是返回优惠券则情况较多，有扫单等。。。
     * @param token
     * @param list
     * @param status  0代表返回优惠券，即更新到使用状态；1代表使用优惠券，即更新使用次数
     * @return
     */
    @Override
    public RemoteResult updateMembercouponrelsStatus(String lenovoId,String token, List<String> list, int status) {
       return this.updateMembercouponrelsStatus("",lenovoId,token,list,status);
      /*  log.info("updateMembercouponrelsStatus 参数：lenovoId=[" + lenovoId + "],token=[" + token + "],list=[" + list + "] status=[" + status + "]");
        long time1 = new Date().getTime();
        RemoteResult result = new RemoteResult(false);
        try {
            if(hasBlankParameter(lenovoId, token) || CollectionUtils.isEmpty(list) || (status!=0 && status!=1)){
                log.info("updateMembercouponrelsStatus 参数错误");
                result.setResultCode(CouponConstant.RESULT_CODE_ERROR_PARAM);
                result.setResultMsg(CouponConstant.RESULT_MSG_ERROR_PARAM);
                log.info("updateMembercouponrelsStatus 结果："+result);
                return result;
            }
            Map ids_Map = new HashMap();
            ids_Map.put("ids",list);
            ResponseResult<List<Membercouponrels>> responseResult = memberCouponrelsManager.getMembercouponrelsListByIds(ids_Map);
            if(responseResult.isSuccess()){
                List<Membercouponrels> membercouponrelsList = responseResult.getData();
                if(membercouponrelsList.size() != list.size()){
                    log.info("updateMembercouponrelsStatus 根据用户优惠券主键ids["+list+"]查询出来的优惠券数量不相等"+membercouponrelsList);
                    result.setResultCode("16");
                    result.setResultMsg("根据用户优惠券主键ids[" + list + "]查询出来的优惠券数量不相等");
                    log.info("updateMembercouponrelsStatus 结果" + result);
                    return result;
                }
                Date currentTime = new Date();
                Map map = new HashMap();
                map.put("ids",list);
                map.put("currentTime", currentTime);
                //使用优惠券
                if(1 == status){
                    List<MembercouponrelsLog> logList = new ArrayList<MembercouponrelsLog>();
                    MembercouponrelsLog membercouponrelsLog = null;
                    for(Membercouponrels m : membercouponrelsList){
                        membercouponrelsLog = new MembercouponrelsLog();
                        //使用优惠券时，判断是否是用户自己的券
                        if(!m.getLenovoid().equals(lenovoId)){
                            log.info("updateMembercouponrelsStatus 用户优惠券的用户["+m.getLenovoid()+"]和传进来的参数lenovoId["+lenovoId+"]不匹配"+m);
                            result.setResultCode("15");
                            result.setResultMsg("用户优惠券的用户["+m.getLenovoid()+"]和传进来的参数lenovoId["+lenovoId+"]不匹配");
                            result.setT(m.getId());
                            log.info("updateMembercouponrelsStatus 结果"+result);
                            return result;
                        }
                        //更新之前检查是否过期，未过期才能使用
                        if(m.getTotime().getTime() < new Date().getTime()){
                            log.info("updateMembercouponrelsStatus ["+m.getId()+"]优惠券已经过期！");
                            result.setResultCode("11");
                            result.setResultMsg(m.getId()+"优惠券已经过期！");
                            result.setT(m.getId());
                            log.info("updateMembercouponrelsStatus 结果"+result);
                            return result;
                        }
                        //检查是否有禁用的券
                        if(m.getDisabled() == CouponConstant.COUPON_DISABLED_JINYONG){
                            log.info("updateMembercouponrelsStatus ["+m.getId()+"]已经被禁用！");
                            result.setResultCode("12");
                            result.setResultMsg(m.getId()+"已经被禁用！");
                            result.setT(m.getId());
                            log.info("updateMembercouponrelsStatus 结果"+result);
                            return result;
                        }
                        //检查是否可用 status=0 代表未使用
                        if(m.getStatus() != CouponConstant.COUPON_STATUS_ISUSED_FALSE){
                            log.info("updateMembercouponrelsStatus ["+m.getId()+"]已经被使用！");
                            result.setResultCode("13");
                            result.setResultMsg(m.getId()+"已经被使用！");
                            result.setT(m.getId());
                            log.info("updateMembercouponrelsStatus 结果"+result);
                            return result;
                        }

                        membercouponrelsLog.setMembercouponrelsid(m.getId());
                        membercouponrelsLog.setToken(token);
                        membercouponrelsLog.setStatus(status);
                        membercouponrelsLog.setCreatetime(currentTime);
                        membercouponrelsLog.setCreateby(lenovoId);
                        membercouponrelsLog.setUpdatetime(currentTime);
                        logList.add(membercouponrelsLog);
                    }

                    ResponseResult res_used = memberCouponrelsManager.updateMembercouponrelsUsed(map);
                    if(res_used.isSuccess()){
                        ResponseResult res_log = membercouponrelsLogManager.insertBatch(logList);
                        if(!res_log.isSuccess()){
                            log.info("updateMembercouponrelsStatus 优惠券使用记录表保存失败，"+logList);
                        }

                        result.setResultCode(CouponConstant.RESULT_CODE_SUC);
                        result.setResultMsg(CouponConstant.RESULT_MSG_SUC);
                        result.setSuccess(true);
                        log.info("updateMembercouponrelsStatus 结果"+result);
                        long time_use = new Date().getTime();
                        log.info("updateMembercouponrelsStatus 使用优惠券时总耗时："+(time_use - time1)+"毫秒");
                        return result;
                    }else {
                        log.info("updateMembercouponrelsStatus 更新优惠券["+list+"]为使用状态时不成功 "+membercouponrelsList);
                        result.setResultCode(CouponConstant.RESULT_CODE_FAIL);
                        result.setResultMsg("updateMembercouponrelsStatus 更新优惠券["+list+"]为使用状态时不成功 ");
                        result.setSuccess(false);
                        log.info("updateMembercouponrelsStatus 结果"+result);
                        return result;
                    }

                }else {
                    ResponseResult res_return = memberCouponrelsManager.updateMembercouponrelsReturn(map);
                    if(res_return.isSuccess()){
                        List<MembercouponrelsLog> logList2 = new ArrayList<MembercouponrelsLog>();
                        MembercouponrelsLog membercouponrelsLog = null;
                        for(Membercouponrels m : membercouponrelsList){
                            *//**
                             * status=1 代表已使用状态，如果返还优惠券时，该券状态不是已使用状态，则说明该券已经出现了问题
                             *//*
                            if(m.getStatus() != CouponConstant.COUPON_STATUS_ISUSED_TRUE){
                                log.info("updateMembercouponrelsStatus 返还用户优惠券["+m.getId()+"]时该券的当前状态为["+m.getStatus()+"] 异常情况！"+m);
                                result.setResultCode("14");
                                result.setResultMsg("返还用户优惠券["+m.getId()+"]时该券的当前状态为["+m.getStatus()+"] 异常情况！");
                                result.setSuccess(false);
                                log.info("updateMembercouponrelsStatus 结果"+result);
                                return result;
                            }
                            membercouponrelsLog = new MembercouponrelsLog();
                            membercouponrelsLog.setMembercouponrelsid(m.getId());
                            membercouponrelsLog.setToken(token);
                            membercouponrelsLog.setStatus(status);
                            membercouponrelsLog.setCreatetime(currentTime);
                            membercouponrelsLog.setCreateby(lenovoId);
                            membercouponrelsLog.setUpdatetime(currentTime);
                            logList2.add(membercouponrelsLog);
                        }
                        ResponseResult res_log = membercouponrelsLogManager.insertBatch(logList2);
                        if(!res_log.isSuccess()){
                            log.info("updateMembercouponrelsStatus 优惠券使用记录表保存失败，"+logList2);
                        }

                        result.setResultCode(CouponConstant.RESULT_CODE_SUC);
                        result.setResultMsg(CouponConstant.RESULT_MSG_SUC);
                        result.setSuccess(true);
                        log.info("updateMembercouponrelsStatus 结果"+result);
                        long time_return = new Date().getTime();
                        log.info("updateMembercouponrelsStatus 返还优惠券时总耗时："+(time_return - time1)+"毫秒");
                        return result;
                    }else {
                        log.info("updateMembercouponrelsStatus 返还优惠券["+list+"]时不成功 "+membercouponrelsList);
                        result.setResultCode(CouponConstant.RESULT_CODE_FAIL);
                        result.setResultMsg("updateMembercouponrelsStatus 返还优惠券["+list+"]时不成功 ");
                        result.setSuccess(false);
                        log.info("updateMembercouponrelsStatus 结果"+result);
                        return result;
                    }
                }
            }else {
                log.info("updateMembercouponrelsStatus 根据传入参数["+list+"]未找到用户优惠券");
                result.setResultCode("10");
                result.setResultMsg("根据传入参数[" + list + "]未找到用户优惠券");
                log.info("updateMembercouponrelsStatus "+result);
                return result;
            }
        } catch (Exception e) {
            log.error("updateMembercouponrelsStatus 异常：" + ExceptionUtil.getStackTrace(e));
            result.setResultCode(CouponConstant.RESULT_CODE_ERROR);
            result.setResultMsg(CouponConstant.RESULT_MSG_ERROR);
            result.setSuccess(false);
            return result;
        }*/
    }

    public RemoteResult updateMembercouponrelsStatus(Tenant tenant, String lenovoId, String token, List<String> list, int status) {

        return this.updateMembercouponrelsStatus(String.valueOf(tenant.getShopId()), lenovoId, token, list, status);
    }

    @Override
    public RemoteResult rectifyMembercouponrelsStatus(Long id, int status) {
        log.info(String.format("Rectify membercouponrels status, id=%s, status=%d", String.valueOf(id), status));
        RemoteResult result = new RemoteResult(false);
        if(id == null || StringUtils.isEmpty(String.valueOf(id)) || status != 0 || status != 1){
            result.setResultCode(CouponConstant.RESULT_CODE_ERROR_PARAM);
            result.setResultMsg(CouponConstant.RESULT_MSG_ERROR_PARAM);
            log.info("Rectify membercouponrels parameter error.");
            return result;
        }
        ResponseResult responseResult = memberCouponrelsManager.updateMembercouponrels(id, status);
        if(responseResult.isSuccess()){
            result.setResultCode(CouponConstant.RESULT_CODE_SUC);
            result.setResultMsg(CouponConstant.RESULT_MSG_SUC);
        }else {
            result.setResultCode(CouponConstant.RESULT_CODE_FAIL);
            result.setResultMsg(CouponConstant.RESULT_MSG_FAIL);
        }
        return result;
    }

    /**
     * 更新优惠券状态
     * @param shopId
     * @param lenovoId  操作人，即谁更改了券的状态，如果是使用券，则该操作人为用户自己；如果是返回优惠券则情况较多，有扫单等。。。
     * @param token
     * @param list
     * @param status  0代表返回优惠券，即更新到使用状态；1代表使用优惠券，即更新使用次数
     * @return
     */
    @Override
    public RemoteResult updateMembercouponrelsStatus(String shopId, String lenovoId, String token, List<String> list, int status) {
       /* if(updateConfig.getShardingFlag()){
            return newMemberCouponsApi.updateMembercouponrelsStatus(shopId,lenovoId,token,list,status);
        }*/
        log.info("updateMembercouponrelsStatus 参数：shopId=["+shopId+"],lenovoId=[" + lenovoId + "],token=[" + token + "],list=[" + list + "] status=[" + status + "]");
        long time1 = new Date().getTime();
        RemoteResult result = new RemoteResult(false);
        String key = shopId+","+lenovoId+","+token+","+list.toString()+""+status;
        RedisLock redisLock = new RedisLock(key, redisObjectManager);
        try {
            if(hasBlankParameter(lenovoId, token) || CollectionUtils.isEmpty(list) || (status!=0 && status!=1)){
                log.info("updateMembercouponrelsStatus 参数错误");
                result.setResultCode(CouponConstant.RESULT_CODE_ERROR_PARAM);
                result.setResultMsg(CouponConstant.RESULT_MSG_ERROR_PARAM);
                log.info("updateMembercouponrelsStatus 结果："+result);
                return result;
            }
            boolean flag = redisLock.lock(5000);
            if(!flag){
                return RemoteResultUtil.convert(ErrorMessageEnum.ERROR_APP_ERROR_BUSY);
            }
            Map ids_Map = new HashMap();
            ids_Map.put("ids",list);
            if(StringUtils.isNotEmpty(shopId)){
                ids_Map.put("shopId",shopId);
            }

            ResponseResult<List<Membercouponrels>> responseResult = memberCouponrelsManager.getMembercouponrelsListByIds(ids_Map);
            if(responseResult.isSuccess()){
                List<Membercouponrels> membercouponrelsList = responseResult.getData();
                if(membercouponrelsList.size() != list.size()){
                    log.info("updateMembercouponrelsStatus 根据用户优惠券主键ids["+list+"]查询出来的优惠券数量不相等"+membercouponrelsList);
                    result.setResultCode("16");
                    result.setResultMsg("根据用户优惠券主键ids[" + list + "]查询出来的优惠券数量不相等");
                    log.info("updateMembercouponrelsStatus 结果" + result);
                    return result;
                }
                Map map = new HashMap();
                map.put("ids",list);
                if(StringUtils.isNotEmpty(shopId)){
                    map.put("shopId",shopId);
                }

                //使用优惠券
                if(1 == status){
                    List<MembercouponrelsLog> logList = new ArrayList<MembercouponrelsLog>();
                    MembercouponrelsLog membercouponrelsLog = null;
                    for(Membercouponrels m : membercouponrelsList){
                        membercouponrelsLog = new MembercouponrelsLog();
                        //使用优惠券时，判断是否是用户自己的券
                        if(!m.getLenovoid().equals(lenovoId)){
                            log.info("updateMembercouponrelsStatus 用户优惠券的用户["+m.getLenovoid()+"]和传进来的参数lenovoId["+lenovoId+"]不匹配"+m);
                            result.setResultCode("15");
                            result.setResultMsg("用户优惠券的用户["+m.getLenovoid()+"]和传进来的参数lenovoId["+lenovoId+"]不匹配");
                            result.setT(m.getId());
                            log.info("updateMembercouponrelsStatus 结果"+result);
                            return result;
                        }
                        //更新之前检查是否过期，未过期才能使用
                        if(m.getTotime().getTime() < new Date().getTime()){
                            log.info("updateMembercouponrelsStatus ["+m.getId()+"]优惠券已经过期！");
                            result.setResultCode("11");
                            result.setResultMsg(m.getId()+"优惠券已经过期！");
                            result.setT(m.getId());
                            log.info("updateMembercouponrelsStatus 结果"+result);
                            return result;
                        }
                        //检查是否有禁用的券
                        if(m.getDisabled() == CouponConstant.COUPON_DISABLED_JINYONG){
                            log.info("updateMembercouponrelsStatus ["+m.getId()+"]已经被禁用！");
                            result.setResultCode("12");
                            result.setResultMsg(m.getId()+"已经被禁用！");
                            result.setT(m.getId());
                            log.info("updateMembercouponrelsStatus 结果"+result);
                            return result;
                        }
                        //检查是否可用 status=0 代表未使用
                        if(m.getStatus() != CouponConstant.COUPON_STATUS_ISUSED_FALSE){
                            log.info("updateMembercouponrelsStatus ["+m.getId()+"]已经被使用！");
                            result.setResultCode("13");
                            result.setResultMsg(m.getId()+"已经被使用！");
                            result.setT(m.getId());
                            log.info("updateMembercouponrelsStatus 结果"+result);
                            return result;
                        }

                        membercouponrelsLog.setMembercouponrelsid(m.getId());
                        membercouponrelsLog.setToken(token);
                        membercouponrelsLog.setStatus(status);
                        membercouponrelsLog.setCreatetime(new Date());
                        membercouponrelsLog.setCreateby(lenovoId);
                        membercouponrelsLog.setUpdatetime(new Date());
                        logList.add(membercouponrelsLog);
                    }

                    ResponseResult res_used = memberCouponrelsManager.updateMembercouponrelsUsed(map);
                    if(res_used.isSuccess()){
                        ResponseResult res_log = membercouponrelsLogManager.insertBatch(logList);
                        if(!res_log.isSuccess()){
                            log.info("updateMembercouponrelsStatus 优惠券使用记录表保存失败，"+logList);
                        }

                        result.setResultCode(CouponConstant.RESULT_CODE_SUC);
                        result.setResultMsg(CouponConstant.RESULT_MSG_SUC);
                        result.setSuccess(true);
                        log.info("updateMembercouponrelsStatus 结果"+result);
                        long time_use = new Date().getTime();
                        log.info("updateMembercouponrelsStatus 使用优惠券时总耗时："+(time_use - time1)+"毫秒");
                        return result;
                    }else {
                        log.info("updateMembercouponrelsStatus 更新优惠券["+list+"]为使用状态时不成功 "+membercouponrelsList);
                        result.setResultCode(CouponConstant.RESULT_CODE_FAIL);
                        result.setResultMsg("updateMembercouponrelsStatus 更新优惠券["+list+"]为使用状态时不成功 ");
                        result.setSuccess(false);
                        log.info("updateMembercouponrelsStatus 结果"+result);
                        return result;
                    }

                }else {
                    ResponseResult res_return = memberCouponrelsManager.updateMembercouponrelsReturn(map);
                    if(res_return.isSuccess()){
                        List<MembercouponrelsLog> logList2 = new ArrayList<MembercouponrelsLog>();
                        MembercouponrelsLog membercouponrelsLog = null;
                        for(Membercouponrels m : membercouponrelsList){
                            /**
                             * status=1 代表已使用状态，如果返还优惠券时，该券状态不是已使用状态，则说明该券已经出现了问题
                             */
                            if(m.getStatus() != CouponConstant.COUPON_STATUS_ISUSED_TRUE){
                                log.info("updateMembercouponrelsStatus 返还用户优惠券["+m.getId()+"]时该券的当前状态为["+m.getStatus()+"] 异常情况！"+m);
                                result.setResultCode("14");
                                result.setResultMsg("返还用户优惠券["+m.getId()+"]时该券的当前状态为["+m.getStatus()+"] 异常情况！");
                                result.setSuccess(false);
                                log.info("updateMembercouponrelsStatus 结果"+result);
                                return result;
                            }
                            membercouponrelsLog = new MembercouponrelsLog();
                            membercouponrelsLog.setMembercouponrelsid(m.getId());
                            membercouponrelsLog.setToken(token);
                            membercouponrelsLog.setStatus(status);
                            membercouponrelsLog.setCreatetime(new Date());
                            membercouponrelsLog.setCreateby(lenovoId);
                            membercouponrelsLog.setUpdatetime(new Date());
                            logList2.add(membercouponrelsLog);
                        }
                        ResponseResult res_log = membercouponrelsLogManager.insertBatch(logList2);
                        if(!res_log.isSuccess()){
                            log.info("updateMembercouponrelsStatus 优惠券使用记录表保存失败，"+logList2);
                        }

                        result.setResultCode(CouponConstant.RESULT_CODE_SUC);
                        result.setResultMsg(CouponConstant.RESULT_MSG_SUC);
                        result.setSuccess(true);
                        log.info("updateMembercouponrelsStatus 结果"+result);
                        long time_return = new Date().getTime();
                        log.info("updateMembercouponrelsStatus 返还优惠券时总耗时："+(time_return - time1)+"毫秒");
                        return result;
                    }else {
                        log.info("updateMembercouponrelsStatus 返还优惠券["+list+"]时不成功 "+membercouponrelsList);
                        result.setResultCode(CouponConstant.RESULT_CODE_FAIL);
                        result.setResultMsg("updateMembercouponrelsStatus 返还优惠券["+list+"]时不成功 ");
                        result.setSuccess(false);
                        log.info("updateMembercouponrelsStatus 结果"+result);
                        return result;
                    }
                }
            }else {
                log.info("updateMembercouponrelsStatus 根据传入参数["+list+"]未找到用户优惠券");
                result.setResultCode("10");
                result.setResultMsg("根据传入参数[" + list + "]未找到用户优惠券");
                log.info("updateMembercouponrelsStatus "+result);
                return result;
            }
        } catch (Exception e) {
            log.error("updateMembercouponrelsStatus 异常：" + ExceptionUtil.getStackTrace(e));
            result.setResultCode(CouponConstant.RESULT_CODE_ERROR);
            result.setResultMsg(CouponConstant.RESULT_MSG_ERROR);
            result.setSuccess(false);
            return result;
        }finally {
            redisLock.unlock();
        }

    }

    /**
     *
     * @param token
     * @param orderId
     * @param type 1 代表更新优惠券的订单号，0代表更新优惠码的订单号
     * @return  todo  即有券又有码的情况
     */
    @Override
    public RemoteResult updateMembercouponrelsOrderId(String token, String orderId,String type) {
        log.info("updateMembercouponrelsOrderId 参数：token=[" + token + "],orderId=[" + orderId + "] type=[" + type + "]");
        RemoteResult result = new RemoteResult(false);
        if(hasBlankParameter(token, orderId, type) || (!type.equals("1") && !type.equals("0"))){
            log.info("updateMembercouponrelsOrderId 参数错误");
            result.setResultCode(CouponConstant.RESULT_CODE_ERROR_PARAM);
            result.setResultMsg(CouponConstant.RESULT_MSG_ERROR_PARAM);
            log.info("updateMembercouponrelsOrderId 结果："+result);
            return result;
        }
        if(type.equals("1")){
            ResponseResult responseResult = membercouponrelsLogManager.updateMembercouponrelsLog(token, orderId);
            if(responseResult.isSuccess()){
                result.setSuccess(true);
                return  result;
            }else {
                log.info("updateMembercouponrelsOrderId 更新 优惠券 订单号时失败token=["+token+"] orderId=["+orderId+"]");
                result.setResultMsg("更新主订单号失败");
                return result;
            }
        }else if(type.equals("0")){
            ResponseResult responseResult = couponsLogManager.updateCouponsLog(token,orderId);
            if(responseResult.isSuccess()){
                result.setSuccess(true);
                return  result;
            }else {
                log.info("updateMembercouponrelsOrderId 更新 优惠码 订单号时失败token=["+token+"] orderId=["+orderId+"]");
                result.setResultMsg("更新主订单号失败");
                return result;
            }
        }
        return result;
    }

    @Override
    public RemoteResult updateMembercouponrelsOrderId(Tenant tenant, String token, String orderId, String type) {
        return this.updateMembercouponrelsOrderId(String.valueOf(tenant.getShopId()), token, orderId, type);
    }

    /**
     * 新加shopId 做为更新条件
     * @param shopId
     * @param token
     * @param orderId
     * @param type  1 代表更新优惠券的订单号，0代表更新优惠码的订单号
     * @return
     */
    @Override
    public RemoteResult updateMembercouponrelsOrderId(String shopId, String token, String orderId, String type) {
        return updateMembercouponrelsOrderId(token, orderId, type);
    }

    @Override
    public RemoteResult getCouponsWithProduct(Tenant tenant, UserApi userApi, List<ProductInfoApi> list, String terminal,String mCode) {
        return this.getCouponsWithProduct(userApi, list, String.valueOf(tenant.getShopId()), terminal, mCode);
    }

    /**
     * 获取商品对应的优惠券
     * @param userApi
     * @param list
     * @param shopId
     * @param terminal
     * @param mCode
     * @return
     */
    @Override
    public RemoteResult getCouponsWithProduct(UserApi userApi, List<ProductInfoApi> list, String shopId, String terminal,String mCode) {
        log.info("getCouponsWithProduct 参数："+userApi+","+list+",shopId=["+shopId+"] terminal=["+terminal+"] mCode=["+mCode+"]");
        long time1 = new Date().getTime();
        RemoteResult result = new RemoteResult(false);
        try {
            if(hasBlankParameter(shopId, terminal, mCode) || CollectionUtils.isEmpty(list)){
                log.info("getCouponsWithProduct ： 参数错误！");
                result.setResultCode(CouponConstant.RESULT_CODE_ERROR_PARAM);
                result.setResultMsg(CouponConstant.RESULT_MSG_ERROR_PARAM);
                log.info("getCouponsWithProduct 结果： "+result);
                return result;
            }
            if(String.valueOf(ShopIdEnum.EPP.getType()).equals(shopId) ){
                if(userApi == null || hasBlankParameter(userApi.getLenovoid(), userApi.getGroupCode())){
                    log.info("getCouponsWithProduct ： 参数错误！");
                    result.setResultCode(CouponConstant.RESULT_CODE_ERROR_PARAM);
                    result.setResultMsg(CouponConstant.RESULT_MSG_ERROR_PARAM);
                    log.info("getCouponsWithProduct 结果： "+result);
                    return result;
                }
            }
            /**
             * coupons表中只取status为0的数据，为1的代表禁用了
             */
            ResponseResult res_coupons = couponsManager.getCouponsByCode(mCode);
            if(res_coupons.isSuccess() && res_coupons.getData() != null){
                Coupons coupons = (Coupons)res_coupons.getData();
                if (checkCoupon(userApi, shopId, terminal, mCode, result, coupons)) return result;

                CouponsJsonApi couponsJsonApi = new CouponsJsonApi();
                couponsJsonApi.setId(coupons.getId());
                couponsJsonApi.setCode(mCode);
                couponsJsonApi.setAmount(coupons.getAmount()+"");
                List<String> codesList = new ArrayList<String>();
                if(CouponConstant.COUPON_TYPE_DETAIL_1 == coupons.getType()){  // 校验分类绑定
                    Detailsrule detailsrule = new Detailsrule();
                    detailsrule.setSalescouponid( coupons.getSalescouponid());
                    ResponseResult<List<Detailsrule>> res_d = detailsruleManager.getDetailsruleList(detailsrule);
                    if(res_d.isSuccess() && null != res_d.getData()) {
                        List<Detailsrule> list_d = res_d.getData();
                        for (ProductInfoApi p : list) {
                            for (Detailsrule d : list_d){
                                //如果该商品在分类的排除商品中，则该券不匹配该商品
                                if(StringUtils.isNotEmpty(d.getNojoincodes()) && d.getNojoincodes().contains(p.getGoodscode())){
                                    break;
                                }
                                //如果分类能匹配，则该券匹配该商品
                                if(null != p.getCategorycode() && p.getCategorycode().equals(d.getGoodscategoryid())){
                                    codesList.add(p.getGoodscode());
                                    break;
                                }
                            }
                        }
                    }else {
                        log.info("getCouponsWithProduct 优惠码["+mCode+"]为分类码["+coupons.getType()+"] 通过["+coupons.getSalescouponid()+"]没有查到分类信息！"+coupons);
                        result.setResultCode("20");
                        result.setResultMsg("getCouponsWithProduct 优惠码["+mCode+"]为分类码["+coupons.getType()+"] 通过["+coupons.getSalescouponid()+"]没有查到分类信息！");
                        log.info("getCouponsWithProduct 结果： "+result);
                        return result;
                    }
                }else if (CouponConstant.COUPON_TYPE_PRODUCT_2 == coupons.getType()){  // 校验商品绑定
                    Productrule productrule = new Productrule();
                    productrule.setSalescouponid(coupons.getSalescouponid());
                    ResponseResult<List<Productrule>> res_p = productruleManager.getProductruleList(productrule);
                    if(res_p.isSuccess() && null != res_p.getData()){
                        Productrule pro = res_p.getData().get(0);
                        for (ProductInfoApi p : list) {
                            if(pro.getGoodscodes().contains(p.getGoodscode())){
                                codesList.add(p.getGoodscode());
                            }
                        }
                    }else {
                        log.info("getCouponsWithProduct 优惠码["+mCode+"]为商品码["+coupons.getType()+"] 通过["+coupons.getSalescouponid()+"]没有查到码关联的商品信息！"+coupons);
                        result.setResultCode("21");
                        result.setResultMsg("getCouponsWithProduct 优惠码["+mCode+"]为商品码["+coupons.getType()+"] 通过["+coupons.getSalescouponid()+"]没有查到关联的商品信息！");
                        log.info("getCouponsWithProduct 结果： "+result);
                        return result;
                    }
                }else if(CouponConstant.COUPON_TYPE_PRODUCTGROUP_3 == coupons.getType()){  // 校验分类绑定
                    Distributorrule distributorrule = new Distributorrule();
                    distributorrule.setSalescouponid( coupons.getSalescouponid());
                    ResponseResult<List<Distributorrule>> res_d = distributorruleManager.getDistributorruleListGroupBy(distributorrule);
                    if(res_d.isSuccess() && null != res_d.getData()) {
                        List<Distributorrule> list_d = res_d.getData();
                        for (ProductInfoApi p : list) {
                            for (Distributorrule d : list_d){
                                //如果该商品在分类的排除商品中，则该券不匹配该商品
                                if(StringUtils.isNotEmpty(d.getNojoincodes()) && d.getNojoincodes().contains(p.getGoodscode())){
                                    break;
                                }
                                //如果分类能匹配，则该券匹配该商品
                                if(null != p.getProductgroupcode() && p.getProductgroupcode().equals(d.getProductgroupid())){
                                    codesList.add(p.getGoodscode());
                                    break;
                                }
                            }
                        }
                    }else {
                        log.info("getCouponsWithProduct 优惠码["+mCode+"]为分类码["+coupons.getType()+"] 通过["+coupons.getSalescouponid()+"]没有查到分类信息！"+coupons);
                        result.setResultCode("20");
                        result.setResultMsg("getCouponsWithProduct 优惠码["+mCode+"]为分类码["+coupons.getType()+"] 通过["+coupons.getSalescouponid()+"]没有查到分类信息！");
                        log.info("getCouponsWithProduct 结果： "+result);
                        return result;
                    }
                }else {
                    log.info("优惠码["+mCode+"]不存在这个绑定规则 type="+coupons.getType());
                    result.setResultCode("22");
                    result.setResultMsg("优惠码["+mCode+"]不存在这个绑定规则 type="+coupons.getType());
                    log.info("getCouponsWithProduct 结果： "+result);
                    return result;
                }

                if(CollectionUtils.isNotEmpty(codesList)){
                    couponsJsonApi.setGoodsCodesList(codesList);
                }else {
                    couponsJsonApi = null;
                }
                result.setResultCode(CouponConstant.RESULT_CODE_SUC);
                result.setResultMsg(CouponConstant.RESULT_MSG_SUC);
                result.setT(couponsJsonApi);
                result.setSuccess(true);
                long time2 = new Date().getTime();
                log.info("getCouponsWithProduct 总耗时： "+(time2 - time1)+"毫秒");
                log.info("getCouponsWithProduct 结果： "+result);
                    return result;
            }else {
                log.info("getCouponsWithProduct ： 优惠码["+mCode+"]找不到相关信息！");
                result.setResultCode("10");
                result.setResultMsg("没有找到该优惠码[" + mCode + "]");
                log.info("getCouponsWithProduct 结果： " + result);
                return result;
            }
        } catch (Exception e) {
            log.error("getCouponsWithProduct 异常：" + ExceptionUtil.getStackTrace(e));
            result.setResultCode(CouponConstant.RESULT_CODE_ERROR);
            result.setResultMsg(CouponConstant.RESULT_MSG_ERROR);
            result.setSuccess(false);
            return result;
        }
    }

    private boolean checkCoupon(UserApi userApi, String shopId, String terminal, String mCode, RemoteResult result, Coupons coupons) {
        if(!coupons.getShopid().equals(shopId)){
            log.info("getCouponsWithProduct 商城["+shopId+"]与该优惠码["+mCode+"]不匹配!");
            result.setResultCode("11");
            result.setResultMsg("商城与该优惠码["+mCode+"]不匹配！");
            log.info("getCouponsWithProduct 结果： "+result);
            return true;
        }
        if(String.valueOf(ShopIdEnum.EPP.getType()).equals(shopId) ){
            if(StringUtils.isEmpty(coupons.getGroupcode())){
                log.info("getCouponsWithProduct epp商城的码["+mCode+"] 的用户组为空");
                result.setResultCode("11");
                result.setResultMsg("epp商城的用户组不能为空！");
                result.setSuccess(false);
                log.info("getCouponsWithProduct 结果："+result);
                return true;
            }
            if(!coupons.getGroupcode().contains(userApi.getGroupCode())){
                log.info("getCouponsWithProduct EPP商城的优惠码的用户组["+coupons.getGroupcode() + "] 与用户的组[" + userApi.getGroupCode() + "]不匹配，不能使用！");
                result.setResultCode("13");
                result.setResultMsg("EPP商城的优惠码的用户组与用户的组[" + userApi.getGroupCode() + "]不匹配，不能使用！");
                log.info("getCouponsWithProduct 结果： "+result);
                return true;
            }
        }

        if(!coupons.getTerminal().contains(terminal)){
            log.info("getCouponsWithProduct 该优惠码["+mCode+"]不能用在该平台["+terminal+"]");
            result.setResultCode("14");
            result.setResultMsg("该优惠码["+mCode+"]不能用在该平台["+terminal+"]");
            log.info("getCouponsWithProduct 结果： "+result);
            return true;
        }

        long nowtime = new Date().getTime();
        if(coupons.getStarttime().getTime() > coupons.getEndtime().getTime()){
            log.info("getCouponsWithProduct 优惠码["+mCode+"]有效期开始时间必须小于结束时间！");
            result.setResultCode("15");
            result.setResultMsg("优惠码["+mCode+"]有效期开始时间必须小于结束时间！");
            log.info("getCouponsWithProduct 结果： "+result);
            return true;
        }
        if(coupons.getStarttime().getTime() >  nowtime){
            log.info("getCouponsWithProduct 优惠码["+mCode+"]有效期还未开始！");
            result.setResultCode("16");
            result.setResultMsg("优惠码["+mCode+"]有效期还未开始！");
            log.info("getCouponsWithProduct 结果： "+result);
            return true;
        }
        if( nowtime > coupons.getEndtime().getTime()){
            log.info("getCouponsWithProduct 优惠码["+mCode+"]已经过期了！");
            result.setResultCode("17");
            result.setResultMsg("优惠码["+mCode+"]已经过期了！");
            log.info("getCouponsWithProduct 结果： "+result);
            return true;
        }
        if( coupons.getTotalnumber() < 1){
            log.info("getCouponsWithProduct 优惠码["+mCode+"]总使用次数小于1了！");
            result.setResultCode("18");
            result.setResultMsg("优惠码["+mCode+"]总使用次数小于1了！");
            log.info("getCouponsWithProduct 结果： "+result);
            return true;
        }
        //使用次数小于总次数才可以用
        if( coupons.getOccupynumber() >= coupons.getTotalnumber()){
            log.info("getCouponsWithProduct 优惠码["+mCode+"]的使用次数["+coupons.getTotalnumber()+"]已经使用完了！");
            result.setResultCode("19");
            result.setResultMsg("优惠码["+mCode+"]的使用次数["+coupons.getTotalnumber()+"]已经使用完了！");
            log.info("getCouponsWithProduct 结果： "+result);
            return true;
        }
        return false;
    }

    @Override
    public RemoteResult updateCouponsStatus(String lenovoId, String token, String macode, int status) {
        log.info("updateCouponsStatus 参数：lenovoId=["+lenovoId+"],token=["+token+"],macode=["+macode+"],status=["+status+"]");
        RemoteResult result = new RemoteResult(false);
        if(hasBlankParameter(lenovoId, token, macode) || (status!=0 && status!=1)){
            log.info("updateCouponsStatus 参数错误！");
            result.setResultCode(CouponConstant.RESULT_CODE_ERROR_PARAM);
            result.setResultMsg(CouponConstant.RESULT_MSG_ERROR_PARAM);
            log.info("updateCouponsStatus 结果： "+result);
            return result;
        }
        ResponseResult responseResult = couponsManager.getCouponsByCode(macode);
        if(responseResult.isSuccess()){
            Coupons coupons = (Coupons)responseResult.getData();
            //使用优惠码  检查码的有效性
            if( 1 == status){
                ResponseResult res = salescouponsManager.getSalescoupons(coupons.getSalescouponid());
                if(res.isSuccess()){
                    Salescoupons salescoupons = (Salescoupons)res.getData();
                    long nowtime = new Date().getTime();
                    if(salescoupons.getFromtime().getTime() > salescoupons.getTotime().getTime()){
                        log.info("updateCouponsStatus 优惠码["+macode+"]有效期开始时间必须小于结束时间！");
                        result.setResultCode("13");
                        result.setResultMsg("优惠码["+macode+"]有效期开始时间必须小于结束时间！");
                        log.info("updateCouponsStatus 结果： "+result);
                        return result;
                    }
                    if(salescoupons.getFromtime().getTime() >  nowtime){
                        log.info("updateCouponsStatus 优惠码["+macode+"]有效期还未开始！");
                        result.setResultCode("14");
                        result.setResultMsg("优惠码["+macode+"]有效期还未开始！");
                        log.info("updateCouponsStatus 结果： "+result);
                        return result;
                    }
                    if( nowtime > salescoupons.getTotime().getTime()){
                        log.info("updateCouponsStatus 优惠码["+macode+"]已经过期了！");
                        result.setResultCode("15");
                        result.setResultMsg("优惠码["+macode+"]已经过期了！");
                        log.info("updateCouponsStatus 结果： "+result);
                        return result;
                    }
                    if( salescoupons.getTotalnumber() < 1){
                        log.info("优惠码["+coupons.getMacode()+"]总使用次数小于1了！");
                        result.setResultCode("16");
                        result.setResultMsg("优惠码["+coupons.getMacode()+"]总使用次数小于1了！");
                        log.info("getCouponsWithProduct 结果： "+result);
                        return result;
                    }
                    //使用次数小于总次数才可以用
                    if( coupons.getOccupynumber() >= salescoupons.getTotalnumber()){
                        log.info("updateCouponsStatus 优惠码["+coupons.getMacode()+"]的使用次数["+salescoupons.getTotalnumber()+"]已经使用完了！");
                        result.setResultCode("17");
                        result.setResultMsg("优惠码["+coupons.getMacode()+"]的使用次数["+salescoupons.getTotalnumber()+"]已经使用完了！");
                        log.info("updateCouponsStatus 结果： "+result);
                        return result;
                    }
                    Map map = new HashMap();
                    map.put("id",coupons.getId());
                    map.put("totalnumber",salescoupons.getTotalnumber());
                    ResponseResult res_update = couponsManager.updateCouponsPlus(map);
                    if(res_update.isSuccess()){
                        LogVo couponsLog = new LogVo();
                        couponsLog.setContent(JsonUtil.toJson(couponsLog));
                        couponsLog.setModul(ModulNameEnum.SALES_COUPON_LOG.getDesc());
                        couponsLog.setOperationType("updateCouponsStatus");
                        couponsLog.setLenovoId(lenovoId);
                        couponsLog.setCreateTime(new Date().toString());
                        try {
                            logService.save2Mongo(couponsLog);
                        } catch (Exception e) {
                            log.info("updateCouponsStatus 在使用优惠码时保存日志记录失败 "+couponsLog);

                        }
                        result.setResultCode(CouponConstant.RESULT_CODE_SUC);
                        result.setResultMsg(CouponConstant.RESULT_MSG_SUC);
                        result.setSuccess(true);
                        log.info("updateCouponsStatus 结果： "+result);
                        return result;
                    }else {
                        log.info("updateCouponsStatus 根据优惠码主键macode=["+macode+"]更新不成功！更新时使用次数["+coupons.getOccupynumber()+"] 总次数["+salescoupons.getTotalnumber()+"] "+coupons+" "+ salescoupons);
                        result.setResultCode("18");
                        result.setResultMsg("根据优惠码主键macode=["+macode+"]更新不成功！更新时使用次数["+coupons.getOccupynumber()+"] 总次数["+salescoupons.getTotalnumber()+"]");
                        result.setSuccess(false);
                        log.info("updateCouponsStatus 结果： "+result);
                        return result;
                    }
                }else {
                    log.info("updateCouponsStatus 优惠码主键macode=["+macode+"] 根据salescouponId=["+coupons.getSalescouponid()+"]找不到数据！");
                    result.setResultCode("11");
                    result.setResultMsg("优惠码主键macode=["+macode+"] 根据salescouponId=["+coupons.getSalescouponid()+"]找不到数据！");
                    result.setSuccess(false);
                    log.info("updateCouponsStatus 结果： "+result);
                    return result;
                }
            }else {
                //返还优惠码 不检查有效性
                if(coupons.getOccupynumber() <= 0){
                    log.info("updateCouponsStatus 优惠码["+macode+"] 使用次数["+coupons.getOccupynumber()+"]小于等于0 已经无法返还优惠码！");
                    result.setResultCode("19");
                    result.setResultMsg("优惠码["+macode+"] 使用次数["+coupons.getOccupynumber()+"]小于等于0 已经无法返还优惠码！");
                    result.setSuccess(false);
                    log.info("updateCouponsStatus 结果： "+result);
                    return result;
                }
                Map map = new HashMap();
                map.put("id", coupons.getId());
                ResponseResult res_reduce = couponsManager.updateCouponsReduce(map);
                if(res_reduce.isSuccess()){
                    LogVo couponsLog = new LogVo();
                    couponsLog.setContent(JsonUtil.toJson(coupons));
                    couponsLog.setOperationType("返还优惠码");
                    couponsLog.setModul(ModulNameEnum.SALES_COUPON_LOG.getDesc());
                    couponsLog.setLenovoId(lenovoId);
                    couponsLog.setCreateTime(new Date().toString());
                    try {
                        logService.save2Mongo(couponsLog);
                    } catch (Exception e) {
                        log.info("updateCouponsStatus 在返还优惠码时保存日志记录失败 "+e);
                    }

                    result.setResultCode(CouponConstant.RESULT_CODE_SUC);
                    result.setResultMsg(CouponConstant.RESULT_MSG_SUC);
                    result.setSuccess(true);
                    log.info("updateCouponsStatus 结果： "+result);
                    return result;
                }else {
                    log.info("updateCouponsStatus 优惠码["+macode+"]更新不成功！更新时使用次数["+coupons.getOccupynumber()+"] "+coupons);
                    result.setResultCode("20");
                    result.setResultMsg("优惠码["+macode+"]更新不成功！更新时使用次数["+coupons.getOccupynumber()+"] ");
                    result.setSuccess(false);
                    log.info("updateCouponsStatus 结果： "+result);
                    return result;
                }
            }
        }else {
            log.info("updateCouponsStatus 根据优惠码["+macode+"]找不到数据！ ");
            result.setResultCode("10");
            result.setResultMsg("根据优惠码["+macode+"]找不到数据！");
            result.setSuccess(false);
            log.info("updateCouponsStatus 结果： "+result);
            return result;
        }
    }

    @Override
    public RemoteResult updateCouponsStatus(Tenant tenant, String lenovoId, String token, String macode, int status) {
        return this.updateCouponsStatus(String.valueOf(tenant.getShopId()), lenovoId, token, macode, status);
    }

    @Override
    public RemoteResult updateCouponsStatus(String shopId, String lenovoId, String token, String macode, int status) {
        log.info(String.format("updateCouponsStatus 参数：shopId=[%s], lenovoId=[%s], token=[%s], macode=[%s], status=[%d]", shopId, lenovoId, token, macode, status));
        RemoteResult result = new RemoteResult(false);
        if(hasBlankParameter(shopId, lenovoId, token, macode) || (status != 0 && status != 1)){
            log.info("updateCouponsStatus 参数错误！");
            result.setResultCode(CouponConstant.RESULT_CODE_ERROR_PARAM);
            result.setResultMsg(CouponConstant.RESULT_MSG_ERROR_PARAM);
            log.info("updateCouponsStatus 结果： "+result);
            return result;
        }

        ResponseResult responseResult = couponsManager.getCouponsByCode(shopId, macode);
        if(responseResult.isSuccess()){
            Coupons coupons = (Coupons)responseResult.getData();
            //使用优惠码  检查码的有效性
            if( 1 == status){
                ResponseResult res = salescouponsManager.getSalescoupons(coupons.getSalescouponid());
                if(res.isSuccess()){
                    Salescoupons salescoupons = (Salescoupons)res.getData();
                    long nowtime = new Date().getTime();
                    if(salescoupons.getFromtime().getTime() > salescoupons.getTotime().getTime()){
                        log.info("updateCouponsStatus 优惠码["+macode+"]有效期开始时间必须小于结束时间！");
                        result.setResultCode("13");
                        result.setResultMsg("优惠码["+macode+"]有效期开始时间必须小于结束时间！");
                        log.info("updateCouponsStatus 结果： "+result);
                        return result;
                    }
                    if(salescoupons.getFromtime().getTime() >  nowtime){
                        log.info("updateCouponsStatus 优惠码["+macode+"]有效期还未开始！");
                        result.setResultCode("14");
                        result.setResultMsg("优惠码["+macode+"]有效期还未开始！");
                        log.info("updateCouponsStatus 结果： "+result);
                        return result;
                    }
                    if( nowtime > salescoupons.getTotime().getTime()){
                        log.info("updateCouponsStatus 优惠码["+macode+"]已经过期了！");
                        result.setResultCode("15");
                        result.setResultMsg("优惠码["+macode+"]已经过期了！");
                        log.info("updateCouponsStatus 结果： "+result);
                        return result;
                    }
                    if( salescoupons.getTotalnumber() < 1){
                        log.info("优惠码["+coupons.getMacode()+"]总使用次数小于1了！");
                        result.setResultCode("16");
                        result.setResultMsg("优惠码["+coupons.getMacode()+"]总使用次数小于1了！");
                        log.info("getCouponsWithProduct 结果： "+result);
                        return result;
                    }
                    //使用次数小于总次数才可以用
                    if( coupons.getOccupynumber() >= salescoupons.getTotalnumber()){
                        log.info("updateCouponsStatus 优惠码["+coupons.getMacode()+"]的使用次数["+salescoupons.getTotalnumber()+"]已经使用完了！");
                        result.setResultCode("17");
                        result.setResultMsg("优惠码["+coupons.getMacode()+"]的使用次数["+salescoupons.getTotalnumber()+"]已经使用完了！");
                        log.info("updateCouponsStatus 结果： "+result);
                        return result;
                    }
                    Map map = new HashMap();
                    map.put("id",coupons.getId());
                    map.put("totalnumber",salescoupons.getTotalnumber());
                    map.put("shopId", shopId);
                    ResponseResult res_update = couponsManager.updateCouponsPlus(map);
                    if(res_update.isSuccess()){
                        CouponsLog couponsLog = new CouponsLog();
                        couponsLog.setCouponsid(coupons.getId());
                        couponsLog.setToken(token);
                        couponsLog.setStatus(status);
                        couponsLog.setCreatetime(new Date());
                        couponsLog.setCreateby(lenovoId);
                        couponsLog.setUpdatetime(new Date());
                        ResponseResult res_1_log = couponsLogManager.insertCouponsLog(couponsLog);
                        if(!res_1_log.isSuccess()){
                            log.info("updateCouponsStatus 在使用优惠码时保存日志记录失败 "+couponsLog);
                        }
                        result.setResultCode(CouponConstant.RESULT_CODE_SUC);
                        result.setResultMsg(CouponConstant.RESULT_MSG_SUC);
                        result.setSuccess(true);
                        log.info("updateCouponsStatus 结果： "+result);
                        return result;
                    }else {
                        log.info("updateCouponsStatus 根据优惠码主键macode=["+macode+"]更新不成功！更新时使用次数["+coupons.getOccupynumber()+"] 总次数["+salescoupons.getTotalnumber()+"] "+coupons+" "+ salescoupons);
                        result.setResultCode("18");
                        result.setResultMsg("根据优惠码主键macode=["+macode+"]更新不成功！更新时使用次数["+coupons.getOccupynumber()+"] 总次数["+salescoupons.getTotalnumber()+"]");
                        result.setSuccess(false);
                        log.info("updateCouponsStatus 结果： "+result);
                        return result;
                    }
                }else {
                    log.info("updateCouponsStatus 优惠码主键macode=["+macode+"] 根据salescouponId=["+coupons.getSalescouponid()+"]找不到数据！");
                    result.setResultCode("11");
                    result.setResultMsg("优惠码主键macode=["+macode+"] 根据salescouponId=["+coupons.getSalescouponid()+"]找不到数据！");
                    result.setSuccess(false);
                    log.info("updateCouponsStatus 结果： "+result);
                    return result;
                }
            }else {
                //返还优惠码 不检查有效性
                if(coupons.getOccupynumber() <= 0){
                    log.info("updateCouponsStatus 优惠码["+macode+"] 使用次数["+coupons.getOccupynumber()+"]小于等于0 已经无法返还优惠码！");
                    result.setResultCode("19");
                    result.setResultMsg("优惠码["+macode+"] 使用次数["+coupons.getOccupynumber()+"]小于等于0 已经无法返还优惠码！");
                    result.setSuccess(false);
                    log.info("updateCouponsStatus 结果： "+result);
                    return result;
                }
                Map map = new HashMap();
                map.put("id", coupons.getId());
                map.put("shopId", shopId);
                ResponseResult res_reduce = couponsManager.updateCouponsReduce(map);
                if(res_reduce.isSuccess()){
                    CouponsLog couponsLog = new CouponsLog();
                    couponsLog.setCouponsid(coupons.getId());
                    couponsLog.setToken(token);
                    couponsLog.setStatus(status);
                    couponsLog.setCreatetime(new Date());
                    couponsLog.setCreateby(lenovoId);
                    couponsLog.setUpdatetime(new Date());
                    ResponseResult res_0_log = couponsLogManager.insertCouponsLog(couponsLog);
                    if(!res_0_log.isSuccess()){
                        log.info("updateCouponsStatus 在返还优惠码时保存日志记录失败 "+couponsLog);
                    }
                    result.setResultCode(CouponConstant.RESULT_CODE_SUC);
                    result.setResultMsg(CouponConstant.RESULT_MSG_SUC);
                    result.setSuccess(true);
                    log.info("updateCouponsStatus 结果： "+result);
                    return result;
                }else {
                    log.info("updateCouponsStatus 优惠码["+macode+"]更新不成功！更新时使用次数["+coupons.getOccupynumber()+"] "+coupons);
                    result.setResultCode("20");
                    result.setResultMsg("优惠码["+macode+"]更新不成功！更新时使用次数["+coupons.getOccupynumber()+"] ");
                    result.setSuccess(false);
                    log.info("updateCouponsStatus 结果： "+result);
                    return result;
                }
            }
        }else {
            log.info("updateCouponsStatus 根据优惠码["+macode+"]找不到数据！ ");
            result.setResultCode("10");
            result.setResultMsg("根据优惠码["+macode+"]找不到数据！");
            result.setSuccess(false);
            log.info("updateCouponsStatus 结果： "+result);
            return result;
        }
    }

    @Override
    public RemoteResult getSalescouponsWithLenovoId(Tenant tenant, UserApi userApi, String terminal) {
        return this.getSalescouponsWithLenovoId(userApi, String.valueOf(tenant.getShopId()), terminal);
    }

    @Override
    public RemoteResult getSalescouponsWithLenovoId(UserApi userApi,String shopId,String terminal) {
        log.info("getSalescouponsWithLenovoId 参数：userApi=["+userApi+"],shopId=["+shopId+"] ,terminal=["+terminal+"] ");
        RemoteResult result = new RemoteResult(false);
        try {
            if(userApi == null || hasBlankParameter(userApi.getLenovoid(), userApi.getUsername(), userApi.getGroupCode(), shopId, terminal)){
                log.info("getSalescouponsWithLenovoId ： 参数错误！");
                result.setResultCode(CouponConstant.RESULT_CODE_ERROR_PARAM);
                result.setResultMsg(CouponConstant.RESULT_MSG_ERROR_PARAM);
                log.info("getSalescouponsWithLenovoId 结果："+result);
                return result;
            }

            /**
             * 查询之前先帮全员券, 惠商不绑定全员券
             */
            if(!"14".equals(shopId) && !"15".equals(shopId)) {
                memberCounponrelsService.bindAllMemberSalesCoupons(userApi.getLenovoid(), userApi.getUsername(), userApi.getGroupCode(), shopId);
            }


            ResponseResult<List<Membercouponrels>> res = memberCouponrelsManager.getMemberEffectiveCoupons(userApi.getLenovoid(), shopId, terminal);
            if(res.isSuccess() && res.getData() != null ){
                List<Membercouponrels> list_mc = res.getData();
                log.info("getSalescouponsWithLenovoId 用户的券为"+(list_mc != null ? list_mc.size() : null));
                if (list_mc.size() == 0){
                    log.info("getSalescouponsWithLenovoId 用户["+userApi+"]在商城["+ shopId + "] 平台[" + terminal + "]上没有有效的优惠券！");
//                    result.setResultCode("10");
//                    result.setResultMsg("用户[" + userApi.getLenovoid()+"]在商城["+shopId+"] 平台["+terminal+"]上没有有效的优惠券！");
//                    result.setSuccess(true);
//                    log.info("getSalescouponsWithLenovoId 结果："+result);
//                    return result;
                    return RemoteResultUtil.convert(ErrorMessageEnum.ERROR_USER_SHOP_TERMINAL_NOTFOUND.getCode(), ArrayUtil.toArrayString(new String[]{userApi.getLenovoid(),shopId+"",terminal+""}));
                }


                List<SalescouponsInfoApi> list_s_InfoApi = new ArrayList<SalescouponsInfoApi>();
                SalescouponsInfoApi salescouponsInfoApi = null;
                for(Membercouponrels m : list_mc){
                    salescouponsInfoApi = new SalescouponsInfoApi();
                    salescouponsInfoApi.setAmount(m.getAmount());
                    salescouponsInfoApi.setCurrencyAmount(m.getAmount() == null ? new BigDecimal(0) : m.getAmount().getAmount());
                    salescouponsInfoApi.setConditions(m.getConditions());
                    salescouponsInfoApi.setFromtime(m.getFromtime());
                    salescouponsInfoApi.setTotime(m.getTotime());
                    salescouponsInfoApi.setDescription(m.getDescription());
                    salescouponsInfoApi.setShopid(m.getShopid());
                    salescouponsInfoApi.setTerminal(m.getTerminal());
                    salescouponsInfoApi.setName(m.getName());
                    salescouponsInfoApi.setUsescope(m.getUsescope());
                    salescouponsInfoApi.setType(m.getType());
                    salescouponsInfoApi.setClassification(m.getClassification());
                    salescouponsInfoApi.setSuperposition(m.getSuperposition());
                    list_s_InfoApi.add(salescouponsInfoApi);
                }

                result.setResultCode(CouponConstant.RESULT_CODE_SUC);
                result.setResultMsg(CouponConstant.RESULT_MSG_SUC);
                result.setT(list_s_InfoApi);
                result.setSuccess(true);
                log.info("getSalescouponsWithLenovoId 结果：" + result);
            }
        } catch (Exception e) {
            log.error("getSalescouponsWithLenovoId 异常：" + ExceptionUtil.getStackTrace(e));
            result.setResultCode(CouponConstant.RESULT_CODE_ERROR);
            result.setResultMsg(CouponConstant.RESULT_MSG_ERROR);
            result.setSuccess(false);
            return result;
        }
        return result;
    }



    /**
     * 查找距商品最近的分类所绑定的优惠券，如果一个分类绑定多个C2C优惠券，
     * 则返回金额最大的优惠券。
     * @param categorycodeId
     * @param gcodes
     * @param bindCategoryCoupons
     * @param detailsRules
     * @return
     */
    private Salescoupons findProperCoupon(String categorycodeId, String gcodes, Map<String, Salescoupons> bindCategoryCoupons, List<Detailsrule> detailsRules) {
        Salescoupons targetCoupon = null;
        for(Detailsrule detailsrule: detailsRules){
            String goodsCategoryId = detailsrule.getGoodscategoryid();
            String couponId = String.valueOf(detailsrule.getSalescouponid());
            String noJoinGoodsCodes = detailsrule.getNojoincodes() == null ? "" : detailsrule.getNojoincodes();
            if(goodsCategoryId.equals(categorycodeId) && noJoinGoodsCodes.indexOf(gcodes) < 0){
                if(targetCoupon == null){
                    targetCoupon = bindCategoryCoupons.get(couponId);
                }else{
                    Money targetAmount = targetCoupon.getAmount();
                    Salescoupons currentCoupon =  bindCategoryCoupons.get(couponId);
                    Money currentAmount = currentCoupon.getAmount();
                    if(currentAmount.compareTo(targetAmount) == 1){
                        targetCoupon = currentCoupon;
                    }
                }
            }
        }
        if(targetCoupon == null){
            String parentCategoryCodeId = categorycodeId.substring(0, categorycodeId.length()-2);
            if(parentCategoryCodeId != null && parentCategoryCodeId.length() > 0) {
                findProperCoupon(parentCategoryCodeId, gcodes, bindCategoryCoupons, detailsRules);
            }else {
                return null;
            }
        }
        return targetCoupon;
    }

    private RemoteResult bindC2CCouponToMember(UserApi userApi, RemoteResult result, Salescoupons targetCoupon, long bindStartTime) {
        ResponseResult existCouponList = memberCouponrelsManager.getMemberCoupons(userApi.getLenovoid(), targetCoupon.getId());
        if(existCouponList != null && existCouponList.isSuccess()){
            log.info("{} is already has coupon{}, no need bind again.", userApi.getUsername(), targetCoupon.getId());
            result.setResultCode(CouponConstant.RESULT_CODE_SUC);
            result.setResultMsg("用户已拥有该优惠券");
            result.setSuccess(true);
            log.info("bind C2C Coupon used: " + (System.currentTimeMillis() - bindStartTime) + "ms");
            return result;
        }
        Membercouponrels membercouponrels = makeMembercouponrels(targetCoupon, userApi);
        List<Membercouponrels> membercouponrelsList = new ArrayList<Membercouponrels>();
        membercouponrelsList.add(membercouponrels);
        RemoteResult remoteResult = memberCouponrelsManager.insertBatch(membercouponrelsList);
        log.info("bind C2C Coupon used: " + (System.currentTimeMillis() - bindStartTime) + "ms");
        if(remoteResult != null && remoteResult.isSuccess()){
            log.info(String.format("bind C2C coupon{} to {} success.", targetCoupon.getId(), userApi.getUsername()));
            result.setResultCode(CouponConstant.RESULT_CODE_SUC);
            result.setResultMsg(CouponConstant.RESULT_MSG_SUC);
            result.setSuccess(true);
            return result;
        }else {
            log.info(String.format("bind C2C coupon[%d] to %s failure.", targetCoupon.getId(), userApi.getUsername()));
            result.setResultCode(CouponConstant.RESULT_CODE_ERROR);
            result.setResultMsg("绑C2C券失败！");
            result.setSuccess(false);
            return result;
        }
    }



    /**
     *单个用户批量赠送指定优惠券,对外接口
     * @param couponIds
     * @param lenovoId
     * @param memberCode
     * @return
     */
    @Override
    public RemoteResult bindBatchCoupons(String couponIds, String lenovoId, String memberCode) {
        log.info("bindBatchCoupons 参数：couponIds=[" + couponIds + "],lenovoId=[" + lenovoId + "] ,terminal=[" + memberCode + "] ");
        RemoteResult result = new RemoteResult(false);
        try {
            String[] ids_array = couponIds.split(",");
            //对传入的couponIds去重
            List<String> ck_containsCouponIds = checkRepetitionCouponIds(ids_array);
            int inportCouponsSize = ck_containsCouponIds.size();
            Map paramMap = new HashMap();
            paramMap.put("ids", ck_containsCouponIds.toArray());
            //查询传入的优惠券ID
            ResponseResult<List<Salescoupons>> resSales = salescouponsManager.getSalescouponsList(paramMap);
            if (resSales.isSuccess() && resSales.getData() != null && resSales.getData().size() > 0){
                List<Salescoupons> list =  resSales.getData();
                //验证优惠券有效信息
                List<ErroeSalesCoupons> erlist = checkCoupons(list);
                if (list.size() < inportCouponsSize){
                    List<String> existCouponIds =  new ArrayList<String>();
                    List<String> uploadCouponIds = new ArrayList<String>();
                    //取出查询的couponsIds
                    for (int i=0;i<list.size();i++){
                        existCouponIds.add(list.get(i).getId().toString());
                    }
                    //传入的couponsIds
                    for (String coupon : ck_containsCouponIds){
                        uploadCouponIds.add(coupon);
                    }
                    //显示为找到的优惠券id getRemoveAll 传入数据，查出数据
                    List NotFindCouponsList = getRemoveAll(uploadCouponIds,existCouponIds);
//                    result.setResultCode("01");
//                    result.setResultMsg("bindBatchCoupons!发券失败！有未找到的优惠券");
//                    result.setT(NotFindCouponsList);
//                    result.setSuccess(false);
                    log.info("bindBatchCoupons未找到优惠券： " + NotFindCouponsList);
//                    return result;
                    return RemoteResultUtil.convert(ErrorMessageEnum.ERROR_CANT_FIND_COUPON_INOF);
                }else {
                    if (erlist.size()>0){
//                        result.setResultCode("02");
//                        result.setResultMsg("bindBatchCoupons!发券失败！");
//                        result.setT(erlist);
//                        result.setSuccess(false);
                        log.info("bindBatchCoupons 结果： " + erlist);
//                        return result;
                        return   RemoteResultUtil.convert(ErrorMessageEnum.ERROR_SEND_COUPON_FAIL);
                    }else if(erlist.size()==0){
                        List<Membercouponrels> memlist = new ArrayList<Membercouponrels>();
                        for (int i=0;i<list.size();i++){
                            Membercouponrels member = new Membercouponrels();
                            member.setId(Long.parseLong(idSequenceService.genId()));
                            member.setLenovoid(lenovoId);
                            member.setMembercode(memberCode);
                            member.setSalescouponid(list.get(i).getId());
                            member.setCouponcode(list.get(i).getCouponcode());
                            member.setUsescope(list.get(i).getUsescope());
                            member.setShopid(list.get(i).getShopid());
                            member.setName(list.get(i).getName());
                            member.setAmount(list.get(i).getAmount());
                            member.setTerminal(list.get(i).getTerminal());
                            member.setConditions(list.get(i).getConditions());
                            member.setType(list.get(i).getType());
                            member.setFromtime(list.get(i).getFromtime());
                            member.setTotime(list.get(i).getTotime());
                            member.setEppgroup(list.get(i).getEppgroup());
                            member.setTotalnumber(list.get(i).getTotalnumber());
                            member.setSurplusnumber(list.get(i).getSuperposition());
                            member.setCouponsource(CouponConstant.COUPON_SOURCE_EXCEL);
                            member.setClassification(list.get(i).getClassification());
                            member.setClassificationname(list.get(i).getClassificationName());
                            member.setSuperposition(list.get(i).getSuperposition());
                            member.setCreatetime(new Date());
                            member.setUpdatetime(new Date());
                            member.setCreateby(list.get(i).getCreateby());
                            member.setDescription(list.get(i).getDescription());
                            member.setDisabled(0);
                            member.setStatus(0);
                            member.setCurrencyCode(list.get(i).getCurrencyCode());
                            memlist.add(member);
                        }
                        RemoteResult<Boolean> remoteResult =  memberCouponrelsManager.insertBatch(memlist);
                        if (remoteResult.isSuccess()){
                            result.setResultCode("00");
                            result.setResultMsg("bindBatchCoupons!发券成功！");
                            result.setT(memlist.toArray());
                            result.setSuccess(true);
                            log.info("bindBatchCoupons 成功");
                            return result;
                        }
                    }
                }
            }else if (!resSales.isSuccess()&&resSales.getData()==null){
                    List<String> uploadCouponIds = new ArrayList<String>();
                    //传入的couponsIds
                    for (String coupon : ck_containsCouponIds){
                        uploadCouponIds.add(coupon);
                    }
                    return   RemoteResultUtil.convert(ErrorMessageEnum.ERROR_PARA);
            }else{
            	 return   RemoteResultUtil.convert(ErrorMessageEnum.ERROR_CANT_FIND_COUPON_INOF);
            }
        }catch (Exception e){
        	 return   RemoteResultUtil.convert(ErrorMessageEnum.ERROR_SERVICE);
        }
        return result;
    }

    @Override
    public RemoteResult getUserIshaveTheCoupon(Map map) {
        log.info("getUserIshaveTheCoupon参数：lenovoId="+map.get("lenovoId")+",membercode="+map.get("membercode")+",salesCouponIds="+map.get("salesCouponIds"));
        RemoteResult result = new RemoteResult(false);
        try {
            ResponseResult<List<Membercouponrels>> res = memberCouponrelsManager.getUserIshaveTheCoupon(map);
            if (res.isSuccess() && res.getData()!=null){
                List<Membercouponrels> list = res.getData();
                List<Membercouponrels> listApi = new ArrayList<Membercouponrels>();
                Membercouponrels memApi = null;
                for (Membercouponrels mem : list){
                    memApi = new Membercouponrels();
                    new DomainUtil().copy(mem,memApi);
                    listApi.add(memApi);
                }
                result.setResultMsg(CouponConstant.RESULT_MSG_SUC);
                result.setResultCode(CouponConstant.RESULT_CODE_SUC);
                result.setT(listApi);
                result.setSuccess(true);
            }else {
                result.setResultMsg(CouponConstant.RESULT_MSG_FAIL);
                result.setResultCode(CouponConstant.RESULT_CODE_FAIL);
                result.setSuccess(false);
            }
        }catch (Exception e){
            log.error("getUserIshaveTheCoupon 异常：" + ExceptionUtil.getStackTrace(e));
            result.setResultMsg(CouponConstant.RESULT_MSG_FAIL);
            result.setResultCode(CouponConstant.RESULT_CODE_FAIL);
            result.setSuccess(false);
        }
        return result;
    }

    @Override
    public RemoteResult getUserSalescouponsWithLenovoId(Tenant tenant, UserApi userApi, String terminal) {

        return this.getUserSalescouponsWithLenovoId(userApi, String.valueOf(tenant.getShopId()), terminal);
    }

    @Override
    public RemoteResult getUserSalescouponsWithLenovoId(UserApi userApi, String shopId, String terminal) {
        /*if(updateConfig.getShardingFlag()){
            return  newMemberCouponsApi.getUserSalescouponsWithLenovoId(userApi,shopId,terminal);
        }*/
        log.info("getUserSalescouponsWithLenovoId 参数：userApi=["+userApi+"],shopId=["+shopId+"] ,terminal=["+terminal+"] ");
        RemoteResult result = new RemoteResult(false);
        try {
            if(userApi == null || hasBlankParameter(userApi.getLenovoid(), userApi.getUsername(), shopId, terminal)){
                log.info("getUserSalescouponsWithLenovoId ： 参数错误！");
                result.setResultCode(CouponConstant.RESULT_CODE_ERROR_PARAM);
                result.setResultMsg(CouponConstant.RESULT_MSG_ERROR_PARAM);
                log.info("getUserSalescouponsWithLenovoId 结果："+result);
                return result;
            }
            ResponseResult<List<Membercouponrels>> res = memberCouponrelsManager.getMemberAllEffectiveCoupons(userApi.getLenovoid(), shopId, null);
            if(res.isSuccess() && res.getData() != null ){
                List<Membercouponrels> list_mc = res.getData();
                log.info("getUserSalescouponsWithLenovoId 用户的券为"+(list_mc != null ? list_mc.size() : null));
                if(list_mc.size() == 0){
                    log.info("getUserSalescouponsWithLenovoId 用户["+userApi+"]在商城["+shopId+"] 平台["+terminal+"]上没有有效的优惠券！");
                    return RemoteResultUtil.convert(ErrorMessageEnum.ERROR_USER_SHOP_TERMINAL_NOTFOUND.getCode(), ArrayUtil.toArrayString(new String[]{userApi.getLenovoid(),shopId+"",terminal+""}));
                }
                List<SalescouponsInfoApi> list_s_InfoApi = new ArrayList<SalescouponsInfoApi>();
                SalescouponsInfoApi salescouponsInfoApi = null;
                for(Membercouponrels m : list_mc){
                    salescouponsInfoApi = new SalescouponsInfoApi();
                    salescouponsInfoApi.setId(m.getId());
                    salescouponsInfoApi.setSalesCouponId(m.getSalescouponid());
                    salescouponsInfoApi.setAmount(m.getAmount());
                    salescouponsInfoApi.setConditions(m.getConditions());
                    salescouponsInfoApi.setFromtime(m.getFromtime());
                    salescouponsInfoApi.setTotime(m.getTotime());
                    salescouponsInfoApi.setDescription(m.getDescription());
                    salescouponsInfoApi.setShopid(m.getShopid());
                    salescouponsInfoApi.setTerminal(m.getTerminal());
                    salescouponsInfoApi.setName(m.getName());
                    salescouponsInfoApi.setUsescope(m.getUsescope());
                    salescouponsInfoApi.setType(m.getType());
                    salescouponsInfoApi.setClassification(m.getClassification());
                    salescouponsInfoApi.setSuperposition(m.getSuperposition());
                    list_s_InfoApi.add(salescouponsInfoApi);
                }

                result.setResultCode(CouponConstant.RESULT_CODE_SUC);
                result.setResultMsg(CouponConstant.RESULT_MSG_SUC);
                result.setT(list_s_InfoApi);
                result.setSuccess(true);
                log.info("getUserSalescouponsWithLenovoId 结果：" + result);
            }
        } catch (Exception e) {
            log.error("getUserSalescouponsWithLenovoId 结果：" + ExceptionUtil.getStackTrace(e));
            result.setResultCode(CouponConstant.RESULT_CODE_ERROR);
            result.setResultMsg(CouponConstant.RESULT_MSG_ERROR);
            result.setSuccess(false);
            return result;
        }
        return result;
    }

    //对比传入和查出的couponIds
    private List getRemoveAll(List<String> uploadCouponIds, List<String> existCouponIds ){
        List<String> notExistCoupons = new ArrayList<String>();
        for(String couponId : uploadCouponIds){
            if(existCouponIds.indexOf(couponId) < 0){
                notExistCoupons.add(couponId);
            }
        }
        return notExistCoupons;
    }

    /**
     * 单个用户批量赠送指定优惠券,传入优惠券去重
     * @param ids_array
     */
    public List<String> checkRepetitionCouponIds(String[] ids_array){
        List<String> list = new ArrayList<String>();
        for (int i = 0; i < ids_array.length; i++) {
            if (!list.contains(ids_array[i])) {// 如果数组 list 不包含当前项，则增加该项到数组中
                list.add(ids_array[i]);
            }
        }
        String[] newStr = list.toArray(new String[1]);
        return list;
    }

    //验证优惠券有效信息
    private List<ErroeSalesCoupons> checkCoupons(List<Salescoupons> list) {
        List<ErroeSalesCoupons> errorList = new ArrayList<ErroeSalesCoupons>();
        ErroeSalesCoupons errorSalesCoupons = null;
        Date currentTime = new Date();
        Date getendtime = null;
        Date getstarttime = null;
        Date toTime = null;
        Date fromtime =null;
        for (int i = 0; i < list.size(); i++) {
            errorSalesCoupons = new ErroeSalesCoupons();
            String message = "";
            String code = "";
            toTime = list.get(i).getTotime();
            fromtime = list.get(i).getFromtime();
            if (list.get(i).getStatus() != 2) {
                //是否审核通过
                if (list.get(i).getStatus() != 2) {
                    code = "01";
                    message = "审核状态错误;";
                }
            }
            //是否可领取
            if (list.get(i).getIscanget() != 1) {
                if (code == "") {
                    code = code + "02";
                } else {
                    code = code + ",02,";
                }
                message = message + "不可领取的优惠券;";
            }
            //可领取时验证领取时间
            if (list.get(i).getIscanget() == 1) {
                getendtime = list.get(i).getGetendtime();
                getstarttime = list.get(i).getGetstarttime();
                if (null == getendtime || null == getstarttime){
                    //领取时间验证
                    if (code == "") {
                        code = code + "03";
                    } else {
                        code = code + ",03,";
                    }
                    message = message + "领取时间为空;";
                }else {
                    if (currentTime.after(getendtime) || currentTime.before(getstarttime)) {
                        //领取时间验证
                        if (code == "") {
                            code = code + "03";
                        } else {
                            code = code + ",03,";
                        }
                        message = message + "领取时间错误;";
                    }
                }

            }
            //有效时间验证
            if (null == toTime || null == fromtime){
                if (code == "") {
                    code = "04";
                } else {
                    code = code + "04";
                }
                message = message+"有效开始时间或结束时间为空;";
            }else {
                if (currentTime.after(toTime)) {
                    if (code == "") {
                        code = "04";
                    } else {
                        code = code + "04";
                    }
                    message = message+"有效时间错误;";
                }
            }
            if (message != "") {
                errorSalesCoupons.setCouponIds(list.get(i).getId());
                errorSalesCoupons.setCouponName(list.get(i).getName());
                errorSalesCoupons.setCode(code);
                errorSalesCoupons.setMsg(code + ";" + message);
                errorList.add(errorSalesCoupons);
            }


        }
        if (errorList.size() != 0) {
            log.info("验证错误信息：" + errorList);
        }
        return errorList;
    }

    /**
     * 封装以旧换新代金券对象
     * @param shopId
     * @param terminal
     * @param couponamount
     * @return
     */
    private Salescoupons makeSalescoupons(String shopId, String terminal, BigDecimal couponamount, String currencyCode){
        Salescoupons salescoupons = new Salescoupons();
        try {
            salescoupons.setStyle(CouponConstant.COUPON_style_coupon_1);
            salescoupons.setAmount(new Money(couponamount, currencyCode));
            salescoupons.setCouponcode("OldfornewCash");//todo
            salescoupons.setName("以旧换新代金券");
            salescoupons.setType(CouponConstant.COUPON_TYPE_NEIHTER_0);
            salescoupons.setShopid(shopId);
            salescoupons.setTerminal(terminal);
            Date d = new Date();
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd 00:00:00");
            salescoupons.setFromtime(sdf.parse(sdf.format(d)));
            salescoupons.setGetstarttime(sdf.parse(sdf.format(d)));
            Calendar cal = Calendar.getInstance();
            cal.setTime(d);
            cal.add(Calendar.YEAR, 3);//有效期3年
            salescoupons.setTotime(sdf.parse(sdf.format(cal.getTime())));
            salescoupons.setGetendtime(sdf.parse(sdf.format(cal.getTime())));
            salescoupons.setUsescope(CouponConstant.COUPON_USESCOPE_YIJIUHUANXINDAIJINQUAN);
            salescoupons.setCouponway(null);
            salescoupons.setDescription("代金券可以在以旧换新区中使用");
            salescoupons.setHaspassed(1);//默认依旧审核过
            salescoupons.setStatus(CouponConstant.COUPON_STATUS_PASTAUDIT_2);
            salescoupons.setIscanget(CouponConstant.COUPON_ISCANGET_CAN);//可以领取1
            salescoupons.setBacksend(CouponConstant.COUPON_Backsend_1);//默认已经发过券了
            salescoupons.setClassification(0);//依旧换新代金券的分类 默认为0
            salescoupons.setNoticeInvalidCount(0);
            salescoupons.setNoticeValidCount(0);
            salescoupons.setSuperposition(CouponConstant.COUPON_Superposition_FALSE);//是否叠加 不叠加，一个订单只能用一张券
            salescoupons.setCreateby("Oldfornew");
            salescoupons.setCreatetime(d);
            salescoupons.setUpdatetime(d);
            salescoupons.setLimitSymbol(1);
            salescoupons.setCurrencyCode(currencyCode);
        } catch (ParseException e) {
            log.error("封装以旧换新代金券异常：" + ExceptionUtil.getStackTrace(e));
        }
        return salescoupons;
    }

    /**
     * 封装用户优惠券信息
     * @param salescoupons
     * @param userApi
     * @return
     */

    private Membercouponrels makeMembercouponrels(Salescoupons salescoupons,UserApi userApi){
        Membercouponrels membercouponrels = new Membercouponrels();
        membercouponrels.setId(Long.parseLong(idSequenceService.genId()));
        membercouponrels.setMembercode(userApi.getUsername());
        membercouponrels.setLenovoid(userApi.getLenovoid());
        membercouponrels.setSalescouponid(salescoupons.getId());
        membercouponrels.setUsescope(salescoupons.getUsescope());
        membercouponrels.setCouponcode(salescoupons.getCouponcode());
        membercouponrels.setShopid(salescoupons.getShopid());
        membercouponrels.setTerminal(salescoupons.getTerminal());
        membercouponrels.setName(salescoupons.getName());
        membercouponrels.setAmount(salescoupons.getAmount());
        membercouponrels.setConditions(salescoupons.getConditions());
        membercouponrels.setType(salescoupons.getType());
        membercouponrels.setDescription(salescoupons.getDescription());
        membercouponrels.setFromtime(salescoupons.getFromtime());
        membercouponrels.setTotime(salescoupons.getTotime());
        membercouponrels.setTotalnumber(salescoupons.getTotalnumber());
        membercouponrels.setSurplusnumber(salescoupons.getTotalnumber());
        membercouponrels.setClassification(salescoupons.getClassification());
        membercouponrels.setSuperposition(salescoupons.getSuperposition());
        membercouponrels.setCouponsource(CouponConstant.COUPON_SOURCE_API);
        membercouponrels.setBatchno(String.valueOf(new Date().getTime()));
        membercouponrels.setStatus(0);//0未使用 1已使用
        membercouponrels.setDisabled(0);//0未禁用 1已禁用
        membercouponrels.setCreatetime(new Date());
        membercouponrels.setUpdatetime(new Date());
        membercouponrels.setCreateby(userApi.getLenovoid());
        membercouponrels.setCurrencyCode(salescoupons.getCurrencyCode());
        return membercouponrels;
    }

    /**
     * 判断参数是否有null或空，如果有返回true，否则返回false
     * @param params
     * @return
     */
    private boolean hasBlankParameter(String... params){
        boolean result = false;
        for (String param : params){
            if(StringUtils.isEmpty(param)){
                result = true;
            }
        }
        return result;
    }
}
