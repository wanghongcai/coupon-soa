package com.lenovo.m2.couponV2.service.launcher;

import com.lenovo.m2.couponV2.common.exception.ExceptionUtil;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;



/**
 * 功能描述：服务提供者
 */
public class Provider {
    private static final Logger logger = 
    		LoggerFactory.getLogger(Provider.class);
    private static volatile boolean running = true;
    private static ApplicationContext ctx;

    public static void main(String[] args){
        try{
            ctx = new ClassPathXmlApplicationContext(
                    new String[]{
                            "classpath:applicationContext-resources.xml",
                            "classpath:applicationContext-dao.xml",
                            "classpath:applicationContext-coupon-manager.xml",
                            "classpath:applicationContext-coupon-service.xml",
                            "classpath:applicationContext-aop.xml",
                            "classpath:applicationContext-redis-shard.xml",
                            "classpath:applicationContext-provider.xml",
                            "classpath:applicationContext-rpc.xml",
                            "classpath:applicationContext-dubbo-rpc.xml",
                    }
            );
            logger.info("hs-coupon-soa server started====.");
            System.out.println("hs-coupon-soa server started====.");
        }catch (Exception e){
            running  = false;
            logger.error(ExceptionUtil.getStackTrace(e));
        }

        synchronized (Provider.class) {
            while (running) {
                try {
                    Provider.class.wait();
                } catch (Exception e) {
                }
            }
        }
    }
}
