package com.lenovo.m2.couponV2.service.impl;

import com.lenovo.m2.arch.framework.domain.PageModel2;
import com.lenovo.m2.arch.framework.domain.PageQuery;
import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.couponV2.api.model.OneKeyToReceiveApi;
import com.lenovo.m2.couponV2.api.model.SalescouponsApi;
import com.lenovo.m2.couponV2.api.service.OneKeyToReceiveService;
import com.lenovo.m2.couponV2.common.CouponConstant;
import com.lenovo.m2.couponV2.common.DomainUtil;
import com.lenovo.m2.couponV2.common.RemoteResultUtil;
import com.lenovo.m2.couponV2.common.enums.ActivityEnum;
import com.lenovo.m2.couponV2.common.enums.ErrorMessageEnum;
import com.lenovo.m2.couponV2.common.util.JsonUtil;
import com.lenovo.m2.couponV2.dao.mybatis.model.Membercouponrels;
import com.lenovo.m2.couponV2.dao.mybatis.model.OneKeyToReceive;
import com.lenovo.m2.couponV2.dao.mybatis.model.Salescoupons;
import com.lenovo.m2.couponV2.dao.util.ResponseResult;
import com.lenovo.m2.couponV2.manager.MemberCouponrelsManager;
import com.lenovo.m2.couponV2.manager.OneKeyToReceiveManager;
import com.lenovo.m2.couponV2.manager.SalescouponsManager;
import com.lenovo.m2.couponV2.remote.IDSequenceService;
import com.lenovo.m2.couponV2.service.util.StringUtil;
import org.apache.commons.collections.map.HashedMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

/**
 * Created by pxg01 on 2017/7/4.
 */
@Service("oneKeyToReceiveService")
public class OneKeyToReceiveServiceImpl implements OneKeyToReceiveService {
    private static Logger logger = LoggerFactory.getLogger(OneKeyToReceiveServiceImpl.class);
    @Autowired
    private OneKeyToReceiveManager oneKeyToReceiveManager;
    @Autowired
    private SalescouponsManager salescouponsManager;
    @Autowired
    private MemberCouponrelsManager memberCouponrelsManager;
    @Autowired
    private IDSequenceService idSequenceService;
    @Override
    public RemoteResult addReceiveActivity(OneKeyToReceiveApi oneKeyToReceiveApi) {
        RemoteResult result = new RemoteResult();
        //校验是否存在有效的名称相同的活动
        try {
            OneKeyToReceive receives = oneKeyToReceiveManager.getActivityName(oneKeyToReceiveApi.getActivityName());
            if(receives!= null && 0 != receives.getId()){
                logger.info("存在名称相同的活动 activityid={}",receives.getId());
                return RemoteResultUtil.convert(ErrorMessageEnum.ERROR_SAME_ACTIVITY_NAME);
            }
            String[] ids = oneKeyToReceiveApi.getSalecouponsIds().split(",");

            OneKeyToReceive receive = new OneKeyToReceive();
            BeanUtils.copyProperties(oneKeyToReceiveApi,receive);
            receive.setOneKeyUpdateTime(receive.getOneKeyCreateTime());
            receive.setOneKeyUpdateby(receive.getOneKeyCreateby());
            receive.setActivityType(ActivityEnum.LUHAN_FANS.getCode());
            int sum = oneKeyToReceiveManager.addReceiveActivity(receive);
            result.setSuccess(true);
            result.setResultMsg(ErrorMessageEnum.SUCCESS.getCommon());
            result.setResultCode(ErrorMessageEnum.SUCCESS.getCode());

            return result;
        } catch (Exception e) {
            logger.error("exception",e);
            return RemoteResultUtil.convert(ErrorMessageEnum.ERROR_SERVICE);
        }


    }

    @Override
    public RemoteResult editReceiveActivity(OneKeyToReceiveApi oneKeyToReceiveApi) {
        RemoteResult result = new RemoteResult();
        //校验是否存在有效的名称相同的活动
        try {
            OneKeyToReceive re = oneKeyToReceiveManager.getActivityName(oneKeyToReceiveApi.getActivityName());
            logger.info(">>>>>>>>>>>>>>>>>...re={}",JsonUtil.toJson(re));
            if(re != null && !re.getId().equals(oneKeyToReceiveApi.getId())){
                logger.info("存在名称相同的活动 activityid={}",re.getId());
                return RemoteResultUtil.convert(ErrorMessageEnum.ERROR_SAME_ACTIVITY_NAME);
            }


            String[] ids = oneKeyToReceiveApi.getSalecouponsIds().split(",");


            OneKeyToReceive receive = new OneKeyToReceive();
            BeanUtils.copyProperties(oneKeyToReceiveApi,receive);

            int sum = oneKeyToReceiveManager.editReceiveActivity(receive);
            result.setSuccess(true);
            result.setResultMsg(ErrorMessageEnum.SUCCESS.getCommon());
            result.setResultCode(ErrorMessageEnum.SUCCESS.getCode());

            return result;
        } catch (Exception e) {
            logger.error("exception",e);
            return RemoteResultUtil.convert(ErrorMessageEnum.ERROR_SERVICE);
       }


    }

    @Override
    public RemoteResult deleteReceiveActivity(Map map) {
       RemoteResult result = new RemoteResult();
        try {

            //根据活动id 查询优惠券详情
            String ids = (String) map.get("id");
            String[] split = ids.split(",");
            System.out.println(JsonUtil.toJson(split));
            map.put("ids",split);

            int delete = oneKeyToReceiveManager.deleteReceiveActivity(map);
            if(delete > 0){
                result.setT(true);
                result.setSuccess(true);
                result.setResultCode(ErrorMessageEnum.SUCCESS.getCode());
                result.setResultMsg(ErrorMessageEnum.SUCCESS.getCommon());
                return result;
            }

            logger.error("删除活动失败");
            return RemoteResultUtil.convert(ErrorMessageEnum.ERROR_DELETE_ONE_KEY_ACTIVITY);
        } catch (Exception e) {
            logger.error("exception",e);
            return RemoteResultUtil.convert(ErrorMessageEnum.ERROR_SERVICE);
        }
    }
    //分页查询一键获活动信息接口
    @Override
    public RemoteResult<PageModel2<OneKeyToReceiveApi>> getReceiveActivity(PageQuery pageQuery, Map map) {
        RemoteResult result = new RemoteResult();
        try {
            PageModel2<OneKeyToReceive> receiveActivity = null;
            String couponsname = (String) map.get("couponsname");
            //优惠券名称为空 只查询活动表
            if(StringUtil.isEmpty(couponsname)){
                receiveActivity = oneKeyToReceiveManager.getReceiveActivityByCondityon(pageQuery, map);
                logger.info("单查活动表返回datas={}", JsonUtil.toJson(receiveActivity));
            }else {
                receiveActivity = oneKeyToReceiveManager.getReceiveActivity(pageQuery, map);
                logger.info("关联查询表返回datas={}", JsonUtil.toJson(receiveActivity));
            }

            logger.info("getReceiveActivity datas={}", JsonUtil.toJson(receiveActivity));
            if(receiveActivity !=null && receiveActivity.getDatas() != null){
                List<OneKeyToReceive> datas = receiveActivity.getDatas();
               List<OneKeyToReceiveApi> apiList = new ArrayList<OneKeyToReceiveApi>();
                for (OneKeyToReceive onekeyreceive: datas) {
                    OneKeyToReceiveApi api = new OneKeyToReceiveApi();
                    DomainUtil domain = new DomainUtil();
                    try {
                        domain.copy(onekeyreceive,api);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    apiList.add(api);
                }

                result.setT(new PageModel2<OneKeyToReceiveApi>(pageQuery,apiList));

            }
            result.setSuccess(true);
            result.setResultCode(ErrorMessageEnum.SUCCESS.getCode());
            result.setResultMsg(ErrorMessageEnum.SUCCESS.getCommon());
            return result;

        } catch (Exception e) {
            logger.error("error occour",e);
           return  RemoteResultUtil.convert(ErrorMessageEnum.ERROR_SERVICE);
        }


    }

    @Override
    public RemoteResult confirmUserIfJoinTheAcitity(String lenovoId, Integer activityType) {
        RemoteResult result = new RemoteResult();
        try {
            String s = oneKeyToReceiveManager.confirmUserIfJoinTheAcitity(lenovoId, activityType,"");
            result.setSuccess(true);
            result.setResultCode(ErrorMessageEnum.SUCCESS.getCode());
            result.setResultMsg(ErrorMessageEnum.SUCCESS.getCommon());
            result.setT(s);
            return result;

        } catch (Exception e) {
            logger.error("occor error",e);
            return RemoteResultUtil.convert(ErrorMessageEnum.ERROR_SERVICE);

        }
    }

    @Override
    public RemoteResult<PageModel2<SalescouponsApi>> getAviableSalesCoupons(PageQuery pageQuery, OneKeyToReceiveApi oneKeyToReceiveApi) {
            RemoteResult<PageModel2<SalescouponsApi>> result = new RemoteResult<PageModel2<SalescouponsApi>>();
        logger.info("getAviableSalesCoupons param={}",JsonUtil.toJson(oneKeyToReceiveApi));
        Map map = new HashedMap();
        map.put("name",oneKeyToReceiveApi.getName());
        map.put("fromTime",oneKeyToReceiveApi.getFromTime());
        map.put("toTime",oneKeyToReceiveApi.getToTime());

        try {
            PageModel2<Salescoupons> onekeySalecoupons = salescouponsManager.getOnekeySalecoupons(pageQuery, map);
            logger.info("getOnekeySalecoupons return ={}",onekeySalecoupons);
            if(onekeySalecoupons != null && onekeySalecoupons.getDatas() != null){
                List<Salescoupons> datas = onekeySalecoupons.getDatas();
                List<SalescouponsApi> apiList = new ArrayList<SalescouponsApi>();
                for(Salescoupons s : datas){
                    SalescouponsApi api = new SalescouponsApi();
                    DomainUtil util = new DomainUtil();
                    util.copy(s,api);
                    apiList.add(api);
                }

                PageModel2<SalescouponsApi> salescouponsApi = new PageModel2<SalescouponsApi>(pageQuery, apiList);
                result.setSuccess(true);
                result.setT(salescouponsApi);
                result.setResultCode(ErrorMessageEnum.SUCCESS.getCode());
                result.setResultMsg(ErrorMessageEnum.SUCCESS.getCommon());
                return  result;
            }
        } catch (Exception e) {
            logger.error("execption",e);
            result.setResultCode(ErrorMessageEnum.ERROR_SERVICE.getCode());
            result.setResultMsg(ErrorMessageEnum.ERROR_SERVICE.getCommon());

        }
        return result;
    }

    @Override
    public RemoteResult bindCouponsForOneKeyPeople(String lenovoId, Integer activityType,String memberCode) {
       /*if(updateConfig.getShardingFlag()){
           return  newMemberCouponsApi.bindCouponsForOneKeyPeople(lenovoId,activityType,memberCode);
       }*/
        RemoteResult result = new RemoteResult();

        try {
            Map map = new HashedMap();
            map.put("activityType",activityType);
            List<OneKeyToReceive> datas = oneKeyToReceiveManager.getReceiveActivityForBinds(map);
            logger.info("getReceiveActivityForBinds return={}"+JsonUtil.toJson(datas));
             if(datas !=null && datas.size() >1){
                return  RemoteResultUtil.convert(ErrorMessageEnum.ERROR_ACTIVE_NOT_ONLY);
            }
            if(datas != null && datas.size() == 1){
                OneKeyToReceive receive = datas.get(0);
                //校验活动是否有效
                if(!processActivityIsAviable(result,datas)) return  result;
                //校验用户是否参加过该活动
                String s = oneKeyToReceiveManager.confirmUserIfJoinTheAcitity(lenovoId, activityType,receive.getActivityName());
                if(s != null){

                    result.setT(s);
                    result.setResultCode(ErrorMessageEnum.ERROR_ACTIVITY_CAN_NOT_JOIN.getCode());
                    result.setResultMsg(ErrorMessageEnum.ERROR_ACTIVITY_CAN_NOT_JOIN.getCommon());
                    return result;
                }
                //校验用户是否领过活动中的某张或某些券 有就不再发放
                String [] idArr = receive.getSalecouponsIds().split(",");


                Map param = new HashMap();
                param.put("lenovoId",lenovoId);
                param.put("memberCode",memberCode);
                param.put("salesCouponIds",idArr);
                param.put("activityType",activityType);
                param.put("activityName",receive.getActivityName());

                ResponseResult<List<Membercouponrels>> userIshaveTheCoupon = memberCouponrelsManager.getUserIshaveTheCoupon(param);
                Map sale_map = new HashMap();
                if(userIshaveTheCoupon != null && userIshaveTheCoupon.getData() != null){
                    logger.info("用户lenovoId={}已经拥有的优惠券Membercouponrels={}",lenovoId,JsonUtil.toJson(userIshaveTheCoupon.getData()));
                    List<Membercouponrels> mlist = userIshaveTheCoupon.getData();
                    Map map1 = changeList2Map(mlist);
                    List<Long> bindcouponsIds = new ArrayList<Long>();

                 //
                    for(String id : idArr){
                        if(map1.get(Long.parseLong(id)) == null){
                            bindcouponsIds.add(Long.parseLong(id));
                        }
                    }
                    logger.info("可发放的优惠券列表 list={}",JsonUtil.toJson(bindcouponsIds));
                    if(bindcouponsIds.size() == 0){
                        logger.info("用户已拥有该礼包中所有优惠券,不满足领取条件");
                        return RemoteResultUtil.convert(ErrorMessageEnum.ERROR_HAVING_ALL_THE_COUPONS);
                    }
                    sale_map.put("salesCouponIds",bindcouponsIds);
                }else{
                    sale_map.put("salesCouponIds",idArr);
                }


                List<Salescoupons> salescoupons = salescouponsManager.getSalescouponsBySalesCouponIdsForOneKey(sale_map);
                logger.info("用户绑定优惠券详情 list={}",JsonUtil.toJson(salescoupons));
                //绑券
                if(salescoupons != null && salescoupons.size()>0){
                    List<Membercouponrels> membercouponrelses = makeMembercouponrels(salescoupons, lenovoId, memberCode);
                    RemoteResult<Boolean> booleanRemoteResult = memberCouponrelsManager.insertBatch(membercouponrelses);
                    if(!booleanRemoteResult.getT()){
                        result.setResultMsg(ErrorMessageEnum.ERROR_SEND_COUPON_FAIL.getCommon());
                        result.setResultCode(ErrorMessageEnum.ERROR_SEND_COUPON_FAIL.getCode());
                        return  result;
                    }

                    //保存领取记录
                    int save = oneKeyToReceiveManager.saveOnekeygetinfo(param);
                    if(save >0){
                        result.setT(true);
                        result.setResultMsg(ErrorMessageEnum.SUCCESS.getCommon());
                        result.setResultCode(ErrorMessageEnum.SUCCESS.getCode());
                        return  result;
                    }

                }
            }
            return RemoteResultUtil.convert(ErrorMessageEnum.ERROR_ACTIVE_NOT_FOUND);
        } catch (Exception e) {
            logger.error("occor error",e);
            return RemoteResultUtil.convert(ErrorMessageEnum.ERROR_SERVICE);
        }
    }

private Map changeList2Map(List<Membercouponrels> list){
    Map map = new HashMap(list.size());
    for(Membercouponrels m :list){
        if(map.get(m.getSalescouponid()) == null){
            map.put(m.getSalescouponid(),m);
        }

    }
    return  map;
}
    @Override
    public RemoteResult<List<Salescoupons>> getOneKeyReceiveSalesCouponsInfo(Long activityId) {
        RemoteResult<List<Salescoupons>> result= new RemoteResult<List<Salescoupons>>();
        try {
            OneKeyToReceive activityInfo = oneKeyToReceiveManager.getActivityInfoById(activityId);
            if(activityInfo == null){
                return  RemoteResultUtil.convert(ErrorMessageEnum.ERROR_ACTIVE_NOT_FOUND);
            }
            String salecouponsIds = activityInfo.getSalecouponsIds();
            if(salecouponsIds == null){
                result.setSuccess(true);
                result.setResultMsg(ErrorMessageEnum.SUCCESS.getCommon());
                result.setResultCode(ErrorMessageEnum.SUCCESS.getCommon());
                return result;
            }
            String[] ids_array = salecouponsIds.split(",");
            Map map = new HashMap();
            map.put("ids",ids_array);
            ResponseResult<List<Salescoupons>> list = salescouponsManager.getSalescouponsList(map);
            result.setT(list.getData());
            result.setSuccess(true);
            result.setResultCode(ErrorMessageEnum.SUCCESS.getCode());
            result.setResultMsg(ErrorMessageEnum.SUCCESS.getCommon());
            return result;
        } catch (Exception e) {
            logger.error("occor error",e);
            return RemoteResultUtil.convert(ErrorMessageEnum.ERROR_SERVICE);

        }
    }

    @Override
    public RemoteResult setOneKeyUseable(Long activityId, Integer useable,String updateBy) {
        RemoteResult result = new RemoteResult();
        try {
            //1 启用  查询是否有正在启用还没到期的活动
            if(useable == 1){
                Integer integer = oneKeyToReceiveManager.selectAnyActivityIsHolding();
                if(integer > 0){
                    return RemoteResultUtil.convert(ErrorMessageEnum.ERROR_HAS_ACTIVITI_IS_HOLDING);
                }
            }
            int shopid = oneKeyToReceiveManager.setOnekeyUseable(activityId, useable,updateBy);
            if(shopid >0 ){
                result.setSuccess(true);
                result.setT(true);
                result.setResultMsg(ErrorMessageEnum.SUCCESS.getCommon());
                result.setResultCode(ErrorMessageEnum.SUCCESS.getCode());
                return result;
            }
            return RemoteResultUtil.convert(ErrorMessageEnum.ERROR_OPER_FAIL);
        } catch (Exception e) {
            logger.error("error >>>>>>>>>",e);
           return  RemoteResultUtil.convert(ErrorMessageEnum.ERROR_SERVICE);
        }
    }

    private List<Membercouponrels> makeMembercouponrels(List<Salescoupons> salescouponsList,String lenovoId,String membercode){
       List<Membercouponrels> list = new ArrayList<Membercouponrels>();
       for (Salescoupons salescoupons : salescouponsList){

           Membercouponrels membercouponrels = new Membercouponrels();
           membercouponrels.setId(Long.parseLong(idSequenceService.genId()));
           membercouponrels.setMembercode(membercode);
           membercouponrels.setLenovoid(lenovoId);
           membercouponrels.setSalescouponid(salescoupons.getId());
           membercouponrels.setUsescope(salescoupons.getUsescope());
           membercouponrels.setCouponcode(salescoupons.getCouponcode());
           membercouponrels.setShopid(salescoupons.getShopid());
           membercouponrels.setTerminal(salescoupons.getTerminal());
           membercouponrels.setName(salescoupons.getName());
           membercouponrels.setAmount(salescoupons.getAmount());
           membercouponrels.setConditions(salescoupons.getConditions());
           membercouponrels.setType(salescoupons.getType());
           membercouponrels.setDescription(salescoupons.getDescription());
           membercouponrels.setFromtime(salescoupons.getFromtime());
           membercouponrels.setTotime(salescoupons.getTotime());
           membercouponrels.setTotalnumber(salescoupons.getTotalnumber());
           membercouponrels.setSurplusnumber(salescoupons.getTotalnumber());
           membercouponrels.setClassification(salescoupons.getClassification());
           membercouponrels.setSuperposition(salescoupons.getSuperposition());
           membercouponrels.setCouponsource(CouponConstant.COUPON_SOURCE_API);
           membercouponrels.setBatchno(String.valueOf(new Date().getTime()));
           membercouponrels.setStatus(0);//0未使用 1已使用
           membercouponrels.setDisabled(0);//0未禁用 1已禁用
           membercouponrels.setCreatetime(new Date());
           membercouponrels.setUpdatetime(new Date());
           membercouponrels.setCreateby(lenovoId);
           membercouponrels.setCurrencyCode(salescoupons.getCurrencyCode());
           list.add(membercouponrels);
       }

        return list;
    }
    private  Boolean processActivityIsAviable(RemoteResult result,List<OneKeyToReceive> datas){
        Date fromTime = datas.get(0).getActivityfromTime();
        Date totime = datas.get(0).getActivitytoTime();
        Integer useable = datas.get(0).getUseable();
        //活动未开始
        if(fromTime.getTime() > new Date().getTime()){
           logger.info("活动未开始 id={}",datas.get(0).getId());
            result.setSuccess(false);
            result.setResultCode(ErrorMessageEnum.ERROR_ACTIVE_NOT_VALIDATE.getCode());
            result.setResultMsg(ErrorMessageEnum.ERROR_ACTIVE_NOT_VALIDATE.getCommon());
            return  false;
        }
        //活动已结束
        if (totime.getTime() < new Date().getTime()){
            logger.info("活动已经结束 id={}",datas.get(0).getId());
            result.setSuccess(false);
            result.setResultCode(ErrorMessageEnum.ERROR_ACTIVITY_HAS_BEEN_END.getCode());
            result.setResultMsg(ErrorMessageEnum.ERROR_ACTIVITY_HAS_BEEN_END.getCommon());
            return  false;
        }
        if(0 == useable){
            logger.info("活动不可用 id={}",datas.get(0).getId());
            result.setSuccess(false);
            result.setResultCode(ErrorMessageEnum.ERROR_ACTIVITY_HAS_BEEN_END.getCode());
            result.setResultMsg(ErrorMessageEnum.ERROR_ACTIVITY_HAS_BEEN_END.getCommon());
            return false;
        }
        return  true;
    };
}
