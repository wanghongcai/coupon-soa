package com.lenovo.m2.couponV2.service.impl;

import com.lenovo.m2.arch.framework.domain.*;
import com.lenovo.m2.arch.tool.util.CollectionUtils;
import com.lenovo.m2.arch.tool.util.StringUtils;
import com.lenovo.m2.couponV2.api.dubboModel.RpcCouponsApi;
import com.lenovo.m2.couponV2.api.dubboService.RpcCouponsService;
import com.lenovo.m2.couponV2.api.model.CouponsApi;
import com.lenovo.m2.couponV2.api.model.SalescouponsApi;
import com.lenovo.m2.couponV2.common.ArrayUtil;
import com.lenovo.m2.couponV2.common.CouponConstant;
import com.lenovo.m2.couponV2.common.RemoteResultUtil;
import com.lenovo.m2.couponV2.common.TripleDESUtil;
import com.lenovo.m2.couponV2.common.enums.ErrorMessageEnum;
import com.lenovo.m2.couponV2.common.enums.ModulNameEnum;
import com.lenovo.m2.couponV2.common.util.JsonUtil;
import com.lenovo.m2.couponV2.common.vo.LogVo;
import com.lenovo.m2.couponV2.dao.mybatis.model.Couponchecks;
import com.lenovo.m2.couponV2.dao.mybatis.model.Coupons;
import com.lenovo.m2.couponV2.dao.mybatis.model.Productrule;
import com.lenovo.m2.couponV2.dao.mybatis.model.Salescoupons;
import com.lenovo.m2.couponV2.dao.util.ResponseResult;
import com.lenovo.m2.couponV2.manager.*;
import com.lenovo.m2.couponV2.service.util.DomainUtil;
import org.apache.commons.lang.RandomStringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Created by zhaocl1 on 2016/3/15.
 */
@Service("rpcCouponsService")
public class RpcCouponsServiceImpl implements RpcCouponsService {
    private static final Logger log = LoggerFactory.getLogger(RpcCouponsServiceImpl.class);
    @Autowired
    private SalescouponsManager salescouponsManager;
    @Autowired
    private CouponsManager couponsManager;
    @Autowired
    private ProductruleManager productruleManager;
    @Autowired
    private CouponsLogManager couponsLogManager;
    @Autowired
    private CouponchecksManager couponchecksManager;
    @Autowired
    private LogService logService;

    private static final int NUM = 1000;//一批次保存优惠码的数量
    public static final int PAGE_MAXSIZE=100;
    private static ArrayList<String> list = new ArrayList<String>();
    //对象copy时排除的信息
    static {
        list.add("goodscategoryids");
        list.add("goodcodes");
        list.add("detailsruleApiList");
        list.add("productruleApi");
        list.add("pageSize");
        list.add("nojoingoodcodes");
        list.add("createTime");
        list.add("lastModifyTime");
        list.add("version");
    }

    /**
     * 对外提供的保存优惠码接口，保存批次信息，只保存商品，不保存分类；默认审核，同时生成优惠码
     * @param salescouponsApi
     * @return
     */
    @Override
    public RemoteResult add(SalescouponsApi salescouponsApi) {
        RemoteResult result = new RemoteResult(false);
        try{
            /**
             * 参数校验
             */
            if(salescouponsApi == null || StringUtils.isEmpty(salescouponsApi.getGoodcodes()) || StringUtils.isEmpty(salescouponsApi.getName()) || StringUtils.isEmpty(salescouponsApi.getShopid()) || StringUtils.isEmpty(salescouponsApi.getTerminal())  ){
                log.info("add ： 参数错误！");
                result.setResultCode(CouponConstant.RESULT_CODE_ERROR_PARAM);
                result.setResultMsg(CouponConstant.RESULT_MSG_ERROR_PARAM);
                log.info("add 结果：" + result);
                return result;
            }
            if(salescouponsApi.getTotalnumber() <=0 || salescouponsApi.getMaxnumber() <=0 || salescouponsApi.getMaxnumber() >= CouponConstant.COUPON_COUPONS_MAXNUMBER_MAX || salescouponsApi.getType()!=2){
                log.info("add ： 参数错误！");
                result.setResultCode(CouponConstant.RESULT_CODE_ERROR_PARAM);
                result.setResultMsg(CouponConstant.RESULT_MSG_ERROR_PARAM);
                log.info("add 结果：" + result);
                return result;
            }
            Money zero = new Money(0L, salescouponsApi.getCurrencyCode());
            if(salescouponsApi.getAmount().compareTo(zero) == -1 || salescouponsApi.getAmount().compareTo(zero) == 0 ){
                log.info("add ： 参数错误！");
                result.setResultCode(CouponConstant.RESULT_CODE_ERROR_PARAM);
                result.setResultMsg(CouponConstant.RESULT_MSG_ERROR_PARAM);
                log.info("add 结果：" + result);
                return result;
            }
            if(salescouponsApi.getFromtime() ==null || "".equals(salescouponsApi.getFromtime()) || salescouponsApi.getTotime() ==null || "".equals(salescouponsApi.getTotime())){
                log.info("add ： 参数错误！");
                result.setResultCode(CouponConstant.RESULT_CODE_ERROR_PARAM);
                result.setResultMsg(CouponConstant.RESULT_MSG_ERROR_PARAM);
                log.info("add 结果：" + result);
                return result;
            }
            if(salescouponsApi.getMacode()==null || "".equals(salescouponsApi.getMacode())){
                log.info("add ： 参数错误！");
                result.setResultCode(CouponConstant.RESULT_CODE_ERROR_PARAM);
                result.setResultMsg(CouponConstant.RESULT_MSG_ERROR_PARAM);
                log.info("add 结果：" + result);
                return result;
            }
            Salescoupons salesCoupons = new Salescoupons();
            DomainUtil.copy2(salescouponsApi, salesCoupons, list);
            salesCoupons.setStyle(CouponConstant.COUPON_style_code_2);
            salesCoupons.setBatchno(String.valueOf(new Date().getTime()));
            salesCoupons.setStatus(CouponConstant.COUPON_STATUS_NEW_0);//默认为新建状态 0
            salesCoupons.setCreatetime(new Date());
            salesCoupons.setUpdatetime(new Date());
            salesCoupons.setHaspassed(0);
            salesCoupons.setNoticeValidCount(0);
            salesCoupons.setNoticeInvalidCount(0);

            ResponseResult<Salescoupons> responseResult = salescouponsManager.insertSalescoupons(salesCoupons);
            if(responseResult.isSuccess()){
                Productrule productrule = new Productrule();
                productrule.setSalescouponid(salesCoupons.getId());
                productrule.setGoodscodes(salescouponsApi.getGoodcodes());
                productrule.setStyle(CouponConstant.COUPON_style_code_2);
                productrule.setCreateby(salescouponsApi.getCreateby());
                productrule.setCreatetime(new Date());
                productrule.setUpdatetime(new Date());
                ResponseResult respro = productruleManager.insertProductrule(productrule);
                if(respro.isSuccess()){
//                    /**
//                     * 保存批次信息已经商品信息后，生产具体的优惠码
//                     */
//                    int total = salescouponsApi.getMaxnumber();
//                    int count = 0;
//                    log.info("add 该批次优惠码的总数量为：" + total + ", salescouponID：" + salesCoupons.getId());
//                    if (total <= NUM) {
//                        count += produceCouponCodes(salesCoupons, salesCoupons.getMaxnumber(), "addRpc");
//                    } else {
//                        int n =total / NUM;
//                        int m = total % NUM;
//                        for (int i = 0; i < n; i++) {
//                            count += produceCouponCodes(salesCoupons, NUM, "addRpc");
//                        }
//                        count += produceCouponCodes(salesCoupons, m, "addRpc");
//                    }
//                    log.info("add 成功生成的优惠码数量：" + count);
//
//                    if (total != count){
//                        log.info("add 优惠码数量：total=" +total +", 实际生成码数量count="+ count);
//                    }

                    result.setResultMsg(CouponConstant.RESULT_MSG_SUC);
                    result.setResultCode(CouponConstant.RESULT_CODE_SUC);
                    result.setT(salesCoupons.getId());
                    result.setSuccess(true);
                    log.info("add 结果："+result);
                    return result;
                }else {
                    log.info("add ：insertProductrule 保存优惠码批次商品信息时不成功！");
//                    result.setResultCode("11");
//                    result.setResultMsg("保存优惠码批次商品信息时不成功！");
//                    log.info("add 结果：" + result);
//                    return result;
                    return RemoteResultUtil.convert(ErrorMessageEnum.ERROR_OPER_FAIL);
                }
            }else {
                log.info("add ： insertSalescoupons保存优惠码批次信息时不成功！");
//                result.setResultCode("10");
//                result.setResultMsg("保存优惠码批次信息时不成功！");
//                log.info("add 结果：" + result);
//                return result;
                return RemoteResultUtil.convert(ErrorMessageEnum.ERROR_OPER_FAIL);
            }
        }catch (Exception e){
            log.error(e.getMessage(), e);
            result.setResultMsg(CouponConstant.RESULT_MSG_ERROR);
            result.setResultCode(CouponConstant.RESULT_CODE_ERROR);
            result.setSuccess(false);
        }
        return result;
    }

    /**
     * 批量生成优惠码
     * @param main 优惠码主属性对象
     * @param count 要生成的数量
     * @param operator 操作人
     * @return 返回成功的数量
     */
    private int produceCouponCodes(Salescoupons main, int count, String operator, String macode){
        if (count<=0){
            log.info("优惠码的批次创建数量为0");
            return 0;
        }
        List<Coupons> list = new ArrayList<Coupons>();
        Date currentTime = new Date();
        for (int i = 0; i < count; i++) {
            Coupons couponCode = new Coupons();
            couponCode.setBatchno(main.getBatchno());
            couponCode.setAmount(main.getAmount());
            couponCode.setName(main.getName());
            couponCode.setMacode(TripleDESUtil.encryptMode(macode + RandomStringUtils.randomAlphanumeric(10)));
            couponCode.setStatus(0);
            couponCode.setSalescouponid(main.getId());
            couponCode.setShopid(main.getShopid());
            couponCode.setTerminal(main.getTerminal());
            couponCode.setType(main.getType());
            couponCode.setStarttime(main.getFromtime());
            couponCode.setEndtime(main.getTotime());
            couponCode.setTotalnumber(main.getTotalnumber());
            couponCode.setSurplusnumber(main.getTotalnumber());
            couponCode.setOccupynumber(0);
            couponCode.setCreatetime(currentTime);
            couponCode.setCreateby(operator);
            couponCode.setUpdatetime(currentTime);
            couponCode.setCurrencyCode(main.getCurrencyCode());
            list.add(couponCode);
        }
        ResponseResult<Integer> result= couponsManager.insertBatch(list);
        if (result!=null&&result.isSuccess()){
            return result.getData();
        }
        return 0;
    }

    @Override
    public RemoteResult delete(Tenant tenant, long id, String terminal) {
        return this.delete(id, String.valueOf(tenant.getShopId()), terminal);
    }

    /**
     * 根据主键删除优惠码所有信息，物理删除
     * @param id
     * @param shopId
     * @param terminal
     * @return
     */
    @Override
    public RemoteResult delete(long id, String shopId, String terminal) {
        log.info("delete id=["+id+"] shopId=["+shopId+"] terminal=["+terminal+"]");
        RemoteResult result = new RemoteResult(false);
        if(id <= 0 || StringUtils.isEmpty(shopId) || StringUtils.isEmpty(terminal)){
            log.info("delete ： 参数错误！");
            result.setResultCode(CouponConstant.RESULT_CODE_ERROR_PARAM);
            result.setResultMsg(CouponConstant.RESULT_MSG_ERROR_PARAM);
            log.info("delete 结果：" + result);
            return result;
        }
        Salescoupons salescoupons = new Salescoupons();
        salescoupons.setId(id);
        ResponseResult<Salescoupons> res = salescouponsManager.getSalescoupons(id);
        if(res.isSuccess()){
            Salescoupons sa = res.getData();
            /**
             * 审核过之后不允许在删除或者修改
             */
            if(sa.getStatus() == CouponConstant.COUPON_STATUS_PASTAUDIT_2 && sa.getHaspassed() == 1){
                log.info("delete id=["+id+"] 已经审核通过，不允许删除！");
//                result.setResultMsg("已经审核通过，不允许删除！");
//                result.setResultCode(CouponConstant.RESULT_CODE_FAIL);
//                log.info("delete 结果："+result);
//                return result;
               return  RemoteResultUtil.convert(ErrorMessageEnum.ERROR_ALREADY_SHENHE_NOT_ALLOW_OPERA);
            }
            ResponseResult responseResult = salescouponsManager.delSalescoupons(salescoupons);
            if(responseResult.isSuccess()){
                Productrule productrule = new Productrule();
                productrule.setSalescouponid(id);
                ResponseResult res_product = productruleManager.delProductrule(productrule);
                if(!res_product.isSuccess()){
                    log.info("delete 删除商品信息时失败！");
                }
//            ResponseResult res_coupons = couponsManager.deleteCouponsBySalescouponsId(id);
//            if(!res_coupons.isSuccess()){
//                log.info("delete 删除优惠码信息时失败！");
//            }
//            if(res_product.isSuccess() && res_coupons.isSuccess()){
                result.setResultMsg(CouponConstant.RESULT_MSG_SUC);
                result.setResultCode(CouponConstant.RESULT_CODE_SUC);
                result.setSuccess(true);
                log.info("delete 结果："+result);
                return result;
//            }else {
//                log.info("delete 删除优惠码时，商品信息或者码信息删除失败！");
//                result.setResultMsg(CouponConstant.RESULT_CODE_FAIL);
//                result.setResultCode("删除优惠码时，商品信息或者码信息删除失败！");
//                log.info("delete 结果："+result);
//                return result;
//            }
            }else {
                log.info("delete ： 删除优惠码批次信息时不成功！");
//                result.setResultCode("10");
//                result.setResultMsg("删除优惠码批次信息时不成功！");
//                log.info("delete 结果：" + result);
//                return result;
                return  RemoteResultUtil.convert(ErrorMessageEnum.ERROR_OPER_FAIL);
            }
        }
        return result;
    }

    @Override
    public RemoteResult update(Tenant tenant, long id, String terminal, Money amount, String fromtime, String totime,String userId) {
        return this.update(id, String.valueOf(tenant.getShopId()), terminal, amount.getAmount(), fromtime, totime, userId);
    }

    @Override
    public RemoteResult update(long id, String shopId, String terminal, BigDecimal amount, String fromtime, String totime,String userId) {
        log.info("update id=["+id+"] shopId=["+shopId+"] terminal=["+terminal+"] amount=["+amount+"] fromtime=["+fromtime+"] totime=["+totime+"]");
        RemoteResult result = new RemoteResult(false);
        if(id <= 0 || StringUtils.isEmpty(shopId) || StringUtils.isEmpty(terminal) || StringUtils.isEmpty(userId) ){
            log.info("update ： 参数错误！");
            result.setResultCode(CouponConstant.RESULT_CODE_ERROR_PARAM);
            result.setResultMsg(CouponConstant.RESULT_MSG_ERROR_PARAM);
            log.info("update 结果：" + result);
            return result;
        }
        BigDecimal zero = new BigDecimal(0);
        if(StringUtils.isEmpty(fromtime) && StringUtils.isEmpty(totime) && (amount.compareTo(zero) ==-1 || amount.compareTo(zero) ==0)){
            log.info("update ： 参数错误！金额、有效期必须有一个有值，不能都为空！");
            result.setResultCode(CouponConstant.RESULT_CODE_ERROR_PARAM);
            result.setResultMsg(CouponConstant.RESULT_MSG_ERROR_PARAM);
            log.info("update 结果：" + result);
            return result;
        }
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date fromtime_date =null;
        Date totime_date = null;
        try {
            if(StringUtils.isNotEmpty(fromtime)){
                fromtime_date = simpleDateFormat.parse(fromtime);
            }
            if(StringUtils.isNotEmpty(totime)){
                totime_date = simpleDateFormat.parse(totime);
            }
        } catch (ParseException e) {
            log.error(e.getMessage(), e);
            log.error("有效期进行格式转换时，出现异常，请检查参数中传入的时间是否符合 yyyy-MM-dd HH:mm:ss 格式");
//            result.setResultMsg("有效期进行格式转换时，出现异常，请检查参数中传入的时间是否符合 yyyy-MM-dd HH:mm:ss 格式");
//            result.setResultCode("10");
//            result.setSuccess(false);
//            log.error("update 结果："+result);
            return RemoteResultUtil.convert(ErrorMessageEnum.ERROR_PARA);
        }

        ResponseResult<Salescoupons> res = salescouponsManager.getSalescoupons(id);
        if(res.isSuccess()) {
            Salescoupons sa = res.getData();
            /**
             * 审核过之后不允许在删除或者修改
             */
            if (sa.getStatus() == CouponConstant.COUPON_STATUS_PASTAUDIT_2 && sa.getHaspassed() == 1) {
                log.info("delete id=[" + id + "] 已经审核通过，不允许修改！");
//                result.setResultMsg("已经审核通过，不允许修改！");
//                result.setResultCode(CouponConstant.RESULT_CODE_FAIL);
//                log.info("delete 结果：" + result);
//                return result;
                return RemoteResultUtil.convert(ErrorMessageEnum.ERROR_ALREADY_SHENHE_NOT_ALLOW_OPERA);
            }

            Salescoupons salescoupons = new Salescoupons();
            salescoupons.setId(id);
            salescoupons.setAmount(new Money(amount, Money.DEFAULT_CURRENCY_CODE));
            salescoupons.setFromtime(fromtime_date);
            salescoupons.setTotime(totime_date);
            salescoupons.setUpdateby(userId);
            ResponseResult res_sales = salescouponsManager.editSalescoupons(salescoupons);
            if(!res_sales.isSuccess()){
                log.info("update 更新优惠码批次信息时出现错误！");
//                result.setResultMsg("更新优惠码批次信息时出现错误！");
//                result.setResultCode("10");
//                log.info("update 结果："+result);
//                return result;
                return RemoteResultUtil.convert(ErrorMessageEnum.ERROR_OPER_FAIL);
            }
//        Coupons coupons = new Coupons();
//        coupons.setSalescouponid(salescoupons.getId());
//        coupons.setAmount(salescoupons.getAmount());
//        coupons.setStarttime(salescoupons.getFromtime());
//        coupons.setEndtime(salescoupons.getTotime());
//        coupons.setUpdateby(userId);
//        ResponseResult res_coupons = couponsManager.updateCouponsBySalescouponsId(coupons);
//        if(!res_coupons.isSuccess()){
//            log.info("update 更新优惠码信息时出现错误！");
//            result.setResultMsg(" 更新优惠码信息时出现错误！");
//            result.setResultCode("11");
//            log.info("update 结果："+result);
//            return result;
//        }

            result.setResultMsg(CouponConstant.RESULT_MSG_SUC);
            result.setResultCode(CouponConstant.RESULT_CODE_SUC);
            result.setSuccess(true);
            log.info("update 结果："+result);
            return result;
        }
        return result;
    }

    /**
     * 启用优惠码，即审核，在启用的时候生产优惠码
     * @param map
     * @return
     */
    @Override
    public RemoteResult enableCoupons(Map<String,String> map) {
        log.info("enableCoupons id=["+map.get("id")+"] shopId=["+map.get("shopid")+"] terminal=["+map.get("terminal"));
        RemoteResult result = new RemoteResult(false);
        if(StringUtils.isEmpty(map.get("id")) || StringUtils.isEmpty(map.get("shopid")) || StringUtils.isEmpty(map.get("terminal")) || StringUtils.isEmpty(map.get("userId"))){
            log.info("enableCoupons ： 参数错误！");
            result.setResultCode(CouponConstant.RESULT_CODE_ERROR_PARAM);
            result.setResultMsg(CouponConstant.RESULT_MSG_ERROR_PARAM);
            log.info("enableCoupons 结果：" + result);
            return result;
        }

        Long salescouponId = Long.valueOf(map.get("id"));
        String userId = map.get("userId");

        ResponseResult<Salescoupons> re = salescouponsManager.getSalescoupons(salescouponId);
        if (re != null && re.isSuccess() && re.getData() != null) {
            Salescoupons mainCoupon = re.getData();
            String macode = mainCoupon.getMacode();
            boolean isEmpty = macode == null ? false : StringUtils.isEmpty(macode.trim());
            if(isEmpty == true){
                log.info("macode ： 参数错误！");
                return result;
            }
            //style 1优惠券 2优惠码  优惠码审核通过后需要生成一批次码插入coupons表 重复审核通过不再插入
            //生产码
            if (mainCoupon.getStyle() == 2 && mainCoupon.getStatus() == 0 && mainCoupon.getHaspassed()==0) {

                int total = mainCoupon.getMaxnumber();
                int count = 0;
                log.info("该批次优惠码的总数量为：" + total + ", salescouponID：" + mainCoupon.getId());
                if (mainCoupon.getMaxnumber() <= NUM) {
                    count += produceCouponCodes(mainCoupon, mainCoupon.getMaxnumber(), userId,macode);
                } else {
                    int n = mainCoupon.getMaxnumber() / NUM;
                    int m = mainCoupon.getMaxnumber() % NUM;
                    for (int i = 0; i < n; i++) {
                        count += produceCouponCodes(mainCoupon, NUM, userId,macode);
                    }
                    count += produceCouponCodes(mainCoupon, m, userId,macode);
                }
                log.info("成功生成的优惠码数量：" + count);

                //审核表中插入数据
                List<Couponchecks> list_couponcheck = new ArrayList<Couponchecks>();
                Couponchecks couponchecks = new Couponchecks();
                couponchecks.setSalescouponid(mainCoupon.getId());
                couponchecks.setStyle(CouponConstant.COUPON_style_code_2);
                couponchecks.setName(mainCoupon.getName());
                couponchecks.setCheckpersonid(userId);
                couponchecks.setCheckposttime(new Date());
                couponchecks.setCheckstatus(CouponConstant.COUPON_STATUS_PASTAUDIT_2);
                couponchecks.setCreateby(userId);
                couponchecks.setCreatetime(new Date());
                couponchecks.setUpdatetime(new Date());
                list_couponcheck.add(couponchecks);
                int row = couponchecksManager.insertCouponchecksBatch(list_couponcheck);
                if(row != 1){
                    log.info("enableCoupons insertCouponchecksBatch 失败");
                }

                Salescoupons salescoupons = new Salescoupons();
                salescoupons.setId(mainCoupon.getId());
                salescoupons.setStatus(CouponConstant.COUPON_STATUS_PASTAUDIT_2);
                salescoupons.setUpdatetime(new Date());
                salescoupons.setUpdateby(userId);
                salescoupons.setHaspassed(1);//已经审核通过过
                ResponseResult responseResult = salescouponsManager.editSalescoupons(salescoupons);
                if(!responseResult.isSuccess()){
                    log.info("enableCoupons editSalescoupons 失败");
                }

                if ( count == total) {
                    result.setSuccess(true);
                    result.setResultMsg(CouponConstant.RESULT_MSG_SUC);
                    result.setResultCode(CouponConstant.RESULT_CODE_SUC);
                    result.setT(true);
                    return result;
                }
            }
        }

        return result;
    }

    public RemoteResult getPage(Tenant tenant, String terminal, String amount, String name, String fromtime, String totime, String page, String page_size, String status) {
        return this.getPage(String.valueOf(tenant.getShopId()), terminal, amount, name, fromtime, totime, page, page_size, status);
    }

    /**
     * 优惠码信息表分页接口
     * @param shopId
     * @param terminal
     * @param fromtime
     * @param totime
     * @param page
     * @param page_size
     * @return
     */
    @Override
    public RemoteResult getPage(String shopId, String terminal,String amount,String name, String fromtime, String totime, String page, String page_size,String status) {
        log.info("getPage page=["+page+"] shopId=["+shopId+"] terminal=["+terminal+"] page_size=["+page_size+"] fromtime=["+fromtime+"] totime=["+totime+"] amount=["+amount+"] name=["+name+"]");
        RemoteResult result = new RemoteResult(false);
        if(StringUtils.isEmpty(shopId) || StringUtils.isEmpty(terminal)  || StringUtils.isEmpty(page) || StringUtils.isEmpty(page_size)){
            log.info("getPage ： 参数错误！");
            result.setResultCode(CouponConstant.RESULT_CODE_ERROR_PARAM);
            result.setResultMsg(CouponConstant.RESULT_MSG_ERROR_PARAM);
            log.info("getPage 结果：" + result);
            return result;
        }
        /**
         * 默认情况下返回第一页数据
         */
        int pageNumber = 1;
        int pageSize = 10;
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
        String fromtime_date =null;
        String totime_date = null;
        try {
            pageNumber = Integer.valueOf(page);
            pageSize = Integer.valueOf(page_size);

            if(StringUtils.isNotEmpty(fromtime)){
                fromtime_date =  simpleDateFormat.format(simpleDateFormat.parse(fromtime));
            }
            if(StringUtils.isNotEmpty(totime)){
                totime_date = simpleDateFormat.format(simpleDateFormat.parse(totime));
            }
        } catch (Exception e) {
            log.error("getPage ： 参数转换时出现异常",e);
//            result.setResultCode(CouponConstant.RESULT_CODE_ERROR);
//            result.setResultMsg("参数转换时出现异常");
//            log.error("getPage 结果："+result);
//            return result;
            return RemoteResultUtil.convert(ErrorMessageEnum.ERROR_PARA);
        }
        PageQuery pageQuery = new PageQuery(pageNumber, pageSize);

        Map map = new HashMap();
        map.put("style", CouponConstant.COUPON_style_code_2);
        map.put("shopid",shopId);
        map.put("terminal",terminal);
        map.put("status",status);

        if(StringUtils.isNotEmpty(fromtime_date)){
            map.put("fromtime",fromtime_date);
        }
        if(StringUtils.isNotEmpty(totime_date)){
            map.put("totime",totime_date);
        }
        if(StringUtils.isNotEmpty(amount)){
            map.put("amount",amount);
        }
        if(StringUtils.isNotEmpty(name)){
            map.put("name",name);
        }
        if(StringUtils.isNotEmpty(status)){
            map.put("status",status); //对于moto商城，0代表新建，2代表审核通过，3代表失效
        }

        PageModel2<Salescoupons> pageModel2 = salescouponsManager.getSalescouponsInfoPage(pageQuery, map);
        List<RpcCouponsApi> rpcCouponsApiList = new ArrayList<RpcCouponsApi>();
        if(null != pageModel2 && null !=pageModel2.getDatas() && pageModel2.getDatas().size() > 0 ){
            for (Salescoupons salescoupons : pageModel2.getDatas()) {
                RpcCouponsApi rpcCouponsApi = new RpcCouponsApi();
                rpcCouponsApi.setId(salescoupons.getId());
                rpcCouponsApi.setAmount(salescoupons.getAmount());
                rpcCouponsApi.setBatchno(salescoupons.getBatchno());
                rpcCouponsApi.setFromtime(salescoupons.getFromtime());
                rpcCouponsApi.setTotime(salescoupons.getTotime());
                rpcCouponsApi.setName(salescoupons.getName());
                rpcCouponsApi.setShopid(salescoupons.getShopid());
                rpcCouponsApi.setTerminal(salescoupons.getTerminal());
                rpcCouponsApi.setTotalnumber(salescoupons.getTotalnumber());
                rpcCouponsApi.setType(salescoupons.getType());
                rpcCouponsApi.setStatus(salescoupons.getStatus());
                rpcCouponsApi.setCreateby(salescoupons.getCreateby());
                rpcCouponsApi.setCreatetime(salescoupons.getCreatetime());
                rpcCouponsApi.setUpdateby(salescoupons.getUpdateby());
                rpcCouponsApi.setUpdatetime(salescoupons.getUpdatetime());
                rpcCouponsApi.setMaxnumber(salescoupons.getMaxnumber());
                rpcCouponsApi.setDescription(salescoupons.getDescription());
                rpcCouponsApiList.add(rpcCouponsApi);
            }
        }
        PageModel2<RpcCouponsApi> pageModel=new PageModel2<RpcCouponsApi>(pageQuery,rpcCouponsApiList);
        result.setResultMsg(CouponConstant.RESULT_MSG_SUC);
        result.setResultCode(CouponConstant.RESULT_CODE_SUC);
        result.setT(pageModel);
        result.setSuccess(true);
        return result;
    }

    @Override
    public RemoteResult getCouponsPage(Map map) {
        log.info("getCouponsPage page=["+map.get("page")+"] shopid=["+map.get("shopid")+"] terminal=["+map.get("terminal")+"] page_size=["+map.get("page_size")+"] salescouponid=["+map.get("salescouponid")+"] batchno=["+map.get("batchno")+"] macode=["+map.get("macode")+"] status=["+map.get("status")+"]");
        RemoteResult result = new RemoteResult(false);
        if(StringUtils.isEmpty(map.get("page").toString()) || StringUtils.isEmpty(map.get("terminal").toString()) || StringUtils.isEmpty(map.get("shopid").toString()) || StringUtils.isEmpty(map.get("page_size").toString()) || StringUtils.isEmpty(map.get("salescouponid").toString()) || StringUtils.isEmpty(map.get("batchno").toString())){
            log.info("getCouponsPage ： 参数错误！");
            result.setResultCode(CouponConstant.RESULT_CODE_ERROR_PARAM);
            result.setResultMsg(CouponConstant.RESULT_MSG_ERROR_PARAM);
            log.info("getCouponsPage 结果：" + result);
            return result;
        }
        if(Integer.valueOf(map.get("page_size").toString()) >=PAGE_MAXSIZE ){
            log.info("getCouponsPage ： 参数错误！");
//            result.setResultCode(CouponConstant.RESULT_CODE_ERROR_PARAM);
//            result.setResultMsg("超过每页的最大数量100条！");
//            log.info("getCouponsPage 结果：" + result);
//            return result;
            return RemoteResultUtil.convert(ErrorMessageEnum.ERROR_MAX_PAGESIZE);
        }
        /**
         * 默认情况下返回第一页数据
         */
        int pageNumber = 1;
        int pageSize = 10;
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
        String fromtime_date =null;
        String totime_date = null;
        try {
            pageNumber = Integer.valueOf(map.get("page").toString());
            pageSize = Integer.valueOf(map.get("page_size").toString());
        } catch (Exception e) {
            log.error(e.getMessage(),e);
        }
        PageQuery pageQuery = new PageQuery(pageNumber, pageSize);

        Map parammap = new HashMap();
//        parammap.put("shopid",map.get("shopid").toString());
//        parammap.put("terminal",map.get("terminal").toString());
        String status = map.get("status")!= null ? map.get("status").toString() : null;
        if(StringUtils.isNotEmpty(status)){
            parammap.put("status",status);
        }

        parammap.put("batchno",map.get("batchno").toString());
        parammap.put("salescouponid",map.get("salescouponid").toString());
        if(null != map.get("macode")){
            parammap.put("macode",map.get("macode").toString());
        }

        PageModel2<Coupons> pageModel2 = couponsManager.getCouponsInfoPage(pageQuery, parammap);
        List<RpcCouponsApi> rpcCouponsApiList = new ArrayList<RpcCouponsApi>();
        if(null != pageModel2 && null !=pageModel2.getDatas() && pageModel2.getDatas().size() > 0 ){
            RpcCouponsApi rpcCouponsApi = null;
            for (Coupons coupons : pageModel2.getDatas()) {
                rpcCouponsApi = new RpcCouponsApi();
                rpcCouponsApi.setId(coupons.getId());
                rpcCouponsApi.setAmount(coupons.getAmount());
                rpcCouponsApi.setBatchno(coupons.getBatchno());
                rpcCouponsApi.setMcode(coupons.getMacode());
                rpcCouponsApi.setFromtime(coupons.getStarttime());
                rpcCouponsApi.setTotime(coupons.getEndtime());
                rpcCouponsApi.setName(coupons.getName());
                rpcCouponsApi.setShopid(coupons.getShopid());
                rpcCouponsApi.setTerminal(coupons.getTerminal());
                rpcCouponsApi.setTotalnumber(coupons.getTotalnumber());
                rpcCouponsApi.setOccupynumber(coupons.getOccupynumber());
                rpcCouponsApi.setType(coupons.getType());
                rpcCouponsApi.setStatus(coupons.getStatus());
                rpcCouponsApi.setCreateby(coupons.getCreateby());
                rpcCouponsApi.setCreatetime(coupons.getCreatetime());
                rpcCouponsApi.setUpdateby(coupons.getUpdateby());
                rpcCouponsApi.setUpdatetime(coupons.getUpdatetime());
                rpcCouponsApiList.add(rpcCouponsApi);
            }
        }
        PageModel2<RpcCouponsApi> pageModel=new PageModel2<RpcCouponsApi>(pageQuery,rpcCouponsApiList);
        result.setResultMsg(CouponConstant.RESULT_MSG_SUC);
        result.setResultCode(CouponConstant.RESULT_CODE_SUC);
        result.setT(pageModel);
        result.setSuccess(true);
        return result;
    }

    @Override
    public RemoteResult check(Tenant tenant, List<String> codeslist, String terminal, String couponCode) {
        return this.check(codeslist, String.valueOf(tenant.getShopId()), terminal, couponCode);
    }

    @Override
    public RemoteResult check(List<String> codeslist, String shopId, String terminal, String couponCode) {
        log.info("check 参数：codeslist="+codeslist+",shopId=["+shopId+"] terminal=["+terminal+"] couponCode=["+couponCode+"]");
        RemoteResult result = new RemoteResult(false);
        try {
            if( StringUtils.isEmpty(shopId) || StringUtils.isEmpty(terminal) || CollectionUtils.isEmpty(codeslist) || StringUtils.isEmpty(couponCode)){
                log.info("check ： 参数错误！");
                result.setResultCode(CouponConstant.RESULT_CODE_ERROR_PARAM);
                result.setResultMsg(CouponConstant.RESULT_MSG_ERROR_PARAM);
                log.info("check 结果： " + result);
                return result;
            }

            ResponseResult res_coupons = couponsManager.getCouponsByCode(couponCode);
            if(res_coupons.isSuccess() && res_coupons.getData() != null){
                Coupons coupons = (Coupons)res_coupons.getData();
                if(!coupons.getShopid().equals(shopId)){
                    log.info("check 商城[" + shopId + "]与该优惠码[" + shopId + "]不匹配!");
//                    result.setResultCode("11");
//                    result.setResultMsg("商城["+shopId+"]与该优惠码["+couponCode+"]不匹配！");
//                    log.info("check 结果： " + result);
//                    return result;
                    return RemoteResultUtil.convert(ErrorMessageEnum.ERROR_COUPONCODE_SHOP.getCode(), ArrayUtil.toArrayString(new String[]{shopId,shopId}));
                }

                if(!coupons.getTerminal().contains(terminal)){
                    log.info("check 该优惠码["+couponCode+"]不能用在该平台["+terminal+"]");
//                    result.setResultCode("12");
//                    result.setResultMsg("该优惠码["+couponCode+"]不能用在该平台["+couponCode+"]");
//                    log.info("check 结果： "+result);
//                    return result;
                    return RemoteResultUtil.convert(ErrorMessageEnum.ERROR_COUPONCODE_TERMINAL.getCode(), ArrayUtil.toArrayString(new String[]{terminal+"",couponCode}));
                }

                long nowtime = new Date().getTime();
                if(coupons.getStarttime().getTime() > coupons.getEndtime().getTime()){
                    log.info("check 优惠码["+couponCode+"]有效期开始时间必须小于结束时间！");
//                    result.setResultCode("13");
//                    result.setResultMsg("优惠码["+couponCode+"]有效期开始时间必须小于结束时间！");
//                    log.info("check 结果： "+result);
//                    return result;
                    return RemoteResultUtil.convert(ErrorMessageEnum.ERROR_COUPONCODE_VALIDATE.getCode(), ArrayUtil.toArrayString(new String[]{couponCode}));
                }
                if(coupons.getStarttime().getTime() >  nowtime){
                    log.info("check 优惠码["+couponCode+"]有效期还未开始！");
//                    result.setResultCode("14");
//                    result.setResultMsg("优惠码["+couponCode+"]有效期还未开始！");
//                    log.info("check 结果： "+result);
//                    return result;
                    return RemoteResultUtil.convert(ErrorMessageEnum.ERROR_COUPONCODE_NOTSTART.getCode(), ArrayUtil.toArrayString(new String[]{couponCode}));
                }
                if( nowtime > coupons.getEndtime().getTime()){
                    log.info("check 优惠码["+couponCode+"]已经过期了！");
//                    result.setResultCode("15");
//                    result.setResultMsg("优惠码["+couponCode+"]已经过期了！");
//                    log.info("check 结果： "+result);
//                    return result;
                    return RemoteResultUtil.convert(ErrorMessageEnum.ERROR_COUPONCODE_EXPIRE.getCode(), ArrayUtil.toArrayString(new String[]{couponCode}));
                }
                if( coupons.getTotalnumber() < 1){
                    log.info("check 优惠码["+couponCode+"]总使用次数小于1了！");
//                    result.setResultCode("16");
//                    result.setResultMsg("优惠码["+couponCode+"]总使用次数小于1了！");
//                    log.info("check 结果： "+result);
//                    return result;
                    return RemoteResultUtil.convert(ErrorMessageEnum.ERROR_COUPONCODE_USERTIMES.getCode(), ArrayUtil.toArrayString(new String[]{couponCode}));
                }
                //使用次数小于总次数才可以用
                if( coupons.getOccupynumber() >= coupons.getTotalnumber()){
                    log.info("check 优惠码["+couponCode+"]的使用次数["+coupons.getTotalnumber()+"]已经使用完了！");
//                    result.setResultCode("17");
//                    result.setResultMsg("优惠码["+couponCode+"]的使用次数["+coupons.getTotalnumber()+"]已经使用完了！");
//                    log.info("check 结果： "+result);
//                    return result;
                    return RemoteResultUtil.convert(ErrorMessageEnum.ERROR_COUPONCODE_USERTIMES.getCode(), ArrayUtil.toArrayString(new String[]{couponCode}));
                }

                for(String s : codeslist){
                    if(CouponConstant.COUPON_TYPE_PRODUCT_2 == coupons.getType()){
                        //商品券
                        Productrule productrule = new Productrule();
                        productrule.setSalescouponid(coupons.getSalescouponid());
                        ResponseResult<List<Productrule>> res_p = productruleManager.getProductruleList(productrule);
                        if(res_p.isSuccess() && res_p.getData() != null){
                            Productrule pro = res_p.getData().get(0);
                            //券的商品集合包含该商品
                            if(pro.getGoodscodes().contains(s)){
                                result.setResultCode(CouponConstant.RESULT_CODE_SUC);
                                result.setResultMsg(CouponConstant.RESULT_MSG_SUC);
                                result.setSuccess(true);
                                log.info("check 结果： "+result);
                                return result;
                            }
                        }else {
                            log.info("check 优惠码[" + couponCode + "]为商品码[" + coupons.getType() + "] 通过[" + coupons.getSalescouponid() + "]没有查到码关联的商品信息！" + coupons);
//                            result.setResultCode("18");
//                            result.setResultMsg("check 未找到优惠码["+couponCode+"]关联的商品信息！");
//                            log.info("check 结果： " + result);
//                            return result;
                            return RemoteResultUtil.convert(ErrorMessageEnum.ERROR_COUPONCODE_PRODUCT_INFO.getCode(), ArrayUtil.toArrayString(new String[]{couponCode}));
                        }
                    }else {
                        log.info("moto优惠码[" + couponCode + "]不存在这个绑定规则 type=" + coupons.getType());
//                        result.setResultCode("19");
//                        result.setResultMsg("优惠码["+couponCode+"]不存在这个绑定规则 type="+coupons.getType());
//                        log.info("check 结果： "+result);
//                        return result;
                        return RemoteResultUtil.convert(ErrorMessageEnum.ERROR_COUPONCODE_NOT_EXIS_RULE.getCode(), ArrayUtil.toArrayString(new String[]{couponCode,coupons.getType()+""}));
                    }
                }
                log.info("check 优惠码[" + couponCode + "]和传进来的商品[" + codeslist + "] 不匹配！");
//                result.setResultCode("20");
//                result.setResultMsg("优惠码["+couponCode+"]和商品["+codeslist+"] 不匹配！");
//                log.info("check 结果： "+result);
//                return result;
                return RemoteResultUtil.convert(ErrorMessageEnum.ERROR_COUPONCODE_NOT_RULE_4PRODUCT.getCode(), ArrayUtil.toArrayString(new String[]{couponCode, JsonUtil.toJson(codeslist)}));
            }else {
                log.info("check ： 优惠码[" + couponCode + "]找不到相关信息！");
//                result.setResultCode("10");
//                result.setResultMsg("没有找到该优惠码["+couponCode+"]");
//                log.info("check 结果： " + result);
//                return result;
                return RemoteResultUtil.convert(ErrorMessageEnum.ERROR_COUPONCODE_PRODUCT_INFO.getCode(), ArrayUtil.toArrayString(new String[]{couponCode}));
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            result.setResultCode(CouponConstant.RESULT_CODE_ERROR);
            result.setResultMsg(CouponConstant.RESULT_MSG_ERROR);
            result.setSuccess(false);
            log.error("check 结果： " + result);
            return result;
        }
    }

    @Override
    public RemoteResult updateCouponsStatus(String userId,CouponsApi couponsApi) {
        log.info("updateCouponsStatus 参数：userId=["+userId+"] "+couponsApi);
        RemoteResult result = new RemoteResult(false);
        if( couponsApi.getId() <=0 || StringUtils.isEmpty(couponsApi.getMacode()) || couponsApi.getStatus() == null){
            log.info("updateCouponsStatus ： 参数错误！");
            result.setResultCode(CouponConstant.RESULT_CODE_ERROR_PARAM);
            result.setResultMsg(CouponConstant.RESULT_MSG_ERROR_PARAM);
            log.info("updateCouponsStatus 结果： " + result);
            return result;
        }
        if(couponsApi.getStatus() != 0 && couponsApi.getStatus() != 1){
            log.info("updateCouponsStatus ： 参数错误！status状态值错误！");
            result.setResultCode(CouponConstant.RESULT_CODE_ERROR_PARAM);
            result.setResultMsg(CouponConstant.RESULT_MSG_ERROR_PARAM);
            log.info("updateCouponsStatus 结果： " + result);
            return result;
        }

        Coupons coupons = new Coupons();
        coupons.setId(couponsApi.getId());
        coupons.setMacode(couponsApi.getMacode());
        coupons.setStatus(couponsApi.getStatus());
        ResponseResult res_coupons = couponsManager.updateCouponsStatus(coupons);
        if(res_coupons != null && res_coupons.isSuccess()){
            LogVo couponsLog = new LogVo();
            couponsLog.setModul(ModulNameEnum.MEMBER_COIUPON_REL_LOG.getDesc());
            couponsLog.setOperationType("updateCouponsStatus");
            couponsLog.setCreateTime(new Date().toString());
            couponsLog.setLenovoId(coupons.getUpdateby());
            couponsLog.setContent(JsonUtil.toJson(coupons));

            try {
                logService.save2Mongo(couponsLog);
            } catch (Exception e) {
                log.info("updateCouponsStatus savelogtomongo error",e);
            }

            result.setResultCode(CouponConstant.RESULT_CODE_SUC);
            result.setResultMsg(CouponConstant.RESULT_MSG_SUC);
            result.setSuccess(true);
            log.info("updateCouponsStatus 结果： "+result);
            return result;
        }else {
            log.info("updateCouponsStatus 删除优惠码时不成功！");
//            result.setResultCode(CouponConstant.RESULT_CODE_FAIL);
//            result.setResultMsg("删除优惠码时不成功");
//            result.setSuccess(false);
//            log.info("updateCouponsStatus 结果： "+result);
//            return result;
            return RemoteResultUtil.convert(ErrorMessageEnum.ERROR_OPER_FAIL);
        }
    }

    @Override
    public RemoteResult invalidCoupons(Tenant tenant, String userId, String terminal, String id, String batchno) {
        return this.invalidCoupons(userId, String.valueOf(tenant.getShopId()), terminal, id, batchno);
    }

    /**
     * 对于moto的码，salescoupons表 status 0:新建，2，生效，1失效
     *               coupons表      status 0:正常，1:失效
     * @param userId
     * @param shopId
     * @param terminal
     * @param id
     * @return
     */
    @Override
    public RemoteResult invalidCoupons(String userId, String shopId, String terminal, String id,String batchno) {
        log.info("invalidCoupons 参数：userId=["+userId+"] shopId=["+shopId+"] terminal=["+terminal+"],id=["+id+"]");
        RemoteResult result = new RemoteResult(false);
        if(StringUtils.isEmpty(userId) || StringUtils.isEmpty(shopId) || StringUtils.isEmpty(id) || StringUtils.isEmpty(batchno)){
            log.info("invalidCoupons ： 参数错误！");
            result.setResultCode(CouponConstant.RESULT_CODE_ERROR_PARAM);
            result.setResultMsg(CouponConstant.RESULT_MSG_ERROR_PARAM);
            log.info("invalidCoupons 结果： " + result);
            return result;
        }
        ResponseResult responseResult = salescouponsManager.getSalescoupons(Long.valueOf(id));
        if(responseResult != null && responseResult.isSuccess()){
            Salescoupons salescoupons = (Salescoupons)responseResult.getData();
            /**
             * 2 代表已经生效过，即生成了具体的码
             */
            if(salescoupons.getStatus() != 2){
                log.info("invalidCoupons ： 券活动[" + id + "]当前状态为[" + salescoupons.getStatus() + "] 未生效（2）之前不能失效！");
//                result.setResultCode(CouponConstant.RESULT_CODE_FAIL);
//                result.setResultMsg("券活动还未生效");
//                log.info("invalidCoupons 结果： " + result);
//                return result;
                return RemoteResultUtil.convert(ErrorMessageEnum.ERROR_ACTIVE_NOT_VALIDATE);
            }

            if(!salescoupons.getShopid().equals(shopId)){
                log.info("invalidCoupons ： 券活动商城[" + salescoupons.getShopid() + "]和当前传入的商城[" + shopId + "] 不匹配！");
//                result.setResultCode(CouponConstant.RESULT_CODE_FAIL);
//                result.setResultMsg("商城不匹配");
//                log.info("invalidCoupons 结果： " + result);
//                return result;
                return RemoteResultUtil.convert(ErrorMessageEnum.ERROR_SHOPID);
            }

            if(!salescoupons.getBatchno().equals(batchno)){
                log.info("invalidCoupons ： 券活动批次号[" + salescoupons.getBatchno() + "]和当前传入的批次号[" + batchno + "] 不匹配！");
//                result.setResultCode(CouponConstant.RESULT_CODE_FAIL);
//                result.setResultMsg("批次号不匹配");
//                log.info("invalidCoupons 结果： " + result);
//                return result;
                return RemoteResultUtil.convert(ErrorMessageEnum.ERROR_BATCH_NO);
            }

            Coupons coupons = new Coupons();
            coupons.setStatus(1);// 1 代表码失效
            coupons.setUpdateby(userId);
            coupons.setUpdatetime(new Date());
            coupons.setSalescouponid(Long.valueOf(id));
            ResponseResult res_coupons = couponsManager.updateCouponsBySalescouponsId(coupons);
            if(res_coupons != null && res_coupons.isSuccess()){
                int row  = (Integer)res_coupons.getData();
                if(row == salescoupons.getMaxnumber()){
                    //审核表中插入数据
                    List<Couponchecks> list_couponcheck = new ArrayList<Couponchecks>();
                    Couponchecks couponchecks = new Couponchecks();
                    couponchecks.setSalescouponid(salescoupons.getId());
                    couponchecks.setStyle(CouponConstant.COUPON_style_code_2);
                    couponchecks.setName(salescoupons.getName());
                    couponchecks.setCheckpersonid(userId);
                    couponchecks.setCheckposttime(new Date());
                    couponchecks.setCheckstatus(CouponConstant.COUPON_STATUS_NOPASTAUDIT_1);
                    couponchecks.setUpdateby(userId);
                    couponchecks.setCreatetime(new Date());
                    couponchecks.setUpdatetime(new Date());
                    list_couponcheck.add(couponchecks);
                    int row_checks = couponchecksManager.insertCouponchecksBatch(list_couponcheck);
                    if(row_checks != 1){
                        log.info("invalidCoupons insertCouponchecksBatch 失败");
                    }

                    List<Salescoupons> list1 = new ArrayList<Salescoupons>();
                    Salescoupons s = new Salescoupons();
                    s.setId(salescoupons.getId());
                    s.setStatus(1);//1 代表moto的码活动失效
                    s.setUpdateby(userId);
                    list1.add(s);
                    int row_sales = salescouponsManager.updateSalesCouponStatusBatch(list1);
                    if(row_sales == 1){
                        result.setResultCode(CouponConstant.RESULT_CODE_SUC);
                        result.setResultMsg(CouponConstant.RESULT_MSG_SUC);
                        result.setSuccess(true);
                        log.info("invalidCoupons 结果： "+result);
                        return result;
                    }
                }
            }
        }else {
            log.info("invalidCoupons ： 未找到券活动[" + id + "]");
//            result.setResultCode(CouponConstant.RESULT_CODE_FAIL);
//            result.setResultMsg("未找到券活动");
//            log.info("invalidCoupons 结果： "+result);
//            return result;
            return RemoteResultUtil.convert(ErrorMessageEnum.ERROR_ACTIVE_NOT_FOUND);
        }
        return result;
    }
}
