package com.lenovo.m2.couponV2.service.impl;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.tool.util.CollectionUtils;
import com.lenovo.m2.couponV2.api.dubboModel.DisplayPositionEnum;
import com.lenovo.m2.couponV2.api.model.AvailableSalescouponsApi;
import com.lenovo.m2.couponV2.api.service.AvailableSalescouponsService;
import com.lenovo.m2.couponV2.common.CouponConstant;
import com.lenovo.m2.couponV2.common.DomainUtil;
import com.lenovo.m2.couponV2.common.enums.ModulNameEnum;
import com.lenovo.m2.couponV2.common.exception.ExceptionUtil;
import com.lenovo.m2.couponV2.common.util.JsonUtil;
import com.lenovo.m2.couponV2.common.vo.LogVo;
import com.lenovo.m2.couponV2.dao.mybatis.model.AvailableSalescoupons;
import com.lenovo.m2.couponV2.dao.mybatis.model.AvailableSalescouponsLog;
import com.lenovo.m2.couponV2.dao.util.ResponseResult;
import com.lenovo.m2.couponV2.manager.AvailableSalescouponsManager;
import com.lenovo.m2.couponV2.manager.LogService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Created by fenglg1 on 2016/12/15.
 */
@Service("availableSalescouponsService")
public class AvailableSalescouponsServiceImpl implements AvailableSalescouponsService {
    private static final Logger log = LoggerFactory.getLogger(AvailableSalescouponsServiceImpl.class);
    @Autowired
    private AvailableSalescouponsManager availableSalescouponsManager;

    @Autowired
    private LogService logService;

    @Override
    public RemoteResult<List<AvailableSalescouponsApi>> getAllSelectedAvailableSalescoupons() {
        RemoteResult<List<AvailableSalescouponsApi>> remoteResult = new RemoteResult<List<AvailableSalescouponsApi>>();
        try {
            ResponseResult<List<AvailableSalescoupons>> responseResult = availableSalescouponsManager.getAllSelectedAvailableSalescoupons();
            if(responseResult.isSuccess()){
                remoteResult.setSuccess(true);
                remoteResult.setResultCode(CouponConstant.RESULT_CODE_SUC);
                remoteResult.setResultMsg(CouponConstant.RESULT_MSG_SUC);
                List<AvailableSalescoupons> availableSalescouponsList = responseResult.getData();
                List<AvailableSalescouponsApi> availableSalescouponsApiList = new ArrayList<AvailableSalescouponsApi>();
                DomainUtil domainUtil = new DomainUtil();
                for(AvailableSalescoupons coupon : availableSalescouponsList){
                    AvailableSalescouponsApi availableSalescouponsApi = new AvailableSalescouponsApi();
                    try {
                        domainUtil.copy(coupon, availableSalescouponsApi);
                    } catch (Exception e) {
                        log.error(ExceptionUtil.getStackTrace(e));
                    }
                    availableSalescouponsApiList.add(availableSalescouponsApi);
                }
                remoteResult.setT(availableSalescouponsApiList);
            }else {
                remoteResult.setSuccess(false);
                remoteResult.setResultCode(CouponConstant.RESULT_CODE_FAIL);
                remoteResult.setResultMsg(CouponConstant.RESULT_MSG_FAIL);
            }
        } catch (Exception e) {
            log.error(ExceptionUtil.getStackTrace(e));
            remoteResult.setSuccess(false);
            remoteResult.setResultCode(CouponConstant.RESULT_CODE_ERROR);
            remoteResult.setResultMsg(CouponConstant.RESULT_MSG_ERROR);
        }
        return remoteResult;
    }

    @Override
    public RemoteResult saveAvailableSalescoupons(List<AvailableSalescouponsApi> availableSalescouponsList,DisplayPositionEnum displayPositionEnum) {
        RemoteResult remoteResult = new RemoteResult();
        try {
            List<AvailableSalescoupons> needToSaveCoupons = null;
            if(CollectionUtils.isNotEmpty(availableSalescouponsList)){
                needToSaveCoupons = new ArrayList<AvailableSalescoupons>();
                DomainUtil domainUtil = new DomainUtil();
                StringBuilder coupons = new StringBuilder(availableSalescouponsList.size());
                for (AvailableSalescouponsApi coupon : availableSalescouponsList){
                    AvailableSalescoupons availableSalescoupons = new AvailableSalescoupons();
                    try {
                        domainUtil.copy(coupon, availableSalescoupons);
                        coupons.append(coupon.getSalesCouponsID()).append(",");
                    } catch (Exception e) {
                        log.error(ExceptionUtil.getStackTrace(e));
                    }
                    availableSalescoupons.setDisplayPosition(null == displayPositionEnum? DisplayPositionEnum.USER_CENTER.getCode():displayPositionEnum.getCode());
                    needToSaveCoupons.add(availableSalescoupons);
                }
                coupons.deleteCharAt(coupons.lastIndexOf(","));
                ResponseResult responseResult = availableSalescouponsManager.saveAvailableSalescoupons(needToSaveCoupons);
                if(responseResult.isSuccess()){
                    remoteResult.setSuccess(true);
                    remoteResult.setResultCode(CouponConstant.RESULT_CODE_SUC);
                    remoteResult.setResultMsg(CouponConstant.RESULT_MSG_SUC);
                    log.info("Save available salescoupons success. couponIds: "+ coupons.toString());
                }else {
                    remoteResult.setSuccess(false);
                    remoteResult.setResultCode(CouponConstant.RESULT_CODE_FAIL);
                    remoteResult.setResultMsg(CouponConstant.RESULT_MSG_FAIL);
                    log.info("Save available salescoupons failure. couponIds: "+ coupons.toString());
                }
            }
        } catch (Exception e) {
            log.error(ExceptionUtil.getStackTrace(e));
            remoteResult.setSuccess(false);
            remoteResult.setResultCode(CouponConstant.RESULT_CODE_ERROR);
            remoteResult.setResultMsg(CouponConstant.RESULT_MSG_ERROR);
        }
        return remoteResult;
    }

    @Override
    public RemoteResult deleteAvailableSalescoupons(String operator, Long salesCouponsId,String displayPosition) {
        RemoteResult remoteResult = new RemoteResult();
        try {
            writeSingleAvailableSalescouponsLog(operator, salesCouponsId,displayPosition);
            ResponseResult responseResult = availableSalescouponsManager.deleteAvailableSalescoupons(salesCouponsId,displayPosition);
            if(responseResult.isSuccess()){
                remoteResult.setSuccess(true);
                remoteResult.setResultCode(CouponConstant.RESULT_CODE_SUC);
                remoteResult.setResultMsg(CouponConstant.RESULT_MSG_SUC);
                log.info(String.format("Delete available salescoupons[%s] success", String.valueOf(salesCouponsId)));
            }else {
                remoteResult.setSuccess(false);
                remoteResult.setResultCode(CouponConstant.RESULT_CODE_FAIL);
                remoteResult.setResultMsg(CouponConstant.RESULT_MSG_FAIL);
                log.info(String.format("Delete available salescoupons[%s] failure", String.valueOf(salesCouponsId)));
            }
        } catch (Exception e) {
            log.error(ExceptionUtil.getStackTrace(e));
            remoteResult.setSuccess(false);
            remoteResult.setResultCode(CouponConstant.RESULT_CODE_ERROR);
            remoteResult.setResultMsg(CouponConstant.RESULT_MSG_ERROR);
        }
        return remoteResult;
    }

    private void writeSingleAvailableSalescouponsLog(String operator, Long salesCouponsId,String displayposition) {
        ResponseResult delAvailableSalescoupons = availableSalescouponsManager.getAvailableSalescouponsByCouponId(salesCouponsId);
        if(delAvailableSalescoupons.isSuccess()) {
            List<AvailableSalescoupons> availableSalescoupons =  (List<AvailableSalescoupons>) delAvailableSalescoupons.getData();

            LogVo vo = new LogVo();
            vo.setLenovoId(operator);
            vo.setModul(ModulNameEnum.AVALIBLE_SALES_COIUPON_LOG.getDesc());
            vo.setOperationType("AvailableSalescoupons");
            vo.setContent(JsonUtil.toJson(availableSalescoupons));
            vo.setCreateTime(new Date().toString());
            vo.setOperationType("2");
            vo.setMessage("deleteAvailableSalescoupons");

            logService.save2Mongo(vo);
        }
    }

    @Override
    public RemoteResult deleteAllSelectedAvailableSalescoupons(String operator) {
        RemoteResult remoteResult = new RemoteResult();
        try {
            writeBatchAvailableSalescouponsLog(operator);
            ResponseResult responseResult = availableSalescouponsManager.deleteAllSelectedAvailableSalescoupons();
            if(responseResult.isSuccess()){
                remoteResult.setSuccess(true);
                remoteResult.setResultCode(CouponConstant.RESULT_CODE_SUC);
                remoteResult.setResultMsg(CouponConstant.RESULT_MSG_SUC);
                log.info("Delete All selected available salescoupons success.");
            }else {
                remoteResult.setSuccess(false);
                remoteResult.setResultCode(CouponConstant.RESULT_CODE_FAIL);
                remoteResult.setResultMsg(CouponConstant.RESULT_MSG_FAIL);
                log.info("Delete All selected available salescoupons failure.");
            }
        } catch (Exception e) {
            log.error(ExceptionUtil.getStackTrace(e));
            remoteResult.setSuccess(false);
            remoteResult.setResultCode(CouponConstant.RESULT_CODE_ERROR);
            remoteResult.setResultMsg(CouponConstant.RESULT_MSG_ERROR);
        }
        return remoteResult;
    }

    private void writeBatchAvailableSalescouponsLog(String operator){
        ResponseResult<List<AvailableSalescoupons>> responseResult = availableSalescouponsManager.getAllSelectedAvailableSalescoupons();
        if(responseResult.isSuccess()) {
            List<AvailableSalescoupons> availableSalescouponsList = responseResult.getData();

            LogVo vo = new LogVo();
            vo.setLenovoId(operator);
            vo.setMessage("deleteAllSelectedAvailableSalescoupons");
            vo.setModul(ModulNameEnum.AVALIBLE_SALES_COIUPON_LOG.getDesc());
            vo.setContent(JsonUtil.toJson(availableSalescouponsList));
            vo.setCreateTime(new Date().toString());
            vo.setOperationType("2");
            logService.save2Mongo(vo);
        }
    }

    private AvailableSalescouponsLog assembleAvailableSalescouponsLog(String operator, AvailableSalescoupons availableSalescoupons, Date updateTime) {
        AvailableSalescouponsLog availableSalescouponsLog = new AvailableSalescouponsLog();
        DomainUtil domainUtil = new DomainUtil();
        try {
            domainUtil.copy(availableSalescoupons, availableSalescouponsLog);
        } catch (Exception e) {
            log.error(ExceptionUtil.getStackTrace(e));
        }
        availableSalescouponsLog.setLogBatch(updateTime.getTime());
        availableSalescouponsLog.setUpdateBy(operator);
        availableSalescouponsLog.setUpdateTime(updateTime);
        return availableSalescouponsLog;
    }

   
}
