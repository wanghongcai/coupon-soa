package com.lenovo.m2.couponV2.service.impl;


import com.lenovo.m2.arch.framework.domain.PageModel2;
import com.lenovo.m2.arch.framework.domain.PageQuery;
import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.couponV2.api.model.CouponsCategoryApi;
import com.lenovo.m2.couponV2.api.service.CouponsCategoryService;
import com.lenovo.m2.couponV2.common.CouponConstant;
import com.lenovo.m2.couponV2.common.DomainUtil;
import com.lenovo.m2.couponV2.common.exception.ExceptionUtil;
import com.lenovo.m2.couponV2.dao.mybatis.model.CouponsCategory;
import com.lenovo.m2.couponV2.manager.CouponsCategoryManager;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Created by zhaocl1 on 2015/8/26.
 */
@Service("couponsCategoryService")
public class CouponsCategoryServiceImpl implements CouponsCategoryService {
    private static final Logger log = LoggerFactory.getLogger(CouponsCategoryServiceImpl.class);
    @Autowired
    private CouponsCategoryManager couponsCategoryManager;
    @Override
    public RemoteResult<CouponsCategoryApi> getCouponsCategory(String id) {
        RemoteResult result = new RemoteResult(false);
        try{
            if(StringUtils.isNotEmpty(id)){
                try {
                    CouponsCategory couponsCategory= couponsCategoryManager.selectByPrimaryKey(Integer.parseInt(id));
                    CouponsCategoryApi couponsCategoryApi = new CouponsCategoryApi();
                    new DomainUtil().copy(couponsCategory, couponsCategoryApi);
                    result.setResultMsg(CouponConstant.RESULT_MSG_SUC);
                    result.setResultCode(CouponConstant.RESULT_CODE_SUC);
                    result.setT(couponsCategoryApi);
                    result.setSuccess(true);
                }catch (Exception e){
                    result.setResultMsg(CouponConstant.RESULT_MSG_ERROR);
                    result.setResultCode(CouponConstant.RESULT_CODE_ERROR);
                    result.setSuccess(false);
                }
            }
        }catch (Exception e){
            log.error(ExceptionUtil.getStackTrace(e));
        }
        return result;
    }

    @Override
    public RemoteResult<PageModel2<CouponsCategoryApi>> getCouponsCategoryInfoPage(PageQuery pageQuery, Map map) {
        RemoteResult result = new RemoteResult(false);
        try{
            PageModel2<CouponsCategory> rs = couponsCategoryManager.getCouponsCategoryInfoPage(pageQuery, map);

            List<CouponsCategoryApi> couponsCategoryApiList = new ArrayList<CouponsCategoryApi>();
            if(null != rs && null !=rs.getDatas() && rs.getDatas().size() > 0 ){
                for (CouponsCategory couponsCategory : rs.getDatas()) {
                    CouponsCategoryApi couponsCategoryApi = new CouponsCategoryApi();
                    new DomainUtil().copy(couponsCategory, couponsCategoryApi);
                    couponsCategoryApiList.add(couponsCategoryApi);
                }
            }

            PageModel2<CouponsCategoryApi> pageModel=new PageModel2<CouponsCategoryApi>(pageQuery,couponsCategoryApiList);
            result.setResultMsg(CouponConstant.RESULT_MSG_SUC);
            result.setResultCode(CouponConstant.RESULT_CODE_SUC);
            result.setT(pageModel);
            result.setSuccess(true);
        }catch (Exception e){
            log.error(ExceptionUtil.getStackTrace(e));
            result.setResultMsg(CouponConstant.RESULT_MSG_ERROR);
            result.setResultCode(CouponConstant.RESULT_CODE_ERROR);
            result.setSuccess(false);
        }
        return result;
    }

    @Override
    public RemoteResult<Integer> insertCouponsCategory(CouponsCategoryApi couponsCategoryApi) {

        CouponsCategory couponsCategory =new CouponsCategory();
        RemoteResult result = new RemoteResult(false);
        try {
            new DomainUtil().copy(couponsCategoryApi,couponsCategory);
            int num= couponsCategoryManager.insertSelective(couponsCategory);
            result.setResultMsg(CouponConstant.RESULT_MSG_SUC);
            result.setResultCode(CouponConstant.RESULT_CODE_SUC);
            result.setT(num);
            result.setSuccess(true);
        } catch (Exception e) {
            log.error(ExceptionUtil.getStackTrace(e));
            result.setResultMsg(CouponConstant.RESULT_MSG_ERROR);
            result.setResultCode(CouponConstant.RESULT_CODE_ERROR);
            result.setSuccess(false);
        }
        return result;
    }

    @Override
    public RemoteResult<Boolean> delCouponsCategory(CouponsCategoryApi couponsCategoryApi) {
        CouponsCategory couponsCategory =new CouponsCategory();
        RemoteResult result = new RemoteResult(false);
        try {
            new DomainUtil().copy(couponsCategoryApi,couponsCategory);
            int num= couponsCategoryManager.deleteByPrimaryKey(couponsCategory.getId());
            result.setSuccess(true);
            result.setResultMsg(CouponConstant.RESULT_MSG_SUC);
            result.setResultCode(CouponConstant.RESULT_CODE_SUC);
            result.setT(num);
        } catch (Exception e) {
            log.error(ExceptionUtil.getStackTrace(e));
            result.setResultMsg(CouponConstant.RESULT_MSG_ERROR);
            result.setResultCode(CouponConstant.RESULT_CODE_ERROR);
            result.setSuccess(false);
        }

        return  result;
    }

    @Override
    public RemoteResult<Boolean> editCouponsCategory(CouponsCategoryApi couponsCategoryApi) {
        CouponsCategory couponsCategory =new CouponsCategory();
        RemoteResult result = new RemoteResult(false);
        try {
            new DomainUtil().copy(couponsCategoryApi,couponsCategory);
            int num= couponsCategoryManager.updateByPrimaryKey(couponsCategory);
            result.setSuccess(true);
            result.setResultMsg(CouponConstant.RESULT_MSG_SUC);
            result.setResultCode(CouponConstant.RESULT_CODE_SUC);
            result.setT(num);
        } catch (Exception e) {
            log.error(e.getMessage(),e);
            result.setResultMsg(CouponConstant.RESULT_MSG_ERROR);
            result.setResultCode(CouponConstant.RESULT_CODE_ERROR);
            result.setSuccess(false);
        }

        return  result;
    }

    @Override
    public RemoteResult<Boolean> disableCouponCategoryById(int id) {
        RemoteResult<Boolean> remoteResult = new RemoteResult<Boolean>(false);
        try {
            int i = couponsCategoryManager.disableCouponCategoryById(id);
            if (i>0){
                remoteResult.setSuccess(true);
                remoteResult.setT(true);
                remoteResult.setResultMsg("success");
                return remoteResult;
            }
        }catch (Exception e){
            log.error(ExceptionUtil.getStackTrace(e));
        }
        return null;
    }
}
