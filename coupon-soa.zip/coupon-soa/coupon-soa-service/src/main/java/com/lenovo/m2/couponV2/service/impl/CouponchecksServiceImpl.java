package com.lenovo.m2.couponV2.service.impl;

import com.lenovo.m2.arch.framework.domain.PageModel2;
import com.lenovo.m2.arch.framework.domain.PageQuery;
import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.couponV2.api.model.CouponchecksApi;
import com.lenovo.m2.couponV2.api.service.CouponchecksService;
import com.lenovo.m2.couponV2.common.CouponConstant;
import com.lenovo.m2.couponV2.common.DomainUtil;
import com.lenovo.m2.couponV2.common.RemoteResultUtil;
import com.lenovo.m2.couponV2.common.TripleDESUtil;
import com.lenovo.m2.couponV2.common.enums.ErrorMessageEnum;
import com.lenovo.m2.couponV2.common.exception.ExceptionUtil;
import com.lenovo.m2.couponV2.dao.mybatis.model.Couponchecks;
import com.lenovo.m2.couponV2.dao.mybatis.model.Coupons;
import com.lenovo.m2.couponV2.dao.mybatis.model.Salescoupons;
import com.lenovo.m2.couponV2.dao.util.ResponseResult;
import com.lenovo.m2.couponV2.manager.CouponchecksManager;
import com.lenovo.m2.couponV2.manager.CouponsManager;
import com.lenovo.m2.couponV2.manager.SalescouponsManager;
import com.lenovo.m2.couponV2.manager.redisObject.RedisObjectManager;
import com.lenovo.m2.couponV2.manager.redisObject.lock.RedisLock;

import org.apache.commons.lang.RandomStringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Created by yezhenyue on 2016/2/19.
 */
@Service("couponchecksService")
public class CouponchecksServiceImpl implements CouponchecksService {
    @Autowired
    CouponchecksManager couponchecksManager;
    @Autowired
    SalescouponsManager salescouponsManager;
    
    @Autowired
    private RedisObjectManager redisObjectManager;
    @Autowired
    CouponsManager couponsManager;
    private static final Logger LOGGER = LoggerFactory.getLogger(CouponchecksServiceImpl.class);
    private static final int NUM = 1000;
    private static final ExecutorService executorService = Executors.newCachedThreadPool();
    @Override
    public RemoteResult<PageModel2<CouponchecksApi>> getCouponchecksInfoPage(PageQuery pageQuery, Map map){
        RemoteResult<PageModel2<CouponchecksApi>> result = new RemoteResult<PageModel2<CouponchecksApi>>(false);
        try{
            PageModel2<Couponchecks> rs = couponchecksManager.getCouponchecksInfoPage(pageQuery, map);
            List<CouponchecksApi> couponchecksApis = new ArrayList<CouponchecksApi>();
            if(null != rs && null !=rs.getDatas() && rs.getDatas().size() > 0 ){
                for (Couponchecks couponchecks : rs.getDatas()) {
                    CouponchecksApi couponchecksApi = new CouponchecksApi();
                    new DomainUtil().copy(couponchecks, couponchecksApi);
                    couponchecksApis.add(couponchecksApi);
                }
            }
            PageModel2<CouponchecksApi> pageModel=new PageModel2<CouponchecksApi>(pageQuery,couponchecksApis);
            result.setResultMsg(CouponConstant.RESULT_MSG_SUC);
            result.setResultCode(CouponConstant.RESULT_CODE_SUC);
            result.setT(pageModel);
            result.setSuccess(true);
        }catch (Exception e){
            LOGGER.error(ExceptionUtil.getStackTrace(e));
        }
        return result;
    }
    
    private String  getIDS(List<CouponchecksApi> list){
    	if(null == list){
    		return "";
    	}
    	StringBuffer buffer = new StringBuffer();
    	for(CouponchecksApi api : list){
    		buffer.append(api.getSalescouponid()).append(",");
    	}
    	return buffer.toString();
    }

    @Override
    public RemoteResult<Boolean> updateCouponchecksBatch(List<CouponchecksApi> list) {
        RemoteResult<Boolean> result = new RemoteResult<Boolean>(false);
        String key = "updateCouponchecksBatch_"+getIDS(list);
        RedisLock redisLock = new RedisLock(key, redisObjectManager);
        try {
        	 boolean flag = redisLock.lock(10);
         	if(!flag){
         		return RemoteResultUtil.convert(ErrorMessageEnum.ERROR_APP_ERROR_BUSY);
         	}
            if (list!=null && list.size()>0) {
                List<Couponchecks> couponchecksList = new ArrayList<Couponchecks>();
                List<Salescoupons> salescouponsList = new ArrayList<Salescoupons>();
                for (final CouponchecksApi couponchecksApi:list){
                    ResponseResult<Salescoupons> re = salescouponsManager.getSalescoupons(couponchecksApi.getSalescouponid());
                    if (re != null && re.isSuccess() && re.getData() != null) {
                        final Salescoupons mainCoupon = re.getData();
                        executorService.execute(new Runnable() {
                            @Override
                            public void run() {
                                //style 1优惠券 2优惠码  优惠码审核通过后需要生成一批次码插入coupons表 重复审核通过不再插入
                                if (couponchecksApi.getStyle() == 2 && couponchecksApi.getCheckstatus() == 2 && mainCoupon.getHaspassed() == 0) {
                                    int total = mainCoupon.getMaxnumber();
                                    int count = 0;
                                    LOGGER.info("该批次优惠码的总数量为：" + total + ", salescouponID：" + couponchecksApi.getSalescouponid(),mainCoupon.getCreateby());
                                    if (mainCoupon.getMaxnumber() <= NUM) {
                                        count += produceCouponCodes(mainCoupon, mainCoupon.getMaxnumber(), couponchecksApi.getCheckpersonid(),mainCoupon.getCreateby());
                                    } else {
                                        int n = mainCoupon.getMaxnumber() / NUM;
                                        int m = mainCoupon.getMaxnumber() % NUM;
                                        for (int i = 0; i < n; i++) {
                                            count += produceCouponCodes(mainCoupon, NUM, couponchecksApi.getCheckpersonid(),mainCoupon.getCreateby());
                                        }
                                        count += produceCouponCodes(mainCoupon, m, couponchecksApi.getCheckpersonid(),mainCoupon.getCreateby());
                                    }
                                    LOGGER.info("成功生成的优惠码数量：" + count);
                                }
                            }

                        });
                        Couponchecks couponchecks = new Couponchecks();
                        Salescoupons salescoupons = new Salescoupons();
                        new DomainUtil().copy(couponchecksApi, couponchecks);
                        salescoupons.setId(couponchecksApi.getSalescouponid());
                        salescoupons.setStatus(couponchecksApi.getCheckstatus());
                        salescoupons.setUpdatetime(new Date());
                        salescoupons.setUpdateby(couponchecksApi.getCheckpersonid());
                        if (couponchecksApi.getCheckstatus()==2 && mainCoupon.getHaspassed()==0){
                            salescoupons.setHaspassed(1);
                        }
                        couponchecksList.add(couponchecks);
                        salescouponsList.add(salescoupons);

                        /**
                         * 审核过，再次审核存在修改的可能
                         */
                        if(couponchecksApi.getStyle() == 2 && mainCoupon.getHaspassed()==1){
                            Coupons coupons = new Coupons();
                            coupons.setSalescouponid(mainCoupon.getId());
                            coupons.setStarttime(mainCoupon.getFromtime());
                            coupons.setEndtime(mainCoupon.getTotime());
                            coupons.setTotalnumber(mainCoupon.getTotalnumber());
                            coupons.setType(mainCoupon.getType());
                            couponsManager.updateCouponsBySalescouponsId(coupons);
                        }
                    }
                }
                int num = couponchecksManager.updateCouponchecksBatch(couponchecksList);
                int count = salescouponsManager.updateSalesCouponStatusBatch(salescouponsList);
                if (num>0 && count>0) {
                    result.setSuccess(true);
                    result.setResultMsg(CouponConstant.RESULT_MSG_SUC);
                    result.setResultCode(CouponConstant.RESULT_CODE_SUC);
                    result.setT(true);
                }
            }
        } catch (Exception e) {
            LOGGER.error(ExceptionUtil.getStackTrace(e));
            result.setResultMsg(CouponConstant.RESULT_MSG_ERROR);
            result.setResultCode(CouponConstant.RESULT_CODE_ERROR);
            result.setSuccess(false);
        }finally {
			redisLock.unlock();
		}

        return  result;
    }


    @Override
    public RemoteResult<Boolean> updateCouponSecondchecksBatch(List<CouponchecksApi> list) {
        RemoteResult<Boolean> result = new RemoteResult<Boolean>(false);
        String key = "updateCouponSecondchecksBatch_"+getIDS(list);
        RedisLock redisLock = new RedisLock(key, redisObjectManager);
        try {
        	 boolean flag = redisLock.lock(10);
         	if(!flag){
         		return RemoteResultUtil.convert(ErrorMessageEnum.ERROR_APP_ERROR_BUSY);
         	}
            if (list!=null && list.size()>0) {
                List<Couponchecks> couponchecksList = new ArrayList<Couponchecks>();
                List<Salescoupons> salescouponsList = new ArrayList<Salescoupons>();
                for (final CouponchecksApi couponchecksApi:list){
                    ResponseResult<Salescoupons> re = salescouponsManager.getSalescoupons(couponchecksApi.getSalescouponid());
                    if (re != null && re.isSuccess() && re.getData() != null) {
                        final Salescoupons mainCoupon = re.getData();
                        executorService.execute(new Runnable() {
                            @Override
                            public void run() {
                                //style 1优惠券 2优惠码  优惠码审核通过后需要生成一批次码插入coupons表 重复审核通过不再插入
                                if (couponchecksApi.getStyle() == 2 && couponchecksApi.getCheckstatus() == 2 && mainCoupon.getHaspassed() == 0) {
                                    int total = mainCoupon.getMaxnumber();
                                    int count = 0;
                                    LOGGER.info("该批次优惠码的总数量为：" + total + ", salescouponID：" + couponchecksApi.getSalescouponid(),mainCoupon.getCreateby());
                                    if (mainCoupon.getMaxnumber() <= NUM) {
                                        count += produceCouponCodes(mainCoupon, mainCoupon.getMaxnumber(), couponchecksApi.getCheckpersonid(),mainCoupon.getCreateby());
                                    } else {
                                        int n = mainCoupon.getMaxnumber() / NUM;
                                        int m = mainCoupon.getMaxnumber() % NUM;
                                        for (int i = 0; i < n; i++) {
                                            count += produceCouponCodes(mainCoupon, NUM, couponchecksApi.getCheckpersonid(),mainCoupon.getCreateby());
                                        }
                                        count += produceCouponCodes(mainCoupon, m, couponchecksApi.getCheckpersonid(),mainCoupon.getCreateby());
                                    }
                                    LOGGER.info("成功生成的优惠码数量：" + count);
                                }
                            }

                        });
                        Couponchecks couponchecks = new Couponchecks();
                        Salescoupons salescoupons = new Salescoupons();
                        new DomainUtil().copy(couponchecksApi, couponchecks);
                        salescoupons.setId(couponchecksApi.getSalescouponid());
                        salescoupons.setStatus(couponchecksApi.getCheckstatus());
                        salescoupons.setUpdatetime(new Date());
                        salescoupons.setUpdateby(couponchecksApi.getCheckpersonid());
                        if (couponchecksApi.getCheckstatus()==2 && mainCoupon.getHaspassed()==0){
                            salescoupons.setHaspassed(1);
                        }
                        couponchecksList.add(couponchecks);
                        salescouponsList.add(salescoupons);

                        /**
                         * 审核过，再次审核存在修改的可能
                         */
                        if(couponchecksApi.getStyle() == 2 && mainCoupon.getHaspassed()==1){
                            Coupons coupons = new Coupons();
                            coupons.setSalescouponid(mainCoupon.getId());
                            coupons.setStarttime(mainCoupon.getFromtime());
                            coupons.setEndtime(mainCoupon.getTotime());
                            coupons.setTotalnumber(mainCoupon.getTotalnumber());
                            coupons.setType(mainCoupon.getType());
                            couponsManager.updateCouponsBySalescouponsId(coupons);
                        }
                    }
                }
                int num = couponchecksManager.updateCouponSecondchecksBatch(couponchecksList);
                int count = salescouponsManager.updateSalesCouponStatusBatch(salescouponsList);
                if (num>0 && count>0) {
                    result.setSuccess(true);
                    result.setResultMsg(CouponConstant.RESULT_MSG_SUC);
                    result.setResultCode(CouponConstant.RESULT_CODE_SUC);
                    result.setT(true);
                }
            }
        } catch (Exception e) {
            LOGGER.error(ExceptionUtil.getStackTrace(e));
            result.setResultMsg(CouponConstant.RESULT_MSG_ERROR);
            result.setResultCode(CouponConstant.RESULT_CODE_ERROR);
            result.setSuccess(false);
        }finally {
        	redisLock.unlock();
		}

        return  result;
    }

    @Override
    public RemoteResult<Boolean> updateCouponSecondCodechecksBatch(List<CouponchecksApi> list) {
        RemoteResult<Boolean> result = new RemoteResult<Boolean>(false);
        String key = "updateCouponSecondCodechecksBatch_"+getIDS(list);
        RedisLock redisLock = new RedisLock(key, redisObjectManager);
        try {
        	 boolean flag = redisLock.lock(10);
         	if(!flag){
         		return RemoteResultUtil.convert(ErrorMessageEnum.ERROR_APP_ERROR_BUSY);
         	}
            if (list!=null && list.size()>0) {
                List<Couponchecks> couponchecksList = new ArrayList<Couponchecks>();
                List<Salescoupons> salescouponsList = new ArrayList<Salescoupons>();
                for (final CouponchecksApi couponchecksApi:list){
                    ResponseResult<Salescoupons> re = salescouponsManager.getSalescoupons(couponchecksApi.getSalescouponid());
                    if (re != null && re.isSuccess() && re.getData() != null) {
                        final Salescoupons mainCoupon = re.getData();
                        executorService.execute(new Runnable() {
                            @Override
                            public void run() {
                                //style 1优惠券 2优惠码  优惠码审核通过后需要生成一批次码插入coupons表 重复审核通过不再插入
                                if (couponchecksApi.getStyle() == 2 && couponchecksApi.getCheckstatus() == 2 && mainCoupon.getHaspassed() == 0) {
                                    int total = mainCoupon.getMaxnumber();
                                    int count = 0;
                                    LOGGER.info("该批次优惠码的总数量为：" + total + ", salescouponID：" + couponchecksApi.getSalescouponid(),mainCoupon.getCreateby());
                                    if (mainCoupon.getMaxnumber() <= NUM) {
                                        count += produceCouponCodes(mainCoupon, mainCoupon.getMaxnumber(), couponchecksApi.getCheckpersonid(),mainCoupon.getCreateby());
                                    } else {
                                        int n = mainCoupon.getMaxnumber() / NUM;
                                        int m = mainCoupon.getMaxnumber() % NUM;
                                        for (int i = 0; i < n; i++) {
                                            count += produceCouponCodes(mainCoupon, NUM, couponchecksApi.getCheckpersonid(),mainCoupon.getCreateby());
                                        }
                                        count += produceCouponCodes(mainCoupon, m, couponchecksApi.getCheckpersonid(),mainCoupon.getCreateby());
                                    }
                                    LOGGER.info("成功生成的优惠码数量：" + count);
                                }
                            }

                        });
                        Couponchecks couponchecks = new Couponchecks();
                        Salescoupons salescoupons = new Salescoupons();
                        new DomainUtil().copy(couponchecksApi, couponchecks);
                        salescoupons.setId(couponchecksApi.getSalescouponid());
                        salescoupons.setStatus(couponchecksApi.getCheckstatus());
                        salescoupons.setUpdatetime(new Date());
                        salescoupons.setUpdateby(couponchecksApi.getCheckpersonid());
                        if (couponchecksApi.getCheckstatus()==2 && mainCoupon.getHaspassed()==0){
                            salescoupons.setHaspassed(1);
                        }
                        couponchecksList.add(couponchecks);
                        salescouponsList.add(salescoupons);

                        /**
                         * 审核过，再次审核存在修改的可能
                         */
                        if(couponchecksApi.getStyle() == 2 && mainCoupon.getHaspassed()==1){
                            Coupons coupons = new Coupons();
                            coupons.setSalescouponid(mainCoupon.getId());
                            coupons.setStarttime(mainCoupon.getFromtime());
                            coupons.setEndtime(mainCoupon.getTotime());
                            coupons.setTotalnumber(mainCoupon.getTotalnumber());
                            coupons.setType(mainCoupon.getType());
                            couponsManager.updateCouponsBySalescouponsId(coupons);
                        }
                    }
                }
                int num = couponchecksManager.updateCouponchecksBatch(couponchecksList);
                int count = salescouponsManager.updateSalesCouponStatusBatch(salescouponsList);
                if (num>0 && count>0) {
                    result.setSuccess(true);
                    result.setResultMsg(CouponConstant.RESULT_MSG_SUC);
                    result.setResultCode(CouponConstant.RESULT_CODE_SUC);
                    result.setT(true);
                }
            }
        } catch (Exception e) {
            LOGGER.error(ExceptionUtil.getStackTrace(e));
            result.setResultMsg(CouponConstant.RESULT_MSG_ERROR);
            result.setResultCode(CouponConstant.RESULT_CODE_ERROR);
            result.setSuccess(false);
        }finally {
			redisLock.unlock();
		}

        return  result;
    }

   /*
    * yuzj7 2017年5月12日10:38:49 edit 加入事务，加快审核，加快优惠码生成速度
    * (非 Javadoc)
   * <p>Title: checkCouponByCondition</p>
   * <p>Description: </p>
   * @param couponchecksApi
   * @return
   * @see com.lenovo.m2.couponV2.api.service.CouponchecksService#checkCouponByCondition(com.lenovo.m2.couponV2.api.model.CouponchecksApi)
    */
    @Override
    @Transactional(propagation=Propagation.REQUIRED,isolation=Isolation.READ_COMMITTED)
    public RemoteResult<Boolean> checkCouponByCondition(CouponchecksApi couponchecksApi) {
        RemoteResult<Boolean> result = new RemoteResult<Boolean>(false);
        String key = "checkCouponByCondition_"+couponchecksApi.getSalescouponid();
        RedisLock redisLock = new RedisLock(key, redisObjectManager);
        try {
        	boolean flag = redisLock.lock(10);
        	if(!flag){
        		return RemoteResultUtil.convert(ErrorMessageEnum.ERROR_APP_ERROR_BUSY);
        	}
            ResponseResult<Salescoupons> re = salescouponsManager.getSalescoupons(couponchecksApi.getSalescouponid());
            if (re != null && re.isSuccess() && re.getData() != null) {
                Salescoupons mainCoupon = re.getData();
                //style 1优惠券 2优惠码  优惠码审核通过后需要生成一批次码插入coupons表 重复审核通过不再插入
                if (couponchecksApi.getStyle() == 2 && couponchecksApi.getCheckstatus() == 2 && mainCoupon.getHaspassed()==0) {
                    int total = mainCoupon.getMaxnumber();
                    int count = 0;
                    LOGGER.info("该批次优惠码的总数量为：" + total + ", salescouponID：" + couponchecksApi.getSalescouponid(),mainCoupon.getCreateby());
                    if (mainCoupon.getMaxnumber() <= NUM) {
                        count += produceCouponCodes(mainCoupon, mainCoupon.getMaxnumber(), couponchecksApi.getCheckpersonid(),mainCoupon.getCreateby());
                    } else {
                        int n = mainCoupon.getMaxnumber() / NUM;
                        int m = mainCoupon.getMaxnumber() % NUM;
                        for (int i = 0; i < n; i++) {
                            count += produceCouponCodes(mainCoupon, NUM, couponchecksApi.getCheckpersonid(),mainCoupon.getCreateby());
                        }
                        count += produceCouponCodes(mainCoupon, m, couponchecksApi.getCheckpersonid(),mainCoupon.getCreateby());
                    }
                    LOGGER.info("成功生成的优惠码数量：" + count);
                }
            Couponchecks couponchecks = new Couponchecks();
            Salescoupons salescoupons = new Salescoupons();
            new DomainUtil().copy(couponchecksApi, couponchecks);
            salescoupons.setId(couponchecksApi.getSalescouponid());
            salescoupons.setStatus(couponchecksApi.getCheckstatus());
            salescoupons.setUpdatetime(new Date());
            salescoupons.setUpdateby(couponchecksApi.getCheckpersonid());
            if (couponchecksApi.getCheckstatus()==2 && mainCoupon.getHaspassed()==0){
                salescoupons.setHaspassed(1);
            }
            int num = couponchecksManager.checkCouponByCondition(couponchecks);
            ResponseResult responseResult = salescouponsManager.editSalescoupons(salescoupons);
            /**
             * 更新码数据
             */
            if(couponchecksApi.getStyle() == 2 && mainCoupon.getHaspassed()==1){
                Coupons coupons = new Coupons();
                coupons.setSalescouponid(mainCoupon.getId());
//                coupons.setName(mainCoupon.getName());
//                coupons.setAmount(mainCoupon.getAmount());
                coupons.setStarttime(mainCoupon.getFromtime());
                coupons.setEndtime(mainCoupon.getTotime());
                coupons.setTotalnumber(mainCoupon.getTotalnumber());
                coupons.setType(mainCoupon.getType());
                couponsManager.updateCouponsBySalescouponsId(coupons);
            }


            if (num > 0 && responseResult != null && responseResult.isSuccess()) {
                result.setSuccess(true);
                result.setResultMsg(CouponConstant.RESULT_MSG_SUC);
                result.setResultCode(CouponConstant.RESULT_CODE_SUC);
                result.setT(true);
            }
            }
        } catch (Exception e) {
            LOGGER.error(ExceptionUtil.getStackTrace(e));
            result.setResultMsg(CouponConstant.RESULT_MSG_ERROR);
            result.setResultCode(CouponConstant.RESULT_CODE_ERROR);
            result.setSuccess(false);
        }finally {
        	redisLock.unlock();
		}

        return result;
    }

    /**
     * 批量生成优惠码
     * @param main 优惠码主属性对象
     * @param count 要生成的数量
     * @param operator 操作人
     * @return 返回成功的数量
     */
    private int produceCouponCodes(Salescoupons main,int count,String checkPerson,String operator){
        if (count<=0){
            LOGGER.info("优惠码的批次创建数量为0");
            return 0;
        }
        List<Coupons> list = new ArrayList<Coupons>();
        for (int i = 0; i < count; i++) {
            Coupons couponCode = new Coupons();
            couponCode.setBatchno(main.getBatchno());
            couponCode.setAmount(main.getAmount());
            couponCode.setName(main.getName());
            couponCode.setMacode(TripleDESUtil.encryptMode(RandomStringUtils.randomAlphanumeric(10)));
            couponCode.setStatus(CouponConstant.COUPON_COUPONS_STATUS_NORMAL); //0正常，1禁用
            couponCode.setSalescouponid(main.getId());
            couponCode.setShopid(main.getShopid());
            couponCode.setTerminal(main.getTerminal());
            couponCode.setType(main.getType());
            couponCode.setStarttime(main.getFromtime());
            couponCode.setEndtime(main.getTotime());
            couponCode.setTotalnumber(main.getTotalnumber());
            couponCode.setSurplusnumber(main.getTotalnumber());
            couponCode.setGroupcode(main.getEppgroup());
            couponCode.setOccupynumber(0);
            couponCode.setCreatetime(new Date());
            couponCode.setCreateby(operator);
            couponCode.setUpdateby(checkPerson);
            couponCode.setUpdatetime(new Date());
            couponCode.setCurrencyCode(main.getCurrencyCode());
            list.add(couponCode);
        }
        ResponseResult<Integer> result= couponsManager.insertBatch(list);
        if (result!=null&&result.isSuccess()){
            return result.getData();
        }
        return 0;
    }
    @Override
    public RemoteResult<CouponchecksApi> queryCouponCheckById(long id) {
        RemoteResult<CouponchecksApi> result = new RemoteResult<CouponchecksApi>(false);
        try {
            RemoteResult<Couponchecks> remoteResult = couponchecksManager.queryCouponCheckById(id);
            if (remoteResult != null && remoteResult.isSuccess() && remoteResult.getT() != null) {
                CouponchecksApi couponchecksApi = new CouponchecksApi();
                new DomainUtil().copy(remoteResult.getT(), couponchecksApi);
                result.setT(couponchecksApi);
                result.setSuccess(true);
            }
        }catch (Exception e){
            LOGGER.error(ExceptionUtil.getStackTrace(e));
        }
        return result;
    }

}
