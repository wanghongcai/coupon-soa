package com.lenovo.m2.base;

import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractJUnit4SpringContextTests;

/**
 * Created by fenglg1 on 2016/11/30.
 */
@ContextConfiguration(locations = {
		"classpath:applicationContext-resources.xml",
		"classpath:applicationContext-dao.xml",
		"classpath:applicationContext-coupon-manager.xml",
		"classpath:applicationContext-coupon-service.xml",
		"classpath:applicationContext-aop.xml",
		"classpath:applicationContext-redis-shard.xml",
		"classpath:applicationContext-provider.xml",
		"classpath:applicationContext-rpc.xml",
		"classpath:applicationContext-akka.xml",
		"classpath:applicationContext-mongo.xml",
		"classpath:applicationContext-dubbo-rpc.xml",
		"classpath:applicationContext-kafka-produce.xml"
		})
public class BaseTest extends AbstractJUnit4SpringContextTests {
	java.util.logging.Logger g;
}
