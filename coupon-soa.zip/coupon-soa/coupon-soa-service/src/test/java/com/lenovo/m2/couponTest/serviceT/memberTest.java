package com.lenovo.m2.couponTest.serviceT;

import com.lenovo.m2.arch.framework.domain.PageModel2;
import com.lenovo.m2.arch.framework.domain.PageQuery;
import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.base.BaseTest;
import com.lenovo.m2.couponV2.api.model.CouponsApi;
import com.lenovo.m2.couponV2.api.model.SalescouponsApi;
import com.lenovo.m2.couponV2.api.service.CouponsService;
import com.lenovo.m2.couponV2.api.service.SalescouponsService;
import com.lenovo.m2.couponV2.api.service.UcenterService;
import com.lenovo.m2.couponV2.common.JacksonMapper;
import com.lenovo.m2.couponV2.remote.IDSequenceService;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class memberTest extends BaseTest{
    @Autowired
    private UcenterService ucenterService;

    @Autowired
    private CouponsService couponsService;

    @Autowired
    private SalescouponsService salescouponsService;

    @Autowired
    private IDSequenceService idSequenceService;


    @Test
    public void getiD(){
//        String s = idSequenceService.genId();
//        System.out.println(s);
        RemoteResult<Boolean> result = salescouponsService.bindCoupons("15", 107881l, "1000076820", "13051167289");
        System.out.println(JacksonMapper.obj2json(result));

    }
    @Test
    public void getAvailableSalescouponsInfoPage(){
        Map map = new HashMap();
        map.put("style",1);
        map.put("shopids","1,3,5,8,9,15,14");
        RemoteResult<PageModel2<SalescouponsApi>> availableSalescouponsInfoPage = salescouponsService.getAvailableSalescouponsInfoPage(new PageQuery(1, 10), map);
        System.out.println(JacksonMapper.obj2json(availableSalescouponsInfoPage));

    }

    @Test
    public void getUserCreateData(){
        Date memberRegisterTime = ucenterService.getMemberRegisterTime("1000012997", "14");
        System.out.println(memberRegisterTime);
    }

    @Test
    public void getInfoPage(){
        Map map = new HashMap();
        RemoteResult<PageModel2<CouponsApi>> result = couponsService.getCouponsInfoPage(new PageQuery(1, 10), map);
        System.out.println(JacksonMapper.obj2json(result));
    }
}
