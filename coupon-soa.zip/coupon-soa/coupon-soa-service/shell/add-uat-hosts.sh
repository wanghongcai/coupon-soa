echo '10.120.120.72  zk01.app.lenovo.com' >> /etc/hosts
echo '10.120.120.73  zk02.app.lenovo.com' >> /etc/hosts
echo '10.120.120.74  zk03.app.lenovo.com' >> /etc/hosts

echo '10.120.120.72 c01.zk.dtc.uat' >> /etc/hosts
echo '10.120.120.73 c02.zk.dtc.uat' >> /etc/hosts
echo '10.120.21.131 c03.zk.dtc.uat' >> /etc/hosts
