package com.lenovo.m2.couponV2.manager;

import com.lenovo.m2.couponV2.dao.mybatis.model.MembercouponrelsLog;
import com.lenovo.m2.couponV2.dao.util.ResponseResult;

import java.util.List;

/**
 * Created by zhaocl1 on 2016/3/4.
 */
public interface MembercouponrelsLogManager {

    /**
     * 批量插入优惠券使用日志记录
     * @param list
     * @return
     */
    ResponseResult insertBatch(List<MembercouponrelsLog> list);


    /**
     * 根据临时订单号 更新主订单号
     * @param token
     * @param orderId
     * @return
     */
    ResponseResult updateMembercouponrelsLog(String token,String orderId);
}
