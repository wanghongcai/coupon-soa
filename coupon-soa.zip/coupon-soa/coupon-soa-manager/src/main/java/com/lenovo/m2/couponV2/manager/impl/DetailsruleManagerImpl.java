package com.lenovo.m2.couponV2.manager.impl;

import com.lenovo.m2.couponV2.common.CouponConstant;
import com.lenovo.m2.couponV2.common.exception.ExceptionUtil;
import com.lenovo.m2.couponV2.dao.mybatis.mapper.DetailsruleMapper;
import com.lenovo.m2.couponV2.dao.mybatis.model.Detailsrule;
import com.lenovo.m2.couponV2.dao.mybatis.model.DetailsruleExample;
import com.lenovo.m2.couponV2.dao.util.ResponseResult;
import com.lenovo.m2.couponV2.manager.DetailsruleManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

/**
 * Created by zhaocl1 on 2016/2/15.
 */
@Component("detailsruleManager")
public class DetailsruleManagerImpl implements DetailsruleManager {
    private static final Logger LOGGER = LoggerFactory.getLogger(DetailsruleManagerImpl.class);

    @Autowired
    private DetailsruleMapper detailsruleMapper;

    @Override
    public ResponseResult insertBatchDetailsrule(List<Detailsrule> detailsruleList) {
        ResponseResult result = new ResponseResult(false);
        if(detailsruleList != null ){
            if(detailsruleList.size() > 0){
                int row = detailsruleMapper.insertBatchDetailsrule(detailsruleList);
                if(row == detailsruleList.size()){
                    result.setMsg(CouponConstant.RESULT_MSG_SUC);
                    result.setCode(CouponConstant.RESULT_CODE_SUC);
                    result.setSuccess(true);
                }else {
                    result.setMsg(CouponConstant.RESULT_MSG_FAIL);
                    result.setCode(CouponConstant.RESULT_CODE_FAIL);
                }
            }else {
                result.setMsg(CouponConstant.RESULT_MSG_ERROR_PARAM);
                result.setCode(CouponConstant.RESULT_CODE_ERROR_PARAM);
            }
        }else {
            result.setMsg(CouponConstant.RESULT_MSG_ERROR_PARAM);
            result.setCode(CouponConstant.RESULT_CODE_ERROR_PARAM);
        }
        return result;
    }

    @Override
    public ResponseResult delDetailsrule(Detailsrule detailsrule) {
        ResponseResult result = new ResponseResult(false);
        if(detailsrule!=null){
            DetailsruleExample detailsruleExample = new DetailsruleExample();
            detailsruleExample.createCriteria().andSalescouponidEqualTo(detailsrule.getSalescouponid());
            int row = detailsruleMapper.deleteByExample(detailsruleExample);
            if(row>0){
                //注意：有些垃圾数据是分类券但是没有分类，删除的时候row=0
                result.setMsg(CouponConstant.RESULT_MSG_SUC);
                result.setCode(CouponConstant.RESULT_CODE_SUC);
                result.setSuccess(true);
            }
        }else {
            result.setMsg(CouponConstant.RESULT_MSG_ERROR_PARAM);
            result.setCode(CouponConstant.RESULT_CODE_ERROR_PARAM);
        }
        return result;
    }

    @Override
    public ResponseResult<List<Detailsrule>> getDetailsruleList(Detailsrule detailsrule) {
        ResponseResult result = new ResponseResult(false);
        if(detailsrule!=null){
            DetailsruleExample detailsruleExample = new DetailsruleExample();
            detailsruleExample.createCriteria().andSalescouponidEqualTo(detailsrule.getSalescouponid());
            List<Detailsrule> list = detailsruleMapper.selectByExampleWithBLOBs(detailsruleExample);
            if(list != null && list.size()>0){
                result.setMsg(CouponConstant.RESULT_MSG_SUC);
                result.setCode(CouponConstant.RESULT_CODE_SUC);
                result.setData(list);
                result.setSuccess(true);
            }
        }else {
            result.setMsg(CouponConstant.RESULT_MSG_ERROR_PARAM);
            result.setCode(CouponConstant.RESULT_CODE_ERROR_PARAM);
        }
        return result;
    }

    @Override
    public ResponseResult<List<Detailsrule>> getBatchBySalescouponids(Map map) {
        ResponseResult result = new ResponseResult(false);
        try {
            if(map == null ){
                result.setCode(CouponConstant.RESULT_CODE_ERROR_PARAM);
                result.setMsg(CouponConstant.RESULT_MSG_ERROR_PARAM);
                return result;
            }

            List<Detailsrule> list = detailsruleMapper.getBatchBySalescouponids(map);
            if(list != null && list.size()>0){
                result.setData(list);
                result.setSuccess(true);
                return result;
            }else {
                LOGGER.info("没有找到数据记录 主键IDs: " + map.get("ids"));
                result.setMsg("通过主键s未找到用户优惠券！");
                return result;
            }

        } catch (Exception e) {
            LOGGER.error("数据库操作失败" + ExceptionUtil.getStackTrace(e));
            result.setMsg("数据库操作失败");
            return result;
        }
    }

    @Override
    public ResponseResult<List<Detailsrule>> getBatchByCategorycodeId(Map map) {
        ResponseResult result = new ResponseResult(false);
        try {
            if(map == null ){
                result.setCode(CouponConstant.RESULT_CODE_ERROR_PARAM);
                result.setMsg(CouponConstant.RESULT_MSG_ERROR_PARAM);
                return result;
            }

            List<Detailsrule> list = detailsruleMapper.getBatchByCategorycodeId(map);
            if(list != null && list.size()>0){
                result.setData(list);
                result.setSuccess(true);
                return result;
            }else {
                LOGGER.info("没有找到数据记录 主键salesCouponID: " + map.get("salesCouponID") + ";" + map.get("categorycodeId"));
                result.setMsg("通过主键s未找到用户优惠券！");
                return result;
            }

        } catch (Exception e) {
            LOGGER.error(ExceptionUtil.getStackTrace(e));
            result.setMsg("数据库操作失败");
            return result;
        }
    }
}
