package com.lenovo.m2.couponV2.manager;

import com.lenovo.m2.arch.framework.domain.PageModel2;
import com.lenovo.m2.arch.framework.domain.PageQuery;
import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.couponV2.api.dubboModel.MemberExcelTempApi;
import com.lenovo.m2.couponV2.dao.mybatis.model.MemberExcelTemp;
import com.lenovo.m2.couponV2.dao.util.ResponseResult;

import java.text.ParseException;
import java.util.List;
import java.util.Map;

/**
 * Created by yuzn1 on 2016/5/17.
 */
public interface MemberExcelTempManager {

    /**
     * save
     * @param list
     * @return
     */
    public ResponseResult insertBatch(List<MemberExcelTemp> list);

    /**
     * 查出重复数据
     */
    public List<MemberExcelTemp> selectIsRepeat(String itCode);

    /**
     * 更新重复数据状态IsRepeatd==1
     *
     */
    int  updateIsRepeatd(Map<String, Object> map);

    /**
     * 查询导入excel信息
     * @param pageQuery
     * @param map
     * @return
     */
    public PageModel2<MemberExcelTemp> getMemberExcelTempPage(PageQuery pageQuery, Map map);

    //getIsRepeat

    /**
     * MemberExcelTempApi取重
     * @return
     */
     ResponseResult getIsRepeat(String itCode);

    /**
     *查询有效信息
     */
    ResponseResult getValidList(String itCode);

    /**
     * 删除导入excel人员信息
     * @param map
     * @return
     */
    ResponseResult toDelete_exMember(Map map);

    /**
     * 删除本次所有excle导入信息
     * @return
     */
    ResponseResult deleteAll(String itCode);
}
