package com.lenovo.m2.couponV2.manager.impl;

import com.lenovo.m2.arch.framework.domain.PageModel2;
import com.lenovo.m2.arch.framework.domain.PageQuery;
import com.lenovo.m2.couponV2.common.JacksonMapper;
import com.lenovo.m2.couponV2.dao.mybatis.reportmapper.CouponReportMapper;
import com.lenovo.m2.couponV2.dao.mybatis.model.CouponReport;
import com.lenovo.m2.couponV2.manager.CouponReportManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

/**
 * Created by fenglg1 on 2017/1/9.
 */
@Component("couponReportManager")
public class CouponReportManagerImpl implements CouponReportManager {

    @Autowired
    private CouponReportMapper couponReportMapper;

    @Override
    public PageModel2<CouponReport> getCouponReportInfoPage(PageQuery pageQuery, Map map) {
        return new PageModel2(couponReportMapper.getMemberCouponByCondition(pageQuery, map));
    }

    @Override
    public PageModel2<CouponReport> getCouponAndOrderInfoPage(PageQuery pageQuery, Map map) {
        return new PageModel2(couponReportMapper.exportMemberCouponByCouponID(pageQuery, map));
    }

    @Override
    public PageModel2<CouponReport> exportMemberCouponOrderIdByMemberCoupon(PageQuery pageQuery, List list) {
        System.out.println("exportMemberCouponOrderIdByMemberCoupon" + JacksonMapper.obj2json(list));
        return new PageModel2(couponReportMapper.exportMemberCouponOrderIdByMemberCoupon(pageQuery, list));
    }
}
