package com.lenovo.m2.couponV2.manager;

import com.lenovo.m2.couponV2.dao.mybatis.model.Usercouponrel;
import com.lenovo.m2.couponV2.dao.util.ResponseResult;

import java.util.List;

/**
 * Created by zhaocl1 on 2015/9/15.
 */
public interface UsercouponrelManager {

    /**
     * save
     * @param list
     * @return
     */
    public ResponseResult insertBatch(List<Usercouponrel> list);

    /**
     * 根据条件获取列表
     * @param usercouponrel
     * @return
     */
    ResponseResult<List<Usercouponrel>> getUsercouponrelByCondition(Usercouponrel usercouponrel);
}