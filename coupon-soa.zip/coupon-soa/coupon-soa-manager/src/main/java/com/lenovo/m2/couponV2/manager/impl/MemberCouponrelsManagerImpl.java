package com.lenovo.m2.couponV2.manager.impl;

import com.alibaba.dubbo.common.utils.StringUtils;
import com.lenovo.m2.arch.framework.domain.PageModel2;
import com.lenovo.m2.arch.framework.domain.PageQuery;
import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.tool.util.CollectionUtils;
import com.lenovo.m2.arch.tool.util.DateFormatUtils;
import com.lenovo.m2.couponV2.common.CouponConstant;
import com.lenovo.m2.couponV2.common.exception.ExceptionUtil;
import com.lenovo.m2.couponV2.common.util.JsonUtil;
import com.lenovo.m2.couponV2.common.util.StringUtil;
import com.lenovo.m2.couponV2.dao.mybatis.mapper.MembercouponrelsMapper;
import com.lenovo.m2.couponV2.dao.mybatis.model.Membercouponrels;
import com.lenovo.m2.couponV2.dao.mybatis.model.MembercouponrelsExample;
import com.lenovo.m2.couponV2.dao.util.ResponseResult;
import com.lenovo.m2.couponV2.manager.MemberCouponrelsManager;
import com.lenovo.m2.couponV2.manager.MembercouponrelsLogManager;
import com.lenovo.m2.couponV2.manager.conf.UpdateConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.text.ParseException;
import java.util.*;

/**
 * Created by yezhenyue on 2016/1/19.
 */
@Component("memberCouponrelsManager")
public class MemberCouponrelsManagerImpl implements MemberCouponrelsManager {
    private static final Logger LOGGER = LoggerFactory.getLogger(MemberCouponrelsManagerImpl.class);
    @Autowired
    private MembercouponrelsLogManager membercouponrelsLogManager;

    @Resource(name = "membercouponrelsMapper")
    private  MembercouponrelsMapper membercouponrelsMapper;

    @Autowired
    private UpdateConfig updateConfig;
    @Override
    public PageModel2<Membercouponrels> getMemberCouponrelsPage(PageQuery pageQuery, Map map) throws ParseException {
        MembercouponrelsExample example = new MembercouponrelsExample();
        MembercouponrelsExample.Criteria criteria = example.createCriteria();
        if (map.get("name")!=null){
            criteria.andNameEqualTo(map.get("name").toString());
        }
        if (map.get("couponcode")!=null){
            criteria.andCouponcodeEqualTo(map.get("couponcode").toString());
        }
        if (map.get("lenovoid")!=null){
            criteria.andLenovoidEqualTo(map.get("lenovoid").toString());
        }
        if (map.get("usescope")!=null){
            criteria.andUsescopeEqualTo(Integer.parseInt(map.get("usescope").toString()));
        }
        if(map.get("membercode")!=null){
            criteria.andMembercodeEqualTo(map.get("membercode").toString());
        }
        if (map.get("disabled")!=null){
            criteria.andDisabledEqualTo(Integer.parseInt(map.get("disabled").toString()));
        }
        if (map.get("status")!=null){
            criteria.andStatusEqualTo(Integer.parseInt(map.get("status").toString()));
        }
        if (map.get("classificationname")!=null){
            criteria.andClassificationnameEqualTo(map.get("classificationname").toString());
        }
        if (map.get("fromtime")!=null){
            criteria.andFromtimeGreaterThanOrEqualTo(DateFormatUtils.parseDate(map.get("fromtime").toString(), "yyyy-MM-dd"));
        }
        if (map.get("totime")!=null){
            criteria.andTotimeLessThanOrEqualTo(DateFormatUtils.parseDate(map.get("totime").toString(), "yyyy-MM-dd"));
        }
        if (map.get("createtime_start")!=null){
            criteria.andCreatetimeGreaterThanOrEqualTo(DateFormatUtils.parseDate(map.get("createtime_start").toString(), "yyyy-MM-dd"));
        }
        if (map.get("createtime_end")!=null){
            criteria.andCreatetimeLessThanOrEqualTo(DateFormatUtils.parseDate(map.get("createtime_end").toString(), "yyyy-MM-dd"));
        }
        if (map.get("shopid")!=null){
            criteria.andShopidEqualTo(map.get("shopid").toString());
        }
        if (map.get("shopids")!=null){
            criteria.andShopidIn((ArrayList<String>)map.get("shopids"));
        }
        if (map.get("terminal")!=null){
            criteria.andTerminalLike("%" + map.get("terminal").toString() + "%");
        }
        if (map.get("classification")!=null){
            criteria.andClassificationEqualTo(Integer.parseInt(map.get("classification").toString()));
        }

        int count = updateConfig.getMembercouponrelsMapper().countByExample(example);
        pageQuery.setTotalCount(count);
        if (pageQuery.getTotalCount()==0){
            return new PageModel2<Membercouponrels>();
        }
        int pageIndex = (pageQuery.getPageNum() - 1) * pageQuery.getPageSize();
        int pageSize = pageQuery.getPageSize();
        map.put("pageindex", pageIndex);
        map.put("pagesize", pageSize);
        LOGGER.info("getMemberCouponrelsPage param={}"+ JsonUtil.toJson(map));
        List<Membercouponrels> list =  updateConfig.getMembercouponrelsMapper().getMemberCouponrelsPage(map);
        LOGGER.info("getMemberCouponrelsPage return={}"+ JsonUtil.toJson(list));
        return new PageModel2<Membercouponrels>(pageQuery,list);
    }

    @Override
    public PageModel2<Membercouponrels> getMemberCouponrelsInfoPage(PageQuery pageQuery, Map map) throws ParseException {
        return new PageModel2(updateConfig.getMembercouponrelsMapper().getMemberCouponrelsInfoPage(pageQuery, map));
    }

    @Override
    public RemoteResult<Boolean> disableMemberCouponById(long id) {
        RemoteResult<Boolean> remoteResult = new RemoteResult<Boolean>(false);
        Membercouponrels membercouponrels = new Membercouponrels();
        membercouponrels.setId(id);
        membercouponrels.setDisabled(1);
        membercouponrels.setUpdatetime(new Date());
        try {
            int i = updateConfig.getMembercouponrelsMapper().updateByPrimaryKeySelective(membercouponrels);
            if (i > 0) {
                remoteResult.setT(true);
                remoteResult.setSuccess(true);
                remoteResult.setResultMsg("success");
                return remoteResult;
            }else {
                remoteResult.setResultMsg("没有找到数据记录");
                return remoteResult;
            }
        }catch (Exception e){
            LOGGER.error("数据库操作失败" + ExceptionUtil.getStackTrace(e));
            return remoteResult;
        }
    }

    @Override
    public RemoteResult<Membercouponrels> queryMemberCouponById(long id) {
        RemoteResult<Membercouponrels> remoteResult = new RemoteResult<Membercouponrels>(false);
        try {
            Membercouponrels membercouponrels = updateConfig.getMembercouponrelsMapper().selectByPrimaryKey(id);
            if (membercouponrels!=null) {
                remoteResult.setT(membercouponrels);
                remoteResult.setSuccess(true);
                remoteResult.setResultMsg("success");
                return remoteResult;
            }else {
                LOGGER.info("没有找到数据记录 主键ID: " + id);
                remoteResult.setResultMsg("没有找到数据记录");
                return remoteResult;
            }
        }catch (Exception e){
            LOGGER.error("数据库操作失败" + ExceptionUtil.getStackTrace(e));
            return remoteResult;
        }
    }

    @Override
    public ResponseResult<List<Membercouponrels>> getMemberEffectiveCoupons(String lenovoId, String shopId, String terminal) {
        ResponseResult result = new ResponseResult(false);
        try {
            if(StringUtil.isEmpty(lenovoId) || StringUtil.isEmpty(shopId) ){
                result.setCode(CouponConstant.RESULT_CODE_ERROR_PARAM);
                result.setMsg(CouponConstant.RESULT_MSG_ERROR_PARAM);
                return result;
            }
            Map map = new HashMap();
            map.put("lenovoid",lenovoId);
            map.put("shopid",shopId);
            map.put("terminal",terminal);
            List<Membercouponrels> list = updateConfig.getMembercouponrelsMapper().getMemberEffectiveCoupons(map);
            result.setData(list);
            result.setSuccess(true);
            return result;
        } catch (Exception e) {
            LOGGER.error(ExceptionUtil.getStackTrace(e));
            result.setMsg("数据库操作失败");
            return result;
        }
    }

    @Override
    public ResponseResult<List<Membercouponrels>> getMemberAllEffectiveCoupons(String lenovoId, String shopId, String terminal) {
        ResponseResult result = new ResponseResult(false);
        try {
            if(StringUtils.isEmpty(lenovoId) || StringUtils.isEmpty(shopId) ){
                result.setCode(CouponConstant.RESULT_CODE_ERROR_PARAM);
                result.setMsg(CouponConstant.RESULT_MSG_ERROR_PARAM);
                return result;
            }
            Map map = new HashMap();
            map.put("lenovoid",lenovoId);
            map.put("shopid",shopId);
            map.put("terminal",terminal);
            List<Membercouponrels> list = updateConfig.getMembercouponrelsMapper().getMemberAllEffectiveCoupons(map);
            result.setData(list);
            result.setSuccess(true);
            return result;
        } catch (Exception e) {
            LOGGER.error(ExceptionUtil.getStackTrace(e));
            result.setMsg("数据库操作失败");
            return result;
        }
    }

    /**
     * 更新之前先查找用户优惠券，如果完全能找到，则查找成功
     * @param map
     * @return
     */
    @Override
    public ResponseResult<List<Membercouponrels>> getMembercouponrelsListByIds(Map map) {
        ResponseResult result = new ResponseResult(false);
        try {
            if(map == null ){
                result.setCode(CouponConstant.RESULT_CODE_ERROR_PARAM);
                result.setMsg(CouponConstant.RESULT_MSG_ERROR_PARAM);
                return result;
            }

            List<Membercouponrels> list = updateConfig.getMembercouponrelsMapper().getMembercouponrelsListByIds(map);
            if(list != null && list.size()>0){
                result.setData(list);
                result.setSuccess(true);
                return result;
            }else {
                LOGGER.info("没有找到数据记录 主键IDs: " + map.get("ids"));
                result.setMsg("通过主键s未找到用户优惠券！");
                return result;
            }

        } catch (Exception e) {
            LOGGER.error("数据库操作失败" + ExceptionUtil.getStackTrace(e));
            result.setMsg("数据库操作失败");
            return result;
        }
    }

  private  void removeExistmemberCoupon(List<Membercouponrels> updateList,List<Membercouponrels> existmembers,List<Membercouponrels> memberList){

        Iterator<Membercouponrels> iterator = memberList.iterator();
        while (iterator.hasNext()){
            Membercouponrels next = iterator.next();
            for(Membercouponrels exist : existmembers){
                if(exist.getId().equals(next.getId())){
                    updateList.add(next);
                    iterator.remove();
                }
            }
        }



}

    @Override
    public ResponseResult updateMembercouponrelsUsed(Map map) {
        ResponseResult result = new ResponseResult(false);
        try {
            if(map == null){
                result.setCode(CouponConstant.RESULT_CODE_ERROR_PARAM);
                result.setMsg(CouponConstant.RESULT_MSG_ERROR_PARAM);
                return result;
            }
            int row = updateConfig.getMembercouponrelsMapper().updateMembercouponrelsUsed(map);
            if(row >= 1){
                result.setSuccess(true);
                result.setMsg("使用优惠券成功！");
                return result;
            }else {
                result.setSuccess(false);
                result.setMsg("使用优惠券时失败！");
                return result;
            }
        } catch (Exception e) {
            LOGGER.error("数据库操作失败" + ExceptionUtil.getStackTrace(e));
            result.setMsg("数据库操作失败");
            return result;
        }
    }

    @Override
    public ResponseResult updateMembercouponrelsReturn(Map map) {
        ResponseResult result = new ResponseResult(false);
        try {
            if(map == null){
                result.setCode(CouponConstant.RESULT_CODE_ERROR_PARAM);
                result.setMsg(CouponConstant.RESULT_MSG_ERROR_PARAM);
                return result;
            }
            int row = updateConfig.getMembercouponrelsMapper().updateMembercouponrelsReturn(map);
            if(row >= 1){
                result.setSuccess(true);
                result.setMsg("返还优惠券成功！");
                return result;
            }else {
                result.setSuccess(false);
                result.setMsg("返还优惠券时失败！");
                return result;
            }
        } catch (Exception e) {
            LOGGER.error("数据库操作失败" + ExceptionUtil.getStackTrace(e));
            result.setMsg("数据库操作失败");
            return result;
        }
    }

//    public boolean updateMembercouponrelsTxReduce(String lenovoId, String token, int status, List<Membercouponrels> membercouponrelsList) throws Exception {
//        boolean flag = true;
//        for(Membercouponrels mr : membercouponrelsList){
//            Map map = new HashMap();
//            map.put("token",token);
//            map.put("id",mr.getId());
//            int row = membercouponrelsMapper.updateMembercouponrelsUsed(map);
//            if(row == 1){
//                MembercouponrelsLog membercouponrelsLog = new MembercouponrelsLog();
//                membercouponrelsLog.setMembercouponrelsid(mr.getId());
//                membercouponrelsLog.setToken(token);
//                membercouponrelsLog.setStatus(status);
//                membercouponrelsLog.setCreatetime(new Date());
//                membercouponrelsLog.setCreateby(lenovoId);
//                membercouponrelsLog.setUpdatetime(new Date());
//                ResponseResult res_log = membercouponrelsLogManager.insertMembercouponrelsLog(membercouponrelsLog);
//                if(!res_log.isSuccess()){
//                    LOGGER.error("优惠券使用记录表保存失败，"+membercouponrelsLog);
//                }
//            }else {
//                flag = false;
//                throw new Exception();
//            }
//        }
//        return flag;
//    }
//
//    public boolean updateMembercouponrelsTxPlus(String lenovoId, String token, int status, List<Membercouponrels> membercouponrelsList) throws Exception {
//        //返还优惠券  直接返
//        boolean flag = true;
//        for (Membercouponrels mr : membercouponrelsList) {
//            Map map = new HashMap();
//            map.put("token", token);
//            map.put("id", mr.getId());
//            int row = membercouponrelsMapper.updateMembercouponrelsReturn(map);
//            if (row == 1) {
//                MembercouponrelsLog membercouponrelsLog = new MembercouponrelsLog();
//                membercouponrelsLog.setMembercouponrelsid(mr.getId());
//                membercouponrelsLog.setToken(token);
//                membercouponrelsLog.setStatus(status);
//                membercouponrelsLog.setCreatetime(new Date());
//                membercouponrelsLog.setCreateby(lenovoId);
//                membercouponrelsLog.setUpdatetime(new Date());
//                ResponseResult res_log = membercouponrelsLogManager.insertMembercouponrelsLog(membercouponrelsLog);
//                if (!res_log.isSuccess()) {
//                    LOGGER.error("优惠券使用记录表保存失败，" + membercouponrelsLog);
//                }
//            } else {
//                flag = false;
//                throw new Exception();
//            }
//        }
//        return flag;
//    }

    public RemoteResult<Boolean> insertBatchByOneMember(List<Membercouponrels> list) {
        RemoteResult<Boolean> remoteResult = new RemoteResult<Boolean>(false);
        try {
            for (Membercouponrels membercouponrels : list){

                updateConfig.getMembercouponrelsMapper().insertSelective(membercouponrels);
            }
                remoteResult.setT(true);
                remoteResult.setSuccess(true);
                remoteResult.setResultMsg("success");
                return remoteResult;

        }catch (Exception e){
            LOGGER.error("数据库操作失败" + ExceptionUtil.getStackTrace(e));
            return remoteResult;
        }
    }
    public RemoteResult<Boolean> insertBatch(List<Membercouponrels> list) {
        RemoteResult<Boolean> remoteResult = new RemoteResult<Boolean>(false);
        try {
            int i = updateConfig.getMembercouponrelsMapper().insertBatch(list);
            if (i > 0) {
                remoteResult.setT(true);
                remoteResult.setSuccess(true);
                remoteResult.setResultMsg("success");
                return remoteResult;
            }else {
                remoteResult.setResultMsg("批量插入失败");
                return remoteResult;
            }
        }catch (Exception e){
            LOGGER.error("数据库操作失败" + ExceptionUtil.getStackTrace(e));
            return remoteResult;
        }
    }

    @Override
    public ResponseResult insertSelective(Membercouponrels membercouponrels) {
        ResponseResult<Membercouponrels> result = new ResponseResult<Membercouponrels>(false);
        try {
            int i = updateConfig.getMembercouponrelsMapper().insertSelective(membercouponrels);
            if (i > 0) {
                result.setData(membercouponrels);
                result.setSuccess(true);
                return result;
            }else {
                result.setMsg("给用户绑券失败");
                result.setSuccess(false);
                return result;
            }
        }catch (Exception e){
            LOGGER.error("数据库操作失败" + ExceptionUtil.getStackTrace(e));
            result.setSuccess(false);
            return result;
        }
    }

    /**
     * 能查询到数据返回真，否则返回假
     * @param lenovoId
     * @param shopId
     * @param usescope
     * @return
     */
    @Override
    public ResponseResult<List<Membercouponrels>> getMembercouponrelsByShopidAndUsescope(String lenovoId, String shopId, String usescope) {
        ResponseResult result = new ResponseResult(false);
        try {
            if(StringUtils.isEmpty(lenovoId) || StringUtils.isEmpty(shopId) || StringUtils.isEmpty(usescope) ){
                result.setCode(CouponConstant.RESULT_CODE_ERROR_PARAM);
                result.setMsg(CouponConstant.RESULT_MSG_ERROR_PARAM);
                return result;
            }
            Map map = new HashMap();
            map.put("lenovoid",lenovoId);
            map.put("shopid",shopId);
            map.put("usescope",usescope);
            List<Membercouponrels> list = updateConfig.getMembercouponrelsMapper().getMembercouponrelsByShopidAndUsescope(map);
            if(CollectionUtils.isNotEmpty(list)){
                result.setData(list);
                result.setSuccess(true);
                return result;
            }else {
                result.setMsg("未查询到数据！");
                result.setSuccess(false);
                return result;
            }
        } catch (Exception e) {
            LOGGER.error(ExceptionUtil.getStackTrace(e));
            result.setMsg("数据库操作失败");
            return result;
        }
    }
    /**
     * 能查询到数据返回真，否则返回假
     * @param lenovoId
     * @param shopId
     * @return
     */
    @Override
    public ResponseResult<List<Membercouponrels>> getC2CMembercouponrelsByShopid(String lenovoId, String shopId) {
        ResponseResult result = new ResponseResult(false);
        try {
            if(StringUtils.isEmpty(lenovoId) || StringUtils.isEmpty(shopId)){
                result.setCode(CouponConstant.RESULT_CODE_ERROR_PARAM);
                result.setMsg(CouponConstant.RESULT_MSG_ERROR_PARAM);
                return result;
            }
            Map map = new HashMap();
            map.put("lenovoid",lenovoId);
            map.put("shopid",shopId);
            List<Membercouponrels> list = updateConfig.getMembercouponrelsMapper().getC2CMembercouponrelsByShopid(map);
            if(CollectionUtils.isNotEmpty(list)){
                result.setData(list);
                result.setSuccess(true);
                return result;
            }else {
                result.setMsg("未查询到数据！");
                result.setSuccess(false);
                return result;
            }
        } catch (Exception e) {
            LOGGER.error("数据库操作失败" + ExceptionUtil.getStackTrace(e));
            result.setMsg("数据库操作失败");
            return result;
        }
    }

    @Override
    public int getMembercouponrelsCount(Map map) {
        return updateConfig.getMembercouponrelsMapper().getMembercouponrelsCount(map);
    }

    @Override
    public ResponseResult getMembercouponrelsByLenovoIdandSalescouponId(String lenovoId, long salesCouponId) {
        ResponseResult result = new ResponseResult(false);
        try {
            if(StringUtils.isEmpty(lenovoId) || salesCouponId < 0 ){
                result.setCode(CouponConstant.RESULT_CODE_ERROR_PARAM);
                result.setMsg(CouponConstant.RESULT_MSG_ERROR_PARAM);
                return result;
            }
            MembercouponrelsExample membercouponrelsExample = new MembercouponrelsExample();
            membercouponrelsExample.createCriteria().andLenovoidEqualTo(lenovoId).andSalescouponidEqualTo(salesCouponId).andDisabledEqualTo(0);
            List<Membercouponrels> list = updateConfig.getMembercouponrelsMapper().selectByExample(membercouponrelsExample);
            if(CollectionUtils.isNotEmpty(list)){
                result.setData(list.size());
                result.setSuccess(true);
                return result;
            }else {
                result.setMsg("未查询到数据！");
                result.setSuccess(false);
                return result;
            }
        } catch (Exception e) {
            LOGGER.error(ExceptionUtil.getStackTrace(e));
            result.setMsg("数据库操作失败");
            return result;
        }
    }


    @Override
    public ResponseResult getMembercouponrelsByLenovoIdandSalescouponIdandshopId(String shopId,String lenovoId, long salesCouponId) {
        ResponseResult result = new ResponseResult(false);
        try {
            if(StringUtils.isEmpty(lenovoId) || salesCouponId < 0 ){
                result.setCode(CouponConstant.RESULT_CODE_ERROR_PARAM);
                result.setMsg(CouponConstant.RESULT_MSG_ERROR_PARAM);
                return result;
            }
            MembercouponrelsExample membercouponrelsExample = new MembercouponrelsExample();
            membercouponrelsExample.createCriteria().andLenovoidEqualTo(lenovoId).andSalescouponidEqualTo(salesCouponId).andDisabledEqualTo(0).andShopidEqualTo(shopId);
            List<Membercouponrels> list = updateConfig.getMembercouponrelsMapper().selectByExample(membercouponrelsExample);
            if(CollectionUtils.isNotEmpty(list)){
                result.setData(list.size());
                result.setSuccess(true);
                return result;
            }else {
                result.setMsg("未查询到数据！");
                result.setSuccess(false);
                return result;
            }
        } catch (Exception e) {
            LOGGER.error(ExceptionUtil.getStackTrace(e));
            result.setMsg("数据库操作失败");
            return result;
        }
    }



    @Override
    public ResponseResult insertBatchMembercouponrels(List<Membercouponrels> list) {
        ResponseResult result = new ResponseResult(false);
        if(list != null && list.size()>0){
            int row = updateConfig.getMembercouponrelsMapper().insertBatch(list);
            if(row == list.size()){
                result.setMsg(CouponConstant.RESULT_MSG_SUC);
                result.setCode(CouponConstant.RESULT_CODE_SUC);
                result.setSuccess(true);
            }else {
                result.setMsg(CouponConstant.RESULT_MSG_FAIL);
                result.setCode(CouponConstant.RESULT_CODE_FAIL);
                result.setSuccess(false);
            }
        }
        return  result;
    }

    @Override
    public ResponseResult updateBatchMembercouponrels(List<Membercouponrels> list) {
        ResponseResult result = new ResponseResult(false);
        int row = 0;
        for (Membercouponrels membercouponrels : list){
            int shopid = membercouponrelsMapper.updateByPrimaryKeySelective(membercouponrels);
            row+=shopid;
        }


        if(row == list.size()){
            result.setMsg(CouponConstant.RESULT_MSG_SUC);
            result.setCode(CouponConstant.RESULT_CODE_SUC);
            result.setSuccess(true);
        }else {
            result.setMsg(CouponConstant.RESULT_MSG_FAIL);
            result.setCode(CouponConstant.RESULT_CODE_FAIL);
            result.setSuccess(false);
        }

        return  result;
    }

    @Override
    public ResponseResult<List<Membercouponrels>> getUserIshaveTheCoupon(Map map) {
        ResponseResult result = new ResponseResult(false);
        List<Membercouponrels> list = updateConfig.getMembercouponrelsMapper().getUserIshaveTheCoupon(map);
        if(list != null && list.size() > 0){
            result.setMsg(CouponConstant.RESULT_MSG_SUC);
            result.setCode(CouponConstant.RESULT_CODE_SUC);
            result.setData(list);
            result.setSuccess(true);
        }if (list.size()==0){
            result.setMsg("查询成功");
            result.setCode(CouponConstant.RESULT_CODE_SUC);
            result.setData(list);
            result.setSuccess(true);
        }
        return result;
    }

    @Override
    public int getIsHaveSalesCouponsNum(Map map) {
        MembercouponrelsMapper membercouponrelsMapper = updateConfig.getMembercouponrelsMapper();
        return membercouponrelsMapper.getIsHaveSalesCouponsNum(map);
    }

    @Override
    public ResponseResult<List<Membercouponrels>> getMemberCouponsStatus(Map map) {
        LOGGER.info("getMemberCouponsStatus 参数：shopId="+map.get("shopId")+",lenovoId="+map.get("lenovoId")+",salesCouponId="+map.get("salesCouponId"));
        ResponseResult result = new ResponseResult(false);
        List<Membercouponrels> list = updateConfig.getMembercouponrelsMapper().getMemberCouponsStatus(map);
        if (list!=null&&list.size()>0){
            result.setMsg(CouponConstant.RESULT_MSG_SUC);
            result.setCode(CouponConstant.RESULT_CODE_SUC);
            result.setData(list);
            result.setSuccess(true);
            LOGGER.info("获取用户"+map.get("lenovoId")+"下优惠券为"+map.get("salesCouponId")+"使用状态成功");
        }else {
            result.setMsg("查询成功");
            result.setCode(CouponConstant.RESULT_CODE_SUC);
            result.setData(list);
            result.setSuccess(true);
            LOGGER.info("未找到用户" +map.get("lenovoId")+"下拥有"+map.get("salesCouponId")+"该优惠券");
        }
        return result;
    }

    /**
     * 查询用户名下可用的指定优惠券
     * @param lenovoId
     * @param salesCouponId  优惠券ID
     * @return
     */
    @Override
    public ResponseResult getMemberCoupons(String lenovoId, Long salesCouponId) {
        ResponseResult result = new ResponseResult(false);
        if(StringUtils.isEmpty(lenovoId) || salesCouponId < 0 ){
            result.setCode(CouponConstant.RESULT_CODE_ERROR_PARAM);
            result.setMsg(CouponConstant.RESULT_MSG_ERROR_PARAM);
            return result;
        }
        try {
            MembercouponrelsExample membercouponrelsExample = new MembercouponrelsExample();
            membercouponrelsExample.createCriteria()
                    .andLenovoidEqualTo(lenovoId)
                    .andSalescouponidEqualTo(salesCouponId)
                    .andDisabledEqualTo(0)
                    .andStatusEqualTo(0)
                    .andTotimeGreaterThan(new Date());
            List<Membercouponrels> list = updateConfig.getMembercouponrelsMapper().selectByExample(membercouponrelsExample);
            if(CollectionUtils.isNotEmpty(list)){
                result.setData(list.size());
                result.setSuccess(true);
                return result;
            }else{
                result.setMsg("未查询到数据！");
                return result;
            }
        } catch (Exception e) {
            LOGGER.error(ExceptionUtil.getStackTrace(e));
            result.setMsg("数据库操作失败");
            return result;
        }
    }

    @Override
    public ResponseResult updateMembercouponrels(Long id, int status) {
        ResponseResult result = new ResponseResult(false);
        if(id == null || StringUtils.isEmpty(id.toString()) || status != 0 || status != 1){
            result.setCode(CouponConstant.RESULT_CODE_ERROR_PARAM);
            result.setMsg(CouponConstant.RESULT_MSG_ERROR_PARAM);
            return result;
        }
        try {
            Map map = new HashMap();
            map.put("id", id);
            map.put("status", status);
            int updateResult = updateConfig.getMembercouponrelsMapper().updateMembercouponrels(map);
            if(updateResult == 1){
                result.setSuccess(true);
                result.setCode(CouponConstant.RESULT_CODE_SUC);
                result.setMsg(CouponConstant.RESULT_MSG_SUC);
            }else {
                result.setCode(CouponConstant.RESULT_CODE_FAIL);
                result.setMsg(CouponConstant.RESULT_MSG_FAIL);
            }
        } catch (Exception e) {
            LOGGER.error(ExceptionUtil.getStackTrace(e));
            result.setCode(CouponConstant.RESULT_CODE_ERROR);
            result.setMsg(CouponConstant.RESULT_MSG_ERROR);
        }
        return result;
    }

    @Override
    public ResponseResult<List<Membercouponrels>> getMemberCouponRelBySalesCouponId(Long salesCouponId) {
        ResponseResult result = new ResponseResult(false);
        if(salesCouponId == null){
            result.setCode(CouponConstant.RESULT_CODE_ERROR_PARAM);
            result.setMsg(CouponConstant.RESULT_MSG_ERROR_PARAM);
            return result;
        }
        List<Membercouponrels> membercouponrelsList = updateConfig.getMembercouponrelsMapper().getMemberCouponsBySalesCouponId(salesCouponId);
        if(CollectionUtils.isNotEmpty(membercouponrelsList)){
            result.setSuccess(true);
            result.setCode(CouponConstant.RESULT_CODE_SUC);
            result.setMsg(CouponConstant.RESULT_MSG_SUC);
            result.setData(membercouponrelsList);
            return result;
        }
        return null;
    }

    @Override
    public RemoteResult<PageModel2<String>> getlenovoIdsByDistinct(PageQuery pageQuery) {
        RemoteResult result = new RemoteResult();
        try {
            PageModel2<String> list = new PageModel2<String>(pageQuery, updateConfig.getMembercouponrelsMapper().getlenovoIds(pageQuery));
            result.setResultCode("00");
            result.setSuccess(true);
            result.setResultMsg("success");
            result.setT(list);
        } catch (Exception e) {
            LOGGER.error("occour error",e);
            result.setSuccess(false);
            result.setResultCode("01");
            result.setResultMsg("false");
        }
        return result;
    }

    @Override
    public RemoteResult<List<Membercouponrels>> getmemberCouponsByLenovoId(String lenovoId) {
        RemoteResult result = new RemoteResult();
        try {
            List<Membercouponrels> membercouponrelses = updateConfig.getMembercouponrelsMapper().getmemberCouponsbyLenovoId(lenovoId);
            result.setSuccess(true);
            result.setT(membercouponrelses);
            result.setResultMsg("");
            result.setResultCode("00");
            ;
        } catch (Exception e) {
            LOGGER.error("error",e);
            result.setSuccess(false);
            result.setResultMsg("");
            result.setResultCode("01");
        }
        return result;
    }


    /************************************************************************************************************/
    @Override
    public RemoteResult<Boolean> disableMemberCouponById(long id,String lenovoId) {
        RemoteResult<Boolean> remoteResult = new RemoteResult<Boolean>(false);
        Membercouponrels membercouponrels = new Membercouponrels();
        membercouponrels.setId(id);
        membercouponrels.setDisabled(1);
        membercouponrels.setUpdatetime(new Date());
        membercouponrels.setLenovoid(lenovoId);
        try {
            int i = updateConfig.getMembercouponrelsMapper().updateByPrimaryKeySelective(membercouponrels);
            if (i > 0) {
                remoteResult.setT(true);
                remoteResult.setSuccess(true);
                remoteResult.setResultMsg("success");
                return remoteResult;
            }else {
                remoteResult.setResultMsg("没有找到数据记录");
                return remoteResult;
            }
        }catch (Exception e){
            LOGGER.error("数据库操作失败" + ExceptionUtil.getStackTrace(e));
            return remoteResult;
        }
    }
    public RemoteResult<Boolean> insertBatchSharding(MembercouponrelsMapper mapper,List<Membercouponrels> list,String tableName) {
        RemoteResult<Boolean> remoteResult = new RemoteResult<Boolean>(false);
        try {
            int i = mapper.insertBatchsharding(list,tableName);
            if (i > 0) {
                remoteResult.setT(true);
                remoteResult.setSuccess(true);
                remoteResult.setResultMsg("success");
                return remoteResult;
            }else {
                remoteResult.setResultMsg("批量插入失败");
                return remoteResult;
            }
        }catch (Exception e){
            LOGGER.error("数据库操作失败" + ExceptionUtil.getStackTrace(e));
            return remoteResult;
        }
    }

    @Override
    public RemoteResult<List<Membercouponrels>> getMemberCouponrelsConditions(MembercouponrelsMapper mapper, Map map, String tableName) {
        RemoteResult result = new RemoteResult(false);
        try {

            List<Membercouponrels> list = mapper.getMemberCouponrelsConditions(tableName,map);
            if(CollectionUtils.isNotEmpty(list)){
                result.setT(list);
                result.setSuccess(true);
                return result;
            }else {
                result.setResultMsg("未查询到数据！");
                result.setSuccess(false);
                return result;
            }
        } catch (Exception e) {
            LOGGER.error(ExceptionUtil.getStackTrace(e));
            result.setSuccess(false);
            result.setResultMsg("数据库操作失败");
            return result;
        }
    }


    @Override
    public ResponseResult<List<Membercouponrels>> getMemberEffectiveCouponsSharding(MembercouponrelsMapper mapper,String lenovoId, String shopId, String terminal,String tableName) {
        ResponseResult result = new ResponseResult(false);
        try {
            if(StringUtils.isEmpty(lenovoId) || StringUtils.isEmpty(shopId) ){
                result.setCode(CouponConstant.RESULT_CODE_ERROR_PARAM);
                result.setMsg(CouponConstant.RESULT_MSG_ERROR_PARAM);
                return result;
            }
            Map map = new HashMap();
            map.put("lenovoid",lenovoId);
            map.put("shopid",shopId);
            map.put("terminal",terminal);
            List<Membercouponrels> list = mapper.getMemberEffectiveCouponsSharding(tableName,map);
            result.setData(list);
            result.setSuccess(true);
            return result;
        } catch (Exception e) {
            LOGGER.error(ExceptionUtil.getStackTrace(e));
            result.setMsg("数据库操作失败");
            return result;
        }
    }

    @Override
    public ResponseResult<List<Membercouponrels>> getMembercouponrelsListByIdsSharding(MembercouponrelsMapper mapper, Map map, String tableName) {
        ResponseResult result = new ResponseResult(false);
        try {
            if(map == null ){
                result.setCode(CouponConstant.RESULT_CODE_ERROR_PARAM);
                result.setMsg(CouponConstant.RESULT_MSG_ERROR_PARAM);
                return result;
            }

            List<Membercouponrels> list = mapper.getMembercouponrelsListByIdsSharding(tableName,map);
            if(list != null && list.size()>0){
                result.setData(list);
                result.setSuccess(true);
                return result;
            }else {
                LOGGER.info("没有找到数据记录 主键IDs: " + map.get("ids"));
                result.setMsg("通过主键s未找到用户优惠券！");
                return result;
            }

        } catch (Exception e) {
            LOGGER.error("数据库操作失败" + ExceptionUtil.getStackTrace(e));
            result.setMsg("数据库操作失败");
            return result;
        }
    }

    @Override
    public ResponseResult updateMembercouponrelsUsedSharding(MembercouponrelsMapper mapper, String tableName, Map map) {
        ResponseResult result = new ResponseResult(false);
        try {
            if(map == null){
                result.setCode(CouponConstant.RESULT_CODE_ERROR_PARAM);
                result.setMsg(CouponConstant.RESULT_MSG_ERROR_PARAM);
                return result;
            }
            int row = mapper.updateMembercouponrelsUsedSharding(tableName,map);
            if(row >= 1){
                result.setSuccess(true);
                result.setMsg("使用优惠券成功！");
                return result;
            }else {
                result.setSuccess(false);
                result.setMsg("使用优惠券时失败！");
                return result;
            }
        } catch (Exception e) {
            LOGGER.error("数据库操作失败" + ExceptionUtil.getStackTrace(e));
            result.setMsg("数据库操作失败");
            return result;
        }
    }

    @Override
    public PageModel2<Membercouponrels> getMemberCouponrelsInfoPageSharding(MembercouponrelsMapper mapper, String tableName, PageQuery pageQuery, Map map) throws ParseException {
        return new PageModel2<Membercouponrels>(mapper.getMemberCouponrelsInfoPageSharding(tableName,pageQuery,map));
    }

    @Override
    public int getMembercouponrelsCountSharding(MembercouponrelsMapper mapper, String tableName, Map map) {
        return mapper.getMembercouponrelsCountSharding(tableName,map);
    }
    @Override
    public ResponseResult updateMembercouponrelsReturn(MembercouponrelsMapper membercouponrelsMapper,String tableName,Map map) {
        ResponseResult result = new ResponseResult(false);
        try {
            if(map == null){
                result.setCode(CouponConstant.RESULT_CODE_ERROR_PARAM);
                result.setMsg(CouponConstant.RESULT_MSG_ERROR_PARAM);
                return result;
            }
            int row = membercouponrelsMapper.updateMembercouponrelsReturnSharding(tableName,map);
            if(row >= 1){
                result.setSuccess(true);
                result.setMsg("返还优惠券成功！");
                return result;
            }else {
                result.setSuccess(false);
                result.setMsg("返还优惠券时失败！");
                return result;
            }
        } catch (Exception e) {
            LOGGER.error("数据库操作失败" + ExceptionUtil.getStackTrace(e));
            result.setMsg("数据库操作失败");
            return result;
        }
    }

    @Override
    public ResponseResult<List<Membercouponrels>> getUserIshaveTheCouponSharding(MembercouponrelsMapper mapper, String tableName, Map map) {
        ResponseResult result = new ResponseResult(false);
        List<Membercouponrels> list = mapper.getUserIshaveTheCouponSharding(tableName,map);
        if(list != null && list.size() > 0){
            result.setMsg(CouponConstant.RESULT_MSG_SUC);
            result.setCode(CouponConstant.RESULT_CODE_SUC);
            result.setData(list);
            result.setSuccess(true);
        }if (list.size()==0){
            result.setMsg("查询成功");
            result.setCode(CouponConstant.RESULT_CODE_SUC);
            result.setData(list);
            result.setSuccess(true);
        }
        return result;
    }


    @Override
    public ResponseResult<List<Membercouponrels>> getMemberAllEffectiveCouponsSharding(MembercouponrelsMapper mapper,String tableName, String lenovoId, String shopId, String terminal) {
        ResponseResult result = new ResponseResult(false);
        try {
            if(StringUtils.isEmpty(lenovoId) || StringUtils.isEmpty(shopId) ){
                result.setCode(CouponConstant.RESULT_CODE_ERROR_PARAM);
                result.setMsg(CouponConstant.RESULT_MSG_ERROR_PARAM);
                return result;
            }
            Map map = new HashMap();
            map.put("lenovoid",lenovoId);
            map.put("shopid",shopId);
            map.put("terminal",terminal);
            List<Membercouponrels> list = mapper.getMemberAllEffectiveCouponsSharding(tableName,map);
            result.setData(list);
            result.setSuccess(true);
            return result;
        } catch (Exception e) {
            LOGGER.error(ExceptionUtil.getStackTrace(e));
            result.setMsg("数据库操作失败");
            return result;
        }
    }

    @Override
    public ResponseResult insertBatchMembercouponrelsSharding(List<Membercouponrels> list) {
        ResponseResult result = new ResponseResult(false);
        if(list != null && list.size()>0){
            int row =  membercouponrelsMapper.insertBatchMembercouponrelsSharding(list);
            if(row == list.size()){
                result.setMsg(CouponConstant.RESULT_MSG_SUC);
                result.setCode(CouponConstant.RESULT_CODE_SUC);
                result.setSuccess(true);
            }else {
                result.setMsg(CouponConstant.RESULT_MSG_FAIL);
                result.setCode(CouponConstant.RESULT_CODE_FAIL);
                result.setSuccess(false);
            }
        }
        return  result;
    }
}
