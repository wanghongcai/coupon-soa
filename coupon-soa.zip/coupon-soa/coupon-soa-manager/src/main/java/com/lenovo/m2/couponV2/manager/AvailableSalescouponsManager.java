package com.lenovo.m2.couponV2.manager;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.couponV2.dao.mybatis.model.AvailableSalescoupons;
import com.lenovo.m2.couponV2.dao.util.ResponseResult;

import java.util.List;

/**
 * Created by fenglg1 on 2016/12/15.
 */
public interface AvailableSalescouponsManager {
    /**
     * 获取全部已选取的可以领取的优惠券
     * @return
     */
    public ResponseResult<List<AvailableSalescoupons>> getAllSelectedAvailableSalescoupons();

    /**
     * 根据优惠券ID查询可领取的优惠券
     * @param salesCouponsId
     * @return
     */
    public ResponseResult<List<AvailableSalescoupons>> getAvailableSalescouponsByCouponId(Long salesCouponsId);

    /**
     * 保存选取的可领取的优惠券
     * @param availableSalescouponsList
     * @return
     */
    public ResponseResult saveAvailableSalescoupons(List<AvailableSalescoupons> availableSalescouponsList);

    /**
     * 将指定的优惠券从可领取队列中删除
     * @param salesCouponsId
     * @return
     */
    public ResponseResult deleteAvailableSalescoupons(Long salesCouponsId,String displayPosition);

    /**
     * 清空可领取优惠券列表
     * @return
     */
    public ResponseResult deleteAllSelectedAvailableSalescoupons();
}
