package com.lenovo.m2.couponV2.manager;

import com.lenovo.m2.arch.framework.domain.PageModel2;
import com.lenovo.m2.arch.framework.domain.PageQuery;
import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.couponV2.dao.mybatis.model.Couponchecks;
import com.lenovo.m2.couponV2.dao.mybatis.model.Membercouponrels;

import java.text.ParseException;
import java.util.List;
import java.util.Map;

/**
 * Created by yezhenyue on 2016/2/19.
 */
public interface CouponchecksManager {
    /**
     * 分页查询优惠券码审核列表
     * @param pageQuery
     * @param map
     * @return
     */
     PageModel2<Couponchecks> getCouponchecksInfoPage(PageQuery pageQuery, Map map) throws ParseException;

    /**
     * 批量审核
     * @param list
     * @return
     */
     int updateCouponchecksBatch(List<Couponchecks> list);

    /**
     * 二次批量审核
     * @param list
     * @return
     */
    int updateCouponSecondchecksBatch(List<Couponchecks> list);

    /**
     * 批量插入
     * @param list
     * @return
     */
     int insertCouponchecksBatch(List<Couponchecks> list);

    /**
     * 根据条件审核单条
     * @param couponchecks
     * @return
     */
     int checkCouponByCondition(Couponchecks couponchecks);

    RemoteResult<Couponchecks> queryCouponCheckById(long id);
}
