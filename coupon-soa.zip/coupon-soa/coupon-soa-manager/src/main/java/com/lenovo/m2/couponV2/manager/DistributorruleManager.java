package com.lenovo.m2.couponV2.manager;

import com.lenovo.m2.couponV2.dao.mybatis.model.Detailsrule;
import com.lenovo.m2.couponV2.dao.mybatis.model.Distributorrule;
import com.lenovo.m2.couponV2.dao.mybatis.model.DistributorruleLog;
import com.lenovo.m2.couponV2.dao.util.ResponseResult;

import java.util.List;
import java.util.Map;

/**
 * Created by pxg01 on 2017/4/20.
 */

public interface DistributorruleManager {
    /**
     * 批量保存优惠券分类数据
     * @param distributorruleList
     * @return
     */
    public ResponseResult insertBatchDistributorrule(List<Distributorrule> distributorruleList);

    /**
     * 批量保存优惠券分类数据
     * @param distributorrule
     * @return
     */
    public ResponseResult delDistributorrule(Distributorrule distributorrule);

    public ResponseResult saveDistributorruleLog(List<DistributorruleLog> distributorruleLogList);
    public ResponseResult<List<Distributorrule>> getBatchBySalescouponids(Map map);

    public ResponseResult<List<Distributorrule>> getDistributorruleList(Distributorrule detailsrule);
    public ResponseResult<List<Distributorrule>> getDistributorruleListGroupBy(Distributorrule detailsrule);
}
