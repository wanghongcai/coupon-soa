/**
 * Project Name:couponV2-soa-manager
 * File Name:RedisLock.java
 * Package Name:com.lenovo.m2.couponV2.manager.redisObject.lock
 * Date:2017年6月27日下午4:31:50
 * Copyright (c) 2017, yuzj7@lenovo.com All Rights Reserved.
 *
*/

package com.lenovo.m2.couponV2.manager.redisObject.lock;

import java.util.Random;

import com.lenovo.m2.couponV2.manager.redisObject.RedisObjectManager;

/**
 * ClassName:RedisLock <br/>
 * Function: TODO ADD FUNCTION. <br/>
 * Date:     2017年6月27日 下午4:31:50 <br/>
 * @author   yuzj7
 * @version  
 * @since    JDK 1.7
 * @see 	 
 */
public class RedisLock {

	 //加锁标志
    public static final String LOCKED = "TRUE";
    public static final String COUPON_PREFIX = "COUPON_LOCK_";
    public static final long ONE_MILLI_NANOS = 1000000L;
    //默认超时时间（毫秒）
    public static final long DEFAULT_TIME_OUT = 3000;
    public static final Random r = new Random();
    //锁的超时时间（秒），过期删除
    public static final int EXPIRE = 5 * 60;
    private String key;
    //锁状态标志
    private boolean locked = false;
    private RedisObjectManager redisObjectManager;
    public RedisLock(String key,RedisObjectManager redisObjectManager) {
        this.key = COUPON_PREFIX+key;
        this.redisObjectManager = redisObjectManager;
    }

    public boolean lock(long timeout) {
        long nano = System.nanoTime();
        timeout *= ONE_MILLI_NANOS;
        try {
            while ((System.nanoTime() - nano) < timeout) {
                if (redisObjectManager.setStringIfNotExists(key, LOCKED) == 1) {
                	redisObjectManager.expire(key, EXPIRE);
                    locked = true;
                    return locked;
                }
                // 短暂休眠，nano避免出现活锁
                Thread.sleep(3, r.nextInt(500));
            }
        } catch (Exception e) {
        }
        return false;
    }
    public boolean lock() {
        return lock(DEFAULT_TIME_OUT);
    }

    // 无论是否加锁成功，必须调用
    public void unlock() {
            if (locked){
            	redisObjectManager.delKey(key);
            }
    }
}

