package com.lenovo.m2.couponV2.manager;

import com.lenovo.m2.couponV2.dao.mybatis.model.CouponsLog;
import com.lenovo.m2.couponV2.dao.util.ResponseResult;

/**
 * Created by zhaocl1 on 2016/3/7.
 */
public interface CouponsLogManager {

    /**
     * 保存
     * @param couponsLog
     * @return
     */
    ResponseResult insertCouponsLog(CouponsLog couponsLog);


    /**
     * 更新码对应的主订单号
     * @param token
     * @param orderId
     * @return
     */
    ResponseResult updateCouponsLog(String token, String orderId);
}
