package com.lenovo.m2.couponV2.manager.impl;

import com.lenovo.m2.couponV2.dao.mybatis.mapper.OldfornewcouponMapper;
import com.lenovo.m2.couponV2.dao.mybatis.model.Oldfornewcoupon;
import com.lenovo.m2.couponV2.manager.OldfornewcouponManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * Created by zhaocl1 on 2016/3/28.
 */
@Component("oldfornewcouponManager")
public class OldfornewcouponManagerImpl implements OldfornewcouponManager{

    @Autowired
    private OldfornewcouponMapper oldfornewcouponMapper;

    @Override
    public int batchSaveOldfornewCoupon(List<Oldfornewcoupon> list) {
        return oldfornewcouponMapper.batchSaveOldfornewCoupon(list);
    }
}
