package com.lenovo.m2.couponV2.manager.conf;

import com.lenovo.leconf.client.common.annotations.LeconfFile;
import com.lenovo.leconf.client.common.annotations.LeconfFileItem;
import com.lenovo.leconf.client.common.annotations.LeconfUpdateService;
import com.lenovo.leconf.client.common.update.ILeconfUpdate;
import com.lenovo.m2.couponV2.common.enums.MakeUpDateEnum;
import com.lenovo.m2.couponV2.dao.mybatis.mapper.MembercouponrelsMapper;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

/**
 * Created by Administrator on 2017/9/15.
 */
@Component
@LeconfFile(filename = "coupon-dubbo.properties")
@LeconfUpdateService(classes = { UpdateConfig.class })
public class UpdateConfig implements ILeconfUpdate {
    private static Logger log = LogManager.getLogger(UpdateConfig.class.getName());

    @Resource(name = "membercouponrelsMapper")
    private  MembercouponrelsMapper defalutmembercouponrelsMapper;



    public   MembercouponrelsMapper getMembercouponrelsMapper() {
        return defalutmembercouponrelsMapper;
    }

    public MembercouponrelsMapper getDefalutmembercouponrelsMapper() {
        return defalutmembercouponrelsMapper;
    }


    @Override
    public void reload() throws Exception {
        return;
    }
}
