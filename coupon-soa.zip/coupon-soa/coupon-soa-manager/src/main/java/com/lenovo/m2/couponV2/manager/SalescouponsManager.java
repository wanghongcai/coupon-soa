package com.lenovo.m2.couponV2.manager;

import com.lenovo.m2.arch.framework.domain.PageModel2;
import com.lenovo.m2.arch.framework.domain.PageQuery;
import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.couponV2.api.model.OneKeyToReceiveApi;
import com.lenovo.m2.couponV2.dao.mybatis.model.Salescoupons;
import com.lenovo.m2.couponV2.dao.util.ResponseResult;

import java.util.List;
import java.util.Map;

/**
 * Created by zhaocl1 on 2015/8/25.
 */
public interface SalescouponsManager {

    /**
     * 分页查询
     * @param pageQuery
     * @param map
     * @return
     */

    public PageModel2<Salescoupons> getSalescouponsInfoPage(PageQuery pageQuery,Map map);

    /**
     * 保存
     * @param salescoupons
     * @return
     */
    public ResponseResult<Salescoupons> insertSalescoupons(Salescoupons salescoupons);

    /**
     * 查看优惠券
     * @param id
     * @return
     */
    public ResponseResult<Salescoupons> getSalescoupons(Long id);

    /**
     * 删除优惠券信息
     * @param salescoupons
     * @return
     */
    public ResponseResult<Boolean> delSalescoupons(Salescoupons salescoupons);

    /**
     * 更新优惠券
     * @param salescoupons
     * @return
     */
    public ResponseResult editSalescoupons(Salescoupons salescoupons);

    /**
     * 根据主键ids，批量查询
     * @param map
     * @return
     */
    public ResponseResult<List<Salescoupons>> getSalescouponsList(Map map);

    int updateSalesCouponStatusBatch(List<Salescoupons> list);

    int updateSalesCouponBackSendBatch(List<Salescoupons> list);
    /**
     * 根据couponway查询优惠券
     * @param couponWay
     * @return
     */
    Salescoupons getSalescouponsByCouponWay(int couponWay);

    /**
     * 根据shopId 和 couponway查询优惠券
     * @param shopId
     * @param couponWay
     * @return
     */
    Salescoupons getSalescouponsByCouponWay(String shopId, int couponWay);

    /**
     * 查询有效的券
     * @return
     */
    public ResponseResult<List<Salescoupons>> getSalescouponsValidList();

    /**
     * 根据商城、终端查询审核过的、可领取的、在可领取时间内的、有效的c2c券
     * @param map
     * @return
     */
    public ResponseResult<List<Salescoupons>> getSalescouponsByUseScope(Map map);

    /**
     * 根据优惠券id更新通知有效次数
     * @param id
     * @return
     */
    public ResponseResult updateNoticeValidCount(Long id);

    /**
     * 根据优惠券id更新通知无效次数
     * @param id
     * @return
     */
    public ResponseResult updateNoticeInvalidCount(Long id);

    /**
     * 根据id查询优惠券
     * @param map
     * @return
     */
    public ResponseResult<List<Salescoupons>> getSalescouponsforIds(Map map);

    /**
     * 根据优惠券分类ID查询优惠券
     * @param map
     * @return
     */
    public PageModel2<Salescoupons> getSalescouponsForClassification(PageQuery pageQuery,Map map);

    /**
     * 根据优惠券ID查询优惠券
     * @param pageQuery
     * @param map
     * @return
     */
    public PageModel2<Salescoupons> getSalescouponsBySalesCouponIds(PageQuery pageQuery,Map map);
   /*一键领取优惠券调用*/
    public List<Salescoupons> getSalescouponsBySalesCouponIdsForOneKey( Map map);
    /**
     * 获取优惠券可领取数量
     * @param map
     * @return
     */
    ResponseResult<Salescoupons> getSalesCouponsNumbersForId(Map map);

    /**
     * 获取优惠券最大领取张数
     * @param id
     * @return
     */
    public int getSalesCouponsMaxNumber(Long id);

    /**
     * 查询当前所有有效且可领取的C2C优惠券
     * @param shopId
     * @param terminal
     * @return
     */
    public List<Salescoupons> getAllEffectiveC2CCoupons(String shopId, String terminal);

    /**
     * 查询可领取的优惠券
     * @param pageQuery
     * @param map
     * @return
     */
    public PageModel2<Salescoupons> getAvailableSalescouponsInfoPage(PageQuery pageQuery,Map map);

    /**
     * 查询满足领取条件的优惠券
     * @param pageQuery
     * @param map
     * @return
     */
    public PageModel2<Salescoupons> getAllAvailableSalescouponsInfoPage(PageQuery pageQuery, Map map);

    /**
     * 查询可领取的优惠券（领券中心使用）
     * @param pageQuery
     * @return
     */
    public PageModel2<Salescoupons> getDistributeSalescoupons(PageQuery pageQuery);
    /**
     * 查询可领取的优惠券（领券中心使用）
     * @param pageQuery
     * @param displayPosition 显示位置 0，全场，1小新
     * @return
     */
    public PageModel2<Salescoupons> getDistributeSalescoupons(Integer shopId,PageQuery pageQuery,Integer displayPosition);

    public PageModel2<Salescoupons> getOnekeySalecoupons(PageQuery pageQuery, Map map);
}
