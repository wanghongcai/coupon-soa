package com.lenovo.m2.couponV2.manager.impl;

import com.lenovo.m2.arch.framework.domain.PageModel2;
import com.lenovo.m2.arch.framework.domain.PageQuery;
import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.tool.util.DateFormatUtils;
import com.lenovo.m2.couponV2.common.exception.ExceptionUtil;
import com.lenovo.m2.couponV2.dao.mybatis.mapper.CouponchecksMapper;
import com.lenovo.m2.couponV2.dao.mybatis.model.*;
import com.lenovo.m2.couponV2.manager.CouponchecksManager;
import com.lenovo.utils.DateTimeUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * Created by yezhenyue on 2016/2/19.
 */
@Component("couponchecksManager")
public class CouponchecksManagerImpl implements CouponchecksManager {
    @Autowired
    CouponchecksMapper couponchecksMapper;
    private static Logger logger = LoggerFactory.getLogger(CouponchecksManagerImpl.class);
    @Override
    public PageModel2<Couponchecks> getCouponchecksInfoPage(PageQuery pageQuery, Map map) throws ParseException {
        CouponchecksExample example = new CouponchecksExample();
        CouponchecksExample.Criteria criteria = example.createCriteria();
        if (map.get("style")!=null){
            criteria.andStyleEqualTo(Integer.parseInt(map.get("style").toString()));
        }
        if (map.get("name")!=null){
            criteria.andNameLike("%" + map.get("name").toString() + "%");
        }
        if (map.get("createtime_start")!=null){
            criteria.andCreatetimeGreaterThanOrEqualTo(DateFormatUtils.parseDate(map.get("createtime_start").toString(), "yyyy-MM-dd"));
        }
        if (map.get("createtime_end")!=null){
            criteria.andCreatetimeLessThanOrEqualTo(DateFormatUtils.parseDate(map.get("createtime_end").toString(), "yyyy-MM-dd"));
        }
        if (map.get("checkstatus")!=null){
            criteria.andCheckstatusEqualTo(Integer.parseInt(map.get("checkstatus").toString()));
        }
        if (map.get("shopids")!=null){
            criteria.andShopidIn((ArrayList<String>) map.get("shopids"));
        }

        int count = couponchecksMapper.countByExample(example);
        pageQuery.setTotalCount(count);
        if (pageQuery.getTotalCount()==0){
            return new PageModel2<Couponchecks>();
        }
        int pageIndex = (pageQuery.getPageNum() - 1) * pageQuery.getPageSize();
        int pageSize = pageQuery.getPageSize();
        map.put("pageindex", pageIndex);
        map.put("pagesize", pageSize);
        List<Couponchecks> list = couponchecksMapper.getCouponchecksInfoPage(map);
        return new PageModel2<Couponchecks>(pageQuery,list);
    }

    @Override
    public int updateCouponchecksBatch(List<Couponchecks> list) {
        return couponchecksMapper.updateCouponchecksBatch(list);
    }

    @Override
    public int updateCouponSecondchecksBatch(List<Couponchecks> list) {
        return couponchecksMapper.updateCouponSecondchecksBatch(list);
    }

    @Override
    public int insertCouponchecksBatch(List<Couponchecks> list) {
        return couponchecksMapper.insertCouponchecksBatch(list);
    }

    @Override
    public int checkCouponByCondition(Couponchecks couponchecks) {
        return couponchecksMapper.updateByPrimaryKeySelective(couponchecks);
    }

    @Override
    public RemoteResult<Couponchecks> queryCouponCheckById(long id) {
        RemoteResult<Couponchecks> remoteResult = new RemoteResult<Couponchecks>(false);
        try {
            Couponchecks couponchecks = couponchecksMapper.selectByPrimaryKey(id);
            if (couponchecks!=null) {
                remoteResult.setT(couponchecks);
                remoteResult.setSuccess(true);
                remoteResult.setResultMsg("success");
                return remoteResult;
            }else {
                logger.info("没有找到数据记录 主键ID: " + id);
                remoteResult.setResultMsg("没有找到数据记录");
                return remoteResult;
            }
        }catch (Exception e){
            logger.error("数据库操作失败" + ExceptionUtil.getStackTrace(e));
            return remoteResult;
        }
    }
}
