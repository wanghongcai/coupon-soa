/**
 * Project Name:couponV2-soa-manager
 * File Name:LogService.java
 * Package Name:com.lenovo.m2.couponV2.manager
 * Date:2017年5月22日下午2:51:41
 * Copyright (c) 2017, yuzj7@lenovo.com All Rights Reserved.
 *
*/

package com.lenovo.m2.couponV2.manager;

import com.lenovo.m2.couponV2.common.vo.LogVo;

/**
 * ClassName:LogService <br/>
 * Function: 记录log 统一日志接口. <br/>
 * Date:     2017年5月22日 下午2:51:41 <br/>
 * @author   yuzj7
 * @version  
 * @since    JDK 1.7
 * @see 	 
 */
public interface LogService {

	/**
	 * 
	* @Title: save2Mongo
	* @Description: 审计日志统一通过异步的方式记录到mongo 中（审计日志只做记录不做修改）
	* @param logVo	日志vo
	* @throws
	 */
	public void save2Mongo(LogVo logVo);
}

