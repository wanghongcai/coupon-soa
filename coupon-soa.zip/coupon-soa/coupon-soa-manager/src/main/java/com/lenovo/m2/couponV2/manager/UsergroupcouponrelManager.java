package com.lenovo.m2.couponV2.manager;

import com.lenovo.m2.couponV2.dao.mybatis.model.Usergroupcouponrel;
import com.lenovo.m2.couponV2.dao.util.ResponseResult;

import java.util.Date;
import java.util.List;

/**
 * Created by zhaocl1 on 2015/9/15.
 */
public interface UsergroupcouponrelManager {

    /**
     * save
     * @param list
     * @return
     */
    public ResponseResult insertBatch(List<Usergroupcouponrel> list);

    /**
     *
     * @param usergroup 用户组
     * @param shopid    用户所属平台
     * @param registerDate 用户注册时间
     * @return
     */
    ResponseResult<List<Usergroupcouponrel>> getListByCondition(String usergroup,String shopid,Date registerDate);
}
