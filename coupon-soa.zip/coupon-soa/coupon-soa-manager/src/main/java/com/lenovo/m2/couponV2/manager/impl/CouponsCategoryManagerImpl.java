package com.lenovo.m2.couponV2.manager.impl;

import com.lenovo.m2.arch.framework.domain.PageModel2;
import com.lenovo.m2.arch.framework.domain.PageQuery;
import com.lenovo.m2.arch.tool.util.DateFormatUtils;
import com.lenovo.m2.couponV2.dao.mybatis.mapper.CouponsCategoryMapper;
import com.lenovo.m2.couponV2.dao.mybatis.model.CouponsCategory;
import com.lenovo.m2.couponV2.dao.mybatis.model.CouponsCategoryExample;
import com.lenovo.m2.couponV2.manager.CouponsCategoryManager;
import com.lenovo.utils.DateTimeUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
@Component("couponsCategoryManager")
public class CouponsCategoryManagerImpl implements CouponsCategoryManager {
    @Autowired
    private CouponsCategoryMapper couponsCategoryMapper;

    @Override
    public int deleteByPrimaryKey(Integer id) {
        return couponsCategoryMapper.deleteByPrimaryKey(id);
    }

    @Override
    public int insertSelective(CouponsCategory record) {
        return couponsCategoryMapper.insertSelective(record);
    }



    @Override
    public CouponsCategory selectByPrimaryKey(Integer id) {
        return couponsCategoryMapper.selectByPrimaryKey(id);
    }

    @Override
    public int updateByPrimaryKey(CouponsCategory record) {
        return couponsCategoryMapper.updateByPrimaryKeySelective(record);
    }

    @Override
    public PageModel2<CouponsCategory> getCouponsCategoryInfoPage(PageQuery pageQuery, Map map) throws ParseException {
        CouponsCategoryExample example = new CouponsCategoryExample();
        CouponsCategoryExample.Criteria criteria = example.createCriteria();
        if (map.get("usescope")!=null){
            criteria.andUsescopeEqualTo(Integer.parseInt(map.get("usescope").toString()));
        }
        if (map.get("classificationname")!=null){
            criteria.andClassificationnameLike("%" + map.get("classificationname").toString() + "%");
        }
        if (map.get("createtime_start")!=null){
            criteria.andCreatetimeGreaterThanOrEqualTo(DateFormatUtils.parseDate(map.get("createtime_start").toString(), "yyyy-MM-dd"));
        }
        if (map.get("createtime_end")!=null){
            criteria.andCreatetimeLessThanOrEqualTo(DateFormatUtils.parseDate(map.get("createtime_end").toString(), "yyyy-MM-dd"));
        }
        if (map.get("shopid")!=null){
            criteria.andShopidEqualTo(map.get("shopid").toString());
        }
        if (map.get("shopids")!=null){
            criteria.andShopidIn((ArrayList<String>) map.get("shopids"));
        }
        if (map.get("terminal")!=null){
            criteria.andTerminalEqualTo(map.get("terminal").toString());
        }
        if (map.get("superposition")!=null){
            criteria.andSuperpositionEqualTo(Integer.parseInt(map.get("superposition").toString()));
        }
        int count = couponsCategoryMapper.countByExample(example);
        pageQuery.setTotalCount(count);
        if (pageQuery.getTotalCount()==0){
            return new PageModel2<CouponsCategory>();
        }
        int pageIndex = (pageQuery.getPageNum() - 1) * pageQuery.getPageSize();
        int pageSize = pageQuery.getPageSize();
        map.put("pageindex", pageIndex);
        map.put("pagesize", pageSize);
        List<CouponsCategory> list = couponsCategoryMapper.getCouponsCategoryInfoPage(pageQuery, map);
        return new PageModel2<CouponsCategory>(pageQuery,list);
    }

    @Override
    public int disableCouponCategoryById(int id) {
        CouponsCategory couponsCategory = new CouponsCategory();
        couponsCategory.setUpdatetime(new Date());
        couponsCategory.setDisable(1);
        couponsCategory.setId(id);
        return couponsCategoryMapper.updateByPrimaryKeySelective(couponsCategory);
    }
}