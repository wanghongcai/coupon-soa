package com.lenovo.m2.couponV2.manager.impl;

import com.lenovo.m2.couponV2.common.CouponConstant;
import com.lenovo.m2.couponV2.common.exception.ExceptionUtil;
import com.lenovo.m2.couponV2.dao.mybatis.mapper.CouponsLogMapper;
import com.lenovo.m2.couponV2.dao.mybatis.model.*;
import com.lenovo.m2.couponV2.dao.util.ResponseResult;
import com.lenovo.m2.couponV2.manager.CouponsLogManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Date;

/**
 * Created by zhaocl1 on 2016/3/7.
 */
@Component("couponsLogManager")
public class CouponsLogManagerImpl implements CouponsLogManager {
    private static final Logger LOGGER = LoggerFactory.getLogger(CouponsLogManagerImpl.class);
    @Autowired
    private CouponsLogMapper couponsLogMapper;

    @Override
    public ResponseResult insertCouponsLog(CouponsLog couponsLog) {
        ResponseResult result = new ResponseResult(false);
        int row  = couponsLogMapper.insert(couponsLog);
        if(row == 1){
            result.setCode(CouponConstant.RESULT_CODE_SUC);
            result.setMsg(CouponConstant.RESULT_MSG_SUC);
            result.setData(couponsLog);
            result.setSuccess(true);
        }
        return result;
    }

    @Override
    public ResponseResult updateCouponsLog(String token, String orderId) {
        ResponseResult result = new ResponseResult(false);
        try {
            CouponsLog couponsLog = new CouponsLog();
            couponsLog.setOrderid(orderId);
            couponsLog.setUpdatetime(new Date());
            CouponsLogExample couponsLogExample = new CouponsLogExample();
            couponsLogExample.createCriteria().andTokenEqualTo(token);

            int row = couponsLogMapper.updateByExampleSelective(couponsLog,couponsLogExample);
            if(row >= 1){
                result.setSuccess(true);
            }
        } catch (Exception e) {
            LOGGER.error("数据库操作失败" + ExceptionUtil.getStackTrace(e));
            result.setMsg("数据库操作失败");
            return result;
        }
        return result;
    }
}
