package com.lenovo.m2.couponV2.manager;

import com.lenovo.m2.couponV2.dao.mybatis.model.Oldfornewcoupon;

import java.util.List;

/**
 * Created by zhaocl1 on 2016/3/28.
 */
public interface OldfornewcouponManager {

    /**
     * 批量保存
     * @param list
     * @return
     */
    public int batchSaveOldfornewCoupon(List<Oldfornewcoupon> list);
}
