package com.lenovo.m2.couponV2.manager.impl;

import com.lenovo.m2.couponV2.common.CouponConstant;
import com.lenovo.m2.couponV2.common.exception.ExceptionUtil;
import com.lenovo.m2.couponV2.dao.mybatis.mapper.UsergroupcouponrelMapper;
import com.lenovo.m2.couponV2.dao.mybatis.model.CouponchecksExample;
import com.lenovo.m2.couponV2.dao.mybatis.model.Usergroupcouponrel;
import com.lenovo.m2.couponV2.dao.mybatis.model.UsergroupcouponrelExample;
import com.lenovo.m2.couponV2.dao.util.ResponseResult;
import com.lenovo.m2.couponV2.manager.UsergroupcouponrelManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.List;

/**
 * Created by zhaocl1 on 2015/9/15.
 */
@Component("usergroupcouponrelManager")
public class UsergroupcouponrelManagerImpl implements UsergroupcouponrelManager {

    @Autowired
    private UsergroupcouponrelMapper usergroupcouponrelMapper;
    private static final Logger LOGGER = LoggerFactory.getLogger(UsergroupcouponrelManagerImpl.class);

    @Override
    public ResponseResult insertBatch(List<Usergroupcouponrel> list) {
        ResponseResult result = new ResponseResult(false);
        if(list != null && list.size()>0){
            int row = usergroupcouponrelMapper.insertBatch(list);
            if(row == list.size()){
                result.setMsg(CouponConstant.RESULT_MSG_SUC);
                result.setCode(CouponConstant.RESULT_CODE_SUC);
                result.setSuccess(true);
            }else {
                result.setMsg(CouponConstant.RESULT_MSG_FAIL);
                result.setCode(CouponConstant.RESULT_CODE_FAIL);
            }
        }else {
            result.setMsg(CouponConstant.RESULT_MSG_ERROR_PARAM);
            result.setCode(CouponConstant.RESULT_CODE_ERROR_PARAM);
        }
        return  result;
    }

    @Override
    public ResponseResult<List<Usergroupcouponrel>> getListByCondition(String usergroup,String shopid,Date registerDate) {
        ResponseResult<List<Usergroupcouponrel>> result = new ResponseResult(false);
        try {
            UsergroupcouponrelExample example = new UsergroupcouponrelExample();
            UsergroupcouponrelExample.Criteria criteria = example.createCriteria();
            criteria.andUsergroupEqualTo(usergroup);
            criteria.andShopidEqualTo(shopid);
            criteria.andRegisterfromtimeLessThanOrEqualTo(registerDate);
            criteria.andRegistertotimeGreaterThanOrEqualTo(registerDate);
            criteria.andSendtimeGreaterThanOrEqualTo(registerDate);
            List<Usergroupcouponrel> list = usergroupcouponrelMapper.selectByExample(example);
            result.setData(list);
            result.setMsg(CouponConstant.RESULT_MSG_SUC);
            result.setCode(CouponConstant.RESULT_CODE_SUC);
            result.setSuccess(true);
        }catch (Exception e){
            LOGGER.error(ExceptionUtil.getStackTrace(e));
            result.setMsg(CouponConstant.RESULT_MSG_FAIL);
            result.setCode(CouponConstant.RESULT_CODE_FAIL);
        }
        return  result;
    }
}
