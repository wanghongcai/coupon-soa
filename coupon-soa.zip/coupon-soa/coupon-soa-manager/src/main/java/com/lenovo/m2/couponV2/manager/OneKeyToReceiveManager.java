package com.lenovo.m2.couponV2.manager;

import com.lenovo.m2.arch.framework.domain.PageModel2;
import com.lenovo.m2.arch.framework.domain.PageQuery;
import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.couponV2.dao.mybatis.model.OneKeyToReceive;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

/**
 * Created by pxg01 on 2017/7/4.
 */
public interface OneKeyToReceiveManager {

    public OneKeyToReceive getActivityName(String activityName);
    public int addReceiveActivity(OneKeyToReceive oneKeyToReceive);
    public int editReceiveActivity(OneKeyToReceive oneKeyToReceive);
    public  int deleteReceiveActivity(Map map);
    PageModel2<OneKeyToReceive> getReceiveActivity(PageQuery pageQuery, Map map);
    public PageModel2<OneKeyToReceive> getReceiveActivityByCondityon(PageQuery pageQuery, Map map);
    public String confirmUserIfJoinTheAcitity(String lenovoId , Integer activityType,String activityName);
    int saveOnekeygetinfo(Map map);
    OneKeyToReceive getActivityInfoById(Long id);
    int  setOnekeyUseable(Long id, Integer useable,String itcode);
  List<OneKeyToReceive> getReceiveActivityForBinds(Map map);
    Integer selectAnyActivityIsHolding();


}
