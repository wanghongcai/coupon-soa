package com.lenovo.m2.couponV2.manager.impl;

import com.lenovo.m2.arch.framework.domain.PageModel2;
import com.lenovo.m2.arch.framework.domain.PageQuery;
import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.couponV2.api.dubboModel.MemberExcelTempApi;
import com.lenovo.m2.couponV2.common.CouponConstant;
import com.lenovo.m2.couponV2.common.exception.ExceptionUtil;
import com.lenovo.m2.couponV2.dao.mybatis.mapper.MemberExcelTempMapper;
import com.lenovo.m2.couponV2.dao.mybatis.model.MemberExcelTemp;
import com.lenovo.m2.couponV2.dao.util.ResponseResult;
import com.lenovo.m2.couponV2.manager.MemberExcelTempManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.text.ParseException;
import java.util.List;
import java.util.Map;

/**
 * Created by yuzn1 on 2016/5/17.
 */

@Component("memberExcelTempManager")
public class MemberExcelTempManagerImpl implements MemberExcelTempManager {

    private static final Logger LOGGER = LoggerFactory.getLogger(MemberExcelTempManagerImpl.class);

    @Autowired
    private MemberExcelTempMapper memberExcelTempMapper;

    @Override
    public ResponseResult insertBatch(List<MemberExcelTemp> list){
        ResponseResult result = new ResponseResult(false);
        if(list != null && list.size()>0){
            int row = memberExcelTempMapper.insertBatch(list);
            if(row == list.size()){
                result.setMsg(CouponConstant.RESULT_MSG_SUC);
                result.setCode(CouponConstant.RESULT_CODE_SUC);
                result.setSuccess(true);
            }else {
                result.setMsg(CouponConstant.RESULT_MSG_FAIL);
                result.setCode(CouponConstant.RESULT_CODE_FAIL);
            }
        }else {
            result.setMsg(CouponConstant.RESULT_MSG_ERROR_PARAM);
            result.setCode(CouponConstant.RESULT_CODE_ERROR_PARAM);
        }
        return result;
    }

    /**
     * 查询重复数据
     */
    @Override
    public List<MemberExcelTemp> selectIsRepeat(String itCode){
        List<MemberExcelTemp> list = memberExcelTempMapper.selectIsRepeat(itCode);
        return list;
    }

    /**
     * 更新重复数据状态IsRepeatd==1
     */
    @Override
    public int updateIsRepeatd(Map<String, Object> map){
        return memberExcelTempMapper.updateIsRepeatd(map);
    }


    /**
     * 查询导入excel信息
     */
    @Override
    public PageModel2<MemberExcelTemp> getMemberExcelTempPage(PageQuery pageQuery, Map map) {
        return new PageModel2(memberExcelTempMapper.getMemberExcelTempPage(pageQuery, map));
    }

    public ResponseResult getIsRepeat(String itCode){
        ResponseResult result = new ResponseResult(false);
        try {
            MemberExcelTemp memberExcelTemp = new MemberExcelTemp();
            List<MemberExcelTemp> list = memberExcelTempMapper.selectIsRepeat(itCode);
            if (list!=null&&list.size()>0){
                result.setSuccess(true);
                result.setData(list);
                result.setMsg("查询excel重复数据信息成功！");
                return result;
            }else {
                result.setSuccess(false);
                result.setMsg("查询excel重复数据信息时失败！");
                return result;
            }
        }catch (Exception e) {
            LOGGER.error("查询导入excel重复数据库操作失败" + ExceptionUtil.getStackTrace(e));
            result.setMsg("查询导入excel重复数据库操作失败");
            return result;
        }
    }

    @Override
    public ResponseResult getValidList(String itCode){
        ResponseResult result = new ResponseResult(false);
        try {
            MemberExcelTemp memberExcelTemp = new MemberExcelTemp();
            List<MemberExcelTemp> list = memberExcelTempMapper.getValidList(itCode);
            if (list!=null&&list.size()>0){
                result.setSuccess(true);
                result.setData(list);
                result.setMsg("查询导入excel有效信息成功！");
                return result;
            }else {
                result.setSuccess(false);
                result.setMsg("查询导入excel有效信息时失败！");
                return result;
            }
        }catch (Exception e) {
            LOGGER.error("数据库操作失败：查询导入excel有效信息时失败！" + ExceptionUtil.getStackTrace(e));
            result.setMsg("数据库操作失败：查询导入excel有效信息时失败！");
            return result;
        }
    }

    @Override
    public ResponseResult toDelete_exMember(Map map){
        ResponseResult result = new ResponseResult(false);
        try{
            int rows = memberExcelTempMapper.toDelete_exMember(map);
            if (rows>0){
                result.setMsg("删除导入excel信息成功");
                result.setSuccess(true);
                return  result;
            }else{
                result.setMsg("删除导入excel信息失败");
                result.setSuccess(false);
                return  result;
            }
        }catch (Exception e) {
            LOGGER.error("数据库操作失败：删除导入excel信息失败" + ExceptionUtil.getStackTrace(e));
            result.setMsg("数据库操作失败：删除导入excel信息失败");
            return result;
        }
    }

    @Override
    public ResponseResult deleteAll(String itCode) {
        ResponseResult result = new ResponseResult(false);
        try{
            int rows = memberExcelTempMapper.deleteAll(itCode);
            if (rows>0){
                result.setCode("00");
                result.setMsg("清除memberExcelTemp表数据成功");
                result.setSuccess(true);
                return result;
            }else {
                result.setCode("02");
                result.setMsg("删除清除memberExcelTemp表数据失败");
                result.setSuccess(false);
                return result;
            }
        }catch (Exception e) {
            LOGGER.error("数据库操作失败：清除memberExcelTemp表数据" + ExceptionUtil.getStackTrace(e));
            result.setMsg("数据库操作失败：清除memberExcelTemp表数据");
            return result;
        }
    }

}
