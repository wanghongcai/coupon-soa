package com.lenovo.m2.couponV2.manager.impl;

import com.lenovo.m2.couponV2.common.exception.ExceptionUtil;
import com.lenovo.m2.couponV2.dao.mybatis.mapper.SendcouponrecordMapper;
import com.lenovo.m2.couponV2.dao.mybatis.model.Sendcouponrecord;
import com.lenovo.m2.couponV2.dao.util.ResponseResult;
import com.lenovo.m2.couponV2.manager.SendcouponrecordManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by zhaocl1 on 2016/3/28.
 */
@Component("sendcouponrecordManager")
public class SendcouponrecordManagerImpl implements SendcouponrecordManager {

    private static final Logger LOGGER = LoggerFactory.getLogger(SendcouponrecordManagerImpl.class);
    @Autowired
    private SendcouponrecordMapper sendcouponrecordMapper;

    @Override
    public int insertSelective(Sendcouponrecord record) {
        return sendcouponrecordMapper.insertSelective(record);
    }

    @Override
    public ResponseResult getSendCouponRecordByorderid(String orderId, int status) {
        ResponseResult responseResult = new ResponseResult(false);
        try {
            Map<String,Object> map = new HashMap<String, Object>(2);
            map.put("orderId", orderId);
            map.put("status", status);
            Sendcouponrecord sendcouponrecord = sendcouponrecordMapper.getSendCouponRecordByorderid(map);
            if(sendcouponrecord != null){
                responseResult.setData(sendcouponrecord);
                responseResult.setSuccess(true);
            }
        } catch (Exception e) {
//            e.printStackTrace();
            LOGGER.info(ExceptionUtil.getStackTrace(e));
            responseResult.setSuccess(false);
        }
        return responseResult;
    }
}
