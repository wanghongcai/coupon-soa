package com.lenovo.m2.couponV2.manager.impl;

import com.lenovo.m2.couponV2.common.CouponConstant;
import com.lenovo.m2.couponV2.common.exception.ExceptionUtil;
import com.lenovo.m2.couponV2.dao.mybatis.mapper.ProductruleMapper;
import com.lenovo.m2.couponV2.dao.mybatis.model.Productrule;
import com.lenovo.m2.couponV2.dao.mybatis.model.ProductruleExample;
import com.lenovo.m2.couponV2.dao.util.ResponseResult;
import com.lenovo.m2.couponV2.manager.ProductruleManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

/**
 * Created by zhaocl1 on 2016/2/15.
 */
@Component("productruleManager")
public class ProductruleManagerImpl implements ProductruleManager {
    private static final Logger LOGGER = LoggerFactory.getLogger(ProductruleManagerImpl.class);

    @Autowired
    private ProductruleMapper productruleMapper;

    @Override
    public ResponseResult insertProductrule(Productrule productrule) {
        ResponseResult result = new ResponseResult(false);
        if(productrule!=null){
            int row = productruleMapper.insert(productrule);
            if(row>0){
                result.setMsg(CouponConstant.RESULT_MSG_SUC);
                result.setCode(CouponConstant.RESULT_CODE_SUC);
                result.setSuccess(true);
            }
        }else {
            result.setMsg(CouponConstant.RESULT_MSG_ERROR_PARAM);
            result.setCode(CouponConstant.RESULT_CODE_ERROR_PARAM);
        }
        return result;
    }

    @Override
    public ResponseResult delProductrule(Productrule productrule) {
        ResponseResult result = new ResponseResult(false);
        if(productrule!=null){
            ProductruleExample productruleExample = new ProductruleExample();
            productruleExample.createCriteria().andSalescouponidEqualTo(productrule.getSalescouponid());
            int row = productruleMapper.deleteByExample(productruleExample);
            if(row>0){
                result.setMsg(CouponConstant.RESULT_MSG_SUC);
                result.setCode(CouponConstant.RESULT_CODE_SUC);
                result.setSuccess(true);
            }
        }else {
            result.setMsg(CouponConstant.RESULT_MSG_ERROR_PARAM);
            result.setCode(CouponConstant.RESULT_CODE_ERROR_PARAM);
        }
        return result;
    }

    @Override
    public ResponseResult<List<Productrule>> getProductruleList(Productrule productrule) {
        ResponseResult result = new ResponseResult(false);
        if(productrule!=null){
            ProductruleExample productruleExample = new ProductruleExample();
            productruleExample.createCriteria().andSalescouponidEqualTo(productrule.getSalescouponid());
            List<Productrule> list = productruleMapper.selectByExampleWithBLOBs(productruleExample);
            if(list != null && list.size()>0){
                result.setMsg(CouponConstant.RESULT_MSG_SUC);
                result.setCode(CouponConstant.RESULT_CODE_SUC);
                result.setData(list);
                result.setSuccess(true);
            }
        }else {
            result.setMsg(CouponConstant.RESULT_MSG_ERROR_PARAM);
            result.setCode(CouponConstant.RESULT_CODE_ERROR_PARAM);
        }
        return result;
    }

    @Override
    public ResponseResult<List<Productrule>> getBatchBySalescouponids(Map map) {
        ResponseResult result = new ResponseResult(false);
        try {
            if(map == null ){
                result.setCode(CouponConstant.RESULT_CODE_ERROR_PARAM);
                result.setMsg(CouponConstant.RESULT_MSG_ERROR_PARAM);
                return result;
            }

            List<Productrule> list = productruleMapper.getBatchBySalescouponids(map);
            if(list != null && list.size()>0){
                result.setData(list);
                result.setSuccess(true);
                return result;
            }else {
                LOGGER.info("没有找到数据记录 主键IDs: " + map.get("ids"));
                result.setMsg("通过主键s未找到用户优惠券！");
                return result;
            }

        } catch (Exception e) {
            LOGGER.error("数据库操作失败" + ExceptionUtil.getStackTrace(e));
            result.setMsg("数据库操作失败");
            return result;
        }
    }
}
