package com.lenovo.m2.couponV2.manager.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.lenovo.m2.arch.framework.domain.PageModel2;
import com.lenovo.m2.arch.framework.domain.PageQuery;
import com.lenovo.m2.couponV2.common.CouponConstant;
import com.lenovo.m2.couponV2.common.TripleDESUtil;
import com.lenovo.m2.couponV2.common.exception.ExceptionUtil;
import com.lenovo.m2.couponV2.dao.mybatis.mapper.CouponsMapper;
import com.lenovo.m2.couponV2.dao.mybatis.model.Coupons;
import com.lenovo.m2.couponV2.dao.mybatis.model.CouponsExample;
import com.lenovo.m2.couponV2.dao.mybatis.reportmapper.CouponReportMapper;
import com.lenovo.m2.couponV2.dao.util.ResponseResult;
import com.lenovo.m2.couponV2.manager.CouponsManager;

/**
 * Created by zhaocl1 on 2016/3/5.
 */
@Component("couponsManager")
public class CouponsManagerImpl implements CouponsManager {
    private static final Logger LOGGER = LoggerFactory.getLogger(CouponsManagerImpl.class);
    @Autowired
    private CouponsMapper couponsMapper;
    @Autowired
    private CouponReportMapper couponReportMapper;

    @Override
    public ResponseResult getCouponsByCode(String code) {
        ResponseResult result = new ResponseResult(false);
        Map map = new HashMap();
        map.put("initialMacode", code);//初始
        map.put("encryptionMacode", TripleDESUtil.encryptMode(code));//加密
        List<Coupons> list =couponsMapper.getCouponsByCode(map);
        if(list != null && list.size() != 0){
            if(list.size() == 1){
                result.setData(list.get(0));
                result.setSuccess(true);
            }else {
                result.setMsg("同一个码 "+code+" 查询出两条记录，错误！");
                result.setSuccess(false);
                LOGGER.info("同一个码 " + code + " 查询出两条记录，错误！");
            }
        }
        return result;
    }

    @Override
    public ResponseResult getCouponsByCode(String shopId, String code) {
        ResponseResult result = new ResponseResult(false);
        Map map = new HashMap();
        map.put("shopId", shopId);
        map.put("initialMacode", code);//初始
        map.put("encryptionMacode", TripleDESUtil.encryptMode(code));//加密

        List<Coupons> list =couponsMapper.getCouponsByCode(map);
        if(list != null && list.size() != 0){
            if(list.size() == 1){
                result.setData(list.get(0));
                result.setSuccess(true);
            }else {
                result.setMsg("同一个码 "+code+" 查询出两条记录，错误！");
                result.setSuccess(false);
                LOGGER.info("同一个码 " + code + " 查询出两条记录，错误！");
            }
        }
        return result;
    }

    @Override
    public ResponseResult getCouponsById(long id) {
        ResponseResult result = new ResponseResult(false);
        Coupons coupons = couponsMapper.selectByPrimaryKey(id);
        if(coupons != null){
            result.setData(coupons);
            result.setSuccess(true);
        }
        return result;
    }

    @Override
    public ResponseResult updateCouponsPlus(Map map) {
        ResponseResult result = new ResponseResult(false);
        try {
            if(map == null){
                result.setCode(CouponConstant.RESULT_CODE_ERROR_PARAM);
                result.setMsg(CouponConstant.RESULT_MSG_ERROR_PARAM);
                return result;
            }
            int row = couponsMapper.updateCouponsPlus(map);
            if(row == 1){
                result.setSuccess(true);
                result.setMsg("使用优惠码成功！");
                return result;
            }else {
                result.setSuccess(false);
                result.setMsg("使用优惠码时失败！");
                return result;
            }
        } catch (Exception e) {
            LOGGER.error("数据库操作失败" + ExceptionUtil.getStackTrace(e));
            result.setMsg("数据库操作失败");
            return result;
        }
    }

    @Override
    public ResponseResult updateCouponsReduce(Map map) {
        ResponseResult result = new ResponseResult(false);
        try {
            if(map == null){
                result.setCode(CouponConstant.RESULT_CODE_ERROR_PARAM);
                result.setMsg(CouponConstant.RESULT_MSG_ERROR_PARAM);
                return result;
            }
            int row = couponsMapper.updateCouponsReduce(map);
            if(row == 1){
                result.setSuccess(true);
                result.setMsg("返还优惠码成功！");
                return result;
            }else {
                result.setSuccess(false);
                result.setMsg("返还优惠码时失败！");
                return result;
            }
        } catch (Exception e) {
            LOGGER.error("数据库操作失败" + ExceptionUtil.getStackTrace(e));
            result.setMsg("数据库操作失败");
            return result;
        }
    }

    @Override
    public PageModel2<Coupons> getCouponsInfoPage(PageQuery pageQuery, Map map) {
        return new PageModel2(couponsMapper.getCouponsInfoPage(pageQuery, map));
    }

    @Override
    public ResponseResult<Integer> insertBatch(List<Coupons> list) {
        ResponseResult<Integer> result = new ResponseResult<Integer>(false);
        try {
            if(list == null){
                result.setCode(CouponConstant.RESULT_CODE_ERROR_PARAM);
                result.setMsg(CouponConstant.RESULT_MSG_ERROR_PARAM);
                return result;
            }
            int row = couponsMapper.insertBatch(list);
            if(row==list.size()){
                result.setSuccess(true);
                result.setData(row);
                result.setMsg("批量生成优惠码成功！");
                return result;
            }else {
                result.setSuccess(false);
                result.setData(0);
                result.setMsg("批量生成优惠码失败！");
                return result;
            }
        } catch (Exception e) {
            LOGGER.error("数据库操作失败" + ExceptionUtil.getStackTrace(e));
            result.setData(0);
            result.setMsg("数据库操作失败");
            return result;
        }
    }

    @Override
    public ResponseResult getCouponsBySalescouponsId(long salescouponid) {
        ResponseResult result = new ResponseResult(false);
        try {
            if(salescouponid <= 0){
                result.setCode(CouponConstant.RESULT_CODE_ERROR_PARAM);
                result.setMsg(CouponConstant.RESULT_MSG_ERROR_PARAM);
                return result;
            }
            //yuzj7 2017年5月5日20:21:07 分页倒数据 
            //100 条查询一次
            long t1 = System.currentTimeMillis();
            Map<String,Object> mapTemp = new HashMap<String, Object>(1);
            mapTemp.put("salesCouponID", salescouponid);
            int total = couponReportMapper.countCouponByCondition(mapTemp);
            long t2 = System.currentTimeMillis();
            LOGGER.info("导出数据查询总数量耗时:"+(t2-t1)+"ms");
            int pageSize = 1000;
           
            if(total <=0){
            	 result.setSuccess(false);
                 result.setMsg("查询优惠码时失败！");
                 return result;
            }
            int totalPage = total % pageSize == 0 ? total / pageSize : total / pageSize +1;
            List<Coupons> totalList = new ArrayList<Coupons>(1000);
            long t3 = System.currentTimeMillis();
            for(int i=1;i <=totalPage;i++){
            	int start = pageSize * (i-1) ;
            	int end = pageSize;
            	Map<String,Object> map = new HashMap<String, Object>(3);
            	map.put("salesCouponID", salescouponid);
            	map.put("limitStart", start);
            	map.put("limitEnd", end);
            	List<Coupons> temp = couponReportMapper.getCouponListPageByCondition(map);
            	totalList.addAll(temp);
            }
            long t4 = System.currentTimeMillis();
            LOGGER.info("导出数据分页耗时:"+(t4-t3)+"ms");
            if(totalList != null && totalList.size() >= 0 ){
                result.setSuccess(true);
                result.setData(totalList);
                result.setMsg("查询优惠码成功！");
                return result;
            }else {
                result.setSuccess(false);
                result.setMsg("查询优惠码时失败！");
                return result;
            }
        } catch (Exception e) {
            LOGGER.error("数据库操作失败" + ExceptionUtil.getStackTrace(e));
            result.setMsg("数据库操作失败");
            return result;
        }
    }

    @Override
    public ResponseResult deleteCouponsBySalescouponsId(long salescouponid) {
        ResponseResult result = new ResponseResult(false);
        try {
            if(salescouponid <= 0){
                CouponsExample couponsExample = new CouponsExample();
                couponsExample.createCriteria().andSalescouponidEqualTo(salescouponid);
                int row = couponsMapper.deleteByExample(couponsExample);
                if(row>0){
                    result.setMsg(CouponConstant.RESULT_MSG_SUC);
                    result.setCode(CouponConstant.RESULT_CODE_SUC);
                    result.setData(row);
                    result.setSuccess(true);
                    return result;
                }else {
                    result.setSuccess(false);
                    result.setData(0);
                    result.setMsg("批量删除优惠码失败！");
                    return result;
                }
            }else {
                result.setData(0);
                result.setMsg(CouponConstant.RESULT_MSG_ERROR_PARAM);
                result.setCode(CouponConstant.RESULT_CODE_ERROR_PARAM);
                return result;
            }
        } catch (Exception e) {
            LOGGER.error("数据库操作失败" + ExceptionUtil.getStackTrace(e));
            result.setData(0);
            result.setMsg("数据库操作失败");
            return result;
        }
    }

    @Override
    public ResponseResult updateCouponsBySalescouponsId(Coupons coupons) {
        ResponseResult result = new ResponseResult(false);
        try {
            if(coupons != null){
                CouponsExample couponsExample = new CouponsExample();
                couponsExample.createCriteria().andSalescouponidEqualTo(coupons.getSalescouponid());
                int row = couponsMapper.updateByExampleSelective(coupons,couponsExample);
                if(row>0){
                    result.setMsg(CouponConstant.RESULT_MSG_SUC);
                    result.setCode(CouponConstant.RESULT_CODE_SUC);
                    result.setData(row);
                    result.setSuccess(true);
                    return result;
                }else {
                    result.setSuccess(false);
                    result.setData(0);
                    result.setMsg("批量更新优惠码失败！");
                    return result;
                }
            }else {
                result.setData(0);
                result.setMsg(CouponConstant.RESULT_MSG_ERROR_PARAM);
                result.setCode(CouponConstant.RESULT_CODE_ERROR_PARAM);
                return result;
            }
        } catch (Exception e) {
            LOGGER.error("数据库操作失败" + ExceptionUtil.getStackTrace(e));
            result.setData(0);
            result.setMsg("数据库操作失败");
            return result;
        }
    }

    /**
     * 根据码主键和优惠码更新优惠码的状态
     * @param coupons
     * @return
     */
    @Override
    public ResponseResult updateCouponsStatus(Coupons coupons) {
        ResponseResult result = new ResponseResult(false);
        try {
            if(null != coupons){
                CouponsExample couponsExample = new CouponsExample();
                couponsExample.createCriteria().andIdEqualTo(coupons.getId()).andMacodeEqualTo(coupons.getMacode());
                Coupons c = new Coupons();
                c.setStatus(1);
                int row = couponsMapper.updateByExampleSelective(c,couponsExample);
                if(row>0){
                    result.setMsg(CouponConstant.RESULT_MSG_SUC);
                    result.setCode(CouponConstant.RESULT_CODE_SUC);
                    result.setData(row);
                    result.setSuccess(true);
                    return result;
                }else {
                    result.setSuccess(false);
                    result.setData(0);
                    result.setMsg("更新优惠码状态失败！");
                    return result;
                }
            }else {
                result.setData(0);
                result.setMsg(CouponConstant.RESULT_MSG_ERROR_PARAM);
                result.setCode(CouponConstant.RESULT_CODE_ERROR_PARAM);
                return result;
            }
        } catch (Exception e) {
            LOGGER.error("数据库操作失败" + ExceptionUtil.getStackTrace(e));
            result.setData(0);
            result.setMsg("数据库操作失败");
            return result;
        }
    }
    @Override
    public ResponseResult getCouponsBySalescouponsIdAndBatchNO(long salescouponid, String batchNo) {

        ResponseResult result = new ResponseResult(false);
        try {
            if(salescouponid <= 0){
                result.setCode(CouponConstant.RESULT_CODE_ERROR_PARAM);
                result.setMsg(CouponConstant.RESULT_MSG_ERROR_PARAM);
                return result;
            }
            //yuzj7 2017年5月5日20:21:07 分页倒数据
            //100 条查询一次
            long t1 = System.currentTimeMillis();
            Map<String,Object> mapTemp = new HashMap<String, Object>(1);
            mapTemp.put("salesCouponID", salescouponid);
            int total = couponReportMapper.countCouponByCondition(mapTemp);
            long t2 = System.currentTimeMillis();
            LOGGER.info("导出数据查询总数量耗时:"+(t2-t1)+"ms");
            int pageSize = 1000;

            if(total <=0){
                result.setSuccess(false);
                result.setMsg("查询优惠码时失败！");
                return result;
            }
            int totalPage = total % pageSize == 0 ? total / pageSize : total / pageSize +1;
            List<Coupons> totalList = new ArrayList<Coupons>(1000);
            long t3 = System.currentTimeMillis();
            for(int i=1;i <=totalPage;i++){
                int start = pageSize * (i-1) ;
                int end = pageSize;
                Map<String,Object> map = new HashMap<String, Object>(3);
                map.put("salesCouponID", salescouponid);
                map.put("batchno",batchNo);
                map.put("limitStart", start);
                map.put("limitEnd", end);
                List<Coupons> temp = couponReportMapper.getCouponListPageByCondition(map);
                totalList.addAll(temp);
            }
            long t4 = System.currentTimeMillis();
            LOGGER.info("导出数据分页耗时:"+(t4-t3)+"ms");
            if(totalList != null && totalList.size() >= 0 ){
                result.setSuccess(true);
                result.setData(totalList);
                result.setMsg("查询优惠码成功！");
                return result;
            }else {
                result.setSuccess(false);
                result.setMsg("查询优惠码时失败！");
                return result;
            }
        } catch (Exception e) {
            LOGGER.error("数据库操作失败" + ExceptionUtil.getStackTrace(e));
            result.setMsg("数据库操作失败");
            return result;
        }

    }
    @Override
    public int getCouponsCountBySalescouponId(long salescouponid) {
        int res = 0;
        try {
            CouponsExample couponsExample = new CouponsExample();
            couponsExample.createCriteria().andSalescouponidEqualTo(salescouponid);
            res = couponsMapper.countByExample(couponsExample);
        } catch (Exception e) {
            LOGGER.error("数据库操作失败" + ExceptionUtil.getStackTrace(e));
        }
        return res;
    }

    @Override
    public ResponseResult<List<Coupons>> getTrueMacode(Long id, String itCode) {
        ResponseResult result = new ResponseResult(false);
        try {
            Map map = new HashMap();
            map.put("id", id);
            List<Coupons> list = couponsMapper.getTrueMacode(map);
            if(list != null && list.size() != 0){
                if(list.size() == 1){
                    result.setData(list);
                    result.setSuccess(true);
                }else {
                    result.setCode("02");
                    result.setMsg("查找失败");
                    result.setSuccess(false);
                }
            }
        }catch (Exception e) {
            LOGGER.error(ExceptionUtil.getStackTrace(e));
        }
        return result;
    }
}
