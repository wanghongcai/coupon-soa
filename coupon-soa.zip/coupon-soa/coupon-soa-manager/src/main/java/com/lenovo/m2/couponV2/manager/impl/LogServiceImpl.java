/**
 * Project Name:couponV2-soa-manager
 * File Name:LogServiceImpl.java
 * Package Name:com.lenovo.m2.couponV2.manager.impl
 * Date:2017年5月22日下午2:55:11
 * Copyright (c) 2017, yuzj7@lenovo.com All Rights Reserved.
 *
*/

package com.lenovo.m2.couponV2.manager.impl;

import org.apache.logging.log4j.ThreadContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lenovo.m2.couponV2.common.util.JsonUtil;
import com.lenovo.m2.couponV2.common.vo.LogVo;
import com.lenovo.m2.couponV2.manager.LogService;

import akka.actor.ActorRef;

/**
 * ClassName:LogServiceImpl <br/>
 * Function: TODO ADD FUNCTION. <br/>
 * Date:     2017年5月22日 下午2:55:11 <br/>
 * @author   yuzj7
 * @version  
 * @since    JDK 1.7
 * @see 	 
 */
@Service
public class LogServiceImpl implements LogService {
	private static final Logger logger = LoggerFactory.getLogger(LogServiceImpl.class.getName());

	@Override
	public void save2Mongo(LogVo logVo) {
	}

}

