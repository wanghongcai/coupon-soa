package com.lenovo.m2.couponV2.manager.impl;

import com.lenovo.m2.couponV2.common.exception.ExceptionUtil;
import com.lenovo.m2.couponV2.dao.mybatis.mapper.MembercouponrelsLogMapper;
import com.lenovo.m2.couponV2.dao.mybatis.model.MembercouponrelsLog;
import com.lenovo.m2.couponV2.dao.mybatis.model.MembercouponrelsLogExample;
import com.lenovo.m2.couponV2.dao.util.ResponseResult;
import com.lenovo.m2.couponV2.manager.MembercouponrelsLogManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.List;

/**
 * Created by zhaocl1 on 2016/3/4.
 */
@Component("membercouponrelsLogManager")
public class MembercouponrelsLogManagerImpl implements MembercouponrelsLogManager {
    private static final Logger LOGGER = LoggerFactory.getLogger(MembercouponrelsLogManagerImpl.class);
    @Autowired
    private MembercouponrelsLogMapper membercouponrelsLogMapper;

    @Override
    public ResponseResult insertBatch(List<MembercouponrelsLog> list) {
        ResponseResult result = new ResponseResult(false);
        try {
            int row = membercouponrelsLogMapper.insertBatch(list);
            if(row >= 1){
                result.setSuccess(true);
            }
        } catch (Exception e) {
            LOGGER.error("数据库操作失败" + ExceptionUtil.getStackTrace(e));
            result.setMsg("数据库操作失败");
            return result;
        }
        return result;
    }

    @Override
    public ResponseResult updateMembercouponrelsLog(String token, String orderId) {
        ResponseResult result = new ResponseResult(false);
        try {
            MembercouponrelsLog membercouponrelsLog = new MembercouponrelsLog();
            membercouponrelsLog.setOrderid(orderId);
            membercouponrelsLog.setUpdatetime(new Date());
            MembercouponrelsLogExample membercouponrelsLogExample = new MembercouponrelsLogExample();
            membercouponrelsLogExample.createCriteria().andTokenEqualTo(token);
            int row = membercouponrelsLogMapper.updateByExampleSelective(membercouponrelsLog,membercouponrelsLogExample);
            if(row >= 1){
                result.setSuccess(true);
            }
        } catch (Exception e) {
            LOGGER.error("数据库操作失败" + ExceptionUtil.getStackTrace(e));
            result.setMsg("数据库操作失败");
            return result;
        }
        return result;
    }
}
