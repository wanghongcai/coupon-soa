package com.lenovo.m2.couponV2.manager.impl;

import com.lenovo.m2.arch.framework.domain.PageModel2;
import com.lenovo.m2.arch.framework.domain.PageQuery;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.couponV2.common.CouponConstant;
import com.lenovo.m2.couponV2.dao.mybatis.mapper.SalescouponsMapper;
import com.lenovo.m2.couponV2.dao.mybatis.model.Salescoupons;
import com.lenovo.m2.couponV2.dao.mybatis.model.SalescouponsExample;
import com.lenovo.m2.couponV2.dao.util.ResponseResult;
import com.lenovo.m2.couponV2.manager.SalescouponsManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by zhaocl1 on 2015/8/25.
 */
@Component("salescouponsManager")
public class SalescouponsManagerImpl implements SalescouponsManager {

    @Autowired
    private SalescouponsMapper salescouponsMapper;

    @Override
    public PageModel2<Salescoupons> getSalescouponsInfoPage(PageQuery pageQuery, Map map) {
        return new PageModel2(salescouponsMapper.getSalescouponsInfoPage(pageQuery, map));
    }

    @Override
    public ResponseResult<Salescoupons> insertSalescoupons(Salescoupons salescoupons) {
        ResponseResult result = new ResponseResult(false);

        if (salescoupons != null) {
            long size = salescouponsMapper.insert(salescoupons);
            if (size > 0) {
                result.setMsg(CouponConstant.RESULT_MSG_SUC);
                result.setCode(CouponConstant.RESULT_CODE_SUC);
                result.setData(salescoupons);
                result.setSuccess(true);
            }
        } else {
            result.setMsg(CouponConstant.RESULT_MSG_ERROR_PARAM);
            result.setCode(CouponConstant.RESULT_CODE_ERROR_PARAM);
        }

        return result;
    }

    @Override
    public ResponseResult<Salescoupons> getSalescoupons(Long id) {
        ResponseResult result = new ResponseResult(false);
        if (id > 0) {
            Salescoupons salescoupons = salescouponsMapper.selectByPrimaryKey(id);
            if (salescoupons != null) {
                result.setMsg(CouponConstant.RESULT_MSG_SUC);
                result.setCode(CouponConstant.RESULT_CODE_SUC);
                result.setData(salescoupons);
                result.setSuccess(true);
            }
        } else {
            result.setMsg(CouponConstant.RESULT_MSG_ERROR_PARAM);
            result.setCode(CouponConstant.RESULT_CODE_ERROR_PARAM);
        }

        return result;
    }
    @Override
    public ResponseResult<Boolean> delSalescoupons(Salescoupons salescoupons) {
        ResponseResult result = new ResponseResult(false);

        if (salescoupons != null) {
            long size = salescouponsMapper.deleteByPrimaryKey(salescoupons.getId());
            if (size > 0) {
                result.setMsg(CouponConstant.RESULT_MSG_SUC);
                result.setCode(CouponConstant.RESULT_CODE_SUC);
                result.setData(salescoupons);
                result.setSuccess(true);
            }
        } else {
            result.setMsg(CouponConstant.RESULT_MSG_ERROR_PARAM);
            result.setCode(CouponConstant.RESULT_CODE_ERROR_PARAM);
        }

        return result;
    }

    @Override
    public ResponseResult editSalescoupons(Salescoupons salescoupons) {
        ResponseResult result = new ResponseResult(false);

        if (salescoupons != null) {
            long size = salescouponsMapper.updateByPrimaryKeySelective(salescoupons);
            if (size > 0) {
                result.setMsg(CouponConstant.RESULT_MSG_SUC);
                result.setCode(CouponConstant.RESULT_CODE_SUC);
                result.setData(salescoupons);
                result.setSuccess(true);
            }
        } else {
            result.setMsg(CouponConstant.RESULT_MSG_ERROR_PARAM);
            result.setCode(CouponConstant.RESULT_CODE_ERROR_PARAM);
        }

        return result;
    }

    @Override
    public ResponseResult<List<Salescoupons>> getSalescouponsList(Map map) {
        ResponseResult result = new ResponseResult(false);
        List<Salescoupons> list = salescouponsMapper.getSalescouponsList(map);
        if(list != null && list.size() > 0){
            result.setMsg(CouponConstant.RESULT_MSG_SUC);
            result.setCode(CouponConstant.RESULT_CODE_SUC);
            result.setData(list);
            result.setSuccess(true);
        }
        return result;
    }

    @Override
    public int updateSalesCouponStatusBatch(List<Salescoupons> list) {
        return salescouponsMapper.updateSalesCouponStatusBatch(list);
    }

    @Override
    public int updateSalesCouponBackSendBatch(List<Salescoupons> list) {
        return salescouponsMapper.updateSalesCouponBackSendBatch(list);
    }

    @Override
    public Salescoupons getSalescouponsByCouponWay(int couponWay) {
        return salescouponsMapper.getSalescouponsByCouponWay(couponWay);
    }

    @Override
    public Salescoupons getSalescouponsByCouponWay(String shopId, int couponWay) {
        Map paramMap = new HashMap();
        paramMap.put("shopId", shopId);
        paramMap.put("couponWay", couponWay);
        return salescouponsMapper.getSalescouponsByShopIdAndCouponWay(paramMap);
    }

    @Override
    public ResponseResult<List<Salescoupons>> getSalescouponsValidList() {
        ResponseResult result = new ResponseResult(false);
        SalescouponsExample salescouponsExample = new SalescouponsExample();
        salescouponsExample.createCriteria().andFromtimeLessThanOrEqualTo(new Date()).andTotimeGreaterThanOrEqualTo(new Date());
        List<Salescoupons> list =salescouponsMapper.selectByExampleWithBLOBs(salescouponsExample);
        if(list != null){
            result.setMsg(CouponConstant.RESULT_MSG_SUC);
            result.setCode(CouponConstant.RESULT_CODE_SUC);
            result.setData(list);
            result.setSuccess(true);
        }
        return result;
    }

    @Override
    public ResponseResult<List<Salescoupons>> getSalescouponsByUseScope(Map map) {
        ResponseResult result = new ResponseResult(false);
        List<Salescoupons> list = salescouponsMapper.getSalescouponsByUseScope(map);
        if(list != null && list.size() > 0){
            result.setMsg(CouponConstant.RESULT_MSG_SUC);
            result.setCode(CouponConstant.RESULT_CODE_SUC);
            result.setData(list);
            result.setSuccess(true);
        }
        return result;
    }

    @Override
    public ResponseResult updateNoticeValidCount(Long id) {
        ResponseResult result = new ResponseResult(false);
        int row = salescouponsMapper.updateNoticeValidCount(id);
        if(row == 1){
            result.setMsg(CouponConstant.RESULT_MSG_SUC);
            result.setCode(CouponConstant.RESULT_CODE_SUC);
            result.setSuccess(true);
            return result;
        }else {
            result.setMsg("更新时不成功");
            result.setCode("10");
            result.setSuccess(false);
            return result;
        }
    }

    @Override
    public ResponseResult updateNoticeInvalidCount(Long id) {
        ResponseResult result = new ResponseResult(false);
        int row = salescouponsMapper.updateNoticeInvalidCount(id);
        if(row == 1){
            result.setMsg(CouponConstant.RESULT_MSG_SUC);
            result.setCode(CouponConstant.RESULT_CODE_SUC);
            result.setSuccess(true);
            return result;
        }else {
            result.setMsg("更新时不成功");
            result.setCode("10");
            result.setSuccess(false);
            return result;
        }
    }


    @Override
    public ResponseResult<List<Salescoupons>> getSalescouponsforIds(Map map){
        ResponseResult result = new ResponseResult(false);
        List<Salescoupons> list = salescouponsMapper.getSalescouponsList(map);
        if(list != null && list.size() > 0){
            result.setMsg(CouponConstant.RESULT_MSG_SUC);
            result.setCode(CouponConstant.RESULT_CODE_SUC);
            result.setData(list);
            result.setSuccess(true);
        }
        return result;
    }

    @Override
    public PageModel2<Salescoupons> getSalescouponsForClassification(PageQuery pageQuery, Map map) {
       return new PageModel2(salescouponsMapper.getSalescouponsForClassification(pageQuery, map));
    }

    @Override
    public PageModel2<Salescoupons> getSalescouponsBySalesCouponIds(PageQuery pageQuery, Map map) {
        return new PageModel2(salescouponsMapper.getSalescouponsBySalesCouponIds(pageQuery, map));
    }

    @Override
    public List<Salescoupons> getSalescouponsBySalesCouponIdsForOneKey( Map map) {
        return salescouponsMapper.getSalescouponsBySalesCouponIdsForOneKey( map);
    }

    @Override
    public ResponseResult<Salescoupons> getSalesCouponsNumbersForId(Map map) {
        ResponseResult result = new ResponseResult(false);
        Salescoupons salescoupons = salescouponsMapper.getSalesCouponsById(map);

        if(null != salescoupons){
            result.setSuccess(true);
            result.setCode(CouponConstant.RESULT_CODE_SUC);
            result.setMsg(CouponConstant.RESULT_MSG_SUC);
            result.setData(salescoupons);
        }else {
            result.setSuccess(false);
            result.setCode(CouponConstant.RESULT_CODE_FAIL);
            result.setMsg(CouponConstant.RESULT_MSG_FAIL);
            result.setData(null);
        }
        return result;
    }

    @Override
    public int getSalesCouponsMaxNumber(Long id) {
        return salescouponsMapper.getSalesCouponsMaxNumber(id);
    }

    @Override
    public List<Salescoupons> getAllEffectiveC2CCoupons(String shopId, String terminal) {
        Map paramMap = new HashMap();
        paramMap.put("shopid", shopId);
        paramMap.put("terminal", terminal);
        paramMap.put("usescope", CouponConstant.COUPON_USESCOPE_C2C);
        return salescouponsMapper.getSalescouponsByUseScope(paramMap);
    }

    @Override
    public PageModel2<Salescoupons> getAvailableSalescouponsInfoPage(PageQuery pageQuery, Map map) {
        return new PageModel2<Salescoupons>(salescouponsMapper.getAvailableSalescouponsInfoPage(pageQuery, map));
    }

    @Override
    public PageModel2<Salescoupons> getAllAvailableSalescouponsInfoPage(PageQuery pageQuery, Map map) {
        return new PageModel2<Salescoupons>(salescouponsMapper.getAllAvailableSalescouponsInfoPage(pageQuery, map));
    }

    @Override
    public PageModel2<Salescoupons> getDistributeSalescoupons(PageQuery pageQuery) {
    	Map<String,String> map = new HashMap<String, String>(1);
		map.put("displayPosition", "0");//默认个人中心的领券
        return new PageModel2<Salescoupons>(salescouponsMapper.getDistributeSalescouponsInfoPage(pageQuery,map));
    }

	@Override
	public PageModel2<Salescoupons> getDistributeSalescoupons(Integer shopId,PageQuery pageQuery, Integer displayPosition) {
		Map<String,String> map = new HashMap<String, String>(1);
		map.put("displayPosition", String.valueOf(displayPosition));
        map.put("shopId",String.valueOf(shopId));
		 return new PageModel2<Salescoupons>(salescouponsMapper.getDistributeSalescouponsInfoPage(pageQuery,map));
	}

    @Override
    public PageModel2<Salescoupons> getOnekeySalecoupons(PageQuery pageQuery, Map map) {
        return new PageModel2<Salescoupons>(pageQuery,salescouponsMapper.getOnekeySalecoupons(pageQuery,map));
    }
}
