package com.lenovo.m2.couponV2.manager.impl;

import com.lenovo.m2.couponV2.common.CouponConstant;
import com.lenovo.m2.couponV2.common.exception.ExceptionUtil;
import com.lenovo.m2.couponV2.dao.mybatis.mapper.UsercouponrelMapper;
import com.lenovo.m2.couponV2.dao.mybatis.model.Usercouponrel;
import com.lenovo.m2.couponV2.dao.mybatis.model.UsercouponrelExample;
import com.lenovo.m2.couponV2.dao.util.ResponseResult;
import com.lenovo.m2.couponV2.manager.UsercouponrelManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * Created by zhaocl1 on 2015/9/15.
 */
@Component("usercouponrelManager")
public class UsercouponrelManagerImpl implements UsercouponrelManager {
    private static final Logger LOGGER = LoggerFactory.getLogger(UsercouponrelManagerImpl.class);
    @Autowired
    private UsercouponrelMapper usercouponrelMapper;

    @Override
    public ResponseResult insertBatch(List<Usercouponrel> list) {
        ResponseResult result = new ResponseResult(false);
        try {
            if (list != null && list.size() > 0) {
                int row = usercouponrelMapper.insertBatch(list);
                if (row == list.size()) {
                    result.setMsg(CouponConstant.RESULT_MSG_SUC);
                    result.setCode(CouponConstant.RESULT_CODE_SUC);
                    result.setSuccess(true);
                } else {
                    result.setMsg(CouponConstant.RESULT_MSG_FAIL);
                    result.setCode(CouponConstant.RESULT_CODE_FAIL);
                }
            } else {
                result.setMsg(CouponConstant.RESULT_MSG_ERROR_PARAM);
                result.setCode(CouponConstant.RESULT_CODE_ERROR_PARAM);
            }
        }catch (Exception e){
            LOGGER.error(ExceptionUtil.getStackTrace(e));
        }
        return  result;
    }

    @Override
    public ResponseResult<List<Usercouponrel>> getUsercouponrelByCondition(Usercouponrel usercouponrel) {
        ResponseResult<List<Usercouponrel>> result = new ResponseResult(false);
        UsercouponrelExample example = new UsercouponrelExample();
        UsercouponrelExample.Criteria criteria = example.createCriteria();
        criteria.andUsergroupcouponrelidEqualTo(usercouponrel.getUsergroupcouponrelid());
        criteria.andLenovoidEqualTo(usercouponrel.getLenovoid());
        List<Usercouponrel> list = usercouponrelMapper.selectByExample(example);
        result.setMsg(CouponConstant.RESULT_MSG_SUC);
        result.setCode(CouponConstant.RESULT_CODE_SUC);
        result.setData(list);
        result.setSuccess(true);
        return  result;
    }
}
