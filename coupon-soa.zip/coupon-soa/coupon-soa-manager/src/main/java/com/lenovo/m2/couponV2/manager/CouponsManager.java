package com.lenovo.m2.couponV2.manager;

import com.lenovo.m2.arch.framework.domain.PageModel2;
import com.lenovo.m2.arch.framework.domain.PageQuery;
import com.lenovo.m2.couponV2.dao.mybatis.model.Coupons;
import com.lenovo.m2.couponV2.dao.util.ResponseResult;

import java.util.List;
import java.util.Map;

/**
 * Created by zhaocl1 on 2016/3/5.
 */
public interface CouponsManager {

    /**
     * 根据优惠码查询
     * @param code
     * @return
     */
    ResponseResult getCouponsByCode(String code);

    /**
     * 根据优惠码查询
     * @param shopId
     * @param code
     * @return
     */
    ResponseResult getCouponsByCode(String shopId, String code);

    /**
     * 根据优惠码主键id查询优惠码
     * @param id
     * @return
     */
    ResponseResult getCouponsById(long id);

    /**
     * 返还优惠码 即使用次数减1
     * @param map
     * @return
     */
    ResponseResult updateCouponsReduce(Map map);

    /**
     * 使用优惠码，即使用次数加1
     * @param map
     * @return
     */
    ResponseResult updateCouponsPlus(Map map);

    /**
     * 分页查询
     * @param pageQuery
     * @param map
     * @return
     */

    public PageModel2<Coupons> getCouponsInfoPage(PageQuery pageQuery,Map map);
    /**
     * 批量插入
     * @return
     */
    ResponseResult<Integer> insertBatch(List<Coupons> list);

    /**
     * 查询该批次的优惠码
     * @param salescouponid
     * @return
     */
    ResponseResult getCouponsBySalescouponsId(long salescouponid);

    /**
     *批量删除优惠码
     * @param salescouponid
     * @return
     */
    ResponseResult deleteCouponsBySalescouponsId(long salescouponid);

    /**
     * 根据优惠码批次信息的主键批量更新优惠码属性
     * @param coupons
     * @return
     */
    ResponseResult updateCouponsBySalescouponsId(Coupons coupons);

    /**
     * status 0正常状态，1禁用状态
     * @param coupons
     * @return
     */
    ResponseResult updateCouponsStatus(Coupons coupons);

    /**
     * 查询某批次的优惠码的数量
     * @param salescouponid
     * @return
     */
    int getCouponsCountBySalescouponId(long salescouponid);

    /**
     *  查询该批次追加的优惠码
     * @param salescouponid
     * @param batchNo
     * @return
     */
    ResponseResult getCouponsBySalescouponsIdAndBatchNO(long salescouponid, String batchNo);




    /**
     * 获取真实的Macode
     * @param id
     * @param itCode
     * @return
     */
    public ResponseResult<List<Coupons>> getTrueMacode(Long id, String itCode);



}
