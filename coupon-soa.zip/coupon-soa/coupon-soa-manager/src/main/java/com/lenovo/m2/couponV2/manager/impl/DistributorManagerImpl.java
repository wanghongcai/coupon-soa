package com.lenovo.m2.couponV2.manager.impl;

import com.lenovo.m2.couponV2.common.CouponConstant;
import com.lenovo.m2.couponV2.common.exception.ExceptionUtil;
import com.lenovo.m2.couponV2.dao.mybatis.mapper.DistributorruleLogMapper;
import com.lenovo.m2.couponV2.dao.mybatis.mapper.DistributorruleMapper;
import com.lenovo.m2.couponV2.dao.mybatis.model.*;
import com.lenovo.m2.couponV2.dao.util.ResponseResult;
import com.lenovo.m2.couponV2.manager.DistributorruleManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

/**
 * Created by pxg01 on 2017/4/20.
 */
@Service
public class DistributorManagerImpl implements DistributorruleManager {
    private static final Logger log = LoggerFactory.getLogger(DistributorManagerImpl.class);

    @Autowired
    private DistributorruleMapper distributorruleMapper;
    @Autowired
    private DistributorruleLogMapper distributorruleLogMapper;

    @Override
    public ResponseResult insertBatchDistributorrule(List<Distributorrule> distributorruleList) {
        ResponseResult result = new ResponseResult(false);
        if(distributorruleList != null ){
            if(distributorruleList.size() > 0){
                int row = distributorruleMapper.insertBatchDistributorrule(distributorruleList);
                if(row == distributorruleList.size()){
                    result.setMsg(CouponConstant.RESULT_MSG_SUC);
                    result.setCode(CouponConstant.RESULT_CODE_SUC);
                    result.setSuccess(true);
                }else {
                    result.setMsg(CouponConstant.RESULT_MSG_FAIL);
                    result.setCode(CouponConstant.RESULT_CODE_FAIL);
                }
            }else {
                result.setMsg(CouponConstant.RESULT_MSG_ERROR_PARAM);
                result.setCode(CouponConstant.RESULT_CODE_ERROR_PARAM);
            }
        }else {
            result.setMsg(CouponConstant.RESULT_MSG_ERROR_PARAM);
            result.setCode(CouponConstant.RESULT_CODE_ERROR_PARAM);
        }
        return result;
    }

    @Override
    public ResponseResult delDistributorrule(Distributorrule distributorrule) {
        ResponseResult result = new ResponseResult(false);
        if(distributorrule!=null){
            DistributorruleExample distributorruleExample = new DistributorruleExample();
            distributorruleExample.createCriteria().andSalescouponidEqualTo(distributorrule.getSalescouponid());
            int row = distributorruleMapper.deleteByExample(distributorruleExample);
            if(row>0){
                //注意：有些垃圾数据是分类券但是没有分类，删除的时候row=0
                result.setMsg(CouponConstant.RESULT_MSG_SUC);
                result.setCode(CouponConstant.RESULT_CODE_SUC);
                result.setSuccess(true);
            }
        }else {
            result.setMsg(CouponConstant.RESULT_MSG_ERROR_PARAM);
            result.setCode(CouponConstant.RESULT_CODE_ERROR_PARAM);
        }
        return result;
    }

    @Override
    public ResponseResult saveDistributorruleLog(List<DistributorruleLog> distributorruleLogList) {
        ResponseResult responseResult = new ResponseResult(false);
        try {
            int res = distributorruleLogMapper.insertDistributorruleLog(distributorruleLogList);
            if(res > 0) {
                responseResult.setSuccess(true);
                responseResult.setCode(CouponConstant.RESULT_CODE_SUC);
                responseResult.setMsg(CouponConstant.RESULT_MSG_SUC);
            }else {
                responseResult.setCode(CouponConstant.RESULT_CODE_FAIL);
                responseResult.setCode(CouponConstant.RESULT_MSG_FAIL);
            }
        } catch (Exception e) {
            log.error("Save distributorruleLog catch exception, " + ExceptionUtil.getStackTrace(e));
            responseResult.setCode(CouponConstant.RESULT_CODE_ERROR);
            responseResult.setCode(CouponConstant.RESULT_MSG_ERROR);
        }
        return responseResult;
    }

    @Override
    public ResponseResult<List<Distributorrule>> getBatchBySalescouponids(Map map) {
        ResponseResult result = new ResponseResult(false);
        try {
            if(map == null ){
                result.setCode(CouponConstant.RESULT_CODE_ERROR_PARAM);
                result.setMsg(CouponConstant.RESULT_MSG_ERROR_PARAM);
                return result;
            }

            List<Distributorrule> list = distributorruleMapper.getBatchBySalescouponids(map);
            if(list != null && list.size()>0){
                result.setData(list);
                result.setSuccess(true);
                return result;
            }else {
                log.info("没有找到数据记录 主键IDs: " + map.get("ids"));
                result.setMsg("通过主键s未找到用户优惠券！");
                return result;
            }

        } catch (Exception e) {
            log.error("数据库操作失败" + ExceptionUtil.getStackTrace(e));
            result.setMsg("数据库操作失败");
            return result;
        }
    }

    @Override
    public ResponseResult<List<Distributorrule>> getDistributorruleList(Distributorrule detailsrule) {
        ResponseResult result = new ResponseResult(false);
        if(detailsrule!=null){
            DistributorruleExample distributorruleExample = new DistributorruleExample();
            distributorruleExample.createCriteria().andSalescouponidEqualTo(detailsrule.getSalescouponid());
            List<Distributorrule> list = distributorruleMapper.selectByExampleWithBLOBs(distributorruleExample);
            if(list != null && list.size()>0){
                result.setMsg(CouponConstant.RESULT_MSG_SUC);
                result.setCode(CouponConstant.RESULT_CODE_SUC);
                result.setData(list);
                result.setSuccess(true);
            }
        }else {
            result.setMsg(CouponConstant.RESULT_MSG_ERROR_PARAM);
            result.setCode(CouponConstant.RESULT_CODE_ERROR_PARAM);
        }
        return result;
    }

    @Override
    public ResponseResult<List<Distributorrule>> getDistributorruleListGroupBy(Distributorrule detailsrule) {
        ResponseResult result = new ResponseResult(false);
        if(detailsrule!=null){
            DistributorruleExample distributorruleExample = new DistributorruleExample();
            distributorruleExample.createCriteria().andSalescouponidEqualTo(detailsrule.getSalescouponid());
            List<Distributorrule> list = distributorruleMapper.selectByExampleWithBLOBsGroupBy(distributorruleExample);
            if(list != null && list.size()>0){
                result.setMsg(CouponConstant.RESULT_MSG_SUC);
                result.setCode(CouponConstant.RESULT_CODE_SUC);
                result.setData(list);
                result.setSuccess(true);
            }
        }else {
            result.setMsg(CouponConstant.RESULT_MSG_ERROR_PARAM);
            result.setCode(CouponConstant.RESULT_CODE_ERROR_PARAM);
        }
        return result;
    }
}
