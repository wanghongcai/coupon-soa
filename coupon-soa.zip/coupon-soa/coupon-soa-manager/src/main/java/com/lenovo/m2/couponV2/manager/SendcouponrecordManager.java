package com.lenovo.m2.couponV2.manager;

import com.lenovo.m2.couponV2.dao.mybatis.model.Sendcouponrecord;
import com.lenovo.m2.couponV2.dao.util.ResponseResult;

import java.util.Map;

/**
 * Created by zhaocl1 on 2016/3/28.
 */
public interface SendcouponrecordManager {

    /**
     * save
     * @param record
     * @return
     */
    int insertSelective(Sendcouponrecord record);

    /**
     * 根据orderId 、status查询用户是否发过券
     * @param orderId
     * @param status
     * @return
     */
    public ResponseResult getSendCouponRecordByorderid(String orderId, int status);
}
