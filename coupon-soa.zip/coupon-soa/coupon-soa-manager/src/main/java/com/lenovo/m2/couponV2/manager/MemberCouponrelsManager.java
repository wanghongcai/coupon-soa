package com.lenovo.m2.couponV2.manager;

import com.lenovo.m2.arch.framework.domain.PageModel2;
import com.lenovo.m2.arch.framework.domain.PageQuery;
import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.couponV2.api.model.MembercouponrelsApi;
import com.lenovo.m2.couponV2.dao.mybatis.mapper.MembercouponrelsMapper;
import com.lenovo.m2.couponV2.dao.mybatis.model.Membercouponrels;
import com.lenovo.m2.couponV2.dao.util.ResponseResult;

import java.text.ParseException;
import java.util.List;
import java.util.Map;

/**
 * Created by yezhenyue on 2016/1/19.
 */
public interface MemberCouponrelsManager {
    /**
     * 分页查询用户优惠券列表
     *
     * @param pageQuery
     * @param map
     * @return
     */
    public PageModel2<Membercouponrels> getMemberCouponrelsPage(PageQuery pageQuery, Map map) throws ParseException;

    /**
     * 分页查询用户优惠券列表
     *
     * @param pageQuery
     * @param map
     * @return
     */
    public PageModel2<Membercouponrels> getMemberCouponrelsInfoPage(PageQuery pageQuery, Map map) throws ParseException;


    /**
     * 根据主键id禁用用户优惠券
     *
     * @param id
     * @return
     */
    RemoteResult<Boolean> disableMemberCouponById(long id);

    RemoteResult<Membercouponrels> queryMemberCouponById(long id);

    /**
     * 获取用户指定商城、终端上的有效的券
     *
     * @param lenovoId
     * @param shopId
     * @param terminal
     * @return
     */
    ResponseResult<List<Membercouponrels>> getMemberEffectiveCoupons(String lenovoId, String shopId, String terminal);

    /**
     * 获取用户指定商城和终端上的所有有效优惠券（包括未使用和已使用），已过期的除外
     *
     * @param lenovoId
     * @param shopId
     * @param terminal
     * @return
     */
    ResponseResult<List<Membercouponrels>> getMemberAllEffectiveCoupons(String lenovoId, String shopId, String terminal);

    /**
     * 通过主键批量查询
     *
     * @param map
     * @return
     */
    ResponseResult<List<Membercouponrels>> getMembercouponrelsListByIds(Map map);


    /**
     * 使用优惠券
     *
     * @param map
     * @return
     */
    ResponseResult updateMembercouponrelsUsed(Map map);

    /**
     * 返还优惠券
     *
     * @param map
     * @return
     */
    ResponseResult updateMembercouponrelsReturn(Map map);

    /* * 批量插入
     * @return
     */
    public RemoteResult<Boolean> insertBatchByOneMember(List<Membercouponrels> list);

    RemoteResult<Boolean> insertBatch(List<Membercouponrels> list);

    /**
     * 绑券
     *
     * @param membercouponrels
     * @return
     */
    ResponseResult insertSelective(Membercouponrels membercouponrels);

    /**
     * 查询用户在某个商城的某个类型的有效的券
     *
     * @param lenovoId
     * @param shopId
     * @param usescope
     * @return
     */
    ResponseResult<List<Membercouponrels>> getMembercouponrelsByShopidAndUsescope(String lenovoId, String shopId, String usescope);

    /**
     * 查询用户名下是否有有效的C2C券
     *
     * @param lenovoId
     * @param shopId
     * @return
     */
    ResponseResult<List<Membercouponrels>> getC2CMembercouponrelsByShopid(String lenovoId, String shopId);

    /**
     * 根据状态查询数量
     *
     * @param map
     * @return
     */
    int getMembercouponrelsCount(Map map);

    /**
     * 查询该用户是否有这张券
     *
     * @param lenovoId
     * @param salescouonId
     * @return
     */
    ResponseResult getMembercouponrelsByLenovoIdandSalescouponId(String lenovoId, long salescouonId);

    ResponseResult getMembercouponrelsByLenovoIdandSalescouponIdandshopId(String shopid, String lenovoId, long salescouonId);


    /**
     * save
     *
     * @param list
     * @return
     */
    public ResponseResult insertBatchMembercouponrels(List<Membercouponrels> list);

    public ResponseResult updateBatchMembercouponrels(List<Membercouponrels> list);

    /**
     * 查看用户是否拥有该优惠券
     *
     * @param map
     * @return
     */
    ResponseResult<List<Membercouponrels>> getUserIshaveTheCoupon(Map map);

    /**
     * 获取优惠券已领取数量
     *
     * @param map
     * @return
     */
    int getIsHaveSalesCouponsNum(Map map);

    /**
     * 获取用户优惠券使用状态
     *
     * @param map
     * @return
     */
    ResponseResult<List<Membercouponrels>> getMemberCouponsStatus(Map map);

    /**
     * 根据LenovoId和salesCouponId查询该用户名下可用的优惠券
     *
     * @param lenovoId
     * @param salesCouponId
     * @return
     */
    ResponseResult getMemberCoupons(String lenovoId, Long salesCouponId);

    ResponseResult updateMembercouponrels(Long id, int status);

    ResponseResult<List<Membercouponrels>> getMemberCouponRelBySalesCouponId(Long salesCouponId);


    /********************************************分库分表***********************************************************/
    RemoteResult<PageModel2<String>> getlenovoIdsByDistinct(PageQuery pageQuery);

    RemoteResult<List<Membercouponrels>> getmemberCouponsByLenovoId(String lenovoId);

    public RemoteResult<Boolean> disableMemberCouponById(long id, String lenovoId);

    /* * 批量插入
     * @return
     */
    RemoteResult<Boolean> insertBatchSharding(MembercouponrelsMapper mapper, List<Membercouponrels> list, String tableName);

    public RemoteResult getMemberCouponrelsConditions(MembercouponrelsMapper membercouponrelsMapper, Map map, String tableName);

    /**
     * 分页查询用户优惠券列表
     *
     * @param pageQuery
     * @param map
     * @return
     */
    public PageModel2<Membercouponrels> getMemberCouponrelsInfoPageSharding(MembercouponrelsMapper mapper, String tableName, PageQuery pageQuery, Map map) throws ParseException;

    /**
     * 根据状态查询数量
     *
     * @param map
     * @return
     */
    int getMembercouponrelsCountSharding(MembercouponrelsMapper mapper, String tableName, Map map);

    public ResponseResult<List<Membercouponrels>> getMemberEffectiveCouponsSharding(MembercouponrelsMapper mapper, String lenovoId, String shopId, String terminal, String tableName);

    /**
     * 通过主键批量查询
     *
     * @param map
     * @return
     */
    ResponseResult<List<Membercouponrels>> getMembercouponrelsListByIdsSharding(MembercouponrelsMapper mapper, Map map, String tableName);

    /**
     * 使用优惠券
     *
     * @param map
     * @return
     */
    ResponseResult updateMembercouponrelsUsedSharding(MembercouponrelsMapper mapper, String tableName, Map map);

    /**
     * 返还优惠券
     *
     * @param map
     * @return
     */
    ResponseResult updateMembercouponrelsReturn(MembercouponrelsMapper mapper, String tableName, Map map);

    /**
     * 查看用户是否拥有该优惠券
     *
     * @param map
     * @return
     */
    ResponseResult<List<Membercouponrels>> getUserIshaveTheCouponSharding(MembercouponrelsMapper mapper, String tableName, Map map);

    /**
     * 获取用户指定商城和终端上的所有有效优惠券（包括未使用和已使用），已过期的除外
     *
     * @param lenovoId
     * @param shopId
     * @param terminal
     * @return
     */
    ResponseResult<List<Membercouponrels>> getMemberAllEffectiveCouponsSharding(MembercouponrelsMapper mapper, String tableName, String lenovoId, String shopId, String terminal);

    public ResponseResult insertBatchMembercouponrelsSharding(List<Membercouponrels> list);
}
