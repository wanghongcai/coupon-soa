package com.lenovo.m2.couponV2.manager.impl;

import com.lenovo.m2.arch.framework.domain.PageModel2;
import com.lenovo.m2.arch.framework.domain.PageQuery;
import com.lenovo.m2.couponV2.dao.mybatis.mapper.OneKeyToReceiveMapper;
import com.lenovo.m2.couponV2.dao.mybatis.model.OneKeyToReceive;
import com.lenovo.m2.couponV2.manager.OneKeyToReceiveManager;
import org.apache.ibatis.annotations.Param;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

/**
 * Created by pxg01 on 2017/7/4.
 */
@Service

public class OneKeyToReceiveManagerImpl implements OneKeyToReceiveManager {
    private static Logger logger = LoggerFactory.getLogger(OneKeyToReceiveManagerImpl.class);

    @Autowired
    private OneKeyToReceiveMapper oneKeyToReceiveMapper;
    @Override
    public OneKeyToReceive getActivityName(String activityName) {
        return oneKeyToReceiveMapper.getActivityName(activityName);
    }


    @Override
    public int editReceiveActivity(OneKeyToReceive oneKeyToReceive) {
        return oneKeyToReceiveMapper.editReceiveActivity(oneKeyToReceive);
    }

    public int addReceiveActivity(OneKeyToReceive oneKeyToReceive){
        return oneKeyToReceiveMapper.addReceiveActivity(oneKeyToReceive);
    }

    @Override
    public int deleteReceiveActivity(Map map) {
        return oneKeyToReceiveMapper.deleteReceiveActivity(map);
    }

    @Override
    public PageModel2<OneKeyToReceive> getReceiveActivity(PageQuery pageQuery, Map map) {
        return new PageModel2<OneKeyToReceive>(pageQuery,oneKeyToReceiveMapper.getReceiveActivity(pageQuery,map));
    }
    @Override
    public PageModel2<OneKeyToReceive> getReceiveActivityByCondityon(PageQuery pageQuery, Map map) {
        return new PageModel2<OneKeyToReceive>(pageQuery,oneKeyToReceiveMapper.getReceiveActivityByCondityon(pageQuery,map));
    }
    @Override
    public String confirmUserIfJoinTheAcitity(String lenovoId, Integer activityType,String activityName) {
        return oneKeyToReceiveMapper.confirmUserIfJoinTheAcitity(lenovoId,activityType,activityName);
    }

    @Override
    public int saveOnekeygetinfo(Map map) {
        return oneKeyToReceiveMapper.saveOnekeygetinfo(map);
    }

    @Override
    public OneKeyToReceive getActivityInfoById(Long id) {
        return oneKeyToReceiveMapper.getActivityInfoById(id);
    }

    @Override
    public int setOnekeyUseable(Long id, Integer useable,String itcode) {
        return oneKeyToReceiveMapper.setOnekeyUseable(id,useable,itcode);
    }
    @Override
    public  List<OneKeyToReceive> getReceiveActivityForBinds(Map map){
        return oneKeyToReceiveMapper.getReceiveActivityForBinds(map);
    };
    @Override
    public  Integer selectAnyActivityIsHolding(){
        return oneKeyToReceiveMapper.selectAnyActivityIsHolding();
    };

}
