package com.lenovo.m2.couponV2.manager;

import com.lenovo.m2.couponV2.dao.mybatis.model.Detailsrule;
import com.lenovo.m2.couponV2.dao.util.ResponseResult;

import java.util.List;
import java.util.Map;

/**
 * Created by zhaocl1 on 2016/2/15.
 */
public interface DetailsruleManager {
    /**
     * 批量保存优惠券分类数据
     * @param detailsruleList
     * @return
     */
    public ResponseResult insertBatchDetailsrule(List<Detailsrule> detailsruleList);

    /**
     * 通过优惠券id批量删除该券对应的分类
     * @param detailsrule
     * @return
     */
    public ResponseResult delDetailsrule(Detailsrule detailsrule);

    /**
     * 通过优惠券id查看该券下面的分类列表
     * @param detailsrule
     * @return
     */
    public ResponseResult<List<Detailsrule>> getDetailsruleList(Detailsrule detailsrule);

    /**
     * 通过优惠券主键id批量获取数据
     * @param map
     * @return
     */
    public ResponseResult<List<Detailsrule>> getBatchBySalescouponids(Map map);


    /**
     * 根据优惠券Id,分类号获取排除的商品Code
     * @param map
     * @return
     */
    public ResponseResult<List<Detailsrule>> getBatchByCategorycodeId(Map map);
}
