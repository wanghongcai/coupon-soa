package com.lenovo.m2.couponV2.manager.impl;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.tool.util.CollectionUtils;
import com.lenovo.m2.couponV2.common.CouponConstant;
import com.lenovo.m2.couponV2.dao.mybatis.mapper.AvailableSalescouponsMapper;
import com.lenovo.m2.couponV2.dao.mybatis.model.AvailableSalescoupons;
import com.lenovo.m2.couponV2.dao.util.ResponseResult;
import com.lenovo.m2.couponV2.manager.AvailableSalescouponsManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * Created by fenglg1 on 2016/12/15.
 */
@Component("availableSalescouponsManager")
public class AvailableSalescouponsManagerImpl implements AvailableSalescouponsManager {

    @Autowired
    private AvailableSalescouponsMapper availableSalescouponsMapper;

    @Override
    public ResponseResult<List<AvailableSalescoupons>> getAllSelectedAvailableSalescoupons() {
        ResponseResult<List<AvailableSalescoupons>> result = new ResponseResult<List<AvailableSalescoupons>>(false);
        List<AvailableSalescoupons> couponList =  availableSalescouponsMapper.getAllAvailableSalescoupons();
        if(CollectionUtils.isNotEmpty(couponList)){
            result.setSuccess(true);
            result.setCode(CouponConstant.RESULT_CODE_SUC);
            result.setMsg(CouponConstant.RESULT_MSG_SUC);
            result.setData(couponList);
        }else{
            result.setCode(CouponConstant.RESULT_CODE_FAIL);
            result.setMsg(CouponConstant.RESULT_MSG_FAIL);
        }
        return result;
    }

    @Override
    public ResponseResult<List<AvailableSalescoupons>> getAvailableSalescouponsByCouponId(Long salesCouponsId) {
        ResponseResult<List<AvailableSalescoupons>> result = new ResponseResult<List<AvailableSalescoupons>>(false);
        List<AvailableSalescoupons> availableSalescoupons = availableSalescouponsMapper.getAvailableSalescouponsByCouponId(salesCouponsId);
        if (availableSalescoupons != null && availableSalescoupons.size() >0){
            result.setSuccess(true);
            result.setCode(CouponConstant.RESULT_CODE_SUC);
            result.setMsg(CouponConstant.RESULT_MSG_SUC);
            result.setData(availableSalescoupons);
        }else {
            result.setCode(CouponConstant.RESULT_CODE_FAIL);
            result.setMsg(CouponConstant.RESULT_MSG_FAIL);
        }
        return result;
    }

    /*
     * (非 Javadoc)
    * <p>Title: saveAvailableSalescoupons</p>
    * <p>Description: </p>
    * @param availableSalescouponsList
    * @param displayPosition
    * @return
    * @see com.lenovo.m2.couponV2.manager.AvailableSalescouponsManager#saveAvailableSalescoupons(java.util.List, int)
     */
    @Override
    public ResponseResult saveAvailableSalescoupons(List<AvailableSalescoupons> availableSalescouponsList) {
        ResponseResult result = new ResponseResult(false);
        if(CollectionUtils.isEmpty(availableSalescouponsList)){
            result.setCode(CouponConstant.RESULT_CODE_FAIL);
            result.setMsg(CouponConstant.RESULT_MSG_FAIL);
            return result;
        }
        int saveNum = availableSalescouponsMapper.saveAvailableSalescoupons(availableSalescouponsList);
        if(saveNum > 0 && saveNum == availableSalescouponsList.size()){
            result.setSuccess(true);
            result.setCode(CouponConstant.RESULT_CODE_SUC);
            result.setMsg(CouponConstant.RESULT_MSG_SUC);
        }else {
            result.setCode(CouponConstant.RESULT_CODE_FAIL);
            result.setMsg(CouponConstant.RESULT_MSG_FAIL);
        }
        return result;
    }

    @Override
    public ResponseResult deleteAvailableSalescoupons(Long salesCouponsId, String displayPosition) {
        ResponseResult result = new ResponseResult(false);
        int delNum = availableSalescouponsMapper.deleteAvailableSalescoupons(salesCouponsId,displayPosition);
        if(delNum == 1){
            result.setSuccess(true);
            result.setCode(CouponConstant.RESULT_CODE_SUC);
            result.setMsg(CouponConstant.RESULT_MSG_SUC);
        }else {
            result.setCode(CouponConstant.RESULT_CODE_FAIL);
            result.setMsg(CouponConstant.RESULT_MSG_FAIL);
        }
        return result;
    }

    @Override
    public ResponseResult deleteAllSelectedAvailableSalescoupons() {
        ResponseResult result = new ResponseResult(false);
        int delNum =  availableSalescouponsMapper.deleteAllAvailableSalescoupons();
        if(delNum > 0){
            result.setSuccess(true);
            result.setCode(CouponConstant.RESULT_CODE_SUC);
            result.setMsg(CouponConstant.RESULT_MSG_SUC);
        }else {
            result.setCode(CouponConstant.RESULT_CODE_FAIL);
            result.setMsg(CouponConstant.RESULT_MSG_FAIL);
        }
        return result;
    }
}
