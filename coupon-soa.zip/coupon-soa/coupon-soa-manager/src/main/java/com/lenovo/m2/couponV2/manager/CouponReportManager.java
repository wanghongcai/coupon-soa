package com.lenovo.m2.couponV2.manager;

import com.lenovo.m2.arch.framework.domain.PageModel2;
import com.lenovo.m2.arch.framework.domain.PageQuery;
import com.lenovo.m2.couponV2.dao.mybatis.model.CouponReport;

import java.util.List;
import java.util.Map;

/**
 * Created by fenglg1 on 2017/1/9.
 */
public interface CouponReportManager {

    /**
     * 根据条件查询优惠券领取及使用数据
     * @param pageQuery
     * @param map
     * @return
     */
    public PageModel2<CouponReport> getCouponReportInfoPage(PageQuery pageQuery, Map map);

    /**
     * 根据优惠券ID查询优惠券及订单号
     * @param pageQuery
     * @param map
     * @return
     */
    public PageModel2<CouponReport> getCouponAndOrderInfoPage(PageQuery pageQuery, Map map);

    public PageModel2<CouponReport> exportMemberCouponOrderIdByMemberCoupon(PageQuery pageQuery, List list);
}
