package com.lenovo.m2.couponV2.manager;

import com.lenovo.m2.couponV2.dao.mybatis.model.Productrule;
import com.lenovo.m2.couponV2.dao.util.ResponseResult;

import java.util.List;
import java.util.Map;

/**
 * Created by zhaocl1 on 2016/2/15.
 */
public interface ProductruleManager {

    /**
     * 保存优惠券关联商品数据
     * @param productrule
     * @return
     */
    public ResponseResult insertProductrule(Productrule productrule);

    /**
     * 通过优惠券id批量删除该券对应的商品数据
     * @param productrule
     * @return
     */
    public ResponseResult delProductrule(Productrule productrule);

    /**
     * 通过优惠券id查看该券下面的商品
     * @param productrule
     * @return
     */
    public ResponseResult<List<Productrule>> getProductruleList(Productrule productrule);

    /**
     * 通过优惠券主键id批量获取数据
     * @param map
     * @return
     */
    public ResponseResult<List<Productrule>> getBatchBySalescouponids(Map map);
}
