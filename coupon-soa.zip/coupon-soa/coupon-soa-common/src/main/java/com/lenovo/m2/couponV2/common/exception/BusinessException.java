package com.lenovo.m2.couponV2.common.exception;

/**
 * Created by zhaocl1 on 2016/3/25.
 */
public class BusinessException extends RuntimeException {

    private static final long serialVersionUID = 876346050473618607L;
    private int errno;

    public BusinessException(int errno,String errmsg){
        super(errmsg);
        this.errno = errno;
    }

    public int getErrno(){
        return errno;
    }
}
