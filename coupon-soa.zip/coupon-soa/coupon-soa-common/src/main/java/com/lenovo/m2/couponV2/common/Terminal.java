package com.lenovo.m2.couponV2.common;


public enum Terminal {
	
	
	PC(1, "PC"),
	WAP(2, "WAP"),
	APP(3, "APP"),
	WECHAT(4, "微信");
	
	private final int type;
	private final String descr;
	
	private Terminal(int type, String descr){
		this.type = type;
		this.descr = descr;
		
	}

	public int getType() {
		return type;
	}

	public String getDescr() {
		return descr;
	} 

	public static void main(String[] args) {
        System.out.println(Terminal.values());
        System.out.println(Terminal.PC.getType());
        System.out.println(Terminal.PC.getDescr());
	}

	public static Terminal getTerminalByPlat(int plat){
		if(1==plat || 5==plat || 20==plat){
			return Terminal.WAP;
		}
		if(2==plat || 6==plat ){
			return Terminal.WECHAT;
		}
		if(3==plat || 7==plat || 30 ==plat ){
			return Terminal.APP;
		}
		if(4==plat || 8==plat || 22==plat){
			return Terminal.PC;
		}
		return null;
	}

}
