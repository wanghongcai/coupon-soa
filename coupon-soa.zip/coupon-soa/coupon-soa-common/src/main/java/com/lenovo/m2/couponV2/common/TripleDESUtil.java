package com.lenovo.m2.couponV2.common;

import com.lenovo.m2.couponV2.common.exception.ExceptionUtil;
import org.apache.commons.codec.digest.DigestUtils;
import org.springframework.util.StringUtils;
import sun.misc.BASE64Decoder;
import sun.misc.BASE64Encoder;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;

/**
 * Created by fenglg1 on 2016/8/16.
 */
public class TripleDESUtil {
    /**
     * 定义加密算法， 可用 DES、DESede、Blowfish
     */
    private static final String Algorithm = "DESede";
    private static final String KeyWords = "des3KeyWords";

    public static String encryptMode(String src){
        byte[] enk = hex(KeyWords);
        byte[] result = encryptMode(enk, src.getBytes());
        BASE64Encoder base64Encoder = new BASE64Encoder();
        return base64Encoder.encode(result);
    }



    public static String decryptMode(String cipher){
        byte[] enk = hex(KeyWords);
        byte[] result = new byte[0];
        try {
            BASE64Decoder base64Decoder = new BASE64Decoder();
            result = decryptMode(enk, base64Decoder.decodeBuffer(cipher));
        } catch (Exception e) {
            System.out.println("解密出错，" + ExceptionUtil.getStackTrace(e));
        }
        return new String(result);
    }

    /**
     * 加密数据
     * @param keyByte  加密密钥，长度为24字节
     * @param src  被加密的数据缓冲区（源）
     * @return
     */
    private static byte[] encryptMode(byte[] keyByte, byte[] src){
        try {
            // 生成密钥
            SecretKey desKey = new SecretKeySpec(keyByte, Algorithm);
            Cipher cipher = Cipher.getInstance(Algorithm);
            cipher.init(Cipher.ENCRYPT_MODE, desKey);
            return cipher.doFinal(src);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    private static byte[] decryptMode(byte[] keyByte, byte[] src){
        try {
            SecretKey desKey = new SecretKeySpec(keyByte, Algorithm);
            Cipher cipher = Cipher.getInstance(Algorithm);
            cipher.init(Cipher.DECRYPT_MODE, desKey);
            return cipher.doFinal(src);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public static byte[] hex(String pw){
        String key = "Triple_DES";//关键字
        String f = DigestUtils.md5Hex(pw + key);
        byte[] bkeys = new String(f).getBytes();
        byte[] enk = new byte[24];
        for (int i=0;i<24;i++){
            enk[i] = bkeys[i];
        }
        return enk;
    }

    /**
     * 替换字符串中的指定长度的字符，替换原则为末尾留2位，然后往前推替换len长度的字符。
     * eg：
     *    hiddenCharacter("nbekAMxCTa", 4, "*") 返回的结果为：nbek****Ta
     *    hiddenCharacter("QWERTYuI8kSoB6aP", 4, "*")  返回的结果为：QWERTYuI8k****aP
     * @param src  字符串原文
     * @param len  替换长度
     * @param replacer  替换符号，默认为“*”
     * @return
     */
    public static String hiddenCharacter(String src, int len, String replacer){
        String defaultReplacer = "*";
        if(StringUtils.isEmpty(src)){
            return "";
        }
        if(len == 0){
            return src;
        }
        if(!StringUtils.isEmpty(replacer)){
            defaultReplacer = replacer;
        }
        StringBuilder result = new StringBuilder("");
        int srcLength = src.length();
        result.append(src.substring(0, srcLength-(len+2)));
        for(int i = srcLength-(len+2); i < srcLength-2; i++){
            result.append(defaultReplacer);
        }
        result.append(src.substring(srcLength-2));
        return result.toString();
    }

    public static void main(String[] args) {
        //String mw = decryptMode("i7Uc2J1LZjR6D8s0IfGy+Q==");
        String mw = encryptMode("i7Uc2J1LZjR6D8s0IfGy+Q==");
        System.out.println("解密后字符串：" + mw);
       /* String src = "xDYKP0Jisl";
        System.out.println("加密前字符串：" + src);
        String res = encryptMode(src);
        System.out.println("加密后字符串：" + res);


        System.out.println("隐藏后字符串：" + hiddenCharacter(mw, 4, "*"));*/
    }
}
