package com.lenovo.m2.couponV2.common;

import com.lenovo.m2.couponV2.common.exception.BusinessException;

import java.util.HashMap;
import java.util.Map;


/**
 * 商城列表
 * @author wangrq1
 *
 */
public enum ShopIdEnum {
	
	LENOVO(1, "lenovo"),
	THINK(2,"think"),
	EPP(3,"epp"),
	ROMING(4,"roming"),
	MOTO(5,"moto"),
	DONGDE(6,"dongde"),
	THINKCENTER(7,"thinkcenter"),
	HS(14,"huishang"),
	SMB(8,"17商城");
	
			
	private final int type;
	private final String descr;

	private ShopIdEnum(int type, String descr){
		this.type = type;
		this.descr = descr;
	} 
	
	public int getType() {
		return type;
	}

	public String getDescr() {
		return descr;
	}
	
	private static Map<Integer,ShopIdEnum>lookupmap =new HashMap<Integer,ShopIdEnum>();
	
	static{
		for(ShopIdEnum type: ShopIdEnum.values()){
			lookupmap.put(type.type, type);
		}
		
	}
	
	public static void checkPlat(Integer plat){
		if(!lookupmap.containsKey(plat)){
			throw new BusinessException(400, "非法平台号："+plat);
		}
	}

	/**
	* @Title: 判断是否是Think商城
	* @Description: TODO(这里用一句话描述这个方法的作用)
	* @author 2015年9月16日 上午11:06:03 BY zhanghs
	* @param shopid
	* @return boolean
	* @throws
	 */
	public static boolean isThink(Integer shopid){
		if(null == shopid){
			return false;
		}
		return THINK.getType() == shopid;
	}
	
	/**
	* @Title: isEpp
	* @Description: 判断是否是Epp商城
	* @author 2015年9月16日 上午11:12:53 BY zhanghs
	* @param shopid
	* @return
	* @return boolean
	* @throws
	 */
	public static boolean isEpp(Integer shopid){
		return EPP.getType() == shopid;
	}
	
	/**
	* @Title: isB2C
	* @Description: 判断是否是B2C商城
	* @author 2015年9月16日 上午11:14:51 BY zhanghs
	* @param shopId
	* @return
	* @return boolean
	* @throws
	 */
	public static boolean isB2C(Integer shopId){
		if(null == shopId){
			return false;
		}
		return LENOVO.getType() == shopId;
	}
	
	/**
	* @Title: isRoming
	* @Description: 判断是否为ROMING商城
	* @author 2015年9月16日 上午11:16:34 BY zhanghs
	* @param shopId
	* @return
	* @return boolean
	* @throws
	 */
	public static boolean isRoming(Integer shopId){
		return false;
//		return ENUM.MallType.Roaming.getCode()==shopId;
	}
	
	
//	public  static ShopIdEnum getByPlat(int plat){
//		if(plat==1 || plat==2 || plat==3 || plat==4){
//			return ShopIdEnum.LENOVO;
//		}
//		if(plat==5 || plat==6 || plat==7 || plat==8){
//			return ShopIdEnum.THINK;
//		}
//		if(PlatType.isRoming(plat)){
//			return ShopIdEnum.ROMING;
//		}
//		if(plat ==20 || plat==22){
//			return ShopIdEnum.EPP;
//		}
//		return  null;
//	}

}
