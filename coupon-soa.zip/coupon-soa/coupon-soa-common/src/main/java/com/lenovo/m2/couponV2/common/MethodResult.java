/**
 * Project Name:couponV2-soa-common
 * File Name:MethodResult.java
 * Package Name:com.lenovo.m2.couponV2.common
 * Date:2017年6月12日下午5:16:46
 * Copyright (c) 2017, yuzj7@lenovo.com All Rights Reserved.
 *
*/

package com.lenovo.m2.couponV2.common;

import com.lenovo.m2.couponV2.common.enums.ErrorMessageEnum;

/**
 * ClassName:MethodResult <br/>
 * Function: TODO ADD FUNCTION. <br/>
 * Date:     2017年6月12日 下午5:16:46 <br/>
 * @author   yuzj7
 * @version  
 * @since    JDK 1.7
 * @see 	 
 */
public class MethodResult<T1,T2,T3> {

	private String code;
	private String msg;
	//第一个返回值
	private T1 t1;
	//第二个返回值
	private T2 t2;
	//第三个返回值
	private T2 t3;

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

	

	public T1 getT1() {
		return t1;
	}

	public void setT1(T1 t1) {
		this.t1 = t1;
	}

	public T2 getT2() {
		return t2;
	}

	public void setT2(T2 t2) {
		this.t2 = t2;
	}

	public T2 getT3() {
		return t3;
	}

	public void setT3(T2 t3) {
		this.t3 = t3;
	}
	
	

	public MethodResult(String code, String msg, T1 t1, T2 t2, T2 t3) {
		super();
		this.code = code;
		this.msg = msg;
		this.t1 = t1;
		this.t2 = t2;
		this.t3 = t3;
	}

	public MethodResult(ErrorMessageEnum errorMessageEnum, T1 t1, T2 t2, T2 t3) {
		super();
		this.code = errorMessageEnum.getCode();
		this.msg = errorMessageEnum.getCommon();
		this.t1 = t1;
		this.t2 = t2;
		this.t3 = t3;
	}
	
	public MethodResult(ErrorMessageEnum errorMessageEnum) {
		super();
		this.code = errorMessageEnum.getCode();
		this.msg = errorMessageEnum.getCommon();
	}
	public MethodResult(String code,String msg) {
		super();
		this.code = code;
		this.msg = msg;
	}
	
	
	public MethodResult() {
		super();
	}
	
	public boolean isSuccess(){
		if(ErrorMessageEnum.SUCCESS.getCode().equals(this.getCode())){
			return true;
		}
		return false;
	}
	
}

