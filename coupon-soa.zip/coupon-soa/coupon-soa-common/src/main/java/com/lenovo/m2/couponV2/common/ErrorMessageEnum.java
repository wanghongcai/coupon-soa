//package com.lenovo.m2.couponV2.common;
//
//import java.util.Map;
//import java.util.TreeMap;
//
///**
// * 
//* @ClassName: ErrorMessageEnum
//* @Description:公共错误信息汇总
//* @author yuzj7@lenovo.com
//* @date 2015年7月26日 下午4:49:11
//*
// */
//public enum ErrorMessageEnum {
//	
//	ERROR_PARAM("10000","参数错误！"),
//	ERROR_ILLEGAL("10001","参数非法！"),
//	ERROR_NOT_LOGIN("10002","请登陆后操作！"),
//	ERROR_ORDER_FAIL("10003","订单生成失败！"),
//	;
//	private String code;// 代号
//	private String common;// 说明
//	
//	ErrorMessageEnum(String code, String common) {
//		this.code = code;
//		this.common = common;
//	}
//
//	
//	public String getCode() {
//		return code;
//	}
//	public void setCode(String code) {
//		this.code = code;
//	}
//	public String getCommon() {
//		return common;
//	}
//	public void setCommon(String common) {
//		this.common = common;
//	}
//
//
//	static  Map<String, String> map = new TreeMap<String, String>();
//	/**
//	 * 获取枚举类型的所有<值,名称>对
//	 * 
//	 * @return
//	 */
//	public static Map<String, String> toMap() {
//		if(map.size() > 0){
//			return map;
//		}
//		for (int i = 0; i < ErrorMessageEnum.values().length; i++) {
//			map.put(ErrorMessageEnum.values()[i].getCode(), ErrorMessageEnum.values()[i].getCommon());
//		}
//		return map;
//	}
//}
