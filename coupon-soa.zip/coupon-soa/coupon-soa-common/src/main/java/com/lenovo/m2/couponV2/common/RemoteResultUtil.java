/**
 * Project Name:couponV2-soa-common
 * File Name:RemoteResultUtil.java
 * Package Name:com.lenovo.m2.couponV2.common
 * Date:2017年6月12日下午6:11:31
 * Copyright (c) 2017, yuzj7@lenovo.com All Rights Reserved.
 *
*/

package com.lenovo.m2.couponV2.common;
/**
 * ClassName:RemoteResultUtil <br/>
 * Function: TODO ADD FUNCTION. <br/>
 * Date:     2017年6月12日 下午6:11:31 <br/>
 * @author   yuzj7
 * @version  
 * @since    JDK 1.7
 * @see 	 
 */

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.couponV2.common.enums.ErrorMessageEnum;

public class RemoteResultUtil {

	private RemoteResultUtil(){
		
	}
	/**
	 * 
	* @Title: convert
	* @Description:错误枚举转remoteresult
	* @param error
	* @return    设定文件
	* @throws
	 */
	public final static RemoteResult convert(ErrorMessageEnum error){
		RemoteResult temp = new RemoteResult();
		temp.setSuccess(false);
		temp.setResultCode(error.getCode());
		temp.setResultMsg(error.getCommon());
		return temp;
	}
	public final static RemoteResult convert(String code,String msg){
		RemoteResult temp = new RemoteResult();
		temp.setSuccess(false);
		temp.setResultCode(code);
		temp.setResultMsg(msg);
		return temp;
	}
}

