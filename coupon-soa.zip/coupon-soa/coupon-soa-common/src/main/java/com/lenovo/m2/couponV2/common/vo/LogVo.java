/**
 * Project Name:couponV2-soa-common
 * File Name:LogVo.java
 * Package Name:com.lenovo.m2.couponV2.common.vo
 * Date:2017年5月24日上午10:02:35
 * Copyright (c) 2017, yuzj7@lenovo.com All Rights Reserved.
 *
*/

package com.lenovo.m2.couponV2.common.vo;
/**
 * ClassName:LogVo <br/>
 * Function: 通用mongo 存储日志vo 对象. <br/>
 * Date:     2017年5月24日 上午10:02:35 <br/>
 * @author   yuzj7
 * @version  
 * @since    JDK 1.7
 * @see 	 
 */
public class LogVo implements java.io.Serializable{

	/**
	* @Fields serialVersionUID : TODO(用一句话描述这个变量表示什么)
	*/ 
	private static final long serialVersionUID = 1L;
	
	private String modul;//模块,取对应mysql 对应的表名+log，.例如 c2cmemberlog,
	
	private String message;//日志信息
	
	private String lenovoId;//谁
	
	private String createTime;//什么时间
	
	private String operationType;//1.增加，2.删除，3.修改。审核，等枚举操作
	
	private String content;//操作内容 json 字符串

	public String getModul() {
		return modul;
	}

	public void setModul(String modul) {
		this.modul = modul;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getLenovoId() {
		return lenovoId;
	}

	public void setLenovoId(String lenovoId) {
		this.lenovoId = lenovoId;
	}

	public String getCreateTime() {
		return createTime;
	}

	public void setCreateTime(String createTime) {
		this.createTime = createTime;
	}

	public String getOperationType() {
		return operationType;
	}

	public void setOperationType(String operationType) {
		this.operationType = operationType;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}
	
	
	

}

