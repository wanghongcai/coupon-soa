/**
 * Project Name:couponV2-soa-common
 * File Name:OperationType.java
 * Package Name:com.lenovo.m2.couponV2.common.enums
 * Date:2017年5月24日下午2:37:42
 * Copyright (c) 2017, yuzj7@lenovo.com All Rights Reserved.
 *
*/

package com.lenovo.m2.couponV2.common.enums;
/**
 * ClassName:OperationType <br/>
 * Function: 保存到mongo 日志操作类型枚举. <br/>
 * Date:     2017年5月24日 下午2:37:42 <br/>
 * @author   yuzj7
 * @version  
 * @since    JDK 1.7
 * @see 	 
 */
public enum OperationTypeEnum {
	
	ADD("1","保存"),
	DELTE("2","删除"),
	UPDATE("3","修改"),
	AUDIT("4","审核"),
	;
	
	

	private OperationTypeEnum(String code, String desc) {
		this.code = code;
		this.desc = desc;
	}
	private String code;
	private String desc;
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getDesc() {
		return desc;
	}
	public void setDesc(String desc) {
		this.desc = desc;
	}
	
	
}

