package com.lenovo.m2.couponV2.common.usercenter;

import com.lenovo.m2.arch.framework.domain.RemoteResult;

/**
 * Created by zhanghb2 on 2015/12/23.
 */
public class RemoteLenovo<T> extends RemoteResult<T> {
    private Integer invalueableCount;
    private Integer canUserCount;
    private Integer expireCount;
    private Integer allCount;

    public RemoteLenovo() {
    }

    public Integer getAllCount() {
        return allCount;
    }

    public void setAllCount(Integer allCount) {
        this.allCount = allCount;
    }

    public Integer getInvalueableCount() {
        return invalueableCount;
    }

    public void setInvalueableCount(Integer invalueableCount) {
        this.invalueableCount = invalueableCount;
    }

    public Integer getCanUserCount() {
        return canUserCount;
    }

    public void setCanUserCount(Integer canUserCount) {
        this.canUserCount = canUserCount;
    }

    public Integer getExpireCount() {
        return expireCount;
    }

    public void setExpireCount(Integer expireCount) {
        this.expireCount = expireCount;
    }
}
