package com.lenovo.m2.couponV2.common;

import org.apache.http.client.config.RequestConfig;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;

public class HttpClientUtil {
	
	private static PoolingHttpClientConnectionManager pool =null;
	private static HttpClientBuilder httpBulder = null;
	private static CloseableHttpClient httpClient = null;
	private static final int TIMEOUT = 3 * 1000;
	private static final int MAX_HTTP_TOTAL_CONNECTION = 1000;
	private static final int MAX_CONNECTION_PER_HOST = 1000;
	private static HttpClientUtil instance = null;
	private static RequestConfig requestConfig = null;
	
	private static CloseableHttpClient singleHttpClient = null;

	static{
		requestConfig = RequestConfig.custom()
	                .setSocketTimeout(TIMEOUT)
	                .setConnectTimeout(TIMEOUT)
	                .setConnectionRequestTimeout(TIMEOUT)
	                .build();
		pool =  new PoolingHttpClientConnectionManager();
		pool.setMaxTotal(MAX_HTTP_TOTAL_CONNECTION);
		pool.setDefaultMaxPerRoute(MAX_CONNECTION_PER_HOST);
        singleHttpClient = HttpClients.custom().setConnectionManager(pool).setMaxConnTotal(MAX_HTTP_TOTAL_CONNECTION).setMaxConnPerRoute(MAX_HTTP_TOTAL_CONNECTION).build();
	}
	
	public static HttpClientUtil getInstance(){

		if(null == instance){
			synchronized(HttpClientUtil.class){
				if(instance == null){
					instance = new HttpClientUtil();
				}
			}
		}
		
		return instance;
	}
	
	/**
	 * ����һ���µ�HttpClient
	 * @return
	 */
	public CloseableHttpClient createHttpClient(){

		httpBulder = HttpClients.custom();
        httpBulder.setConnectionManager(pool);
		httpClient = httpBulder.build();
		
		return httpClient;
	}
	
	/**
	 * ��ȡһ��HttpClient
	 * @return
	 */
	public CloseableHttpClient getHttpClient(){

		return singleHttpClient;
	}
	
	public static RequestConfig getRequestConfig() {
		
		return requestConfig;
	}
}
