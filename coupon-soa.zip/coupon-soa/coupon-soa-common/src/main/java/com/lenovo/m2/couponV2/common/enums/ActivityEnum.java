package com.lenovo.m2.couponV2.common.enums;

/**
 * Created by pxg01 on 2017/7/4.
 */
public enum ActivityEnum {
    LUHAN_FANS(0001,"鹿晗粉丝节");
    private ActivityEnum(Integer code, String desc) {
        this.code = code;
        this.desc = desc;
    }
    private Integer code;
    private String desc;
    public Integer getCode() {
        return code;
    }
    public void setCode(Integer code) {
        this.code = code;
    }
    public String getDesc() {
        return desc;
    }
    public void setDesc(String desc) {
        this.desc = desc;
    }
}
