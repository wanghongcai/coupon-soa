/**
 * Project Name:purchase-soa-common
 * File Name:ExceptionHandler.java
 * Package Name:com.lenovo.m2.buy.purchase.common.aop
 * Date:2016年8月18日下午4:10:00
 * Copyright (c) 2016, yuzj7@lenovo.com All Rights Reserved.
 *
*/

package com.lenovo.m2.couponV2.common.aop;

import java.lang.reflect.Method;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.aop.ThrowsAdvice;

/**
 * ClassName:ExceptionHandler <br/>
 * Function: 异常捕获打印，方便查看异常日志. <br/>
 * Date:     2016年8月18日 下午4:10:00 <br/>
 * @author   yuzj7
 * @version  
 * @since    JDK 1.7
 * @see 	 
 */
public class ExceptionHandlerAdvice implements ThrowsAdvice{
	private final static Logger log = LoggerFactory.getLogger(ExceptionHandlerAdvice.class.getName());
	/**
     * Gets called after the Exception is thrown at the code level
     *
     * @param m      Method where the exception was thrown
     * @param args   Arguments sent to that method
     * @param target The enclosing class of the method
     * @param ex     The exception that was thrown
     */
    public void afterThrowing(Method m, Object[] args, Object target, Throwable ex) {
        log.error("Exception in method: " + m.getName() + " Exception is:{} ",null != ex ?ex.getStackTrace():"" );
    }


    /**
     * Gets called after the Exception is thrown at the code level
     *
     * @param m      Method where the exception was thrown
     * @param args   Arguments sent to that method
     * @param target The enclosing class of the method
     * @param ex     The exception that was thrown
     */
    public void afterThrowing(Method m, Object[] args, Object target, Exception ex) {
        log.error("Exception in method: " + m.getName() + " Exception is: {}", ex);
    }

}

