package com.lenovo.m2.couponV2.common;

import java.io.Serializable;

/**
 * Created by zcl on 2015/3/18.
 */
public abstract class BaseObject implements Serializable{

    public abstract String toString();

    public abstract boolean equals(Object paramObject);

    public abstract int hashCode();
}
