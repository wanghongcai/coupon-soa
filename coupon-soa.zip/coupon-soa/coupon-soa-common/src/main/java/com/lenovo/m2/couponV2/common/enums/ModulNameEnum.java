/**
 * Project Name:couponV2-soa-common
 * File Name:ModulEnum.java
 * Package Name:com.lenovo.m2.couponV2.common.enums
 * Date:2017年5月24日下午2:41:57
 * Copyright (c) 2017, yuzj7@lenovo.com All Rights Reserved.
 *
*/

package com.lenovo.m2.couponV2.common.enums;
/**
 * ClassName:ModulEnum <br/>
 * Function: 保存到mongo 的日志模块名称枚举. <br/>
 * Date:     2017年5月24日 下午2:41:57 <br/>
 * @author   yuzj7
 * @version  
 * @since    JDK 1.7
 * @see 	 
 */
public enum ModulNameEnum {
	AVALIBLE_SALES_COIUPON_LOG("1","领券日志"),
	C2C_MEMBER_LOG("2","c2c member 日志"),
	DETAIL_RULE_LOG("3","分类规则日志"),
	DISTRUBTOR_RULE_LOG("4","产品组规则日志"),
	MEMBER_COIUPON_REL_LOG("5","用户优惠券日志"),
	PRODUCT_RULE_LOG("6","商品规则日志"),
	SALES_COUPON_LOG("7","优惠券码日志")
	
	;
	private ModulNameEnum(String code, String desc) {
		this.code = code;
		this.desc = desc;
	}
	private String code;
	private String desc;
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getDesc() {
		return desc;
	}
	public void setDesc(String desc) {
		this.desc = desc;
	}
	
}

