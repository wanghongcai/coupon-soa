package com.lenovo.m2.couponV2.common;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.client.methods.RequestBuilder;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.lenovo.m2.couponV2.common.exception.ExceptionUtil;

public class HttpConnectionUtil {
	public static String VB_ERROR = "{\"rc\":1,\"msg\":\"VB�����쳣\"}";
	public static String ERROR = "{\"ret\":1,\"msg\":\"�������\"}";
	
	private static Logger log=LoggerFactory.getLogger(HttpConnectionUtil.class);
	
	public static CloseableHttpClient getHttpClient() {
		return HttpClientUtil.getInstance().getHttpClient();
	}

	/**
	 * �����������Ϊ��ͨ
	 * 
	 * @param url
	 * @param params
	 * @return
	 */
	public static String getHttpContent(String url, String params) {
		HttpURLConnection connection = null;
		String content = "";
		try {
			URL address_url = new URL(url);
			connection = (HttpURLConnection) address_url.openConnection();
			connection.setRequestMethod("POST");
			connection.setConnectTimeout(10000);
			connection.setReadTimeout(10000);
			connection.setDoOutput(true);
			connection.getOutputStream().write(params.getBytes());
			// �õ�����ҳ��ķ���ֵ
			int response_code = connection.getResponseCode();
			if (response_code == HttpURLConnection.HTTP_OK) {
				InputStream in = connection.getInputStream();
				BufferedReader reader = new BufferedReader(
						new InputStreamReader(in, "UTF-8"));
				String line = null;
				while ((line = reader.readLine()) != null) {
					content += line;
				}
				return content;
			}
		} catch (MalformedURLException e) {
			log.error("MalformedURL", e);
		} catch (IOException e) {
			log.error("IO exception", e);
		} finally {
			if (connection != null) {
				connection.disconnect();
			}
		}
		return VB_ERROR;
	}

	/**
	 * �����������Ϊ��ͨ
	 * 
	 * @param url
	 * @param params
	 * @return
	 */
	public static String getHttpPostContent(String url, String params) {
		HttpURLConnection connection = null;
		String content = "";
		try {
			URL address_url = new URL(url);
			connection = (HttpURLConnection) address_url.openConnection();
			connection.setRequestMethod("POST");
			connection.setConnectTimeout(10000);
			connection.setReadTimeout(10000);
			connection.setDoOutput(true);
			connection.getOutputStream().write(params.getBytes());
			// �õ�����ҳ��ķ���ֵ
			int response_code = connection.getResponseCode();
			if (response_code == HttpURLConnection.HTTP_OK) {
				InputStream in = connection.getInputStream();
				BufferedReader reader = new BufferedReader(
						new InputStreamReader(in, "UTF-8"));
				String line = null;
				while ((line = reader.readLine()) != null) {
					content += line;
				}
				return content;
			}
		} catch (MalformedURLException e) {
			log.error("MalformedURL", e);
		} catch (IOException e) {
			log.error("IO exception", e);
		} finally {
			if (connection != null) {
				connection.disconnect();
			}
		}
		return ERROR;
	}

	/**
	 * �����������Ϊjson
	 * 
	 * @param url
	 * @param params
	 * @return
	 */
	public static String getHttpContentJSON(String url, String params) {
		HttpURLConnection connection = null;
		String content = "";
		try {
			URL address_url = new URL(url);
			connection = (HttpURLConnection) address_url.openConnection();
			connection.setRequestMethod("POST");
			connection.setRequestProperty("Content-Type",
					"application/json;charset=utf-8");
			connection.setConnectTimeout(20000);
			connection.setReadTimeout(10000);
			connection.setDoOutput(true);
			connection.getOutputStream().write(params.getBytes());
			// �õ�����ҳ��ķ���ֵ
			int response_code = connection.getResponseCode();
			if (response_code == HttpURLConnection.HTTP_OK) {
				InputStream in = connection.getInputStream();
				BufferedReader reader = new BufferedReader(
						new InputStreamReader(in, "UTF-8"));
				String line = null;
				while ((line = reader.readLine()) != null) {
					content += line;
				}
				return content;
			}
		} catch (MalformedURLException e) {
			log.error("MalformedURL", e);
		} catch (IOException e) {
			log.error("IO exception", e);
		} finally {
			if (connection != null) {
				connection.disconnect();
			}
		}
		return VB_ERROR;
	}
	
	//get����
	public static String sendGETByHttpClient(String url) {
		try{
			CloseableHttpClient client = getHttpClient();
			RequestBuilder requestBuilder =  RequestBuilder.get(url);
			requestBuilder.setHeader("Content-type","application/x-www-form-urlencoded; charset=UTF-8").setConfig(HttpClientUtil.getRequestConfig());
			HttpUriRequest httpUriRequest = requestBuilder.build();
			String responseBody = null;
			CloseableHttpResponse response = null;
			int statusCode = 0;
			try {
				response = client.execute(httpUriRequest);
				statusCode = response.getStatusLine().getStatusCode();
				responseBody = EntityUtils.toString(response.getEntity(), "utf-8");
				log.info("result:" + statusCode + responseBody);
			} catch (Exception e) {
				log.error(ExceptionUtil.getStackTrace(e));
			} finally {
				if (response != null) {
					response.close();
				}
			}
			return responseBody;
		}catch(Exception e){
			log.error("�����쳣");
		}
		return "";
	}
	//post����
	public static String sendPostByHttpClient(String url,Map<String,String> params){
		try{
			CloseableHttpClient client = getHttpClient();
			RequestBuilder requestBuilder =  RequestBuilder.post(url);
			if(params != null && params.size()>0){
				Set<String> keySet = params.keySet();//��ȡmap��keyֵ�ļ��ϣ�set����
				for(String key:keySet){//����key
					requestBuilder.addParameter(key, params.get(key));
				}
			}
			requestBuilder.setHeader("Content-type","application/x-www-form-urlencoded; charset=UTF-8").setConfig(HttpClientUtil.getRequestConfig());
			HttpUriRequest httpUriRequest = requestBuilder.build();
			String responseBody = null;
			CloseableHttpResponse response = null;
			int statusCode = 0;
			try {
				response = client.execute(httpUriRequest);
				statusCode = response.getStatusLine().getStatusCode();
				responseBody = EntityUtils.toString(response.getEntity(), "utf-8");
				log.info("result:" + statusCode + responseBody);
			} catch (Exception e) {
				log.error(ExceptionUtil.getStackTrace(e));
			} finally {
				if (response != null) {
					response.close();
				}
			}
			return responseBody;
		}catch(Exception e){
			log.error("http�����쳣");
		}
		return "";
	}

    public static void main(String[] args) throws ParseException{
    	String array100[] = new String[]{
    			"13955192300",
    			"15093270310",
    			"13698822102",
    			"13931705302",
    			"13581780835",
    			"13862717858",
    			"15265388455",
    			"13698822102",

    	};
    	
    	String array80[]= new String[]{
    			"15857213909"
    	};
    	
    	String array60[] = new String[]{
    			"18092031076",
    			"15265388455",
    	};
    	
    	String array40[] = new String[]{
    			"15264101622",

    			
    	};
    	
    	String array20[]=new String[]{};
    	
    	String arraytotal[] = new String[]{
    			"1000004594;13581780835",
    			"1000091024;13698822102",
    			"1000002771;13862717858",
    			"1000046789;13931705302",
    			"1000065413;13955192300",
    			"1000076666;15093270310",
    			"1000074660;15265388455",
    			"1000081204;15857213909",
    			"1000063536;18092031076",

    			
    	};
    	String not[] = new String[]{
    			"1000006171;13798353818",
    			"1000006171;13798353818",
    			"1000006171;13798353818",
    			"1000008568;13923047788",
    			"1000002898;13951369055",
    			"1000051595;15292449546",
    			"1000091107;15292449546",
    			"1000016837;15303193355",
    			"1000050579;15303809789",
    			"1000002790;15961008065",
    			
    	};

    	List<String> list100 = Arrays.asList(array100);
    	List<String> list80 = Arrays.asList(array80);
    	List<String> list60 = Arrays.asList(array60);
    	List<String> list40 = Arrays.asList(array40);
    	List<String> list20 = Arrays.asList(array20);
    	List<String> listtotal = Arrays.asList(arraytotal);
    	//List<String> listnot = Arrays.asList(not);
    	
    	StringBuffer sb100 = new StringBuffer();
    	StringBuffer sb80 = new StringBuffer();
    	StringBuffer sb60 = new StringBuffer();
    	StringBuffer sb40 = new StringBuffer();
    	StringBuffer sb20 = new StringBuffer();
    	
    	int count = 0;
    	int count100 =0;
    	int count80 =0;
    	int count60 = 0;
    	int count40 = 0;
    	int count20 = 0;
    	for(String all : listtotal){
    		String temp[] = all.split("\\;");
    		if(list100.contains(temp[1])){
    			sb100.append(all).append(",");
    			count++;
    			count100++;
    		}
    		if(list80.contains(temp[1])){
    			sb80.append(all).append(",");
    			count++;
    			count80++;
    		}
    		if(list60.contains(temp[1])){
    			sb60.append(all).append(",");
    			count++;
    			count60++;
    		}
    		if(list40.contains(temp[1])){
    			sb40.append(all).append(",");
    			count++;
    			count40++;
    		}
    		if(list20.contains(temp[1])){
    			sb20.append(all).append(",");
    			count++;
    			count20++;
    		}
    	}
    	
    	System.out.println(sb100);//107164
    	System.out.println(sb80);//107163
    	System.out.println(sb60);//107162
    	System.out.println(sb40);//107161
    	System.out.println(sb20);//107160
    	System.out.println(count);
    	System.out.println(count100);
    	System.out.println(count80);
    	System.out.println(count60);
    	System.out.println(count40);
    	System.out.println(count20);
    	
    	
    	
    	Map<String, String> lenovo_param_json = new HashMap<String, String>();
    	lenovo_param_json.put("members", sb60.toString());
    	lenovo_param_json.put("couponid", "107162");
    	lenovo_param_json.put("shopid", "14");
    	lenovo_param_json.put("userId", "yuzj7");
    	String json = HttpConnectionUtil.sendPostByHttpClient("http://coupon.admin.lenovo.com.cn//api/coupon/sendToSelectedMember.jhtm", lenovo_param_json);
    	System.out.println("============="+json);
    	/* JSONObject jsonObject = JSONObject.parseObject(json);
         String ret =jsonObject.getString("ret");
         if(ret.equals("0")){
         	JSONArray data = jsonObject.getJSONArray("data");
         	JSONObject o = (JSONObject) data.get(0);
             String time = o.getString("createTime");
             if(!StringUtils.isEmpty(time)){
                 SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
                 Date regiterTime = formatter.parse(time);
                 SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                 String time1 = sdf.format(regiterTime);
                 System.out.println("------"+time1);
             }
         }
*/
    }
}
