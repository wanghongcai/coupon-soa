/**
 * Project Name:couponV2-soa-common
 * File Name:ErrorMessageEnum.java
 * Package Name:com.lenovo.m2.couponV2.common.enums
 * Date:2017年6月12日下午3:52:41
 * Copyright (c) 2017, yuzj7@lenovo.com All Rights Reserved.
 *
*/

package com.lenovo.m2.couponV2.common.enums;
/**
 * ClassName:ErrorMessageEnum <br/>
 * Function: 错误信息抽取规范. <br/>
 * Date:     2017年6月12日 下午3:52:41 <br/>
 * @author   yuzj7
 * @version  
 * @since    JDK 1.7
 * @see 	 
 */
public enum ErrorMessageEnum {
	SUCCESS("00","SUCCESS"),
	ERROR_PARA("01","参数错误！"),
	ERROR_OPER_FAIL("02","操作失败！"),
	ERROR_SERVICE("03","服务异常，请稍后再试！"),
	ERROR_CANT_FIND_COUPON_INOF("04","没有找到优惠券信息！"),
	ERROR_FIND("10","查不到有效优惠券"),
	ERROR_COUPON_HAS_BEEN_USED("11","优惠券{0}已经被使用"),
	ERROR_COUPON_IS_FORBIDDEN("12","优惠券{0}已被禁用"),

	ERROR_CANT_FIND_CONDITION_COUPON("10000","没有满足条件的全员券groupcode：{0}, shopid:{1},用户注册时间：{2}"),
	ERROR_NOT_VALIDE_COUPON("10001","没有有效优惠券"),
	ERROR_CANT_FIND_CONDITION_ALL_COUPON("10002","没有满足条件的全员券!"),
	ERROR_USER_REGIST_TIME("10003","用户注册时间有误!"),
	ERROR_COUPON_NOTSHENHE("10004","优惠券{0}未审核!"),
	ERROR_COUPON_EXPIRE("10005","优惠券{0}已过期!"),
	ERROR_COUPON_CANT_GET("10006","优惠券{0}不可领取!"),
	ERROR_COUPON_GETTIME("10007","优惠券{0}领取时间错误!"),
	ERROR_COUPON_GETLIMIT("10008","优惠券{0}达到领取上线!"),
	ERROR_COUPON_ALREDY_HAVE("10009","{0}用户已经拥有 {1}优惠券!"),
	ERROR_COUPON_NOT_REACHGETTIME("10010","优惠券{0}没到领取时间!"),
	ERROR_COUPON_GETTIME_TIMEOUT("10011","优惠券{0}领取时间已过!"),
	ERROR_COUPON_RESULT_NULL("10012","查询结果为空!"),
	ERROR_FIND_GROUP_DISTRUBUTOR("10013","没有找到产品组{0}和分销商{1}的签约关系!"),
	ERROR_INVOIKEGROUP_DISTRUBUTOR("10014","调用接口返回签约关系错误!"),
	ERROR_USER_SHOP_TERMINAL_NOTFOUND("10015","用户[{0}]在商城[{1}] 平台[{2}]上没有有效的优惠券！"),
	
	ERROR_USER_NOTFOUND("10016","用户不存在"),
	ERROR_ORDER_ALREDY_SEND_COUPON("10017","该订单已经发放优惠券"),
	ERROR_SOME_SUCESS_FAIL("10018","创建代金券成功，给用户绑代金券时失败"),
	ERROR_SAVE_OLD4NEW_COUPON("10019","创建代金券时失败"),
	ERROR_USER_INFO("10020","校验用户时出现异常！"),
	ERROR_SUCCESS("1","SUCCESS"),
	
	ERROR_SEND_COUPON_FAIL("10021","优惠券发放失败！"),
	ERROR_ALREADY_SHENHE_NOT_ALLOW_OPERA("10022","已经审核不可以操作！"),
	ERROR_MAX_PAGESIZE("10023","每页最多100条！"),
	ERROR_COUPONCODE_SHOP("10024","商城[{0}]与该优惠码[{1}]不匹配！"),
	ERROR_COUPONCODE_TERMINAL("10025","平台[{0}]与该优惠码[{1}]不匹配！"),
	ERROR_COUPONCODE_VALIDATE("10026","优惠码[{0}]有效期必须小于结束时间！"),
	ERROR_COUPONCODE_NOTSTART("10027","优惠码[{0}]未开始！"),
	ERROR_COUPONCODE_USERTIMES("10028","优惠码[{0}]使用次数已经用完！"),
	ERROR_COUPONCODE_EXPIRE("10029","优惠码[{0}]已经过期！"),
	ERROR_COUPONCODE_PRODUCT_INFO("10030","未找到优惠码[{0}]关联的商品信息！"),
	ERROR_COUPONCODE_NOT_EXIS_RULE("10031","优惠码{0}不存在绑定规则{1}！"),
	ERROR_COUPONCODE_NOT_RULE_4PRODUCT("10032","优惠码{0}和商品信息{1}不匹配！"),
	ERROR_ACTIVE_NOT_VALIDATE("10041","活动还未开始，敬请期待！"),
	ERROR_SHOPID("10034","商城不匹配！"),
	ERROR_BATCH_NO("10035","批次号不匹配！"),
	ERROR_ACTIVE_NOT_FOUND("10036","未找到活动！"),
	ERROR_USER_COUPON_BIND("10037","用户已经绑过优惠券！"),
	ERROR__COUPON_CODE_INFO_CANNOT_FIND("10038","未查询到优惠码{0}信息！"),
	ERROR__COUPON_CODE__CANNOT_USED_MORE("10039","优惠码{0}已达到使用上限！"),
	ERROR_ACTIVE_NOT_ONLY("10033","查询到多条活动信息！"),
	ERROR_HAS_ACTIVITI_IS_HOLDING("10042","有其他活动正在进行，请先停用再进行此操作！"),
	ERROR_SHOPID_NOT_MATCH("10040","绑券平台与优惠券所属平台不匹配！"),

	ERROR_CANT_FIND_RESOURCE_INOF("10050","没有找到用户优惠券源数据信息"),

	ERROR_KCODE_NOSTART("0101","L码活动还未开始！"),
	ERROR_KCODE_NOEXIS("0102","L码不存在！"),
	ERROR_KCODE_EXPIRE("0103","L码已过期！"),
	ERROR_KCODE_USEED("0104","L码已使用！"),
	ERROR_KCODE_NOPRODUCT("0105","非L码商品！"),
	ERROR_KCODE_INVALID("0106","L码已失效！"),
	ERROR_KCODE_NOSHENHE("0107","L码还未审核通过！"),
	ERROR_KCODE_NAME_EXIST("0108","L码名称已存在"),
	ERROR_KCODE_CANT_REPEAT("0109","该商品在相同时间段内已经创建过L码，不能重复创建！"),
	ERROR_KCODE_CANT_REPEAT_SUBMIT("0110","L码已经提交审核，不能重复提交"),
	
	ERROR_APP_ERROR_BUSY("2000","程序正在执行，请不要同时操作!"),

    ERROR_SAME_ACTIVITY_NAME("2001","该名称已经存在，不能重复！"),
	ERROR_DELETE_ONE_KEY_ACTIVITY("2002","删除失败"),
	ERROR_ACTIVITY_HAS_BEEN_END("2003","活动已经结束"),
	ERROR_ACTIVITY_CAN_NOT_JOIN("2004","您已经参加过该活动"),
	ERROR_HAVING_ALL_THE_COUPONS("2005","您已经拥有该礼包中的所有优惠券，无需再次领取,快去使用吧！");
	private String code;// 代号
	private String common;// 说明
	
	
	public String getCode() {
		return code;
	}


	public void setCode(String code) {
		this.code = code;
	}


	public String getCommon() {
		return common;
	}


	public void setCommon(String common) {
		this.common = common;
	}


	ErrorMessageEnum(String code, String common) {
		this.code = code;
		this.common = common;
	}
}

