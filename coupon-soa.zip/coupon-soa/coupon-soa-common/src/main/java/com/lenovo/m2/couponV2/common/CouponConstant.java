package com.lenovo.m2.couponV2.common;

import com.lenovo.m2.arch.tool.util.StringUtils;
import com.lenovo.m2.couponV2.common.exception.ExceptionUtil;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;

/**
 * Created with IntelliJ IDEA.
 * User: zhangqy10
 * Date: 15-7-6
 * Time: 下午13:43
 * To change this template use File | Settings | File Templates.
 */
public class CouponConstant {



    //操作状态code
    public static final String RESULT_CODE_SUC = "00";
    public static final String RESULT_MSG_SUC = "操作成功！";
    public static final String RESULT_CODE_ERROR_PARAM = "01";
    public static final String RESULT_MSG_ERROR_PARAM = "参数错误！";
    public static final String RESULT_CODE_FAIL = "02";
    public static final String RESULT_MSG_FAIL = "操作失败！";
    public static final String RESULT_CODE_ERROR = "03";
    public static final String RESULT_MSG_ERROR = "服务异常，请稍后再试！";
    public static final String RESULT_CODE_EMPTY = "04";  // 已领完
    public static final String RESULT_CODE_OWNED = "05";  // 已领过
    public static final String COUPON_USESCOPE_NAME = "全场";
    public static final String PAGE_SIZE="500";
    public static final String COUPON_GET_NULL = "未知";
    public static final String CAN_NOT_GET_CONPON_EFFIEC_NO = "10";
    public static final String CAN_NOT_GET_CONPON_EFFIEC_MSG = "查不到有效优惠券";



    //K码状态code
    public static final String K_RELT_CODE_01 = "0101";
    public static final String K_RESULT_MSG_01 = "L码活动还未开始！";
    public static final String K_RELT_CODE_02 = "0102";
    public static final String K_RESULT_MSG_02 = "L码不存在！";
    public static final String K_RELT_CODE_03 = "0103";
    public static final String K_RESULT_MSG_03 = "L码已过期！";
    public static final String K_RELT_CODE_04 = "0104";
    public static final String K_RESULT_MSG_04 = "L码已使用！";
    public static final String K_RELT_CODE_05 = "0105";
    public static final String K_RESULT_MSG_05 = "非L码商品！";
    public static final String K_RELT_CODE_06 = "0106";
    public static final String K_RESULT_MSG_06 = "L码已失效！";
    public static final String K_RELT_CODE_07 = "0107";
    public static final String K_RESULT_MSG_07 = "L码还未审核通过！";
    public static final String K_RELT_CODE_08 = "0108";
    public static final String K_RESULT_MSG_08 = "L码名称已存在";
    public static final String K_RELT_CODE_09 = "0109";
    public static final String K_RESULT_MSG_09 = "该商品在相同时间段内已经创建过L码，不能重复创建！";
    public static final String L_CODE_ALREADY_TO_CHECK_MSG = "L码已经提交审核，不能重复提交";
    public static final String L_CODE_ALREADY_TO_CHECK_CODE = "0110";
    //优惠券状态type
    public static final Integer COUPON_TYPE_NEIHTER_0 = 0;//不绑定商品也不绑定分类，依旧换新属于这种情况
    public static final Integer COUPON_TYPE_DETAIL_1 = 1;//分类
    public static final Integer COUPON_TYPE_PRODUCT_2 = 2;//商品
    public static final Integer COUPON_TYPE_PRODUCTGROUP_3 = 3;//按产品组绑定 慧商


    //优惠券/码
    public static final Integer COUPON_style_coupon_1 = 1;//优惠券
    public static final Integer COUPON_style_code_2 = 2;//优惠码

    //商品类型
    public static final Integer COUPON_PRODUCT_TYPE_PUTONG = 0;//普通商品
    public static final Integer COUPON_PRODUCT_TYPE_C2C = 1;//c2c
    public static final Integer COUPON_PRODUCT_TYPE_YIJIUHUANXIN = 2;//依旧换新

    //商城
    public static final String COUPON_SHOPID_Lenovo = "1";//
    public static final String COUPON_SHOPID_Think = "2";//
    public static final String COUPON_SHOPID_EPP = "3";//
    public static final String COUPON_SHOPID_Roaming = "4";//
    public static final String COUPON_SHOPID_Moto = "5";//

    //平台
    public static final String COUPON_TERMINAL_PC = "1";//pc
    public static final String COUPON_TERMINAL_WAP = "2";//wap
    public static final String COUPON_TERMINAL_APP = "3";//app
    public static final String COUPON_TERMINAL_WEIXIN = "4";//weixin

    //优惠券来源
    public static final String COUPON_SOURCE_ADMIN = "ADMIN_SEND";//后台发放
    public static final String COUPON_SOURCE_ALL_USER = "ALL_SEND";//全员券领取
    public static final String COUPON_SOURCE_API = "API_SEND";//外部接口领取
    public static final String COUPON_SOURCE_EXCEL = "EXCEL_SEND";//EXCEL导入
    //是否已经发过优惠券
    public static final Integer COUPON_Backsend_1 = 1;//已经发过券了
    public static final Integer COUPON_Backsend_0 = 0;//还没发过券

    //lenovo think  组 all
    public static final String COUPON_Lenovo_Think_GROUPCODE = "all";//

    //usescope 优惠券类型
    public static final Integer COUPON_USESCOPE_ZHEKOU = 1;//折扣券
    public static final Integer COUPON_USESCOPE_MANJIAN = 2;//满减券
    public static final Integer COUPON_USESCOPE_DAIJINQUAN = 3;//代金券
    public static final Integer COUPON_USESCOPE_C2C = 4;//专属c2c
    public static final Integer COUPON_USESCOPE_YIJIUHUANXIN = 6;//专属--依旧换新
    public static final Integer COUPON_USESCOPE_YIJIUHUANXINDAIJINQUAN = 7;//专属-依旧换新代金券
    public static final Integer COUPON_USESCOPE_GOUWU = 8;//购物券
    public static final Integer COUPON_USESCOPE_CHONGZHI = 9;//充值券
    public static final Integer COUPON_USESCOPE_ITPLACE = 10;//惠商券

    //disabled 禁用
    public static final Integer COUPON_DISABLED_JINYONG = 1;//禁用
    public static final Integer COUPON_DISABLED_NOJINYONG = 0;//未禁用

    //membercouponrels表status 0 代表未使用，1代表已经使用
    public static final Integer COUPON_STATUS_ISUSED_FALSE = 0;//未使用
    public static final Integer COUPON_STATUS_ISUSED_TRUE = 1;//已经使用

    //coupons表，status状态，0代表正常，1代表禁用，即代表删除
    public static final Integer COUPON_COUPONS_STATUS_NORMAL = 0;//正常状态
    public static final Integer COUPON_COUPONS_STATUS_DISABLE = 1;//禁用状态 即删除

    public static final Integer COUPON_Superposition_FALSE = 0;//不叠加 即一个订单只能用一张券
    public static final Integer COUPON_Superposition_TRUE = 1;//叠加

    public static final Integer COUPON_COUPONS_MAXNUMBER_MAX = 20000;//正常状态

//    //优惠券状态couponType
//    public static final Integer COUPON_TYPE_REPEAT_CLASS = 1;//分类重复使用
//    public static final Integer COUPON_TYPE_NOREPEAT_CLASS = 2;//分类一次使用
//    public static final Integer COUPON_TYPE_REPEAT_PRODUCT = 3;//单品多次使用
//    public static final Integer COUPON_TYPE_NOREPEAT_PRODUCT = 4;//单品一次使用
//
//    public static HashMap<Integer, String> couponTypeMap = new HashMap<Integer, String>();
//    static {
//        couponTypeMap.put(COUPON_TYPE_REPEAT_CLASS,"A分类重复使用");
//        couponTypeMap.put(COUPON_TYPE_NOREPEAT_CLASS,"B分类一次使用");
//        couponTypeMap.put(COUPON_TYPE_REPEAT_PRODUCT,"C单品多次使用");
//        couponTypeMap.put(COUPON_TYPE_NOREPEAT_PRODUCT,"D单品一次使用");
//    }
//
//    public static String getCouponTypeMap(Integer key) {
//
//        String value = couponTypeMap.get(key);
//        if(StringUtils.isEmpty(value)){
//            return  COUPON_GET_NULL;
//        }
//        return value;
//    }
//
//    public static HashMap<Integer, String> getCouponTypeMap() {
//        return couponTypeMap;
//    }

    //优惠券审核状态
    public static final Integer COUPON_STATUS_NEW_0 = 0;//新建状态
    public static final Integer COUPON_STATUS_NOPASTAUDIT_1 = 1;//审核未通过
    public static final Integer COUPON_STATUS_PASTAUDIT_2 = 2;//审核通过
    public static final Integer COUPON_STATUS_NOAUDIT_3 = 3;//未审核

    //是否可以领取
    public static final Integer COUPON_ISCANGET_CAN = 1;//可以领取
    public static final Integer COUPON_ISCANGET_NO = 0;//不可以领取
    public static HashMap<Integer, String> isCanGetMap = new HashMap<Integer, String>();
    static {
        isCanGetMap.put(COUPON_ISCANGET_CAN,"是");
        isCanGetMap.put(COUPON_ISCANGET_NO,"否");
    }



    public static String subCategoryCode(String categoryCode){
        return categoryCode.substring(1);
    }

    public static Date dateFormat(String str,String format){
        try {
            if(StringUtils.isNotEmpty(str)){
                if(StringUtils.isNotEmpty(format)){
                    SimpleDateFormat dateformat1=new SimpleDateFormat(format);
                    return (Date)dateformat1.parseObject(str);
                }else {
                    SimpleDateFormat dateformat1=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                    return (Date)dateformat1.parseObject(str);
                }
            }
        } catch (ParseException e) {
            System.out.println(ExceptionUtil.getStackTrace(e));
        }
        return null;
    }

    /**   redis key start   **/
    public static final String REDIS_KEY_coupon_GoodsCategories = "coupon_GoodsCategoriesV2";//分类key
    public static final String REDIS_KEY_coupon_PlatFormList = "coupon_PlatFormListV2";//平台key
    public static final String REDIS_KEY_coupon_EPPGroupsList = "coupon_EPPGroupsListV2";//eppgroup key

    /**   redis key end   **/


    public static HashMap<PairKey, Integer> platformpairkeyMap = new HashMap<PairKey, Integer>();
    static {
        platformpairkeyMap.put(new PairKey("lenovo",1),4);//lenovo pc
        platformpairkeyMap.put(new PairKey("lenovo",2),1);//lenovo wap
        platformpairkeyMap.put(new PairKey("lenovo",3),3);//lenovo app
        platformpairkeyMap.put(new PairKey("lenovo",4),2);//lenovo 微信

        platformpairkeyMap.put(new PairKey("think",1),8);//think pc
        platformpairkeyMap.put(new PairKey("think",2),5);//think wap
        platformpairkeyMap.put(new PairKey("think",3),7);//think app
        platformpairkeyMap.put(new PairKey("think",4),6);//think 微信

        platformpairkeyMap.put(new PairKey("epp",1),22);//epp pc
        platformpairkeyMap.put(new PairKey("epp",2),20);//epp wap
//        platformpairkeyMap.put(new PairKey("epp",3),7);//epp app
//        platformpairkeyMap.put(new PairKey("epp",4),6);//epp 微信
    }

    public static Integer getPlatformpairkeyMap(String mall,int platform) {
        return platformpairkeyMap.get(new PairKey(mall,platform));
    }

    public static HashMap<PairKey, Integer> getPlatformpairkeyMap() {
        return platformpairkeyMap;
    }

    public static HashMap<Integer,PairKey> platformkeyMap = new HashMap<Integer,PairKey>();
    static {
        platformkeyMap.put(4,new PairKey("lenovo",1));//lenovo pc
        platformkeyMap.put(1,new PairKey("lenovo",2));//lenovo wap
        platformkeyMap.put(3,new PairKey("lenovo",3));//lenovo app
        platformkeyMap.put(2,new PairKey("lenovo",4));//lenovo 微信

        platformkeyMap.put(8,new PairKey("think",1));//think pc
        platformkeyMap.put(5,new PairKey("think",2));//think wap
        platformkeyMap.put(7,new PairKey("think",3));//think app
        platformkeyMap.put(6,new PairKey("think",4));//think 微信

        platformkeyMap.put(22,new PairKey("epp",1));//epp pc
        platformkeyMap.put(20,new PairKey("epp",2));//epp wap
//        platformpairkeyMap.put(new PairKey("epp",3),7);//epp app
//        platformpairkeyMap.put(new PairKey("epp",4),6);//epp 微信
    }

    public static PairKey getPlatformkeyMap(int platformcode) {
        return platformkeyMap.get(platformcode);
    }


    public static void main(String[] args){
//        System.out.println("sdfvsd="+CouponConstant.dateFormat("2015-08-26",""));
//        System.out.println(CouponConstant.getCouponTypeMap(2));
        System.out.println("11=="+CouponConstant.getPlatformpairkeyMap("epp",1));
        System.out.println("11=="+CouponConstant.getPlatformkeyMap(1));
    }

}
