package com.lenovo.m2.couponV2.common.usercenter;

import java.io.Serializable;

/**
 * Created by zhanghb2 on 2015/12/18.
 */
public class PageShowBean implements Serializable {

    private String pageNum;
    private String pageCount;
    private String type;
    private String time;
    private String status;
    private Integer invalueableCount;
    private Integer canUserCount;
    private Integer expireCount;
    private Integer allCount;
    private String lenovoId;
    private String lenovoName;

    public String getLenovoName() {
        return lenovoName;
    }

    public void setLenovoName(String lenovoName) {
        this.lenovoName = lenovoName;
    }

    public String getLenovoId() {
        return lenovoId;
    }

    public void setLenovoId(String lenovoId) {
        this.lenovoId = lenovoId;
    }

    public Integer getAllCount() {
        return allCount;
    }

    public void setAllCount(Integer allCount) {
        this.allCount = allCount;
    }

    public Integer getInvalueableCount() {
        return invalueableCount;
    }

    public void setInvalueableCount(Integer invalueableCount) {
        this.invalueableCount = invalueableCount;
    }

    public Integer getCanUserCount() {
        return canUserCount;
    }

    public void setCanUserCount(Integer canUserCount) {
        this.canUserCount = canUserCount;
    }

    public Integer getExpireCount() {
        return expireCount;
    }

    public void setExpireCount(Integer expireCount) {
        this.expireCount = expireCount;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getPageNum() {
        return pageNum;
    }

    public void setPageNum(String pageNum) {
        this.pageNum = pageNum;
    }

    public String getPageCount() {
        return pageCount;
    }

    public void setPageCount(String pageCount) {
        this.pageCount = pageCount;
    }
}
