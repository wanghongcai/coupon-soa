package com.lenovo.m2.couponV2.common.util;

/**
 * Created by pxg01 on 2017/4/25.
 */
public class DistributorInfo {
    private String productgroupno;
    private String fxsno;
    private String fxsname;
    private Integer status;

    public String getFxsno() {
        return fxsno;
    }

    public void setFxsno(String fxsno) {
        this.fxsno = fxsno;
    }

    public String getFxsname() {
        return fxsname;
    }

    public void setFxsname(String fxsname) {
        this.fxsname = fxsname;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public String getProductgroupno() {
        return productgroupno;
    }

    public void setProductgroupno(String productgroupno) {
        this.productgroupno = productgroupno;
    }

    @Override
    public String toString() {
        return "DistributorInfo{" +
                "productgroupno='" + productgroupno + '\'' +
                ", fxsno='" + fxsno + '\'' +
                ", fxsname='" + fxsname + '\'' +
                ", status=" + status +
                '}';
    }
}
