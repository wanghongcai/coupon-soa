package com.lenovo.m2.couponV2.common.exception;

/**
 * Created by fenglg1 on 2016/8/11.
 */
public class ExceptionUtil {
    /**
     * fetch Exception message content, and return it's string value.
     * @param e
     * @return
     */
    public static String getStackTrace(Exception e){
        StackTraceElement[] elements = e.getStackTrace();
        StringBuilder sb = new StringBuilder();
        sb.append(e.getClass()).append(": ");
        sb.append(e.getMessage()).append("\n");
        for(StackTraceElement ste : elements){
            sb.append(ste).append("\n");
        }
        return sb.toString();
    }
}
