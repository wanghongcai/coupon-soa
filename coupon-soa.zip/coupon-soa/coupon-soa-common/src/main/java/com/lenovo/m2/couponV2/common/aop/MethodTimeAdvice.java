package com.lenovo.m2.couponV2.common.aop;

import org.aopalliance.intercept.MethodInterceptor;
import org.aopalliance.intercept.MethodInvocation;
import org.apache.commons.lang.time.StopWatch;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.slf4j.LoggerFactory;

import com.lenovo.m2.couponV2.common.JacksonMapper;

/**
 * 
* @ClassName: MethodTimeAdvice 
* @Description: 记录接口方法执行耗时（记录接口执行耗时，请求参数，返回结果）
* @author yuzj7@lenovo.com 
* @date 2016年3月3日 下午7:47:04 
*
 */
public class MethodTimeAdvice implements MethodInterceptor{

	private final static Logger logger = LogManager.getLogger(MethodTimeAdvice.class.getName());
	private final static org.slf4j.Logger log = LoggerFactory.getLogger(MethodTimeAdvice.class.getName());
	@Override
	public Object invoke(MethodInvocation invocation) throws Throwable {
		 Object[] args = invocation.getArguments();
		 logger.info("该方法请求参数: " + " ["  
	                + invocation.getThis().getClass().getSimpleName() + "."  
	                + invocation.getMethod().getName()+" "+JacksonMapper.obj2json(args)); 
        StopWatch clock = new StopWatch();  
        clock.start(); //计时开始  
        Object result = invocation.proceed();  
        clock.stop();  //计时结束  
  

		if(clock.getTime() > 3000){
			logger.error("该方法执行耗费: " + clock.getTime() + " ms ["
					+ invocation.getThis().getClass().getSimpleName() + "."
					+ invocation.getMethod().getName()+"]");
		}else {
			logger.info("该方法执行耗费: " + clock.getTime() + " ms ["
					+ invocation.getThis().getClass().getSimpleName() + "."
					+ invocation.getMethod().getName()+"]");
		}

        logger.info("该方法执行返回: "+invocation.getThis().getClass().getSimpleName() + "."  
                + invocation.getMethod().getName()+"  "+JacksonMapper.obj2json(result));
        return result;  
	}

}
