package com.lenovo.m2.couponV2.common.enums;

/**
 * Created by Administrator on 2017/9/21.
 */
public enum MakeUpDateEnum {

    SHARDING_TO_OLD(1,"分表到主表"),
    OLD_TO_SHARDING(0,"主表到分表"),
    INSERT_OPERATION(1,"插入数据"),
    SELECT_OPERATION(0,"查询数据");

    private Integer flag;
    private String discription;
     MakeUpDateEnum(Integer flag,String discr){
         this.flag=flag;
         this.discription=discr;
    }

    public Integer getFlag() {
        return flag;
    }

    public void setFlag(Integer flag) {
        this.flag = flag;
    }

    public String getDiscription() {
        return discription;
    }

    public void setDiscription(String discription) {
        this.discription = discription;
    }
}
