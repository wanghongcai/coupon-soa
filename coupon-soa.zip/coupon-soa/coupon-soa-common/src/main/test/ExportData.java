import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import com.lenovo.m2.couponV2.common.TripleDESUtil;

/**
 * Project Name:couponV2-soa-common
 * File Name:ExportData.java
 * Package Name:
 * Date:2017年5月19日上午11:32:29
 * Copyright (c) 2017, yuzj7@lenovo.com All Rights Reserved.
 *
*/

/**
 * ClassName:ExportData <br/>
 * Function: TODO ADD FUNCTION. <br/>
 * Date:     2017年5月19日 上午11:32:29 <br/>
 * @author   yuzj7
 * @version  
 * @since    JDK 1.7
 * @see 	 
 */
public class ExportData {

	public static void main(String[] args) throws IOException {
		//FileInputStream fis = new FileInputStream(new File("D:\\dexportdata\\10.txt"));
		
		FileReader reader = new FileReader(new File("D:\\workspace2016\\couponV2-soa\\couponV2-soa-common\\bb.txt"));
		BufferedReader br = new BufferedReader(reader);
		FileWriter writer = new FileWriter("D:\\workspace2016\\couponV2-soa\\couponV2-soa-common\\12.txt");
		BufferedWriter wr = new BufferedWriter(writer);
		String str = null;
        while((str = br.readLine()) != null) {
        	str = TripleDESUtil.encryptMode(str);
        	wr.write(str);
        	wr.newLine();
        } 
        wr.close();
        writer.close();
        br.close();
        reader.close();
	}
}

