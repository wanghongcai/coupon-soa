package com.lenovo.m2.couponV2.api.dubboService;

import com.lenovo.m2.arch.framework.domain.Money;
import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.framework.domain.Tenant;
import com.lenovo.m2.couponV2.api.model.CouponsApi;
import com.lenovo.m2.couponV2.api.model.SalescouponsApi;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

/**
 * Created by zhaocl1 on 2016/3/15.
 */
public interface RpcCouponsService {

    /**
     * 对外提供的保存优惠码接口，保存批次信息，默认审核，同时生成优惠码
     * @param salescouponsApi
     * @return
     */
    public RemoteResult add(SalescouponsApi salescouponsApi);

    /**
     * 根据主键删除优惠码所有信息，物理删除
     * @param id
     * @param shopId
     * @param terminal
     * @return
     */
    @Deprecated
    public RemoteResult delete(long id, String shopId, String terminal);

    /**
     * 根据主键删除优惠码所有信息，物理删除
     * @param tenant
     * @param id
     * @param terminal
     * @return
     */
    public RemoteResult delete(Tenant tenant, long id, String terminal);

    /**
     * 通过优惠码批次信息主键id更新码属性
     * @param id
     * @param shopId
     * @param terminal
     * @param amount
     * @param fromtime
     * @param totime
     * @return
     */
    @Deprecated
    public RemoteResult update(long id, String shopId, String terminal, BigDecimal amount, String fromtime, String totime, String userId);

    /**
     * 通过优惠码批次信息主键id更新码属性
     * @param tenant
     * @param id
     * @param terminal
     * @param amount
     * @param fromtime
     * @param totime
     * @param userId
     * @return
     */
    public RemoteResult update(Tenant tenant, long id, String terminal, Money amount, String fromtime, String totime, String userId);

    /**
     * 启用优惠码，即审核，在启用的时候生产优惠码
     * @param map
     * @return
     */
    public RemoteResult enableCoupons(Map<String, String> map);

    /**
     * 通过有效期进行某个商城、终端的分页查询
     * @param shopId
     * @param terminal
     * @param fromtime
     * @param totime
     * @param page
     * @param page_size
     * @return
     */
    @Deprecated
    public RemoteResult getPage(String shopId, String terminal, String amount, String name, String fromtime, String totime, String page, String page_size, String status);

    /**
     * 通过有效期进行某个商城、终端的分页查询
     * @param tenant
     * @param terminal
     * @param amount
     * @param name
     * @param fromtime
     * @param totime
     * @param page
     * @param page_size
     * @param status
     * @return
     */
    public RemoteResult getPage(Tenant tenant, String terminal, String amount, String name, String fromtime, String totime, String page, String page_size, String status);

    /**
     * 获取优惠码列表
     * @param map
     * @return
     */
    public RemoteResult getCouponsPage(Map map);

    /**
     * 校验码和商品是否匹配
     * @param codeslist
     * @param shopId
     * @param terminal
     * @param couponCode
     * @return
     */
    @Deprecated
    public RemoteResult check(List<String> codeslist, String shopId, String terminal, String couponCode);

    /**
     * 校验码和商品是否匹配
     * @param tenant
     * @param codeslist
     * @param terminal
     * @param couponCode
     * @return
     */
    public RemoteResult check(Tenant tenant, List<String> codeslist, String terminal, String couponCode);

    /**
     * 根据码主键和码 更新优惠码的状态 0 正常 ，1 禁用
     * @param userId
     * @param couponsApi
     * @return
     */
    public RemoteResult updateCouponsStatus(String userId, CouponsApi couponsApi);

    /**
     * 优惠码生效后失效接口
     * @param userId
     * @param shopId
     * @param terminal
     * @param id
     * @return
     */
    @Deprecated
    public RemoteResult invalidCoupons(String userId, String shopId, String terminal, String id, String batchno);

    /**
     * 优惠码生效后失效接口
     * @param tenant
     * @param userId
     * @param terminal
     * @param id
     * @param batchno
     * @return
     */
    public RemoteResult invalidCoupons(Tenant tenant, String userId, String terminal, String id, String batchno);
}
