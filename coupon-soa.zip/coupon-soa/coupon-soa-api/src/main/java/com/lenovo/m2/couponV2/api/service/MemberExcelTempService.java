package com.lenovo.m2.couponV2.api.service;

import com.lenovo.m2.arch.framework.domain.PageModel2;
import com.lenovo.m2.arch.framework.domain.PageQuery;
import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.couponV2.api.dubboModel.MemberExcelTempApi;

import java.util.List;
import java.util.Map;

/**
 * Created by yuzn1 on 2016/5/17.
 */
public interface MemberExcelTempService {

    /**
     * 批量导入excle用户信息保存
     * @param list
     * @return
     */
    public RemoteResult insertBatch(List<MemberExcelTempApi> list,String itCode);

    /**
     * 查询导入excel信息
     */
    public RemoteResult<PageModel2<MemberExcelTempApi>> getMemberExcelTempPage(PageQuery pageQuery,Map map);

    /**
     * 查询导入重复信息
     */
    public RemoteResult<MemberExcelTempApi> getIsRepeat(String itCode);

    /**
     * 获取有效数据
     * @return
     */
    public RemoteResult<MemberExcelTempApi> getValidList(String itCode);

    /**
     * 删除excle信息
     * @param map
     * @return
     */
    public RemoteResult toDelete_exMember(Map map);

    /**
     * 删除本次所有excle导入信息
     * @return
     */
    public RemoteResult deleteAll(String itCode);
}
