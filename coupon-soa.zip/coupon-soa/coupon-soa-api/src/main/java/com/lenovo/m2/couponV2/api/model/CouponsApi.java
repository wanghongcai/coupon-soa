package com.lenovo.m2.couponV2.api.model;

import com.lenovo.m2.arch.framework.domain.BaseObject;
import com.lenovo.m2.arch.framework.domain.Money;
import java.util.Date;

public class CouponsApi extends BaseObject {
    private Long id;
    private String batchno;
    private String name;
    private Long salescouponid;
    private Integer type;
    private String macode;
    private String shopid;
    private String terminal;
    private Date starttime;
    private Date endtime;
    private Money amount;
    private String currencyCode;
    private Integer totalnumber;
    private Integer surplusnumber;
    private Integer occupynumber;
    private Integer status;
    private Date createtime;
    private String createby;
    private Date updatetime;
    private String updateby;
    private String groupcode;

    public CouponsApi() {
    }

    public Long getId() {
        return this.id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getBatchno() {
        return this.batchno;
    }

    public void setBatchno(String batchno) {
        this.batchno = batchno;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Long getSalescouponid() {
        return this.salescouponid;
    }

    public void setSalescouponid(Long salescouponid) {
        this.salescouponid = salescouponid;
    }

    public Integer getType() {
        return this.type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    public String getMacode() {
        return this.macode;
    }

    public void setMacode(String macode) {
        this.macode = macode;
    }

    public String getShopid() {
        return this.shopid;
    }

    public void setShopid(String shopid) {
        this.shopid = shopid;
    }

    public String getTerminal() {
        return this.terminal;
    }

    public void setTerminal(String terminal) {
        this.terminal = terminal;
    }

    public Date getStarttime() {
        return this.starttime;
    }

    public void setStarttime(Date starttime) {
        this.starttime = starttime;
    }

    public Date getEndtime() {
        return this.endtime;
    }

    public void setEndtime(Date endtime) {
        this.endtime = endtime;
    }

    public Money getAmount() {
        return this.amount;
    }

    public void setAmount(Money amount) {
        this.amount = amount;
    }

    public String getCurrencyCode() {
        return this.currencyCode;
    }

    public void setCurrencyCode(String currencyCode) {
        this.currencyCode = currencyCode;
    }

    public Integer getTotalnumber() {
        return this.totalnumber;
    }

    public void setTotalnumber(Integer totalnumber) {
        this.totalnumber = totalnumber;
    }

    public Integer getSurplusnumber() {
        return this.surplusnumber;
    }

    public void setSurplusnumber(Integer surplusnumber) {
        this.surplusnumber = surplusnumber;
    }

    public Integer getOccupynumber() {
        return this.occupynumber;
    }

    public void setOccupynumber(Integer occupynumber) {
        this.occupynumber = occupynumber;
    }

    public Integer getStatus() {
        return this.status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Date getCreatetime() {
        return this.createtime;
    }

    public void setCreatetime(Date createtime) {
        this.createtime = createtime;
    }

    public String getCreateby() {
        return this.createby;
    }

    public void setCreateby(String createby) {
        this.createby = createby;
    }

    public Date getUpdatetime() {
        return this.updatetime;
    }

    public void setUpdatetime(Date updatetime) {
        this.updatetime = updatetime;
    }

    public String getUpdateby() {
        return this.updateby;
    }

    public void setUpdateby(String updateby) {
        this.updateby = updateby;
    }

    public String getGroupcode() {
        return this.groupcode;
    }

    public void setGroupcode(String groupcode) {
        this.groupcode = groupcode;
    }

    public boolean equals(Object o) {
        if (this == o) {
            return true;
        } else if (o != null && this.getClass() == o.getClass()) {
            CouponsApi that = (CouponsApi)o;
            if (this.amount != null) {
                if (!this.amount.equals(that.amount)) {
                    return false;
                }
            } else if (that.amount != null) {
                return false;
            }

            label254: {
                if (this.batchno != null) {
                    if (this.batchno.equals(that.batchno)) {
                        break label254;
                    }
                } else if (that.batchno == null) {
                    break label254;
                }

                return false;
            }

            label247: {
                if (this.createby != null) {
                    if (this.createby.equals(that.createby)) {
                        break label247;
                    }
                } else if (that.createby == null) {
                    break label247;
                }

                return false;
            }

            if (this.createtime != null) {
                if (!this.createtime.equals(that.createtime)) {
                    return false;
                }
            } else if (that.createtime != null) {
                return false;
            }

            label233: {
                if (this.currencyCode != null) {
                    if (this.currencyCode.equals(that.currencyCode)) {
                        break label233;
                    }
                } else if (that.currencyCode == null) {
                    break label233;
                }

                return false;
            }

            if (this.endtime != null) {
                if (!this.endtime.equals(that.endtime)) {
                    return false;
                }
            } else if (that.endtime != null) {
                return false;
            }

            label219: {
                if (this.groupcode != null) {
                    if (this.groupcode.equals(that.groupcode)) {
                        break label219;
                    }
                } else if (that.groupcode == null) {
                    break label219;
                }

                return false;
            }

            if (this.id != null) {
                if (!this.id.equals(that.id)) {
                    return false;
                }
            } else if (that.id != null) {
                return false;
            }

            if (this.macode != null) {
                if (!this.macode.equals(that.macode)) {
                    return false;
                }
            } else if (that.macode != null) {
                return false;
            }

            label198: {
                if (this.name != null) {
                    if (this.name.equals(that.name)) {
                        break label198;
                    }
                } else if (that.name == null) {
                    break label198;
                }

                return false;
            }

            label191: {
                if (this.occupynumber != null) {
                    if (this.occupynumber.equals(that.occupynumber)) {
                        break label191;
                    }
                } else if (that.occupynumber == null) {
                    break label191;
                }

                return false;
            }

            if (this.salescouponid != null) {
                if (!this.salescouponid.equals(that.salescouponid)) {
                    return false;
                }
            } else if (that.salescouponid != null) {
                return false;
            }

            if (this.shopid != null) {
                if (!this.shopid.equals(that.shopid)) {
                    return false;
                }
            } else if (that.shopid != null) {
                return false;
            }

            label170: {
                if (this.starttime != null) {
                    if (this.starttime.equals(that.starttime)) {
                        break label170;
                    }
                } else if (that.starttime == null) {
                    break label170;
                }

                return false;
            }

            if (this.status != null) {
                if (!this.status.equals(that.status)) {
                    return false;
                }
            } else if (that.status != null) {
                return false;
            }

            if (this.surplusnumber != null) {
                if (!this.surplusnumber.equals(that.surplusnumber)) {
                    return false;
                }
            } else if (that.surplusnumber != null) {
                return false;
            }

            if (this.terminal != null) {
                if (!this.terminal.equals(that.terminal)) {
                    return false;
                }
            } else if (that.terminal != null) {
                return false;
            }

            label142: {
                if (this.totalnumber != null) {
                    if (this.totalnumber.equals(that.totalnumber)) {
                        break label142;
                    }
                } else if (that.totalnumber == null) {
                    break label142;
                }

                return false;
            }

            label135: {
                if (this.type != null) {
                    if (this.type.equals(that.type)) {
                        break label135;
                    }
                } else if (that.type == null) {
                    break label135;
                }

                return false;
            }

            if (this.updateby != null) {
                if (!this.updateby.equals(that.updateby)) {
                    return false;
                }
            } else if (that.updateby != null) {
                return false;
            }

            if (this.updatetime != null) {
                if (!this.updatetime.equals(that.updatetime)) {
                    return false;
                }
            } else if (that.updatetime != null) {
                return false;
            }

            return true;
        } else {
            return false;
        }
    }

    public int hashCode() {
        int result = this.id != null ? this.id.hashCode() : 0;
        result = 31 * result + (this.batchno != null ? this.batchno.hashCode() : 0);
        result = 31 * result + (this.name != null ? this.name.hashCode() : 0);
        result = 31 * result + (this.salescouponid != null ? this.salescouponid.hashCode() : 0);
        result = 31 * result + (this.type != null ? this.type.hashCode() : 0);
        result = 31 * result + (this.macode != null ? this.macode.hashCode() : 0);
        result = 31 * result + (this.shopid != null ? this.shopid.hashCode() : 0);
        result = 31 * result + (this.terminal != null ? this.terminal.hashCode() : 0);
        result = 31 * result + (this.starttime != null ? this.starttime.hashCode() : 0);
        result = 31 * result + (this.endtime != null ? this.endtime.hashCode() : 0);
        result = 31 * result + (this.amount != null ? this.amount.hashCode() : 0);
        result = 31 * result + (this.currencyCode != null ? this.currencyCode.hashCode() : 0);
        result = 31 * result + (this.totalnumber != null ? this.totalnumber.hashCode() : 0);
        result = 31 * result + (this.surplusnumber != null ? this.surplusnumber.hashCode() : 0);
        result = 31 * result + (this.occupynumber != null ? this.occupynumber.hashCode() : 0);
        result = 31 * result + (this.status != null ? this.status.hashCode() : 0);
        result = 31 * result + (this.createtime != null ? this.createtime.hashCode() : 0);
        result = 31 * result + (this.createby != null ? this.createby.hashCode() : 0);
        result = 31 * result + (this.updatetime != null ? this.updatetime.hashCode() : 0);
        result = 31 * result + (this.updateby != null ? this.updateby.hashCode() : 0);
        result = 31 * result + (this.groupcode != null ? this.groupcode.hashCode() : 0);
        return result;
    }

    public String toString() {
        return "CouponsApi{id=" + this.id + ", batchno='" + this.batchno + '\'' + ", name='" + this.name + '\'' + ", salescouponid=" + this.salescouponid + ", type=" + this.type + ", macode='" + this.macode + '\'' + ", shopid='" + this.shopid + '\'' + ", terminal='" + this.terminal + '\'' + ", starttime=" + this.starttime + ", endtime=" + this.endtime + ", amount=" + this.amount + ", currencyCode='" + this.currencyCode + '\'' + ", totalnumber=" + this.totalnumber + ", surplusnumber=" + this.surplusnumber + ", occupynumber=" + this.occupynumber + ", status=" + this.status + ", createtime=" + this.createtime + ", createby='" + this.createby + '\'' + ", updatetime=" + this.updatetime + ", updateby='" + this.updateby + '\'' + ", groupcode='" + this.groupcode + '\'' + '}';
    }
}
