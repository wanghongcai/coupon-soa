/**
 * Project Name:couponV2-soa-api
 * File Name:DisplayPositionEnum.java
 * Package Name:com.lenovo.m2.couponV2.api.dubboModel
 * Date:2017年4月25日下午4:16:09
 * Copyright (c) 2017, yuzj7@lenovo.com All Rights Reserved.
 *
*/

package com.lenovo.m2.couponV2.api.dubboModel;
/**
 * ClassName:DisplayPositionEnum <br/>
 * Function: 领券展示位置. <br/>
 * Date:     2017年4月25日 下午4:16:09 <br/>
 * @author   yuzj7
 * @version  
 * @since    JDK 1.7
 * @see 	 
 */
public enum DisplayPositionEnum {
	//联想商城  17商城
	USER_CENTER("0","领券中心"),
	//小新领券中心
	XIAO_XIN("1","小新—商城特权"),
	XIAO_XIN_AND_USER_CENTER("3","领券中心,商城特权");

	private String code;
	private String desc ;

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	private DisplayPositionEnum(String code, String desc) {
		this.code = code;
		this.desc = desc;
	}
	
	
}

