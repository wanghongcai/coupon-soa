package com.lenovo.m2.couponV2.api.model;

import com.lenovo.m2.couponV2.common.BaseObject;

import java.util.List;

/**
 * Created by pxg01 on 2017/5/19.
 */
public class Product2FaRelationsApi extends BaseObject{
   //产品组编号
    private  String productgroupno;
    //产in组id
    private  String productgroupid;
    //分销商编码
    private List<String> facodes;
    
    

    public Product2FaRelationsApi() {
		super();
	}

	public Product2FaRelationsApi(String productgroupno, String productgroupid, List<String> facodes) {
		super();
		this.productgroupno = productgroupno;
		this.productgroupid = productgroupid;
		this.facodes = facodes;
	}

	public String getProductgroupno() {
        return productgroupno;
    }

    public void setProductgroupno(String productgroupno) {
        this.productgroupno = productgroupno;
    }


    public String getProductgroupid() {
        return productgroupid;
    }

    public void setProductgroupid(String productgroupid) {
        this.productgroupid = productgroupid;
    }

    public List<String> getFacodes() {
        return facodes;
    }

    public void setFacodes(List<String> facodes) {
        this.facodes = facodes;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Product2FaRelationsApi that = (Product2FaRelationsApi) o;

        if (productgroupno != null ? !productgroupno.equals(that.productgroupno) : that.productgroupno != null)
            return false;
        if (productgroupid != null ? !productgroupid.equals(that.productgroupid) : that.productgroupid != null)
            return false;
        return facodes != null ? facodes.equals(that.facodes) : that.facodes == null;

    }

    @Override
    public int hashCode() {
        int result = productgroupno != null ? productgroupno.hashCode() : 0;
        result = 31 * result + (productgroupid != null ? productgroupid.hashCode() : 0);
        result = 31 * result + (facodes != null ? facodes.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "Product2FaRelationsApi{" +
                "productgroupno='" + productgroupno + '\'' +
                ", productgroupid='" + productgroupid + '\'' +
                ", facodes=" + facodes +
                '}';
    }
}
