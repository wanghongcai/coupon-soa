package com.lenovo.m2.couponV2.api.service;

import com.lenovo.price.model.NotifyType;

/**
 * Created by zhaocl1 on 2016/4/12.
 */
public interface ExternalProjectService {

    /**
     * 通知商品接口
     * @param longPrama
     * @param notifyType
     */
    public void couponNotify(Long[] longPrama, NotifyType notifyType);

    /**
     * 通知搜索
     * @param id
     * @param flag
     */
    public boolean changeCoupon(long id,boolean flag);
}
