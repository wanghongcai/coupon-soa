package com.lenovo.m2.couponV2.api.dubboModel;

import com.lenovo.m2.arch.framework.domain.BaseObject;

/**
 * Created by zhaocl1 on 2016/3/2.
 */
public class UserApi extends BaseObject{
    /**
     * 会员id
     */
    private String id;
    /**
     * 用户名
     */
    private String username;
    /**
     *会员等级  1:金 2:银 3:铜
     */
    private Integer leveMember;
    /**
     *  openid
     */
    private String openid;
    /**
     *是否显示优惠劵图标 0不显示  1显示
     */
    private int isshow;
    /**
     * lenovoid
     */
    private String lenovoid;

    private int type;//用户类型  标示是C1用户还是其它（扩展）

    private String groupCode;

    //是否已登录
    private boolean isLogin = false;

    private String isLenovo;//是否内购用户

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public Integer getLeveMember() {
        return leveMember;
    }

    public void setLeveMember(Integer leveMember) {
        this.leveMember = leveMember;
    }

    public String getOpenid() {
        return openid;
    }

    public void setOpenid(String openid) {
        this.openid = openid;
    }

    public int getIsshow() {
        return isshow;
    }

    public void setIsshow(int isshow) {
        this.isshow = isshow;
    }

    public String getLenovoid() {
        return lenovoid;
    }

    public void setLenovoid(String lenovoid) {
        this.lenovoid = lenovoid;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public String getGroupCode() {
        return groupCode;
    }

    public void setGroupCode(String groupCode) {
        this.groupCode = groupCode;
    }

    public boolean isLogin() {
        return isLogin;
    }

    public void setLogin(boolean isLogin) {
        this.isLogin = isLogin;
    }

    public String getIsLenovo() {
        return isLenovo;
    }

    public void setIsLenovo(String isLenovo) {
        this.isLenovo = isLenovo;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        UserApi userApi = (UserApi) o;

        if (isLogin != userApi.isLogin) return false;
        if (isshow != userApi.isshow) return false;
        if (type != userApi.type) return false;
        if (groupCode != null ? !groupCode.equals(userApi.groupCode) : userApi.groupCode != null) return false;
        if (id != null ? !id.equals(userApi.id) : userApi.id != null) return false;
        if (isLenovo != null ? !isLenovo.equals(userApi.isLenovo) : userApi.isLenovo != null) return false;
        if (lenovoid != null ? !lenovoid.equals(userApi.lenovoid) : userApi.lenovoid != null) return false;
        if (leveMember != null ? !leveMember.equals(userApi.leveMember) : userApi.leveMember != null) return false;
        if (openid != null ? !openid.equals(userApi.openid) : userApi.openid != null) return false;
        if (username != null ? !username.equals(userApi.username) : userApi.username != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = id != null ? id.hashCode() : 0;
        result = 31 * result + (username != null ? username.hashCode() : 0);
        result = 31 * result + (leveMember != null ? leveMember.hashCode() : 0);
        result = 31 * result + (openid != null ? openid.hashCode() : 0);
        result = 31 * result + isshow;
        result = 31 * result + (lenovoid != null ? lenovoid.hashCode() : 0);
        result = 31 * result + type;
        result = 31 * result + (groupCode != null ? groupCode.hashCode() : 0);
        result = 31 * result + (isLogin ? 1 : 0);
        result = 31 * result + (isLenovo != null ? isLenovo.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "UserApi{" +
                "id='" + id + '\'' +
                ", username='" + username + '\'' +
                ", leveMember=" + leveMember +
                ", openid='" + openid + '\'' +
                ", isshow=" + isshow +
                ", lenovoid='" + lenovoid + '\'' +
                ", type=" + type +
                ", groupCode='" + groupCode + '\'' +
                ", isLogin=" + isLogin +
                ", isLenovo='" + isLenovo + '\'' +
                '}';
    }
}
