package com.lenovo.m2.couponV2.api.dubboService;

import com.lenovo.m2.arch.framework.domain.Money;
import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.framework.domain.Tenant;
import com.lenovo.m2.couponV2.api.OldforNewModel.SendCouponOldforNewOrderVo;
import com.lenovo.m2.couponV2.api.dubboModel.ProductInfoApi;
import com.lenovo.m2.couponV2.api.dubboModel.UserApi;
import com.lenovo.m2.couponV2.common.BaseInfo;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

/**
 * Created by zhaocl1 on 2016/3/3.
 */
public interface RpcMemberCounponrelsService {

    /**
     * 获取商品对应的优惠券
     * @param userApi
     * @param list
     * @param shopId
     * @param terminal
     * @return
     */
    @Deprecated
    public RemoteResult getSalescouponsWithProduct(UserApi userApi, List<ProductInfoApi> list, String shopId, String terminal);

    /**
     * 根据商品信息获取用户可用的优惠券
     * @param userApi
     * @param productList
     * @param tenant  租户
     * @param terminal  终端
     * @return
     */
    public RemoteResult getSalescouponsWithProduct(Tenant tenant, UserApi userApi, List<ProductInfoApi> productList, String terminal);

    /**
     * 更新优惠券状态
     * @param lenovoId
     * @param token
     * @param list
     * @param status  0代表返回优惠券，即更新到使用状态；1代表使用优惠券，即更新使用次数
     * @return
     */
    @Deprecated
    public RemoteResult updateMembercouponrelsStatus(String lenovoId, String token, List<String> list, int status);

    /**
     * 更新优惠券状态(新)
     * @param shopId
     * @param lenovoId
     * @param token
     * @param list
     * @param status   0代表返回优惠券，即更新到使用状态；1代表使用优惠券，即更新使用次数
     * @return
     */
    @Deprecated
    public RemoteResult updateMembercouponrelsStatus(String shopId, String lenovoId, String token, List<String> list, int status);

    /**
     *
     * @param tenant
     * @param lenovoId
     * @param token
     * @param list
     * @param status  0: 代表返回优惠券，即更新到使用状态；1: 代表使用优惠券，同时更新使用次数
     * @return
     */
    public RemoteResult updateMembercouponrelsStatus(Tenant tenant, String lenovoId, String token, List<String> list, int status);

    /**
     * 矫正用户名下优惠券的状态
     * @param id  用户名下优惠券的ID
     * @param status  0：未使用  1：已使用
     * @return
     */
    public RemoteResult rectifyMembercouponrelsStatus(Long id, int status);

    /**
     * 更新订单号
     * @param token
     * @param orderId
     * @param type  1 代表更新优惠券的订单号，0代表更新优惠码的订单号
     * @return
     */
    @Deprecated
    public RemoteResult updateMembercouponrelsOrderId(String token, String orderId, String type);

    /**
     * 更新订单号
     * @param shopId
     * @param token
     * @param orderId
     * @param type  1 代表更新优惠券的订单号，0代表更新优惠码的订单号
     * @return
     */
    @Deprecated
    public RemoteResult updateMembercouponrelsOrderId(String shopId, String token, String orderId, String type);

    /**
     * 更新订单号
     * @param tenant
     * @param token
     * @param orderId
     * @param couponType  0: 优惠码; 1: 优惠券
     * @return
     */
    public RemoteResult updateMembercouponrelsOrderId(Tenant tenant, String token, String orderId, String couponType);

    /**
     * 获取商品对应的优惠券
     * @param userApi
     * @param list
     * @param shopId
     * @param terminal
     * @param mCode
     * @return
     */
    @Deprecated
    public RemoteResult getCouponsWithProduct(UserApi userApi, List<ProductInfoApi> list, String shopId, String terminal, String mCode);

    /**
     * 获取商品对应的优惠券
     * @param userApi
     * @param list
     * @param tenant
     * @param terminal
     * @param mCode
     * @return
     */
    public RemoteResult getCouponsWithProduct(Tenant tenant, UserApi userApi, List<ProductInfoApi> list, String terminal, String mCode);

    /**
     * 更新优惠码的使用次数
     * @param lenovoId
     * @param token
     * @param macode
     * @param status  0代表返还优惠码，即使用次数-1；1 代表使用优惠码，即使用次数+1
     * @return
     */
    @Deprecated
    public RemoteResult updateCouponsStatus(String lenovoId, String token, String macode, int status);

    /**
     * 更新优惠码的使用次数
     * @param shopId
     * @param lenovoId
     * @param token
     * @param macode
     * @param status  0代表返还优惠码，即使用次数-1；1 代表使用优惠码，即使用次数+1
     * @return
     */
    @Deprecated
    public RemoteResult updateCouponsStatus(String shopId, String lenovoId, String token, String macode, int status);

    /**
     * 更新优惠码的使用次数
     * @param tenant
     * @param lenovoId
     * @param token
     * @param macode
     * @param status 1更新为已使用
     * @return
     */
    public RemoteResult updateCouponsStatus(Tenant tenant, String lenovoId, String token, String macode, int status);

    /**
     * 获取用户的优惠券信息  用户那边调用只要可使用的券
     * @param userApi
     * @param shopId
     * @param terminal
     * @return
     */
    @Deprecated
    public RemoteResult getSalescouponsWithLenovoId(UserApi userApi, String shopId, String terminal);

    /**
     * 获取用户可用的优惠券列表
     * @param userApi
     * @param tenant
     * @param terminal
     * @return
     */
    public RemoteResult getSalescouponsWithLenovoId(Tenant tenant, UserApi userApi, String terminal);


    /**
     * 单个用户批量赠送指定优惠券,对外接口
     * @param couponIds
     * @param lenovoId
     * @param memberCode
     * @return
     */
    public RemoteResult bindBatchCoupons(String couponIds, String lenovoId, String memberCode);

    /**
     * 查看用户是否拥有该优惠券
     * @param map
     * @return
     */
    public RemoteResult getUserIshaveTheCoupon(Map map);

    /**
     * 根据LenovoId 查询其名下的优惠券
     * @param userApi
     * @param shopId
     * @param terminal
     * @return
     */
    @Deprecated
    public RemoteResult getUserSalescouponsWithLenovoId(UserApi userApi, String shopId, String terminal);

    /**
     * 根据LenovoId 查询其名下的优惠券
     * @param userApi
     * @param tenant
     * @param terminal
     * @return
     */
    public RemoteResult getUserSalescouponsWithLenovoId(Tenant tenant, UserApi userApi, String terminal);

}
