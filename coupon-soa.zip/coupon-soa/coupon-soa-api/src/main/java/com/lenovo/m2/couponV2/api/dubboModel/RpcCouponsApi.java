package com.lenovo.m2.couponV2.api.dubboModel;

import com.lenovo.m2.arch.framework.domain.BaseObject;
import com.lenovo.m2.arch.framework.domain.Money;

import java.util.Date;

public class RpcCouponsApi extends BaseObject {
    /**
     *
     *主键
     */
    private Long id;

    /**
     * 批次号
     */
    private String batchno;

    /**
     * 名称
     */
    private String name;

    /**
     * 优惠码编码
     */
    private String mcode;

    /**
     * 绑定类型 2 代表商品
     */
    private Integer type;

    /**
     * 商城
     */
    private String shopid;

    /**
     * 平台 0 pc
     */
    private String terminal;

    /**
     * 有效期开始时间
     */
    private Date fromtime;

    /**
     * 有效期结束时间
     */
    private Date totime;

    /**
     * 金额
     */
    private Money amount;

    /**
     *  码的最大可用次数
     */
    private Integer totalnumber;
    /**
     * 已使用的次数
     */
    private Integer occupynumber;
    /**
     * 一批次的数量
     */
    private Integer maxnumber;

    /**
     * 状态 2 审核通过
     */
    private Integer status;

    /**
     * 创建时间
     */
    private Date createtime;

    /**
     * 创建人
     */
    private String createby;

    /**
     * 更新时间
     */
    private Date updatetime;

    /**
     * 更新人
     */
    private String updateby;

    /**
     * 描述
     */
    private String description;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getBatchno() {
        return batchno;
    }

    public void setBatchno(String batchno) {
        this.batchno = batchno;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    public String getShopid() {
        return shopid;
    }

    public void setShopid(String shopid) {
        this.shopid = shopid;
    }

    public String getTerminal() {
        return terminal;
    }

    public void setTerminal(String terminal) {
        this.terminal = terminal;
    }

    public Date getFromtime() {
        return fromtime;
    }

    public void setFromtime(Date fromtime) {
        this.fromtime = fromtime;
    }

    public Date getTotime() {
        return totime;
    }

    public void setTotime(Date totime) {
        this.totime = totime;
    }

    public Money getAmount() {
        return amount;
    }

    public void setAmount(Money amount) {
        this.amount = amount;
    }

    public Integer getTotalnumber() {
        return totalnumber;
    }

    public void setTotalnumber(Integer totalnumber) {
        this.totalnumber = totalnumber;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Date getCreatetime() {
        return createtime;
    }

    public void setCreatetime(Date createtime) {
        this.createtime = createtime;
    }

    public String getCreateby() {
        return createby;
    }

    public void setCreateby(String createby) {
        this.createby = createby;
    }

    public Date getUpdatetime() {
        return updatetime;
    }

    public void setUpdatetime(Date updatetime) {
        this.updatetime = updatetime;
    }

    public String getUpdateby() {
        return updateby;
    }

    public void setUpdateby(String updateby) {
        this.updateby = updateby;
    }

    public String getMcode() {
        return mcode;
    }

    public void setMcode(String mcode) {
        this.mcode = mcode;
    }

    public Integer getMaxnumber() {
        return maxnumber;
    }

    public void setMaxnumber(Integer maxnumber) {
        this.maxnumber = maxnumber;
    }

    public Integer getOccupynumber() {
        return occupynumber;
    }

    public void setOccupynumber(Integer occupynumber) {
        this.occupynumber = occupynumber;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        RpcCouponsApi that = (RpcCouponsApi) o;

        if (amount != null ? !amount.equals(that.amount) : that.amount != null) return false;
        if (batchno != null ? !batchno.equals(that.batchno) : that.batchno != null) return false;
        if (createby != null ? !createby.equals(that.createby) : that.createby != null) return false;
        if (createtime != null ? !createtime.equals(that.createtime) : that.createtime != null) return false;
        if (description != null ? !description.equals(that.description) : that.description != null) return false;
        if (fromtime != null ? !fromtime.equals(that.fromtime) : that.fromtime != null) return false;
        if (id != null ? !id.equals(that.id) : that.id != null) return false;
        if (maxnumber != null ? !maxnumber.equals(that.maxnumber) : that.maxnumber != null) return false;
        if (mcode != null ? !mcode.equals(that.mcode) : that.mcode != null) return false;
        if (name != null ? !name.equals(that.name) : that.name != null) return false;
        if (occupynumber != null ? !occupynumber.equals(that.occupynumber) : that.occupynumber != null) return false;
        if (shopid != null ? !shopid.equals(that.shopid) : that.shopid != null) return false;
        if (status != null ? !status.equals(that.status) : that.status != null) return false;
        if (terminal != null ? !terminal.equals(that.terminal) : that.terminal != null) return false;
        if (totalnumber != null ? !totalnumber.equals(that.totalnumber) : that.totalnumber != null) return false;
        if (totime != null ? !totime.equals(that.totime) : that.totime != null) return false;
        if (type != null ? !type.equals(that.type) : that.type != null) return false;
        if (updateby != null ? !updateby.equals(that.updateby) : that.updateby != null) return false;
        if (updatetime != null ? !updatetime.equals(that.updatetime) : that.updatetime != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = id != null ? id.hashCode() : 0;
        result = 31 * result + (batchno != null ? batchno.hashCode() : 0);
        result = 31 * result + (name != null ? name.hashCode() : 0);
        result = 31 * result + (mcode != null ? mcode.hashCode() : 0);
        result = 31 * result + (type != null ? type.hashCode() : 0);
        result = 31 * result + (shopid != null ? shopid.hashCode() : 0);
        result = 31 * result + (terminal != null ? terminal.hashCode() : 0);
        result = 31 * result + (fromtime != null ? fromtime.hashCode() : 0);
        result = 31 * result + (totime != null ? totime.hashCode() : 0);
        result = 31 * result + (amount != null ? amount.hashCode() : 0);
        result = 31 * result + (totalnumber != null ? totalnumber.hashCode() : 0);
        result = 31 * result + (occupynumber != null ? occupynumber.hashCode() : 0);
        result = 31 * result + (maxnumber != null ? maxnumber.hashCode() : 0);
        result = 31 * result + (status != null ? status.hashCode() : 0);
        result = 31 * result + (createtime != null ? createtime.hashCode() : 0);
        result = 31 * result + (createby != null ? createby.hashCode() : 0);
        result = 31 * result + (updatetime != null ? updatetime.hashCode() : 0);
        result = 31 * result + (updateby != null ? updateby.hashCode() : 0);
        result = 31 * result + (description != null ? description.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "RpcCouponsApi{" +
                "id=" + id +
                ", batchno='" + batchno + '\'' +
                ", name='" + name + '\'' +
                ", mcode='" + mcode + '\'' +
                ", type=" + type +
                ", shopid='" + shopid + '\'' +
                ", terminal='" + terminal + '\'' +
                ", fromtime=" + fromtime +
                ", totime=" + totime +
                ", amount=" + amount +
                ", totalnumber=" + totalnumber +
                ", occupynumber=" + occupynumber +
                ", maxnumber=" + maxnumber +
                ", status=" + status +
                ", createtime=" + createtime +
                ", createby='" + createby + '\'' +
                ", updatetime=" + updatetime +
                ", updateby='" + updateby + '\'' +
                ", description='" + description + '\'' +
                '}';
    }
}