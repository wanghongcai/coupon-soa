package com.lenovo.m2.couponV2.api.service;

import com.lenovo.m2.arch.framework.domain.PageModel2;
import com.lenovo.m2.arch.framework.domain.PageQuery;
import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.couponV2.api.model.CouponsCategoryApi;

import java.util.List;
import java.util.Map;

/**
 * Created by zhaocl1 on 2015/8/26.
 */
public interface CouponsCategoryService {
    public RemoteResult<CouponsCategoryApi> getCouponsCategory(String id);
    public RemoteResult<PageModel2<CouponsCategoryApi>> getCouponsCategoryInfoPage(PageQuery pageQuery, Map map);
    public RemoteResult<Integer>insertCouponsCategory(CouponsCategoryApi couponsCategoryApi);
    public RemoteResult<Boolean> delCouponsCategory(CouponsCategoryApi couponsCategoryApi);
    public RemoteResult<Boolean> editCouponsCategory(CouponsCategoryApi couponsCategoryApi);
    RemoteResult<Boolean> disableCouponCategoryById(int id);
}
