package com.lenovo.m2.couponV2.api.dubboModel;

import com.lenovo.m2.arch.framework.domain.BaseObject;

/**
 * Created by zhaocl1 on 2016/3/3.
 */
public class ProductInfoApi extends BaseObject{

    //商品code
    String goodscode;
    //商品对应的分类codegroupcode
    String categorycode;
    //商品对应的产品组id
    String productgroupcode;
    int type;//商品类型 0 普通；1 c2c;2 依旧换新
    String facode;

    public String getFacode() {
        return facode;
    }

    public void setFacode(String facode) {
        this.facode = facode;
    }

    public String getProductgroupcode() {
        return productgroupcode;
    }

    public void setProductgroupcode(String productgroupcode) {
        this.productgroupcode = productgroupcode;
    }

    public String getGoodscode() {
        return goodscode;
    }

    public void setGoodscode(String goodscode) {
        this.goodscode = goodscode;
    }

    public String getCategorycode() {
        return categorycode;
    }

    public void setCategorycode(String categorycode) {
        this.categorycode = categorycode;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        ProductInfoApi that = (ProductInfoApi) o;

        if (type != that.type) return false;
        if (categorycode != null ? !categorycode.equals(that.categorycode) : that.categorycode != null) return false;
        if (goodscode != null ? !goodscode.equals(that.goodscode) : that.goodscode != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = goodscode != null ? goodscode.hashCode() : 0;
        result = 31 * result + (categorycode != null ? categorycode.hashCode() : 0);
        result = 31 * result + type;
        return result;
    }

    @Override
    public String toString() {
        return "ProductInfoApi{" +
                "goodscode='" + goodscode + '\'' +
                ", categorycode='" + categorycode + '\'' +
                ", productgroupcode='" + productgroupcode + '\'' +
                ", type=" + type +
                ", facode='" + facode + '\'' +
                '}';
    }
}
