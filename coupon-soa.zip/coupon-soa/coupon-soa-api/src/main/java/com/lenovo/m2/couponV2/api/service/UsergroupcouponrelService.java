package com.lenovo.m2.couponV2.api.service;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.couponV2.api.model.UsergroupcouponrelApi;

import java.util.List;

/**
 * Created by zhaocl1 on 2015/9/15.
 */
public interface UsergroupcouponrelService {
    /**
     * 批量保存
     * @param list
     * @return
     */
    public RemoteResult insertBatch(List<UsergroupcouponrelApi> list);
}
