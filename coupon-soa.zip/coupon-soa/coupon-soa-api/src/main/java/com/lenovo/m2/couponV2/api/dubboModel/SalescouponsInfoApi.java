package com.lenovo.m2.couponV2.api.dubboModel;

import com.lenovo.m2.arch.framework.domain.Money;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

public class SalescouponsInfoApi implements Serializable{

    /**
     * 用户优惠券主键
     */
    private Long id;

    private Long salesCouponId;//优惠券主键ID
    /**
     * 1：普通全场券
     4;专属c2c
     6;专属--依旧换新
     7;专属-依旧换新代金券
     */
    private Integer usescope;
    /**
     *     public static final String COUPON_SHOPID_Lenovo = "Lenovo";//
     public static final String COUPON_SHOPID_Think = "Think";//
     public static final String COUPON_SHOPID_EPP = "EPP";//
     public static final String COUPON_SHOPID_Roaming = "Roaming";//
     public static final String COUPON_SHOPID_Moto = "Moto";//
     */
    private String shopid;
    /**
     *     public static final String COUPON_TERMINAL_PC = "0";//pc
     public static final String COUPON_TERMINAL_WAP = "1";//wap
     public static final String COUPON_TERMINAL_APP = "2";//app
     public static final String COUPON_TERMINAL_WEIXIN = "3";//weixin
     */
    private String terminal;
    /**
     * 名称
     */
    private String name;
    /**
     * 券金额
     */
    private Money amount;
    /**
     * 会员中心使用
     */
    private BigDecimal currencyAmount;
    /**
     * 使用条件
     */
    private Money conditions;
    /**
     *     public static final Integer COUPON_TYPE_DETAIL_1 = 1;//分类
     public static final Integer COUPON_TYPE_PRODUCT_2 = 2;//商品

     */
    private Integer type;
    /**
     * 有效期开始时间
     */
    private Date fromtime;
    /**
     *有效期结束时间
     */
    private Date totime;
    /**
     *券分类
     */
    private Integer classification;
    /**
     *是否叠加
     */
    private Integer superposition;
    /**
     *优惠卷规则描述
     */
    private String description;//优惠券描述

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Integer getUsescope() {
        return usescope;
    }

    public void setUsescope(Integer usescope) {
        this.usescope = usescope;
    }

    public String getShopid() {
        return shopid;
    }

    public void setShopid(String shopid) {
        this.shopid = shopid;
    }

    public String getTerminal() {
        return terminal;
    }

    public void setTerminal(String terminal) {
        this.terminal = terminal;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Money getAmount() {
        return amount;
    }

    public void setAmount(Money amount) {
        this.amount = amount;
    }

    public BigDecimal getCurrencyAmount() {
        return currencyAmount;
    }

    public void setCurrencyAmount(BigDecimal currencyAmount) {
        this.currencyAmount = currencyAmount;
    }

    public Money getConditions() {
        return conditions;
    }

    public void setConditions(Money conditions) {
        this.conditions = conditions;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    public Date getFromtime() {
        return fromtime;
    }

    public void setFromtime(Date fromtime) {
        this.fromtime = fromtime;
    }

    public Date getTotime() {
        return totime;
    }

    public void setTotime(Date totime) {
        this.totime = totime;
    }

    public Integer getClassification() {
        return classification;
    }

    public void setClassification(Integer classification) {
        this.classification = classification;
    }

    public Integer getSuperposition() {
        return superposition;
    }

    public void setSuperposition(Integer superposition) {
        this.superposition = superposition;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Long getSalesCouponId() {
        return salesCouponId;
    }

    public void setSalesCouponId(Long salesCouponId) {
        this.salesCouponId = salesCouponId;
    }

    @Override
    public String toString() {
        return "SalescouponsInfoApi{" +
                "id=" + id +
                ", salesCouponId=" + salesCouponId +
                ", usescope=" + usescope +
                ", shopid='" + shopid + '\'' +
                ", terminal='" + terminal + '\'' +
                ", name='" + name + '\'' +
                ", amount=" + amount +
                ", currencyAmount=" + currencyAmount +
                ", conditions=" + conditions +
                ", type=" + type +
                ", fromtime=" + fromtime +
                ", totime=" + totime +
                ", classification=" + classification +
                ", superposition=" + superposition +
                ", description='" + description + '\'' +
                '}';
    }
}