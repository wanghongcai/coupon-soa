package com.lenovo.m2.couponV2.api.model;


import com.lenovo.m2.arch.framework.domain.Money;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
import java.util.Date;

/**
 * Created by pxg01 on 2017/7/4.
 */

public class OneKeyToReceiveApi implements Serializable{

    private Long id;
    //活动名称
    private String activityName;
    //活动类型
    private Integer activityType;
    //优惠券Id
    private Long  salecouponsId;
    //绑定优惠券Id,多个用逗号隔开
    private String  salecouponsIds;
    //活动开始时间
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date activityfromTime;
    //活动结束时间
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date activitytoTime;
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date oneKeyCreateTime;

    private String oneKeyCreateby;

    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date oneKeyUpdateTime;

    private String oneKeyUpdateby;
    //是否删除 0 否1 删除
    private Integer isDelete;
    private  Integer useable;
    //优惠券属性
    /*s.ID,s.Name,s.Amount,s.Terminal,s.ClassificationName,s.Classification,
    s.IsCanGet,s.Fromtime,s.Totime,s.Status,s.CreateBy,s.UseScope,s.CurrencyCode as currencyCode*/

    private String name;
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date fromTime;
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date toTime;

    public Integer getUseable() {
        return useable;
    }

    public void setUseable(Integer useable) {
        this.useable = useable;
    }

    public String getActivityName() {
        return activityName;
    }

    public void setActivityName(String activityName) {
        this.activityName = activityName;
    }

    public Integer getActivityType() {
        return activityType;
    }

    public void setActivityType(Integer activityType) {
        this.activityType = activityType;
    }

    public Long getSalecouponsId() {
        return salecouponsId;
    }

    public void setSalecouponsId(Long salecouponsId) {
        this.salecouponsId = salecouponsId;
    }

    public String getSalecouponsIds() {
        return salecouponsIds;
    }

    public void setSalecouponsIds(String salecouponsIds) {
        this.salecouponsIds = salecouponsIds;
    }

    public Date getActivityfromTime() {
        return activityfromTime;
    }

    public void setActivityfromTime(Date activityfromTime) {
        this.activityfromTime = activityfromTime;
    }

    public Date getActivitytoTime() {
        return activitytoTime;
    }

    public void setActivitytoTime(Date activitytoTime) {
        this.activitytoTime = activitytoTime;
    }

    public Integer getIsDelete() {
        return isDelete;
    }

    public void setIsDelete(Integer isDelete) {
        this.isDelete = isDelete;
    }

    public Date getOneKeyCreateTime() {
        return oneKeyCreateTime;
    }

    public void setOneKeyCreateTime(Date oneKeyCreateTime) {
        this.oneKeyCreateTime = oneKeyCreateTime;
    }

    public String getOneKeyCreateby() {
        return oneKeyCreateby;
    }

    public void setOneKeyCreateby(String oneKeyCreateby) {
        this.oneKeyCreateby = oneKeyCreateby;
    }

    /*************************/

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Date getFromTime() {
        return fromTime;
    }

    public void setFromTime(Date fromTime) {
        this.fromTime = fromTime;
    }

    public Date getToTime() {
        return toTime;
    }

    public void setToTime(Date toTime) {
        this.toTime = toTime;
    }

    public Date getOneKeyUpdateTime() {
        return oneKeyUpdateTime;
    }

    public void setOneKeyUpdateTime(Date oneKeyUpdateTime) {
        this.oneKeyUpdateTime = oneKeyUpdateTime;
    }

    public String getOneKeyUpdateby() {
        return oneKeyUpdateby;
    }

    public void setOneKeyUpdateby(String oneKeyUpdateby) {
        this.oneKeyUpdateby = oneKeyUpdateby;
    }
}
