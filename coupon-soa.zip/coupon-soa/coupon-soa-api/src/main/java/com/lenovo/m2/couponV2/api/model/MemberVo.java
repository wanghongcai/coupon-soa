package com.lenovo.m2.couponV2.api.model;

import java.io.Serializable;
import java.util.Date;

/**
 * Created by zhanglijun on 2015/9/19.
 */
public class MemberVo implements Serializable{

    //�޸Ĵ�����ͬ���޸�admin�е�MemberVo
    private String     userId;

    private String     username;
    private String    lenovoId;
    private String    memberId;
    private String    userType;
    private String    validFlag;
    private String    loginname;
    private String    mobile;
    private String    email;
    private Date      createTime;
    private String    realname;
    private String    itemname;
    private String    shoplevel;


    private String    itemid;

    private String pageSize;

    private String pageNumber;

    private String  totalCount;


    public String getPageSize() {
        return pageSize;
    }

    public void setPageSize(String pageSize) {
        this.pageSize = pageSize;
    }

    public String getPageNumber() {
        return pageNumber;
    }

    public void setPageNumber(String pageNumber) {
        this.pageNumber = pageNumber;
    }

    public String getTotalCount() {
        return totalCount;
    }

    public void setTotalCount(String totalCount) {
        this.totalCount = totalCount;
    }





    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }
    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getLenovoId() {
        return lenovoId;
    }

    public void setLenovoId(String lenovoId) {
        this.lenovoId = lenovoId;
    }

    public String getMemberId() {
        return memberId;
    }

    public void setMemberId(String memberId) {
        this.memberId = memberId;
    }

    public String getUserType() {
        return userType;
    }

    public void setUserType(String userType) {
        this.userType = userType;
    }

    public String getValidFlag() {
        return validFlag;
    }

    public void setValidFlag(String validFlag) {
        this.validFlag = validFlag;
    }

    public String getLoginname() {
        return loginname;
    }

    public void setLoginname(String loginname) {
        this.loginname = loginname;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getRealname() {
        return realname;
    }

    public void setRealname(String realname) {
        this.realname = realname;
    }

    public String getItemname() {
        return itemname;
    }

    public void setItemname(String itemname) {
        this.itemname = itemname;
    }

    public String getShoplevel() {
        return shoplevel;
    }

    public void setShoplevel(String shoplevel) {
        this.shoplevel = shoplevel;
    }

    public String getItemid() {
        return itemid;
    }

    public void setItemid(String itemid) {
        this.itemid = itemid;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof MemberVo)) return false;

        MemberVo memberVo = (MemberVo) o;

        if (!createTime.equals(memberVo.createTime)) return false;
        if (!email.equals(memberVo.email)) return false;
        if (!itemname.equals(memberVo.itemname)) return false;
        if (!lenovoId.equals(memberVo.lenovoId)) return false;
        if (!loginname.equals(memberVo.loginname)) return false;
        if (!memberId.equals(memberVo.memberId)) return false;
        if (!mobile.equals(memberVo.mobile)) return false;
        if (!realname.equals(memberVo.realname)) return false;
        if (!shoplevel.equals(memberVo.shoplevel)) return false;
        if (!userId.equals(memberVo.userId)) return false;
        if (!userType.equals(memberVo.userType)) return false;
        if (!validFlag.equals(memberVo.validFlag)) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = userId.hashCode();
        result = 31 * result + lenovoId.hashCode();
        result = 31 * result + memberId.hashCode();
        result = 31 * result + userType.hashCode();
        result = 31 * result + validFlag.hashCode();
        result = 31 * result + loginname.hashCode();
        result = 31 * result + mobile.hashCode();
        result = 31 * result + email.hashCode();
        result = 31 * result + createTime.hashCode();
        result = 31 * result + realname.hashCode();
        result = 31 * result + itemname.hashCode();
        result = 31 * result + shoplevel.hashCode();
        return result;
    }


    @Override
    public String toString() {
        return "MemberVo{" +
                "userId='" + userId + '\'' +
                ", username='" + username + '\'' +
                ", lenovoId='" + lenovoId + '\'' +
                ", memberId='" + memberId + '\'' +
                ", userType='" + userType + '\'' +
                ", validFlag='" + validFlag + '\'' +
                ", loginname='" + loginname + '\'' +
                ", mobile='" + mobile + '\'' +
                ", email='" + email + '\'' +
                ", createTime=" + createTime +
                ", realname='" + realname + '\'' +
                ", itemname='" + itemname + '\'' +
                ", shoplevel='" + shoplevel + '\'' +
                ", pageSize='" + pageSize + '\'' +
                ", pageNumber='" + pageNumber + '\'' +
                ", totalCount='" + totalCount + '\'' +
                '}';
    }




}

