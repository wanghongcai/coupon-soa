package com.lenovo.m2.couponV2.api.dubboModel;

import java.io.Serializable;

/**
 * Created by admin on 2016/6/16.
 */
public class ErroeSalesCoupons implements Serializable {

    private Long couponIds;
    private String couponName;
    private String code;
    private String msg;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public Long getCouponIds() {
        return couponIds;
    }

    public void setCouponIds(Long couponIds) {
        this.couponIds = couponIds;
    }

    public String getCouponName() {
        return couponName;
    }

    public void setCouponName(String couponName) {
        this.couponName = couponName;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof ErroeSalesCoupons)) return false;

        ErroeSalesCoupons that = (ErroeSalesCoupons) o;

        if (getCouponIds() != null ? !getCouponIds().equals(that.getCouponIds()) : that.getCouponIds() != null)
            return false;
        if (getCouponName() != null ? !getCouponName().equals(that.getCouponName()) : that.getCouponName() != null)
            return false;
        if (getCode() != null ? !getCode().equals(that.getCode()) : that.getCode() != null) return false;
        return !(getMsg() != null ? !getMsg().equals(that.getMsg()) : that.getMsg() != null);

    }

    @Override
    public int hashCode() {
        int result = getCouponIds() != null ? getCouponIds().hashCode() : 0;
        result = 31 * result + (getCouponName() != null ? getCouponName().hashCode() : 0);
        result = 31 * result + (getCode() != null ? getCode().hashCode() : 0);
        result = 31 * result + (getMsg() != null ? getMsg().hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "ErroeSalesCoupons{" +
                "couponIds=" + couponIds +
                ", couponName='" + couponName + '\'' +
                ", code='" + code + '\'' +
                ", msg='" + msg + '\'' +
                '}';
    }

}
