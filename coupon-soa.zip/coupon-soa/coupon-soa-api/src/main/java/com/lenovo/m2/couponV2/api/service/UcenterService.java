package com.lenovo.m2.couponV2.api.service;

import com.lenovo.m2.couponV2.api.model.MemberVo;

import java.util.Date;

/**
 * Created by yezhenyue on 2016/3/4.
 */
public interface UcenterService {
    /**
     * 根据lenovoid查询用户注册时间
     * @param lenovoId
     * @return
     */
    public Date getMemberRegisterTime(String lenovoId,String shopid);
}
