package com.lenovo.m2.couponV2.api.OldforNewModel;
import java.io.Serializable;

/**
 * 
* @ClassName: SendCouponOldforNewOrderVo
* @Description: 订单发券接口接收参数
* @author yuzj7@lenovo.com
* @date 2015年5月13日 下午2:27:56
*
 */
public class SendCouponOldforNewOrderVo implements Serializable {

	private static final long serialVersionUID = 8462215586094449765L;

	private String orderId;  //订单Id
	private String lenovoid;  // 联想Id
	private String payType;  //支付方式
	private String payTime;  //结算日期
	private String settlePrice; //结算价格
	private String partnerId;  //合作商id	联想赋予有得卖的合作ID
	private String sign;
	private String shopId;  //商户Id

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public String getLenovoid() {
		return lenovoid;
	}

	public void setLenovoid(String lenovoid) {
		this.lenovoid = lenovoid;
	}

	public String getPayType() {
		return payType;
	}

	public void setPayType(String payType) {
		this.payType = payType;
	}

	public String getPayTime() {
		return payTime;
	}

	public void setPayTime(String payTime) {
		this.payTime = payTime;
	}

	public String getSettlePrice() {
		return settlePrice;
	}

	public void setSettlePrice(String settlePrice) {
		this.settlePrice = settlePrice;
	}

	public String getPartnerId() {
		return partnerId;
	}

	public void setPartnerId(String partnerId) {
		this.partnerId = partnerId;
	}

	public String getSign() {
		return sign;
	}

	public void setSign(String sign) {
		this.sign = sign;
	}

	public String getShopId() {
		return shopId;
	}

	public void setShopId(String shopId) {
		this.shopId = shopId;
	}

	@Override
	public String toString() {
		return "SendCouponOldforNewOrderVo{" +
				"orderId='" + orderId + '\'' +
				", lenovoid='" + lenovoid + '\'' +
				", payType='" + payType + '\'' +
				", payTime='" + payTime + '\'' +
				", settlePrice='" + settlePrice + '\'' +
				", partnerId='" + partnerId + '\'' +
				", sign='" + sign + '\'' +
				", shopId='" + shopId + '\'' +
				'}';
	}
}
