package com.lenovo.m2.couponV2.api.service;

import com.lenovo.m2.arch.framework.domain.PageModel2;
import com.lenovo.m2.arch.framework.domain.PageQuery;
import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.framework.domain.Tenant;
import com.lenovo.m2.couponV2.api.model.MemberVo;
import com.lenovo.m2.couponV2.api.model.SalescouponsApi;
import com.lenovo.m2.couponV2.api.model.ShowInfo;

import java.util.List;
import java.util.Map;

/**
 * Created by zhaocl1 on 2015/8/26.
 */
public interface SalescouponsService {

    /**
     * 获取优惠卷列表
     * @param pageQuery
     * @param map
     * @return
     */
    public RemoteResult<PageModel2<SalescouponsApi>> getSalescouponsInfoPage(PageQuery pageQuery,Map map);

    /**
     * 保存优惠券
     * @param salescouponsApi
     * @return
     */
    public RemoteResult insertSalescoupons(SalescouponsApi salescouponsApi);

    /**
     * 查看优惠券
     * @param salescouponsApi
     * @return
     */
    public RemoteResult<SalescouponsApi> getSalescoupons(SalescouponsApi salescouponsApi);

    /**
     * 删除优惠券信息
     * @param salescouponsApi
     * @return
     */
    public RemoteResult<Boolean> delSalescoupons(SalescouponsApi salescouponsApi);

    /**
     * 更新优惠券
     * @param salescouponsApi
     * @return
     */
    public RemoteResult editSalescoupons(SalescouponsApi salescouponsApi) throws Exception;

    /**
     * 只更新优惠券主表
     * @param salescouponsApi
     * @return
     */
    public RemoteResult editSalescouponsOnly(SalescouponsApi salescouponsApi);

    /**
     * 根据主键ids，批量查询
     * @param map
     * @return
     */
    public RemoteResult<List<SalescouponsApi>> getSalescouponsList(Map map);

    RemoteResult<Boolean> submitToCheckBatch(List<SalescouponsApi> list);
    /**
     * 给指定用户发券
     * @param couponid
     * @param list
     * @return
     */
    RemoteResult<Boolean> sendCouponsToMember(Long couponid, List<MemberVo> list,String itCode);

    /**
     * 绑券接口
     * @param couponId
     * @param lenovoId
     * @param memberCode
     * @return
     */
    @Deprecated
    RemoteResult<Boolean> bindCoupons(Long couponId,String lenovoId,String memberCode);

    /**
     * 绑券接口（新）
     * @param couponId
     * @param lenovoId
     * @param memberCode
     * @param shopId
     * @return
     */
    @Deprecated
    RemoteResult<Boolean> bindCoupons(String shopId, Long couponId, String lenovoId, String memberCode);

    /**
     * 绑券接口
     * @param tenant
     * @param couponId
     * @param lenovoId
     * @param memberCode
     * @return
     */
    RemoteResult<Boolean> bindCoupons(Tenant tenant, Long couponId, String lenovoId, String memberCode);

    /**
     * 单个绑券，优惠券只能领取一次
     * @param shopId
     * @param couponId
     * @param lenovoId
     * @param memberCode
     * @return
     */
    @Deprecated
    RemoteResult<Boolean> bindCouponsForOnce(String shopId, Long couponId, String lenovoId, String memberCode);

    /**
     * 单个绑券，优惠券只能领取一次
     * @param tenant
     * @param couponId
     * @param lenovoId
     * @param memberCode
     * @return
     */
    RemoteResult<Boolean> bindCouponsForOnce(Tenant tenant, Long couponId, String lenovoId, String memberCode);

    /**
     * 向redis中删除数据
     * @return
     */
    public RemoteResult deleteSalescoupons4redis(SalescouponsApi salescouponsApi) throws Exception;

    /**
     * 根据优惠券id更新通知有效次数
     * @param id
     * @return
     */
    public RemoteResult updateNoticeValidCount(Long id);

    /**
     * 根据优惠券id更新通知无效次数
     * @param id
     * @return
     */
    public RemoteResult updateNoticeInvalidCount(Long id);

    /**
     * 根据id查询优惠券
     * @param map
     * @return
     */
    public RemoteResult<List<SalescouponsApi>> getSalescouponsforIds(Map map);

    /**
     * 根据优惠券分类ID查询优惠券
     * @param map
     * @return
     */
    public RemoteResult<PageModel2<SalescouponsApi>> getSalescouponsByClassification(PageQuery pageQuery,Map map);

    /**
     * 根据优惠券ID查询优惠券
     * @param pageQuery
     * @param map
     * @return
     */
    public RemoteResult<PageModel2<SalescouponsApi>> getSalescouponsBySalesCouponIds(PageQuery pageQuery,Map map);

    /**
     *获取优惠券可领取数量
     * @param map
     * @return
     */
    public RemoteResult getSalesCouponsNumbersForId(Map map);


    /**
     *获取优惠券可领取数量(后台使用)
     * @param map
     * @return
     */
    public RemoteResult getSalesNumbersManagerment(Map map);

    /**
     * 获取优惠券已领取数量
     * @param map
     * @return
     */
    public RemoteResult getIsHaveSalesCouponsNum(Map map);

    /**
     * 获取优惠券最大发放张数
     * @param id
     * @return
     */
    public RemoteResult getSalesCouponsMaxNumber(Long id);

    /**
     * 获取所有可领取优惠
     * @param pageQuery
     * @param map
     * @return
     */
    public RemoteResult<PageModel2<SalescouponsApi>> getAvailableSalescouponsInfoPage(PageQuery pageQuery, Map map);

    /**
     * 获取满足领取条件的优惠券列表（审核通过、可领取、当前时间在可领取区间内、在有效期内）
     * @param pageQuery
     * @param map
     * @return
     */
    public RemoteResult<PageModel2<SalescouponsApi>> getAllAvailableSalescouponsInfopage(PageQuery pageQuery, Map map);

    /**
     * 分页获取可领取的优惠券（领券中心使用）
     * @param pageQuery
     * @return
     */
    public RemoteResult<PageModel2<SalescouponsApi>> getDistributeSalescoupons(PageQuery pageQuery);
    /**
     * 分页获取可领取的优惠券（领券中心使用）yuzj7 2017年4月26日11:18:18 重载
     * @param pageQuery
     * @param displayPosition 0,全场，1 小新
     * @return
     */
    public RemoteResult<PageModel2<SalescouponsApi>> getDistributeSalescoupons(Tenant tenant,PageQuery pageQuery,Integer displayPosition);
    @Deprecated
    public RemoteResult<PageModel2<SalescouponsApi>> getDistributeSalescoupons(PageQuery pageQuery,Integer displayPosition);

    /**
     * 根据优惠券ID，获取优惠券基本信息
     * @param id
     * @return
     */
    public RemoteResult<SalescouponsApi> getSalescouponsById(Long id);
    /**
     * 根据优惠券IDs，获取优惠券基本信息 慧商积分商城显示列表
     * @param ids
     * @return
     */
    public RemoteResult<List<SalescouponsApi>> getSalescouponsByIds(List ids);

    /**
     * 根据Tenant 和 useScope 获取所有符合条件的优惠券
     * @param tenant
     * @param useScope 优惠券基本类型 1：普通券  4：专属券-c2c  6：专属券-以旧换新  10：惠商券
     * @return
     */
    public RemoteResult<List<SalescouponsApi>> getSalescouponsByUseScope(Tenant tenant, int useScope, Long salescouponId, String couponName);
    public RemoteResult<List<ShowInfo>> getShowInfoByShopId(Tenant tenent);
}
