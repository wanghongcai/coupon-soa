package com.lenovo.m2.couponV2.api.service;

import com.lenovo.m2.arch.framework.domain.PageModel2;
import com.lenovo.m2.arch.framework.domain.PageQuery;
import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.couponV2.api.model.CouponReportApi;

import java.util.Map;

/**
 * Created by fenglg1 on 2017/1/9.
 */
public interface CouponReportService {

    /**
     * 根据条件查询优惠券领取及使用数据
     * @param pageQuery
     * @param map
     * @return
     */
    public RemoteResult<PageModel2<CouponReportApi>> getCouponReportInfoPage(PageQuery pageQuery, Map map);

    /**
     * 根据订单ID查询优惠券及订单号
     * @param pageQuery
     * @param map
     * @return
     */
    public RemoteResult<PageModel2<CouponReportApi>> getCouponAndOrderIdInfoPage(PageQuery pageQuery, Map map);
}
