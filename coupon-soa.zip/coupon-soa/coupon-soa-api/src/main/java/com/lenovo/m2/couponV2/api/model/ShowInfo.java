package com.lenovo.m2.couponV2.api.model;

import com.lenovo.m2.couponV2.api.dubboModel.DisplayPositionEnum;

import java.io.Serializable;

/**
 * Created by pxg01 on 2017/7/12.
 */
public class ShowInfo implements Serializable{
    private Integer shopId;
    private  Integer showNo;
    private  String  showMsg;

public ShowInfo(){};
public ShowInfo(Integer shopId, DisplayPositionEnum displayPositionEnum){
    this.shopId = shopId;
    this.showNo = Integer.parseInt(displayPositionEnum.getCode());

    this.showMsg = displayPositionEnum.getDesc();
};
    public Integer getShopId() {
        return shopId;
    }

    public void setShopId(Integer shopId) {
        this.shopId = shopId;
    }

    public Integer getShowNo() {
        return showNo;
    }

    public void setShowNo(Integer showNo) {
        this.showNo = showNo;
    }

    public String getShowMsg() {
        return showMsg;
    }

    public void setShowMsg(String showMsg) {
        this.showMsg = showMsg;
    }
}
