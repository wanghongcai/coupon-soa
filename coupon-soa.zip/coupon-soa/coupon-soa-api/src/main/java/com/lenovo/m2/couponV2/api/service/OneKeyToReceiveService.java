package com.lenovo.m2.couponV2.api.service;

import com.lenovo.m2.arch.framework.domain.PageModel2;
import com.lenovo.m2.arch.framework.domain.PageQuery;
import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.couponV2.api.model.OneKeyToReceiveApi;
import com.lenovo.m2.couponV2.api.model.SalescouponsApi;

import java.util.Map;

/**
 * Created by pxg01 on 2017/7/4.
 */
public interface OneKeyToReceiveService {
    //添加活动
    public RemoteResult addReceiveActivity(OneKeyToReceiveApi oneKeyToReceiveApi);
    //编辑活动
    public RemoteResult editReceiveActivity(OneKeyToReceiveApi oneKeyToReceiveApi);

    //删除活动
    public RemoteResult deleteReceiveActivity(Map map);
    //查询活动信息
    public RemoteResult<PageModel2<OneKeyToReceiveApi>> getReceiveActivity(PageQuery pageQuery,Map map);
    //查询用户是否参加过该活动
    public RemoteResult confirmUserIfJoinTheAcitity(String lenovoId ,Integer activityType);
    //新建活动时查询优惠券信息
    public RemoteResult<PageModel2<SalescouponsApi>> getAviableSalesCoupons(PageQuery pageQuery, OneKeyToReceiveApi oneKeyToReceiveApi);
    //为参加活动用户绑券
    public RemoteResult bindCouponsForOneKeyPeople(String lenovoId,Integer activityType,String memberCode);
    //查询优惠券绑定的活动详情
    public RemoteResult getOneKeyReceiveSalesCouponsInfo(Long activityId);
    //启用停用
    public RemoteResult setOneKeyUseable(Long activityId,Integer useable,String updateBy);
}
