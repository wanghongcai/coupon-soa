package com.lenovo.m2.couponV2.api.dubboModel;

import java.io.Serializable;
import java.util.List;

/**
 * Created by zhaocl1 on 2016/3/7.
 */
public class CouponsJsonApi implements Serializable {

    private Long id;//优惠码主键id
    private String code ;//优惠码code
    private String amount;//优惠码金额
    private List<String> goodsCodesList;//该优惠码适用的商品集合

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public List<String> getGoodsCodesList() {
        return goodsCodesList;
    }

    public void setGoodsCodesList(List<String> goodsCodesList) {
        this.goodsCodesList = goodsCodesList;
    }

    @Override
    public String toString() {
        return "CouponsJsonApi{" +
                "id=" + id +
                ", code='" + code + '\'' +
                ", amount='" + amount + '\'' +
                ", goodsCodesList=" + goodsCodesList +
                '}';
    }
}
