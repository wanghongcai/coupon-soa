package com.lenovo.m2.couponV2.api.model;

import com.lenovo.m2.arch.framework.domain.BaseObject;
import com.lenovo.m2.arch.framework.domain.Money;

import java.sql.Timestamp;
import java.util.Date;

/**
 * Created by fenglg1 on 2017/1/17.
 */
public class CouponOrderReportApi extends BaseObject {

    /**
     * 优惠券主键
     */
    private Long id;
    /**
     * LenovoID
     */
    private String lenovoid;
    /**
     * 会员帐号
     */
    private String membercode;
    /**
     * 优惠券ID
     */
    private Long salescouponid;
    /**
     * 优惠券名称
     */
    private String name;
    /**
     * 优惠券面值
     */
    private Money amount;
    /**
     * 币种
     */
    private String currencyCode;
    /**
     * 优惠券使用状态  0：未使用  1：已使用
     */
    private Integer status;
    /**
     * 优惠券使用时间
     */
    private Date usetime;
    /**
     * 主订单号
     */
    private String mainOrderCode;
    /**
     * 子订单号
     */
    private String subOrderCode;
    /**
     * 订单金额
     */
    private Money totalCost;
    /**
     * 支付金额
     */
    private Money totalPay;
    /**
     * 产品组
     */
    private String deatLike;
    /**
     * 物料编号
     */
    private String materialCode;
    /**
     * 商品名称
     */
    private String goodsName;
    /**
     * 商品编号
     */
    private String goodsCode;
    /**
     * 商品数量
     */
    private int num;
    /**
     * 商品数量字符串值
     */
    private String numStr;
    /**
     * 下单时间
     */
    private Timestamp createTime;
    /**
     * 支付时间
     */
    private Timestamp paidTime;
    /**
     * 收件人
     */
    private String receiver;
    /**
     * 收件人手机号
     */
    private String mobile;
    /**
     * 省/市
     */
    private String province;
    /**
     * 市
     */
    private String city;
    /**
     * 县
     */
    private String county;
    /**
     * 详细地址
     */
    private String address;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getLenovoid() {
        return lenovoid;
    }

    public void setLenovoid(String lenovoid) {
        this.lenovoid = lenovoid;
    }

    public String getMembercode() {
        return membercode;
    }

    public void setMembercode(String membercode) {
        this.membercode = membercode;
    }

    public Long getSalescouponid() {
        return salescouponid;
    }

    public void setSalescouponid(Long salescouponid) {
        this.salescouponid = salescouponid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Money getAmount() {
        return amount;
    }

    public void setAmount(Money amount) {
        this.amount = amount;
    }

    public String getCurrencyCode() {
        return currencyCode;
    }

    public void setCurrencyCode(String currencyCode) {
        this.currencyCode = currencyCode;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Date getUsetime() {
        return usetime;
    }

    public void setUsetime(Date usetime) {
        this.usetime = usetime;
    }

    public String getMainOrderCode() {
        return mainOrderCode;
    }

    public void setMainOrderCode(String mainOrderCode) {
        this.mainOrderCode = mainOrderCode;
    }

    public String getSubOrderCode() {
        return subOrderCode;
    }

    public void setSubOrderCode(String subOrderCode) {
        this.subOrderCode = subOrderCode;
    }

    public Money getTotalCost() {
        return totalCost;
    }

    public void setTotalCost(Money totalCost) {
        this.totalCost = totalCost;
    }

    public Money getTotalPay() {
        return totalPay;
    }

    public void setTotalPay(Money totalPay) {
        this.totalPay = totalPay;
    }

    public String getDeatLike() {
        return deatLike;
    }

    public void setDeatLike(String deatLike) {
        this.deatLike = deatLike;
    }

    public String getMaterialCode() {
        return materialCode;
    }

    public void setMaterialCode(String materialCode) {
        this.materialCode = materialCode;
    }

    public String getGoodsName() {
        return goodsName;
    }

    public void setGoodsName(String goodsName) {
        this.goodsName = goodsName;
    }

    public String getGoodsCode() {
        return goodsCode;
    }

    public void setGoodsCode(String goodsCode) {
        this.goodsCode = goodsCode;
    }

    public int getNum() {
        return num;
    }

    public void setNum(int num) {
        this.num = num;
    }

    public String getNumStr() {
        return numStr;
    }

    public void setNumStr(String numStr) {
        this.numStr = numStr;
    }

    @Override
    public Timestamp getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Timestamp createTime) {
        this.createTime = createTime;
    }

    public Timestamp getPaidTime() {
        return paidTime;
    }

    public void setPaidTime(Timestamp paidTime) {
        this.paidTime = paidTime;
    }

    public String getReceiver() {
        return receiver;
    }

    public void setReceiver(String receiver) {
        this.receiver = receiver;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getCounty() {
        return county;
    }

    public void setCounty(String county) {
        this.county = county;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        CouponOrderReportApi that = (CouponOrderReportApi) o;

        if (num != that.num) return false;
        if (address != null ? !address.equals(that.address) : that.address != null) return false;
        if (amount != null ? !amount.equals(that.amount) : that.amount != null) return false;
        if (city != null ? !city.equals(that.city) : that.city != null) return false;
        if (county != null ? !county.equals(that.county) : that.county != null) return false;
        if (createTime != null ? !createTime.equals(that.createTime) : that.createTime != null) return false;
        if (currencyCode != null ? !currencyCode.equals(that.currencyCode) : that.currencyCode != null) return false;
        if (deatLike != null ? !deatLike.equals(that.deatLike) : that.deatLike != null) return false;
        if (goodsCode != null ? !goodsCode.equals(that.goodsCode) : that.goodsCode != null) return false;
        if (goodsName != null ? !goodsName.equals(that.goodsName) : that.goodsName != null) return false;
        if (id != null ? !id.equals(that.id) : that.id != null) return false;
        if (lenovoid != null ? !lenovoid.equals(that.lenovoid) : that.lenovoid != null) return false;
        if (mainOrderCode != null ? !mainOrderCode.equals(that.mainOrderCode) : that.mainOrderCode != null)
            return false;
        if (materialCode != null ? !materialCode.equals(that.materialCode) : that.materialCode != null) return false;
        if (membercode != null ? !membercode.equals(that.membercode) : that.membercode != null) return false;
        if (mobile != null ? !mobile.equals(that.mobile) : that.mobile != null) return false;
        if (name != null ? !name.equals(that.name) : that.name != null) return false;
        if (paidTime != null ? !paidTime.equals(that.paidTime) : that.paidTime != null) return false;
        if (province != null ? !province.equals(that.province) : that.province != null) return false;
        if (receiver != null ? !receiver.equals(that.receiver) : that.receiver != null) return false;
        if (salescouponid != null ? !salescouponid.equals(that.salescouponid) : that.salescouponid != null)
            return false;
        if (status != null ? !status.equals(that.status) : that.status != null) return false;
        if (subOrderCode != null ? !subOrderCode.equals(that.subOrderCode) : that.subOrderCode != null) return false;
        if (totalCost != null ? !totalCost.equals(that.totalCost) : that.totalCost != null) return false;
        if (totalPay != null ? !totalPay.equals(that.totalPay) : that.totalPay != null) return false;
        if (usetime != null ? !usetime.equals(that.usetime) : that.usetime != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = id != null ? id.hashCode() : 0;
        result = 31 * result + (lenovoid != null ? lenovoid.hashCode() : 0);
        result = 31 * result + (membercode != null ? membercode.hashCode() : 0);
        result = 31 * result + (salescouponid != null ? salescouponid.hashCode() : 0);
        result = 31 * result + (name != null ? name.hashCode() : 0);
        result = 31 * result + (amount != null ? amount.hashCode() : 0);
        result = 31 * result + (currencyCode != null ? currencyCode.hashCode() : 0);
        result = 31 * result + (status != null ? status.hashCode() : 0);
        result = 31 * result + (usetime != null ? usetime.hashCode() : 0);
        result = 31 * result + (mainOrderCode != null ? mainOrderCode.hashCode() : 0);
        result = 31 * result + (subOrderCode != null ? subOrderCode.hashCode() : 0);
        result = 31 * result + (totalCost != null ? totalCost.hashCode() : 0);
        result = 31 * result + (totalPay != null ? totalPay.hashCode() : 0);
        result = 31 * result + (deatLike != null ? deatLike.hashCode() : 0);
        result = 31 * result + (materialCode != null ? materialCode.hashCode() : 0);
        result = 31 * result + (goodsName != null ? goodsName.hashCode() : 0);
        result = 31 * result + (goodsCode != null ? goodsCode.hashCode() : 0);
        result = 31 * result + num;
        result = 31 * result + (createTime != null ? createTime.hashCode() : 0);
        result = 31 * result + (paidTime != null ? paidTime.hashCode() : 0);
        result = 31 * result + (receiver != null ? receiver.hashCode() : 0);
        result = 31 * result + (mobile != null ? mobile.hashCode() : 0);
        result = 31 * result + (province != null ? province.hashCode() : 0);
        result = 31 * result + (city != null ? city.hashCode() : 0);
        result = 31 * result + (county != null ? county.hashCode() : 0);
        result = 31 * result + (address != null ? address.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "CouponOrderReportApi{" +
                "id=" + id +
                ", lenovoid='" + lenovoid + '\'' +
                ", membercode='" + membercode + '\'' +
                ", salescouponid=" + salescouponid +
                ", name='" + name + '\'' +
                ", amount=" + amount +
                ", currencyCode='" + currencyCode + '\'' +
                ", status=" + status +
                ", usetime=" + usetime +
                ", mainOrderCode='" + mainOrderCode + '\'' +
                ", subOrderCode='" + subOrderCode + '\'' +
                ", totalCost=" + totalCost +
                ", totalPay=" + totalPay +
                ", deatLike='" + deatLike + '\'' +
                ", materialCode='" + materialCode + '\'' +
                ", goodsName='" + goodsName + '\'' +
                ", goodsCode='" + goodsCode + '\'' +
                ", num=" + num +
                ", createTime=" + createTime +
                ", paidTime=" + paidTime +
                ", receiver='" + receiver + '\'' +
                ", mobile='" + mobile + '\'' +
                ", province='" + province + '\'' +
                ", city='" + city + '\'' +
                ", county='" + county + '\'' +
                ", address='" + address + '\'' +
                '}';
    }
}
