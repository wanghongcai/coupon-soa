package com.lenovo.m2.couponV2.api.dubboModel;

import com.lenovo.m2.arch.framework.domain.BaseObject;

/**
 * Created by yezhenyue on 2016/6/14.
 */
public class KcodeParam extends BaseObject {
    private String kcode;//K码
    private String productCode;//商品code
    private String token;//订单临时id
    private String orderCode;//订单号
    private String lenovoId;

    public String getKcode() {
        return kcode;
    }

    public void setKcode(String kcode) {
        this.kcode = kcode;
    }

    public String getProductCode() {
        return productCode;
    }

    public void setProductCode(String productCode) {
        this.productCode = productCode;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getOrderCode() {
        return orderCode;
    }

    public void setOrderCode(String orderCode) {
        this.orderCode = orderCode;
    }

    public String getLenovoId() {
        return lenovoId;
    }

    public void setLenovoId(String lenovoId) {
        this.lenovoId = lenovoId;
    }

    @Override
    public String toString() {
        return "KcodeParam{" +
                "kcode='" + kcode + '\'' +
                ", productCode='" + productCode + '\'' +
                ", token='" + token + '\'' +
                ", orderCode='" + orderCode + '\'' +
                ", lenovoId='" + lenovoId + '\'' +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        return false;
    }

    @Override
    public int hashCode() {
        return 0;
    }
}
