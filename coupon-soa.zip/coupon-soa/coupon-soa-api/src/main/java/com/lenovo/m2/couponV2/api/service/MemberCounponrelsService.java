package com.lenovo.m2.couponV2.api.service;

import com.lenovo.m2.arch.framework.domain.PageModel2;
import com.lenovo.m2.arch.framework.domain.PageQuery;
import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.framework.domain.Tenant;
import com.lenovo.m2.couponV2.api.model.MembercouponrelsApi;
import com.lenovo.m2.couponV2.common.usercenter.RemoteLenovo;

import java.util.List;
import java.util.Map;

/**
 * Created by yezhenyue on 2016/1/19.
 */
public interface MemberCounponrelsService {
    /**
     * 分页获取用户优惠券列表
     * @param pageQuery
     * @param map
     * @return
     */
    public RemoteResult<PageModel2<MembercouponrelsApi>> getMemberCouponrelsPage(PageQuery pageQuery,Map map);

    /**
     * 根据主键id禁用用户优惠券
     * @param id
     * @return
     */
    @Deprecated
    RemoteResult<Boolean> disableMemberCouponById(long id);

    /**
     * 根据主键id禁用用户优惠券
     * @param id
     * @return
     */
    RemoteResult<Boolean> disableMemberCouponByIdandLenovoId(long id,String lenovoId);
    /*TODO*/
    RemoteResult<MembercouponrelsApi> queryMemberCouponById(long id);

    /**
     * 绑定全员券方法
     * @param lenovoid
     * @param memberCode
     * @param groupcode
     * @param shopid
     * @return
     */
    @Deprecated
    public int bindAllMemberSalesCoupons(String lenovoid, String memberCode, String groupcode, String shopid);

    /**
     * 绑定全员券方法
     * @param tenant
     * @param lenovoid
     * @param memberCode
     * @param groupcode
     * @return
     */
    @Deprecated
    public int bindAllMemberSalesCoupons(Tenant tenant, String lenovoid, String memberCode, String groupcode);
    /**
     * 绑定全员券方法 yuzj7 2017年6月12日17:14:05 edit 规范返回值类型
     * @param tenant
     * @param lenovoid
     * @param memberCode
     * @param groupcode
     * @return
     */
    public RemoteResult<Integer> bindAllMemberSalesCouponsN(Tenant tenant, String lenovoid, String memberCode, String groupcode);

    /**
     * 查询用户在商城拥有多少优惠券（数量）
     * @param tenant
     * @param lenovoid
     * @param terminal
     * @return
     */
    public RemoteResult<Integer> getMembercouponrelsByUser(Tenant tenant, String lenovoid, String terminal);


    /**
     * 根据商城、终端、状态查询优惠券
     * @param lenovoId
     * @param shopid 字符串 Lenovo，Think，EPP
     * @param terminal 1pc 2wap 3app 4微信
     * @param status 0未使用  1已使用
     * @param pageQuery
     * @return
     */
    @Deprecated
    RemoteResult<PageModel2<MembercouponrelsApi>> getAppSaleCoupons(String lenovoId, String shopid, String terminal, String status, PageQuery pageQuery);

    /**
     * 根据商城、终端、状态查询优惠券
     * @param tenant
     * @param lenovoId
     * @param terminal
     * @param status
     * @param pageQuery
     * @return
     */
    RemoteResult<PageModel2<MembercouponrelsApi>> getAppSaleCoupons(Tenant tenant, String lenovoId, String terminal, String status, PageQuery pageQuery);

    /**
     * 根据商城、终端、状态查询优惠券
     * @param lenovoId
     * @param shopid 字符串 Lenovo，Think，EPP
     * @param terminal 1pc 2wap 3app 4微信
     * @param status 0未使用  1已使用
     * @param pageQuery
     * @return
     */
    @Deprecated
    RemoteLenovo<PageModel2<MembercouponrelsApi>> getMemberCouponrelsPage4UserCenter(String lenovoId, String shopid, String terminal, String status, String time, PageQuery pageQuery);

    /**
     * 根据商城、终端、状态查询优惠券
     * @param tenant
     * @param lenovoId
     * @param terminal
     * @param status
     * @param time
     * @param pageQuery
     * @return
     */
    RemoteLenovo<PageModel2<MembercouponrelsApi>> getMemberCouponrelsPage4UserCenter(Tenant tenant, String lenovoId, String terminal, String status, String time, PageQuery pageQuery);

    /**
     * 根据商城、终端、状态查询优惠券
     * @param lenovoId
     * @param shopid 字符串 Lenovo，Think，EPP
     * @param terminal 1pc 2wap 3app 4微信
     * @param status 0未使用  1已使用
     * @param pageQuery
     * @return
     */
    @Deprecated
    RemoteLenovo<PageModel2<MembercouponrelsApi>> getMemberCouponrelsPage4WapUserCenter(String lenovoId, String shopid, String terminal, String status, PageQuery pageQuery);

    /**
     * 根据商城、终端、状态查询优惠券
     * @param tenant
     * @param lenovoId
     * @param terminal
     * @param status
     * @param pageQuery
     * @return
     */
    RemoteLenovo<PageModel2<MembercouponrelsApi>> getMemberCouponrelsPage4WapUserCenter(Tenant tenant, String lenovoId, String terminal, String status, PageQuery pageQuery);

    /**
     * 批量插入excel用户优惠券
     * @param list
     * @return
     */
    public RemoteResult insertBatchMembercouponrels(List<MembercouponrelsApi> list);

    /**
     * 获取用户优惠券使用状态
     * @param map
     * @return
     */
    public RemoteResult getMemberCouponsStatus(Map map);

    /**
     * 根据优惠券ID查询已经领取该券的用户列表
     * @param salesCouponId
     * @return
     */
    public RemoteResult<List<MembercouponrelsApi>> getMemberCouponRelBySalesCouponId(Long salesCouponId);
    /**
     * 批量更新用户优惠券
     * @param list
     * @return
     */
    public RemoteResult updateBatchMembercouponrels(List<MembercouponrelsApi> list);
    /**
     * 批量插入excel用户优惠券
     * @param list
     * @return
     */
    public RemoteResult insertBatchMembercouponrelsSharding(List<MembercouponrelsApi> list);
}
