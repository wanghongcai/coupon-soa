package com.lenovo.m2.couponV2.api.dubboService;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.framework.domain.Tenant;
import com.lenovo.m2.couponV2.api.dubboModel.ProductInfoApi;
import com.lenovo.m2.couponV2.api.model.SalescouponsApi;

/**
 * Created by zhaocl1 on 2016/3/10.
 */
public interface RpcSalescouponsService {
    /**
     * 根据id查询优惠券
     * @param id
     * @return
     */
    public RemoteResult getSalescouponsById(long id);

    /**
     * 领取epp优惠券
     * @param couponway 1 注册后送券；2 订单成功后送券
     * @param lenovoid
     * @param memberCode
     * @return
     */
    public RemoteResult<Boolean> addEppCoupon(int couponway, String lenovoid, String memberCode);

    /**
     * 领取epp优惠券
     * @param tenant
     * @param couponway  1: 注册后送券；2: 订单成功后送券
     * @param lenovoid
     * @param memberCode
     * @return
     */
    public RemoteResult<Boolean> addEppCoupon(Tenant tenant, int couponway, String lenovoid, String memberCode);

    /**
     * 领取epp优惠券
     * @param shopId 商户号
     * @param couponway 1 注册后送券；2 订单成功后送券
     * @param lenovoid
     * @param memberCode
     * @return
     */
    @Deprecated
    public RemoteResult<Boolean> addEppCoupon(String shopId, int couponway, String lenovoid, String memberCode);

    /**
     * 获取有效的优惠券信息
     * @return
     */
    public RemoteResult getSalescouponsValidList();

    /**
     * 通过商品查找有效的券
     * @param tenant
     * @param productInfoApi
     * @param terminal
     * @return
     */
    public RemoteResult getSalescouponsByGoodsCode(Tenant tenant, ProductInfoApi productInfoApi, String terminal);

    /**
     * 通过商品查找有效的券
     * @param productInfoApi
     * @param shopId
     * @param terminal
     * @return
     */
    @Deprecated
    public RemoteResult getSalescouponsByGoodsCode(ProductInfoApi productInfoApi, String shopId, String terminal);
}
