package com.lenovo.m2.couponV2.api.service;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.couponV2.api.dubboModel.DisplayPositionEnum;
import com.lenovo.m2.couponV2.api.model.AvailableSalescouponsApi;

import java.util.LinkedList;
import java.util.List;

/**
 * Created by fenglg1 on 2016/12/15.
 */
public interface AvailableSalescouponsService {

    /**
     * 获取全部已选取的可以领取的优惠券
     * @return
     */
    public RemoteResult<List<AvailableSalescouponsApi>> getAllSelectedAvailableSalescoupons();

   
    
    /**
     * 
    * @Title: saveAvailableSalescoupons
    * @Description: 保存可以领取的优惠券
    * @param availableSalescouponsList
    * @param displayPositionEnum
    * @return    设定文件
    * @throws
     */
    public RemoteResult saveAvailableSalescoupons(List<AvailableSalescouponsApi> availableSalescouponsList,DisplayPositionEnum displayPositionEnum);

    /**
     * 将指定的优惠券从可领取队列中删除
     * @param operator
     * @param salesCouponsId
     * @return
     */
    public RemoteResult deleteAvailableSalescoupons(String operator, Long salesCouponsId,String displayPosition);

    /**
     * 清空可领取优惠券列表
     * @param operator
     * @return
     */
    public RemoteResult deleteAllSelectedAvailableSalescoupons(String operator);
}
