package com.lenovo.m2.couponV2.api.service;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.couponV2.api.model.ProductruleApi;

import java.util.List;

/**
 * Created by zhaocl1 on 2016/2/15.
 */
public interface ProductruleService {

    /**
     * 保存优惠券关联商品数据
     * @param productruleApi
     * @return
     */
    public RemoteResult insertProductrule(ProductruleApi productruleApi);

    /**
     * 通过优惠券id批量删除该券对应的商品数据
     * @param productruleApi
     * @return
     */
    public RemoteResult delProductrule(ProductruleApi productruleApi);

    /**
     * 通过优惠券id查看该券下面的商品
     * @param productruleApi
     * @return
     */
    public RemoteResult<List<ProductruleApi>> getProductruleList(ProductruleApi productruleApi);
}
