package com.lenovo.m2.couponV2.api.service;

import com.lenovo.m2.arch.framework.domain.PageModel2;
import com.lenovo.m2.arch.framework.domain.PageQuery;
import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.couponV2.api.model.CouponchecksApi;

import java.text.ParseException;
import java.util.List;
import java.util.Map;

/**
 * Created by yezhenyue on 2016/2/19.
 */
public interface CouponchecksService {
    /**
     * 分页查询优惠券码审核列表
     * @param pageQuery
     * @param map
     * @return
     */
    RemoteResult<PageModel2<CouponchecksApi>> getCouponchecksInfoPage(PageQuery pageQuery, Map map);

    /**
     * 批量审核
     * @param list
     * @return
     */
    RemoteResult<Boolean> updateCouponchecksBatch(List<CouponchecksApi> list);

    /**
     * 二次优惠券批量审核
     * @param list
     * @return
     */
    RemoteResult<Boolean> updateCouponSecondchecksBatch(List<CouponchecksApi> list);

    /**
     * 二次优惠码批量审核
     * @param list
     * @return
     */
    RemoteResult<Boolean> updateCouponSecondCodechecksBatch(List<CouponchecksApi> list);

    /**
     * 根据条件审核单条
     * @param couponchecks
     * @return
     */
    RemoteResult<Boolean> checkCouponByCondition(CouponchecksApi couponchecks);



    RemoteResult<CouponchecksApi> queryCouponCheckById(long id);
}
