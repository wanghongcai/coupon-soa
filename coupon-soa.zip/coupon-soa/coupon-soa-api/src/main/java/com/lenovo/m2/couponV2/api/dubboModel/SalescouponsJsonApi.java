package com.lenovo.m2.couponV2.api.dubboModel;

import java.io.Serializable;
import java.util.List;

/**
 * Created by zhaocl1 on 2016/3/3.
 */
public class SalescouponsJsonApi implements Serializable{

    String code ;//商品code
    List<SalescouponsInfoApi> list;//适合该商品code的优惠券列表

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public List<SalescouponsInfoApi> getList() {
        return list;
    }

    public void setList(List<SalescouponsInfoApi> list) {
        this.list = list;
    }

    @Override
    public String toString() {
        return "SalescouponJsonApi{" +
                "code='" + code + '\'' +
                ", list=" + list +
                '}';
    }
}
